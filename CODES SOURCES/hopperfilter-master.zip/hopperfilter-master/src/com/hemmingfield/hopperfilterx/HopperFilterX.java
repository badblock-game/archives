// 
// Decompiled by Procyon v0.5.30
// 

package com.hemmingfield.hopperfilterx;

import java.io.File;

import org.bukkit.Bukkit;
import org.bukkit.command.CommandExecutor;
import org.bukkit.event.Listener;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

import com.hemmingfield.hopperfilterx.command.HopperFilterCommand;
import com.hemmingfield.hopperfilterx.listener.InventoryListener;
import com.hemmingfield.hopperfilterx.listener.PlayerListener;
import com.hemmingfield.hopperfilterx.listener.WorldListener;
import com.hemmingfield.hopperfilterx.manager.HopperManager;
import com.hemmingfield.hopperfilterx.panel.HopperPanel;
import com.hemmingfield.hopperfilterx.util.Properties;

public class HopperFilterX extends JavaPlugin
{
	
	public static HopperFilterX instance;
	public static File voidFilter;
	public static File amountFilter;
	
	@Override
    public void onEnable() {
		instance = this;
		
        Properties.initialize((Plugin)this);
        voidFilter = new File(getDataFolder(), "void/");
        amountFilter = new File(getDataFolder(), "amount/");
        HopperManager.getInstance().loadHoppers((Plugin)this);
        HopperPanel.initialize((Plugin)this);
        Bukkit.getPluginManager().registerEvents((Listener)new InventoryListener(), (Plugin)this);
        Bukkit.getPluginManager().registerEvents((Listener)new PlayerListener(), (Plugin)this);
        Bukkit.getPluginManager().registerEvents((Listener)new WorldListener((Plugin)this), (Plugin)this);
        this.getCommand("hopperfilter").setExecutor((CommandExecutor)new HopperFilterCommand((Plugin)this));
    }
    
    @Override
    public void onDisable()
    {
    	
    }
    
}
