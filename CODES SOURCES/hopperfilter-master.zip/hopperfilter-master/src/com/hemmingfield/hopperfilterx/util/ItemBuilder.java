// 
// Decompiled by Procyon v0.5.30
// 

package com.hemmingfield.hopperfilterx.util;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.craftbukkit.v1_12_R1.inventory.CraftItemStack;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import net.minecraft.server.v1_12_R1.NBTBase;
import net.minecraft.server.v1_12_R1.NBTTagCompound;

public class ItemBuilder
{
    public static ItemStack buildItem(final String path) {
        final String[] result = path.split(" ");
        if (result.length >= 1) {
            final String type = result[0];
            ItemStack item = new ItemStack(Material.valueOf(type.split(":")[0].toUpperCase()));
            if (type.contains(":")) {
                item.setDurability(Short.parseShort(type.split(":")[1]));
            }
            if (result.length >= 2) {
                try {
                    item.setAmount(Integer.parseInt(result[1]));
                }
                catch (Exception ex) {}
            }
            if (path.contains("name:")) {
                final String name = ChatColor.translateAlternateColorCodes('&', path.split("name:")[1].split(" ")[0]).replace("_", " ");
                final ItemMeta meta = item.getItemMeta();
                meta.setDisplayName(name);
                item.setItemMeta(meta);
            }
            if (path.contains("lore:")) {
                final String[] lore = path.split("lore:")[1].split(" ")[0].split(",");
                final ArrayList<String> formattedLore = new ArrayList<String>();
                String[] array;
                for (int length = (array = lore).length, i = 0; i < length; ++i) {
                    final String line = array[i];
                    formattedLore.add(ChatColor.translateAlternateColorCodes('&', line).replace("_", " "));
                }
                final ItemMeta meta2 = item.getItemMeta();
                meta2.setLore((List)formattedLore);
                item.setItemMeta(meta2);
            }
            Enchantment[] values;
            for (int length2 = (values = Enchantment.values()).length, j = 0; j < length2; ++j) {
                final Enchantment enchantment = values[j];
                if (path.contains(String.valueOf(enchantment.getName()) + ":")) {
                    final int level = Integer.parseInt(path.split(String.valueOf(enchantment.getName()) + ":")[1].split(" ")[0]);
                    if (level > 0 && level <= enchantment.getMaxLevel()) {
                        try {
                            item.addEnchantment(enchantment, level);
                        }
                        catch (Exception ex2) {}
                    }
                }
            }
            if (item.getType() == Material.MOB_SPAWNER) {
                item = setData(item, item.getDurability());
            }
            return item;
        }
        return null;
    }
    
    public static String toString(final ItemStack item) {
        String path = String.valueOf(item.getType().name()) + ":" + item.getDurability() + " " + item.getAmount();
        if (item.hasItemMeta()) {
            final ItemMeta meta = item.getItemMeta();
            if (meta.hasDisplayName()) {
                path = String.valueOf(path) + " name:" + meta.getDisplayName().replace(" ", "_");
            }
            if (meta.hasLore()) {
                path = String.valueOf(path) + " lore:";
                for (final String line : meta.getLore()) {
                    path = String.valueOf(path) + line.replace(" ", "_") + ",";
                }
                path = path.substring(0, path.length() - 1);
            }
            for (final Enchantment enchantment : item.getEnchantments().keySet()) {
                path = String.valueOf(path) + " " + enchantment.getName() + ":" + item.getEnchantmentLevel(enchantment);
            }
        }
        return path;
    }
    
    public static String formatName(final Material type, final int data) {
        if (type == Material.PISTON_BASE) {
            return "Piston";
        }
        String name = "";
        String[] split;
        for (int length = (split = type.name().split("_")).length, i = 0; i < length; ++i) {
            final String word = split[i];
            name = String.valueOf(name) + " " + word.substring(0, 1) + word.substring(1, word.length()).toLowerCase();
        }
        if (data != 0) {
            name = String.valueOf(name) + ":" + data;
        }
        name = name.substring(1);
        return name;
    }
    
    public static ItemStack setData(final ItemStack item, final short entityID) {
        net.minecraft.server.v1_12_R1.ItemStack itemStack = null;
        final CraftItemStack craftStack = CraftItemStack.asCraftCopy(item);
        itemStack = CraftItemStack.asNMSCopy((ItemStack)craftStack);
        NBTTagCompound tag = itemStack.getTag();
        if (tag == null) {
            tag = new NBTTagCompound();
            itemStack.setTag(tag);
        }
        if (!tag.hasKey("SilkSpawners")) {
            tag.set("SilkSpawners", (NBTBase)new NBTTagCompound());
        }
        if (!tag.hasKey("BlockEntityTag")) {
            tag.set("BlockEntityTag", (NBTBase)new NBTTagCompound());
        }
        tag = tag.getCompound("SilkSpawners");
        tag.setShort("entityID", entityID);
        return (ItemStack)CraftItemStack.asCraftMirror(itemStack);
    }
}
