// 
// Decompiled by Procyon v0.5.30
// 

package com.hemmingfield.hopperfilterx.util;

import java.io.IOException;
import org.bukkit.configuration.file.YamlConfiguration;
import java.io.File;
import org.bukkit.plugin.Plugin;
import org.bukkit.ChatColor;
import java.util.Iterator;
import org.bukkit.entity.Player;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;

public enum Properties
{

	ELEMENT_VOID_FILTER_ICON("ELEMENT_VOID_FILTER_ICON", 6, "element-void-filter-icon", "BARRIER 1 name:&eClear_All lore:&bThis_will_remove_all_items_from_this_hopper's_filter"),
	ELEMENT_VOID_ENABLED_FILTER_ICON("ELEMENT_VOID_ENABLED_FILTER_ICON", 7, "element-void-enabled-filter-icon", "BARRIER 1 name:&eClear_All lore:&bThis_will_remove_all_items_from_this_hopper's_filter"),
	ELEMENT_VOID_DISABLED_FILTER_ICON("ELEMENT_VOID_DISABLED_FILTER_ICON", 8, "element-void-disabled-filter-icon", "BARRIER 1 name:&eClear_All lore:&bThis_will_remove_all_items_from_this_hopper's_filter"),
	ELEMENT_AMOUNT_ICON("ELEMENT_AMOUNT_ICON", 9, "element-amount-icon", "BARRIER 1 name:&eClear_All lore:&bThis_will_remove_all_items_from_this_hopper's_filter"),
    ELEMENT_CLEAR_FILTER_ICON("ELEMENT_CLEAR_FILTER_ICON", 0, "element-clear-filter-icon", "BARRIER 1 name:&eClear_All lore:&bThis_will_remove_all_items_from_this_hopper's_filter"), 
    ELEMENT_FILTER_COMPLETE("ELEMENT_FILTER_COMPLETE", 1, "element-filter-complete", "&aHopper Filter X &8\u2022 &eThe filter for the hopper at &b%x%, %y%, %z% &ehas been updated."), 
    ELEMENT_PANEL_TITLE("ELEMENT_PANEL_TITLE", 2, "element-panel-title", "&aHopper Filter"), 
    ERROR_INSUFFICIENT_PERMISSION("ERROR_INSUFFICIENT_PERMISSION", 3, "error-insufficient-permission", "&aHopper Filter X &8\u2022 &cYou do not have permission to perform that command."), 
    ERROR_INVALID_COMMAND_USAGE("ERROR_INVALID_COMMAND_USAGE", 4, "error-invalid-command-usage", "&aHopper Filter X &8\u2022 &cInvalid command usage, use '&b%syntax%&c' for proper usage."), 
    MESSAGE_RELOAD_COMPLETE("MESSAGE_RELOAD_COMPLETE", 5, "message-reload-compelte", "&aHopper Filter X &8\u2022 &eThe &bproperties file &ehas been &breloaded&e.");
    
    private String section;
    private String[] messages;
    
    private Properties(final String s, final int n, final String section, final String message) {
        this.messages = new String[1];
        this.section = section;
        this.messages[0] = message;
    }
    
    private Properties(final String s, final int n, final String section, final String... messages) {
        this.messages = new String[1];
        this.section = section;
        this.messages = messages;
    }
    
    public void sendMessage(final CommandSender sender, final String... args) {
        sender.sendMessage(this.getMessage(args));
    }
    
    public void broadcastMessage(final String... args) {
        String[] message;
        for (int length = (message = this.getMessage(args)).length, i = 0; i < length; ++i) {
            final String line = message[i];
            Bukkit.broadcastMessage(line);
        }
    }
    
    public void broadcastMessageExempt(final String permission, final String... args) {
        String[] message;
        for (int length = (message = this.getMessage(args)).length, i = 0; i < length; ++i) {
            final String line = message[i];
            for (final Player player : Bukkit.getOnlinePlayers()) {
                if (!player.hasPermission(permission)) {
                    player.sendMessage(line);
                }
            }
        }
    }
    
    public void sendTitle(final Player player, final String... args) {
        final String[] messages = this.getMessage(args);
        if (messages.length == 2) {
            player.sendTitle(messages[0], messages[1]);
        }
    }
    
    public void broadcastTitle(final String... args) {
        final String[] messages = this.getMessage(args);
        if (messages.length == 2) {
            for (final Player player : Bukkit.getOnlinePlayers()) {
                player.sendTitle(messages[0], messages[1]);
            }
        }
    }
    
    public String[] getMessage(final String... args) {
        return this.replace(args);
    }
    
    String[] replace(final String... args) {
        final String[] messages = new String[this.messages.length];
        for (int i = 0; i < this.messages.length; ++i) {
            String message = this.messages[i];
            for (int i2 = 0; i2 + 1 < args.length; i2 += 2) {
                message = message.replace(args[i2], args[i2 + 1]);
            }
            messages[i] = ChatColor.translateAlternateColorCodes('&', message);
        }
        return messages;
    }
    
    public static void initialize(final Plugin plugin) {
        final File langFile = new File(plugin.getDataFolder(), "properties.yml");
        final YamlConfiguration lang = YamlConfiguration.loadConfiguration(langFile);
        if (langFile.exists()) {
            for (final String section : lang.getConfigurationSection("").getKeys(false)) {
                Properties[] values;
                for (int length = (values = values()).length, i = 0; i < length; ++i) {
                    final Properties type = values[i];
                    if (section.equalsIgnoreCase(type.section)) {
                        type.messages = lang.getStringList(section).toArray(new String[lang.getStringList(section).size()]);
                    }
                }
            }
        }
        else {
            Properties[] values2;
            for (int length2 = (values2 = values()).length, j = 0; j < length2; ++j) {
                final Properties type2 = values2[j];
                lang.set(type2.section, (Object)type2.messages);
            }
            try {
                lang.save(langFile);
            }
            catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
