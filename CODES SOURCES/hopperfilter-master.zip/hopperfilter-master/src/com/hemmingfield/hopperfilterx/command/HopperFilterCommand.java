// 
// Decompiled by Procyon v0.5.30
// 

package com.hemmingfield.hopperfilterx.command;

import com.hemmingfield.hopperfilterx.util.Properties;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.Plugin;
import org.bukkit.command.CommandExecutor;

public class HopperFilterCommand implements CommandExecutor
{
    private Plugin plugin;
    
    public HopperFilterCommand(final Plugin plugin) {
        this.plugin = plugin;
    }
    
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
            if (sender.hasPermission("hopperfilterx.reload")) {
                Properties.initialize(this.plugin);
                Properties.MESSAGE_RELOAD_COMPLETE.sendMessage(sender, new String[0]);
            }
            else {
                Properties.ERROR_INSUFFICIENT_PERMISSION.sendMessage(sender, new String[0]);
            }
            return true;
        }
        Properties.ERROR_INVALID_COMMAND_USAGE.sendMessage(sender, "%syntax%", "/hopperfilter reload");
        return true;
    }
}
