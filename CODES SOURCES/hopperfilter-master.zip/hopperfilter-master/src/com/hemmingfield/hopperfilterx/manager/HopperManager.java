// 
// Decompiled by Procyon v0.5.30
// 

package com.hemmingfield.hopperfilterx.manager;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

import com.hemmingfield.hopperfilterx.HopperFilterX;
import com.hemmingfield.hopperfilterx.util.ItemBuilder;

public class HopperManager
{
	private static HopperManager instance;

	private HashMap<Location, ArrayList<ItemStack>> hoppers;
	private List<Location>	drops = new ArrayList<>();
	//public Map<Location, Integer> blocks = new HashMap<>();

	static {
		try {
			HopperManager.instance = new HopperManager();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private HopperManager() throws FileNotFoundException, IOException {
		this.hoppers = new HashMap<Location, ArrayList<ItemStack>>();
		this.drops = new ArrayList<>();

		if (!HopperFilterX.voidFilter.exists())
		{
			HopperFilterX.voidFilter.mkdirs();
		}
		
		/*if (!HopperFilterX.amountFilter.exists())
		{
			HopperFilterX.amountFilter.mkdirs();
		}*/

		for (File f : HopperFilterX.voidFilter.listFiles())
		{
			String name = f.getName().replace(".yml", "");
			String[] splitter = name.split("_");
			String world = splitter[0];
			int x = Integer.parseInt(splitter[1]);
			int y = Integer.parseInt(splitter[2]);
			int z = Integer.parseInt(splitter[3]);
			
			drops.add(new Location(Bukkit.getWorld(world), x, y, z));
		}
		
		/*for (File f : HopperFilterX.amountFilter.listFiles())
		{
			String name = f.getName().replace(".yml", "");
			String[] splitter = name.split("_");
			String world = splitter[0];
			int x = Integer.parseInt(splitter[1]);
			int y = Integer.parseInt(splitter[2]);
			int z = Integer.parseInt(splitter[3]);
			
			try(FileInputStream inputStream = new FileInputStream(f.getAbsolutePath())) {     
			    @SuppressWarnings("deprecation")
				String everything = IOUtils.toString(inputStream);
			    
			    int rawAmount = Integer.parseInt(everything);
			    blocks.put(new Location(Bukkit.getWorld(world), x, y, z), rawAmount);
			}
		}*/
	}

	public void setDisabledItems(final Location location, final ArrayList<ItemStack> items) {
		final Iterator<Location> locations = this.hoppers.keySet().iterator();
		while (locations.hasNext()) {
			final Location location2 = locations.next();
			if (location.getWorld().equals(location2.getWorld()) && location.getX() == location2.getX() && location.getY() == location2.getY() && location.getZ() == location2.getZ()) {
				locations.remove();
			}
		}
		this.hoppers.put(location, items);
	}

	public ArrayList<ItemStack> getDisabledItems(final Location location) {
		for (final Location location2 : this.hoppers.keySet()) {
			if (location.getWorld().equals(location2.getWorld()) && location.getX() == location2.getX() && location.getY() == location2.getY() && location.getZ() == location2.getZ()) {
				return this.hoppers.get(location2);
			}
		}
		return new ArrayList<ItemStack>();
	}

	public boolean  hasDrop(Location location)
	{
		return drops.contains(location.getBlock().getLocation());
	}

	public void addDrop(Location location)
	{
		try {
			drops.add(location.getBlock().getLocation());
			new File(HopperFilterX.voidFilter, location.getWorld().getName() + "_" + location.getBlockX() + "_" + location.getBlockY() + "_" + location.getBlockZ() + ".yml").createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/*public void addAmount(Location location, int amount)
	{
		try {
			blocks.put(location.getBlock().getLocation(), amount);
			
			String name = location.getWorld().getName() + "_" + location.getBlockX() + "_" + location.getBlockY() + "_" + location.getBlockZ() + ".yml";
			File fnew = new File(HopperFilterX.amountFilter, name);
			
			if (!fnew.exists())
			{
				fnew.createNewFile();
			}
			
			try {
			    FileWriter f2 = new FileWriter(fnew, false);
			    f2.write(Integer.toString(amount));
			    f2.close();
			} catch (IOException e) {
			    e.printStackTrace();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}*/

	/*public void removeAmount(Location location)
	{
		blocks.remove(location.getBlock().getLocation());
		new File(HopperFilterX.amountFilter, location.getWorld().getName() + "_" + location.getBlockX() + "_" + location.getBlockY() + "_" + location.getBlockZ() + ".yml").delete();
	}*/
	
	public void removeDrop(Location location)
	{
		drops.remove(location.getBlock().getLocation());
		new File(HopperFilterX.voidFilter, location.getWorld().getName() + "_" + location.getBlockX() + "_" + location.getBlockY() + "_" + location.getBlockZ() + ".yml").delete();
	}

	public boolean hasFilter(final Location location) {
		for (final Location location2 : this.hoppers.keySet()) {
			if (location.getWorld().equals(location2.getWorld()) && location.getX() == location2.getX() && location.getY() == location2.getY() && location.getZ() == location2.getZ()) {
				return this.hoppers.get(location2) != null && this.hoppers.get(location2).size() > 0;
			}
		}
		return false;
	}

	public boolean isItemEnabled(final Location location, final ItemStack item) {
		for (final Location location2 : this.hoppers.keySet()) {
			if (location.getWorld().equals(location2.getWorld()) && location.getX() == location2.getX() && location.getY() == location2.getY() && location.getZ() == location2.getZ()) {
				for (final ItemStack item2 : this.hoppers.get(location2)) {
					if (item.getType() == item2.getType() && item.getDurability() == item2.getDurability() && item.getEnchantments().equals(item2.getEnchantments())) {
						return true;
					}
				}
			}
		}
		return false;
	}

	public void loadHoppers(final Plugin plugin) {
		final File dataFile = new File(plugin.getDataFolder(), "data.yml");
		final YamlConfiguration data = YamlConfiguration.loadConfiguration(dataFile);
		for (final String world : data.getConfigurationSection("").getKeys(false)) {
			for (final String x : data.getConfigurationSection(world).getKeys(false)) {
				for (final String y : data.getConfigurationSection(String.valueOf(world) + "." + x).getKeys(false)) {
					for (final String z : data.getConfigurationSection(String.valueOf(world) + "." + x + "." + y).getKeys(false)) {
						final World world2 = Bukkit.getWorld(world);
						if (world2 != null) {
							final Location location = new Location(world2, Double.parseDouble(x), Double.parseDouble(y), Double.parseDouble(z));
							final ArrayList<ItemStack> items = new ArrayList<ItemStack>();
							for (final String item : data.getStringList(String.valueOf(world) + "." + x + "." + y + "." + z)) {
								items.add(ItemBuilder.buildItem(item));
							}
							this.hoppers.put(location, items);
						}
					}
				}
			}
		}
	}

	public void saveHopper(final Plugin plugin, final Location location, final ArrayList<ItemStack> items) {
		final File dataFile = new File(plugin.getDataFolder(), "data.yml");
		final YamlConfiguration data = YamlConfiguration.loadConfiguration(dataFile);
		final ArrayList<String> sitems = new ArrayList<String>();
		for (final ItemStack item : items) {
			sitems.add(String.valueOf(item.getType().name()) + ":" + item.getDurability() + " " + item.getAmount());
		}
		data.set(String.valueOf(location.getWorld().getName()) + "." + (int)location.getX() + "." + (int)location.getY() + "." + (int)location.getZ(), (Object)sitems);
		try {
			data.save(dataFile);
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void deleteHopper(final Plugin plugin, final Location location) {
		this.removeDrop(location);
		//this.removeAmount(location);
		final File dataFile = new File(plugin.getDataFolder(), "data.yml");
		final YamlConfiguration data = YamlConfiguration.loadConfiguration(dataFile);
		data.set(String.valueOf(location.getWorld().getName()) + "." + (int)location.getX() + "." + (int)location.getY() + "." + (int)location.getZ(), (Object)null);
		try {
			data.save(dataFile);
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		this.hoppers.remove(location);
	}

	public static HopperManager getInstance() {
		return HopperManager.instance;
	}
}
