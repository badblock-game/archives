package com.hemmingfield.hopperfilterx.listener.lesslag;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import com.hemmingfield.hopperfilterx.manager.HopperManager;

public class CustomHopperEvent
extends Event implements Cancellable
{
	public ItemStack fromMove = null;
	int fromMoveSlot = -1;
	private boolean cancelled;
	public Inventory hopper;
	public Inventory dest;

	public CustomHopperEvent(Inventory hopper, Inventory dest)
	{
		this.hopper = hopper;
		this.dest = dest;

		for (ItemStack it : hopper.getContents())
		{
			this.fromMoveSlot += 1;
			if (it != null)
			{
				this.fromMove = it;
				break;
			}
		}
		if (this.fromMove == null) {
			return;
		}
	}

	public void exec()
	{
		if (isCancelled())
		{
			return;
		}
		if (hopper == null || dest == null) {
			return;
		}

		int maxAmount = 1;

		if (hopper.getLocation() != null)
		{
			Location hopperLocation = hopper.getLocation();
		/*if (HopperManager.getInstance().blocks.containsKey(hopperLocation))
			{
				maxAmount = HopperManager.getInstance().blocks.get(hopperLocation);
			}*/
		}

		// dest => full
		// TODO something better
		if (dest.firstEmpty() == -1)
		{
			return;
		}

		int amountToAdd = maxAmount;

		// Remove from the source
		if (this.fromMove.getAmount() > maxAmount)
		{
			this.fromMove.setAmount(this.fromMove.getAmount() - maxAmount);
		}
		else
		{
			amountToAdd = this.fromMove.getAmount();
			hopper.setItem(this.fromMoveSlot, new ItemStack(Material.AIR));
		}

		for (int i = 0; i < dest.getContents().length; i++)
		{
			if (amountToAdd <= 0)
			{
				continue;
			}

			ItemStack content = dest.getContents()[i];

			if (content == null)
			{
				ItemStack[] c = dest.getContents();
				ItemStack stacko = fromMove.clone();
				stacko.setAmount(amountToAdd);
				c[i] = stacko;
				amountToAdd -= stacko.getAmount();

				dest.setContents(c);

				continue;
			}

			if (!content.isSimilar(fromMove))
			{
				continue;
			}

			if (content.getAmount() >= content.getMaxStackSize())
			{
				continue;
			}

			int newSize = content.getAmount() + amountToAdd;

			if (newSize > content.getMaxStackSize())
			{
				newSize = content.getMaxStackSize();
				amountToAdd -= content.getMaxStackSize() - content.getAmount();
				
				if (amountToAdd < 0)
				{
					newSize += amountToAdd;
				}
				
			}
			else
			{
				amountToAdd = 0;
			}
			
			content.setAmount(newSize);
			ItemStack[] c= dest.getContents();
			c[i] = content;
			dest.setContents(c);
			
		}
	}

	private static final HandlerList handlers = new HandlerList();

	public HandlerList getHandlers()
	{
		return handlers;
	}

	public static HandlerList getHandlerList() {
		return handlers;
	}

	@Override
	public boolean isCancelled() {
		return cancelled;
	}

	@Override
	public void setCancelled(boolean arg0) {
		this.cancelled = arg0;
	}
}
