// 
// Decompiled by Procyon v0.5.30
// 

package com.hemmingfield.hopperfilterx.listener;

import org.bukkit.event.EventHandler;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import com.hemmingfield.hopperfilterx.panel.HopperPanel;
import org.bukkit.Material;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.Listener;

public class PlayerListener implements Listener
{
    @EventHandler
    public void onPlayerInteract(final PlayerInteractEvent event) {
        final Player player = event.getPlayer();
        final Block block = event.getClickedBlock();
        if (event.getAction() == Action.LEFT_CLICK_BLOCK && block.getType() == Material.HOPPER && player.isSneaking()) {
            event.setCancelled(true);
            HopperPanel.getInstance().display(player, block.getLocation());
        }
    }
}
