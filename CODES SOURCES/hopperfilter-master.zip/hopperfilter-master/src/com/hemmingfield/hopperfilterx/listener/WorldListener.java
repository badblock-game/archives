// 
// Decompiled by Procyon v0.5.30
// 

package com.hemmingfield.hopperfilterx.listener;

import org.bukkit.event.EventPriority;
import org.bukkit.event.EventHandler;
import java.util.Iterator;
import org.bukkit.block.Block;
import org.bukkit.inventory.ItemStack;
import com.hemmingfield.hopperfilterx.manager.HopperManager;
import com.hemmingfield.hopperfilterx.panel.HopperPanel;
import org.bukkit.Material;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.event.Listener;

public class WorldListener implements Listener
{
    private Plugin plugin;
    
    public WorldListener(final Plugin plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler(priority = EventPriority.LOWEST)
    public void onBlockBreak(final BlockBreakEvent event) {
        final Block block = event.getBlock();
        if (block.getType() == Material.HOPPER) {
            HopperPanel.getInstance().closeAll(block.getLocation());
            HopperManager.getInstance().deleteHopper(this.plugin, block.getLocation());
        }
    }
}
