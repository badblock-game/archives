// 
// Decompiled by Procyon v0.5.30
// 

package com.hemmingfield.hopperfilterx.listener;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.Hopper;
import org.bukkit.craftbukkit.v1_12_R1.inventory.CraftItemStack;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.inventory.InventoryPickupItemEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import com.hemmingfield.hopperfilterx.HopperFilterX;
import com.hemmingfield.hopperfilterx.listener.lesslag.CustomHopperEvent;
import com.hemmingfield.hopperfilterx.manager.HopperManager;
import com.hemmingfield.hopperfilterx.panel.HopperPanel;

import net.minecraft.server.v1_12_R1.NBTTagCompound;

public class InventoryListener implements Listener
{

	@EventHandler (priority = EventPriority.LOWEST)
	public void onMove(final InventoryMoveItemEvent event)
	{
	/*if (event.getSource() != null)
		{
			if (event.getDestination() == null) {
				return;
			}

			if (event.getDestination().getType() == InventoryType.PLAYER)
			{
				return;
			}
			
			CustomHopperEvent customHopperEvent = new CustomHopperEvent(event.getSource(), event.getDestination());
			Bukkit.getPluginManager().callEvent(customHopperEvent);

			event.setCancelled(true);

			if (!customHopperEvent.isCancelled())
			{
				Bukkit.getServer().getScheduler().scheduleSyncDelayedTask(HopperFilterX.instance, new Runnable()
				{
					public void run()
					{
						customHopperEvent.exec();
					}
				}, 1L);
			}
		}*/
	}

	@EventHandler (priority = EventPriority.LOWEST)
	public void onCustomHopper(InventoryMoveItemEvent event)
	{
		final Inventory destination = event.getDestination();
		if (destination == null)
		{
			return;
		}
		
		final Location destinationLocation = destination.getLocation();
		if (destinationLocation == null)
		{
			return;
		}

		final ItemStack item = event.getItem();
		Block block = destinationLocation.getBlock();
		int i = 0;
		while (block.getType() != Material.HOPPER) {
			block = destinationLocation.getBlock().getRelative(BlockFace.values()[i]);
			if (block.getType() != Material.HOPPER) {
				block = destinationLocation.getBlock().getRelative(BlockFace.DOWN).getRelative(BlockFace.values()[i]);
			}
			if (++i >= BlockFace.values().length) {
				break;
			}
		}

		if (block.getType().equals(Material.HOPPER))
		{
			if (block.getState() instanceof Hopper)
			{
				Hopper hopper = (Hopper) block.getState();
				hopper.update();
			}
		}

		if (destination.getType() != InventoryType.HOPPER || block.getType() != Material.HOPPER) {
			return;
		}

		if (HopperManager.getInstance().hasDrop(block.getLocation()))
		{
			//event.fromMove = new ItemStack(Material.AIR, 1);
			event.setItem(new ItemStack(Material.AIR, 1));
			destination.clear();
			return;
		}

		if (!HopperManager.getInstance().isItemEnabled(block.getLocation(), item) && HopperManager.getInstance().hasFilter(block.getLocation()))
		{
			event.setCancelled(true);
			return;
		}
	}

	@EventHandler(priority = EventPriority.LOWEST)
	public void onInventoryPickupItem(final InventoryPickupItemEvent event) {
		final Item item = event.getItem();
		Block block = item.getLocation().getBlock();
		int i = 0;
		while (block.getType() != Material.HOPPER) {
			block = item.getLocation().getBlock().getRelative(BlockFace.values()[i]);
			if (block.getType() != Material.HOPPER) {
				block = item.getLocation().getBlock().getRelative(BlockFace.DOWN).getRelative(BlockFace.values()[i]);
			}
			if (++i >= BlockFace.values().length) {
				break;
			}
		}

		if (event.getInventory().getType() != InventoryType.HOPPER || block.getType() != Material.HOPPER) {
			return;
		}

		if (!HopperManager.getInstance().isItemEnabled(block.getLocation(), item.getItemStack()) && HopperManager.getInstance().hasFilter(block.getLocation()))
		{
			event.setCancelled(true);
		}
	}

	public NBTTagCompound compound(ItemStack item)
	{
		net.minecraft.server.v1_12_R1.ItemStack nmsStack = CraftItemStack.asNMSCopy(item);
		NBTTagCompound compound = (nmsStack.hasTag()) ? nmsStack.getTag() : new NBTTagCompound();
		return compound;
	}

	@EventHandler
	public void onInventoryClick(final InventoryClickEvent event) {
		final Player player = (Player)event.getWhoClicked();
		if (HopperPanel.getInstance().isViewing(player)) {
			HopperPanel.getInstance().click(event);
		}
	}

	@EventHandler
	public void onInventoryClose(final InventoryCloseEvent event) {
		final Player player = (Player)event.getPlayer();
		if (HopperPanel.getInstance().isViewing(player)) {
			HopperPanel.getInstance().close(player, event.getInventory());
		}
	}
}
