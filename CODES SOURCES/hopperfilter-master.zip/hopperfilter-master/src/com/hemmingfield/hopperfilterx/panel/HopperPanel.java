// 
// Decompiled by Procyon v0.5.30
// 

package com.hemmingfield.hopperfilterx.panel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;

import com.hemmingfield.hopperfilterx.manager.HopperManager;
import com.hemmingfield.hopperfilterx.util.ItemBuilder;
import com.hemmingfield.hopperfilterx.util.Properties;

public class HopperPanel
{
	private static HopperPanel instance;
	private Plugin plugin;
	private HashMap<Player, Location> players;

	static {
		HopperPanel.instance = new HopperPanel();
	}

	private HopperPanel() {
		this.players = new HashMap<Player, Location>();
	}

	public boolean isViewing(final Player player) {
		return this.players.containsKey(player);
	}

	public void display(final Player player, final Location location) {
		if (players.values().contains(location))
		{
			player.sendMessage("�cUn joueur modifie d�j� le filtre de ce hopper.");
			return;
		}
		final Inventory panel = Bukkit.createInventory((InventoryHolder)null, 54, Properties.ELEMENT_PANEL_TITLE.getMessage(new String[0])[0]);
		for (final ItemStack item : HopperManager.getInstance().getDisabledItems(location)) {
			panel.addItem(new ItemStack[] { item });
		}
		panel.setItem(45, ItemBuilder.buildItem(Properties.ELEMENT_VOID_FILTER_ICON.getMessage(new String[0])[0]));
		if (HopperManager.getInstance().hasDrop(location))
		{
			panel.setItem(46, ItemBuilder.buildItem(Properties.ELEMENT_VOID_ENABLED_FILTER_ICON.getMessage(new String[0])[0]));
			panel.setItem(47, ItemBuilder.buildItem(Properties.ELEMENT_VOID_ENABLED_FILTER_ICON.getMessage(new String[0])[0]));
			panel.setItem(48, ItemBuilder.buildItem(Properties.ELEMENT_VOID_ENABLED_FILTER_ICON.getMessage(new String[0])[0]));
			panel.setItem(49, ItemBuilder.buildItem(Properties.ELEMENT_VOID_ENABLED_FILTER_ICON.getMessage(new String[0])[0]));
			panel.setItem(50, ItemBuilder.buildItem(Properties.ELEMENT_VOID_ENABLED_FILTER_ICON.getMessage(new String[0])[0]));
			panel.setItem(51, ItemBuilder.buildItem(Properties.ELEMENT_VOID_ENABLED_FILTER_ICON.getMessage(new String[0])[0]));
			panel.setItem(52, ItemBuilder.buildItem(Properties.ELEMENT_VOID_ENABLED_FILTER_ICON.getMessage(new String[0])[0]));
		}
		else
		{
			panel.setItem(46, ItemBuilder.buildItem(Properties.ELEMENT_VOID_DISABLED_FILTER_ICON.getMessage(new String[0])[0]));
			panel.setItem(47, ItemBuilder.buildItem(Properties.ELEMENT_VOID_DISABLED_FILTER_ICON.getMessage(new String[0])[0]));
			panel.setItem(48, ItemBuilder.buildItem(Properties.ELEMENT_VOID_DISABLED_FILTER_ICON.getMessage(new String[0])[0]));
			panel.setItem(49, ItemBuilder.buildItem(Properties.ELEMENT_VOID_DISABLED_FILTER_ICON.getMessage(new String[0])[0]));
			panel.setItem(50, ItemBuilder.buildItem(Properties.ELEMENT_VOID_DISABLED_FILTER_ICON.getMessage(new String[0])[0]));
			panel.setItem(51, ItemBuilder.buildItem(Properties.ELEMENT_VOID_DISABLED_FILTER_ICON.getMessage(new String[0])[0]));
			panel.setItem(52, ItemBuilder.buildItem(Properties.ELEMENT_VOID_DISABLED_FILTER_ICON.getMessage(new String[0])[0]));
		}

		/*int am = 1;
		if (HopperManager.getInstance().blocks.containsKey(location))
		{
			am = HopperManager.getInstance().blocks.get(location);
		}*/

		/*ItemStack stacko = ItemBuilder.buildItem(Properties.ELEMENT_AMOUNT_ICON.getMessage(new String[0])[0]);
		ItemMeta itemMeta = stacko.getItemMeta();

		itemMeta.setDisplayName(itemMeta.getDisplayName().replace("%amount%", Integer.toString(am)));
		List<String> lst = new ArrayList<>();
		for (String string : itemMeta.getLore())
		{
			lst.add(string.replace("%amount%", Integer.toString(am)));
		}
		itemMeta.setLore(lst);

		stacko.setItemMeta(itemMeta);

		panel.setItem(49, stacko);*/

		panel.setItem(53, ItemBuilder.buildItem(Properties.ELEMENT_CLEAR_FILTER_ICON.getMessage(new String[0])[0]));
		player.openInventory(panel);
		this.players.put(player, location);
	}

	public void close(final Player player, final Inventory inventory) {
		final Location location = this.players.get(player);
		final ArrayList<ItemStack> items = new ArrayList<ItemStack>();
		int slot = 0;
		ItemStack[] contents;
		for (int length = (contents = inventory.getContents()).length, i = 0; i < length; ++i) {
			final ItemStack item = contents[i];
			if (item != null && slot < 45) {
				items.add(item);
			}
			++slot;
		}
		HopperManager.getInstance().setDisabledItems(location, items);
		HopperManager.getInstance().saveHopper(this.plugin, location, items);
		this.players.remove(player);
		Properties.ELEMENT_FILTER_COMPLETE.sendMessage((CommandSender)player, "%world%", location.getWorld().getName(), "%x%", new StringBuilder(String.valueOf(location.getX())).toString(), "%y%", new StringBuilder(String.valueOf(location.getY())).toString(), "%z%", new StringBuilder(String.valueOf(location.getZ())).toString());
	}

	public void closeAll(final Location location) {
		final Iterator<Player> players = this.players.keySet().iterator();
		while (players.hasNext()) {
			final Player player = players.next();
			final Location location2 = this.players.get(player);
			if (location.getWorld().equals(location2.getWorld()) && location.getX() == location2.getX() && location.getY() == location2.getY() && location.getZ() == location2.getZ()) {
				players.remove();
				player.closeInventory();
			}
		}
	}

	public void click(final InventoryClickEvent event) {
		final Player player = (Player)event.getWhoClicked();
		final Inventory inventory = event.getClickedInventory();

		if (inventory == null)
		{
			return;
		}

		if (player.getOpenInventory() == null)
		{
			return;
		}

		if (player.getOpenInventory().getTopInventory() == null)
		{
			return;
		}

		if (!inventory.equals(player.getOpenInventory().getTopInventory())) {
			return;
		}
		/*if (event.getSlot() == 49)
		{
			event.setCancelled(true);
			int am = 1;

			if (HopperManager.getInstance().blocks.containsKey(players.get(player)))
			{
				am = HopperManager.getInstance().blocks.get(players.get(player));
			}

			if (event.getAction().equals(InventoryAction.PICKUP_ALL))
			{
				if (am >= 64)
				{
					player.sendMessage("�cLe maximum d'items � chaque d�placement est 64.");
					return;
				}
				am++;
				player.sendMessage("�7Nombre d'items � chaque d�placement : �a" + am);
			}
			else if (event.getAction().equals(InventoryAction.PICKUP_HALF))
			{
				if (am <= 1)
				{
					player.sendMessage("�cLe minimum d'items � chaque d�placement est 1.");
					return;
				}
				am--;
				player.sendMessage("�7Nombre d'items � chaque d�placement : �c" + am);
			}
			else
			{
				player.sendMessage("�7Pour augmenter le nombre d'items � chaque d�placement, faites un clic gauche. Pour baisser, faites un clic droit.");
				return;
			}

			HopperManager.getInstance().addAmount(players.get(player), am);

			Inventory panel = event.getInventory();
			if (HopperManager.getInstance().blocks.containsKey(players.get(player)))
			{
				am = HopperManager.getInstance().blocks.get(players.get(player));
			}

			ItemStack stacko = ItemBuilder.buildItem(Properties.ELEMENT_AMOUNT_ICON.getMessage(new String[0])[0]);
			ItemMeta itemMeta = stacko.getItemMeta();

			itemMeta.setDisplayName(itemMeta.getDisplayName().replace("%amount%", Integer.toString(am)));
			List<String> lst = new ArrayList<>();
			for (String string : itemMeta.getLore())
			{
				lst.add(string.replace("%amount%", Integer.toString(am)));
			}
			itemMeta.setLore(lst);

			stacko.setItemMeta(itemMeta);
			//panel.setItem(49, stacko);
			return;
		}*/
		if (event.getSlot() == 45) {
			event.setCancelled(true);
			if (!HopperManager.getInstance().hasDrop(players.get(player)))
			{
				player.sendMessage("�aVoid activ�. Les objets dans ce hopper seront consid�r�s comme inutiles et seront supprim�s.");
				HopperManager.getInstance().addDrop(players.get(player));
			}
			else
			{
				player.sendMessage("�cVoid d�sactiv�.");
				HopperManager.getInstance().removeDrop(players.get(player));
			}
			if (HopperManager.getInstance().hasDrop(players.get(player)))
			{
				Inventory panel = event.getInventory();
				panel.setItem(46, ItemBuilder.buildItem(Properties.ELEMENT_VOID_ENABLED_FILTER_ICON.getMessage(new String[0])[0]));
				panel.setItem(47, ItemBuilder.buildItem(Properties.ELEMENT_VOID_ENABLED_FILTER_ICON.getMessage(new String[0])[0]));
				panel.setItem(48, ItemBuilder.buildItem(Properties.ELEMENT_VOID_ENABLED_FILTER_ICON.getMessage(new String[0])[0]));
				panel.setItem(49, ItemBuilder.buildItem(Properties.ELEMENT_VOID_ENABLED_FILTER_ICON.getMessage(new String[0])[0]));
				panel.setItem(50, ItemBuilder.buildItem(Properties.ELEMENT_VOID_ENABLED_FILTER_ICON.getMessage(new String[0])[0]));
				panel.setItem(51, ItemBuilder.buildItem(Properties.ELEMENT_VOID_ENABLED_FILTER_ICON.getMessage(new String[0])[0]));
				panel.setItem(52, ItemBuilder.buildItem(Properties.ELEMENT_VOID_ENABLED_FILTER_ICON.getMessage(new String[0])[0]));
			}
			else
			{
				Inventory panel = event.getInventory();
				panel.setItem(46, ItemBuilder.buildItem(Properties.ELEMENT_VOID_DISABLED_FILTER_ICON.getMessage(new String[0])[0]));
				panel.setItem(47, ItemBuilder.buildItem(Properties.ELEMENT_VOID_DISABLED_FILTER_ICON.getMessage(new String[0])[0]));
				panel.setItem(48, ItemBuilder.buildItem(Properties.ELEMENT_VOID_DISABLED_FILTER_ICON.getMessage(new String[0])[0]));
				panel.setItem(49, ItemBuilder.buildItem(Properties.ELEMENT_VOID_DISABLED_FILTER_ICON.getMessage(new String[0])[0]));
				panel.setItem(50, ItemBuilder.buildItem(Properties.ELEMENT_VOID_DISABLED_FILTER_ICON.getMessage(new String[0])[0]));
				panel.setItem(51, ItemBuilder.buildItem(Properties.ELEMENT_VOID_DISABLED_FILTER_ICON.getMessage(new String[0])[0]));
				panel.setItem(52, ItemBuilder.buildItem(Properties.ELEMENT_VOID_DISABLED_FILTER_ICON.getMessage(new String[0])[0]));
			}
			return;
		}
		if (event.getSlot() >= 46 && event.getSlot() < 53)
		{
			event.setCancelled(true);
			if (HopperManager.getInstance().hasDrop(players.get(player)))
			{
				player.sendMessage("�7Le void est actuellement �aactiv�. �7Les objets dans ce hopper sont consid�r�s comme inutiles et seront supprim�s.");
			}
			else
			{
				player.sendMessage("�7Void d�sactiv�.");
			}
			if (HopperManager.getInstance().hasDrop(players.get(player)))
			{
				Inventory panel = event.getInventory();
				panel.setItem(46, ItemBuilder.buildItem(Properties.ELEMENT_VOID_ENABLED_FILTER_ICON.getMessage(new String[0])[0]));
				panel.setItem(47, ItemBuilder.buildItem(Properties.ELEMENT_VOID_ENABLED_FILTER_ICON.getMessage(new String[0])[0]));
				panel.setItem(48, ItemBuilder.buildItem(Properties.ELEMENT_VOID_ENABLED_FILTER_ICON.getMessage(new String[0])[0]));
				panel.setItem(49, ItemBuilder.buildItem(Properties.ELEMENT_VOID_ENABLED_FILTER_ICON.getMessage(new String[0])[0]));
				panel.setItem(50, ItemBuilder.buildItem(Properties.ELEMENT_VOID_ENABLED_FILTER_ICON.getMessage(new String[0])[0]));
				panel.setItem(51, ItemBuilder.buildItem(Properties.ELEMENT_VOID_ENABLED_FILTER_ICON.getMessage(new String[0])[0]));
				panel.setItem(52, ItemBuilder.buildItem(Properties.ELEMENT_VOID_ENABLED_FILTER_ICON.getMessage(new String[0])[0]));
			}
			else
			{
				Inventory panel = event.getInventory();
				panel.setItem(46, ItemBuilder.buildItem(Properties.ELEMENT_VOID_DISABLED_FILTER_ICON.getMessage(new String[0])[0]));
				panel.setItem(47, ItemBuilder.buildItem(Properties.ELEMENT_VOID_DISABLED_FILTER_ICON.getMessage(new String[0])[0]));
				panel.setItem(48, ItemBuilder.buildItem(Properties.ELEMENT_VOID_DISABLED_FILTER_ICON.getMessage(new String[0])[0]));
				panel.setItem(49, ItemBuilder.buildItem(Properties.ELEMENT_VOID_DISABLED_FILTER_ICON.getMessage(new String[0])[0]));
				panel.setItem(50, ItemBuilder.buildItem(Properties.ELEMENT_VOID_DISABLED_FILTER_ICON.getMessage(new String[0])[0]));
				panel.setItem(51, ItemBuilder.buildItem(Properties.ELEMENT_VOID_DISABLED_FILTER_ICON.getMessage(new String[0])[0]));
				panel.setItem(52, ItemBuilder.buildItem(Properties.ELEMENT_VOID_DISABLED_FILTER_ICON.getMessage(new String[0])[0]));
			}
		}
		if (event.getSlot() == 53) {
			event.setCancelled(true);
			for (int slot = 0; slot < inventory.getSize(); ++slot) {
				if (slot < 45) {
					inventory.setItem(slot, (ItemStack)null);
				}
			}
		}
	}

	public static void initialize(final Plugin plugin) {
		HopperPanel.instance.plugin = plugin;
	}

	public static HopperPanel getInstance() {
		return HopperPanel.instance;
	}
}
