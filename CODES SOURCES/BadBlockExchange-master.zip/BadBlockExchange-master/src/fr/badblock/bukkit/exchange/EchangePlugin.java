package fr.badblock.bukkit.exchange;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

import lombok.Getter;
import net.minecraft.server.v1_8_R3.ChatClickable;
import net.minecraft.server.v1_8_R3.ChatClickable.EnumClickAction;
import net.minecraft.server.v1_8_R3.ChatHoverable;
import net.minecraft.server.v1_8_R3.ChatHoverable.EnumHoverAction;
import net.minecraft.server.v1_8_R3.ChatMessage;
import net.minecraft.server.v1_8_R3.ChatModifier;
import net.minecraft.server.v1_8_R3.IChatBaseComponent;
import net.minecraft.server.v1_8_R3.MinecraftServer;
import net.minecraft.server.v1_8_R3.PlayerList;

public class EchangePlugin extends JavaPlugin {
	@Getter private static EchangePlugin instance;
	
	@Getter private Map<UUID, Echange> echanges = new HashMap<>();
	@Getter private Map<UUID, UUID> propositions = new HashMap<>();
	@Getter private Map<UUID, ItemStack> cursor = new HashMap<>();
	
	@Override
	public void onEnable(){
		instance = this;
		getServer().getPluginManager().registerEvents(new EchangeListener(), this);
	}
	
	@Override
	public void onDisable(){
		for(Echange echange : echanges.values()){
			if(!echange.isFinalized()){
				echange.close();
			}
		}
	}
	
	@Override
	public boolean onCommand(CommandSender sender, Command command, String label, String[] args){
		if(!(sender instanceof Player)) return true;
//		if(!sender.hasPermission("temp.admin")) return true;
		
		Player who = (Player) sender;
		
		if(args.length == 0){
			ChatUtils.sendMessage(sender, "&cMauvaise utilisation ... Pour plus d'informations /echange help !");
		} else if(args[0].equalsIgnoreCase("help")){
			ChatUtils.sendMessage(who, "&8&l&m-------------------------------------",
					"&b/echange &a<player> &7: propose un �change � un joueur",
					"&b/echange accept &a<player> &7: accepte l'�change propos� par un joueur",
					"&8&l&m-------------------------------------");
		} else if(args[0].equals("accept")){
			if(args.length == 1){
				ChatUtils.sendMessage(sender, "&cMerci de pr�ciser le joueur !");
			} else {
				Player p = Bukkit.getPlayer(args[1]);
				if(p == null){
					ChatUtils.sendMessage(sender, "&cLe joueur '" + args[1] + "' est introuvable !");
				} else {
					UUID with = propositions.get(p.getUniqueId());
					
					if(with == null || !with.equals(who.getUniqueId())){
						ChatUtils.sendMessage(sender, "&cCe joueur ne vous a pas propos� d'�change ...");
					} else {
						propositions.remove(p.getUniqueId());
						Echange echange = new Echange(p.getUniqueId(), who.getUniqueId());
						
						echanges.put(p.getUniqueId(), echange);
						echanges.put(who.getUniqueId(), echange);
					}
				}
			}
		} else {
			Player p = Bukkit.getPlayer(args[0]);
			if(p == null){
				ChatUtils.sendMessage(sender, "&cLe joueur '" + args[0] + "' est introuvable !");
			} else {
				UUID with = propositions.get(p.getUniqueId());
				
				if(p.getUniqueId().equals(who.getUniqueId())){
					ChatUtils.sendMessage(sender, "&cT'es un marrant toi, en fait."); return true;
				}
				
				if(with != null && with.equals(p.getUniqueId())){
					ChatUtils.sendMessage(sender, "&cVous avez d�j� propos� un �change � ce joueur !");
				} else {
					propositions.put(who.getUniqueId(), p.getUniqueId());
					ChatUtils.sendMessage(p, "&a" + who.getName() + " vous a propos� un �change.");
					IChatBaseComponent base = new ChatMessage("�a/echange accept " + who.getName() + " pour commencer.");
					ChatModifier modifier = new ChatModifier();
					modifier.setChatClickable(new ChatClickable(EnumClickAction.RUN_COMMAND, "/echange accept " + who.getName()));
					modifier.setChatHoverable(new ChatHoverable(EnumHoverAction.SHOW_TEXT, new ChatMessage("�bCliquez pour commencer l'�change avec " + who.getName())));
					base.setChatModifier(modifier);
					PlayerList list = MinecraftServer.getServer().getPlayerList();
			        list.getPlayer(p.getName()).sendMessage(base);
					ChatUtils.sendMessage(p, "&aLa demande sera annul�e dans 2 minutes.");
					ChatUtils.sendMessage(who, "&aLa proposition d'�change a �t� envoy�e ! Elle sera annul�e dans deux minutes.");

					final UUID whoUID = who.getUniqueId(),
							pUID = p.getUniqueId();
					
					new BukkitRunnable(){
						@Override
						public void run(){
							UUID with = propositions.get(whoUID);
							if(with != null && with.equals(pUID)){
								propositions.remove(whoUID);
							}
						}
					}.runTaskLater(this, 20L * 120);
				}
			}
		}
		
		return true;
	}
}
