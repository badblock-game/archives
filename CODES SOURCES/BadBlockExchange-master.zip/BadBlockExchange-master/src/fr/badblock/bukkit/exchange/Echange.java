package fr.badblock.bukkit.exchange;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import lombok.Getter;

public class Echange {
	@Getter private Inventory handler;
	@Getter private UUID firstPlayer, secondPlayer;
	
	@Getter private boolean firstAgree, secondAgree;
	
	@Getter private boolean finalized;
	
	public Echange(UUID firstPlayer, UUID secondPlayer){
		this.handler = Bukkit.createInventory(null, 9 * 5, ChatUtils.colorReplace("&4[&cBadBlock&4] &cEchange"));
		this.firstAgree = false;
		this.secondAgree = false;
		
		this.finalized = false;
		
		this.firstPlayer = firstPlayer;
		this.secondPlayer = secondPlayer;
		
		for(int i=18;i<=26;i++){
			ItemStack item = new ItemStack(Material.STAINED_GLASS_PANE, 1, (byte)3);
			ItemMeta meta = item.getItemMeta();
			meta.setDisplayName("-");
			meta.setLore(Arrays.asList("§b⬆ §7" + Bukkit.getPlayer(firstPlayer).getName(), "§b⬇ §7" + Bukkit.getPlayer(secondPlayer).getName()));
			item.setItemMeta(meta);
			
			handler.setItem(i, item);
		}
		
		Bukkit.getPlayer(firstPlayer).openInventory(handler);
		Bukkit.getPlayer(secondPlayer).openInventory(handler);
		
		setFirstAgree(false);
		setSecondAgree(false);
	}
	
	public void setFirstAgree(boolean firstAgree){
		if(firstAgree){
			handler.setItem(17, createAgreeItem());
		} else handler.setItem(17, createDisagreeItem());

		this.firstAgree = firstAgree;
		
		notifyUpdate();
	}
	
	public void setSecondAgree(boolean secondAgree){
		if(secondAgree){
			handler.setItem(44, createAgreeItem());
		} else handler.setItem(44, createDisagreeItem());

		this.secondAgree = secondAgree;
		
		notifyUpdate();
	}
	
	public void sendMessage(String message){
		Player p = Bukkit.getPlayer(firstPlayer);
		Player p2 = Bukkit.getPlayer(secondPlayer);
		
		if(p != null)
			ChatUtils.sendMessage(p, message);
		if(p2 != null)
			ChatUtils.sendMessage(p2, message);
	}
	
	public void close(){
		finalized = true;
		Player p = Bukkit.getPlayer(firstPlayer);
		Player p2 = Bukkit.getPlayer(secondPlayer);

		if(p != null) p.closeInventory();
		if(p2 != null) p2.closeInventory();
	}
	
	public void finalize() {
		if(!firstAgree || !secondAgree || finalized) return;
		Player p = Bukkit.getPlayer(firstPlayer);
		Player p2 = Bukkit.getPlayer(secondPlayer);
		
		if(p == null){
			abort(firstPlayer, true);
		} else if(p2 == null){
			abort(secondPlayer, true);
		} else {
			List<ItemStack> forFirstPlayer = new ArrayList<ItemStack>(),
					forSecondPlayer = new ArrayList<ItemStack>();
			
			for(int i=27;i<44;i++){
				ItemStack is = handler.getItem(i);
				if(is != null){
					forFirstPlayer.add(is);
				}
			}
			
			for(int i=0;i<17;i++){
				ItemStack is = handler.getItem(i);
				if(is != null){
					forSecondPlayer.add(is);
				}
			}
			
			if(!canGive(p, forFirstPlayer) || !canGive(p2, forSecondPlayer)){
				sendMessage("%red%L'un d'entre vous n'a pas assez de place dans son inventaire ! Videz-le et refaites l'échange.");
				abort(p.getUniqueId(), false);
				abort(p2.getUniqueId(), false);
			} else {
				give(p, forFirstPlayer);
				give(p2, forSecondPlayer);
				
				sendMessage("&aL'échange est bien terminé ! Bravo !");
			}
			
			finalized = true;
			EchangePlugin.getInstance().getEchanges().remove(firstPlayer);
			EchangePlugin.getInstance().getEchanges().remove(secondPlayer);

			p.closeInventory();
			p2.closeInventory();
		
			p.updateInventory();
			p2.updateInventory();
		}
	}
	
	public void abort(UUID who, boolean disconnectOrClose){
		if(finalized) return;
		Player p = null;
		
		if(who.equals(firstPlayer)){
			p = Bukkit.getPlayer(secondPlayer);
		} else if(who.equals(secondPlayer)){
			p = Bukkit.getPlayer(firstPlayer);
		}
		
		finalized = true;
		
		if(p != null && disconnectOrClose) {
			if (p.getItemOnCursor() != null) {
				p.getInventory().addItem(p.getItemOnCursor());
				p.setItemOnCursor(null);
			}
			ChatUtils.sendMessage(p, "&cVotre partenaire s'est déconnecté ou a fermé son inventaire, fin de l'échange.");
			p.updateInventory();
			p.closeInventory();
		}
		
		List<ItemStack> forFirstPlayer = new ArrayList<ItemStack>(),
				forSecondPlayer = new ArrayList<ItemStack>();
		
		for(int i=27;i<44;i++){
			ItemStack is = handler.getItem(i);
			if(is != null){
				forSecondPlayer.add(is);
			}
		}
		
		forSecondPlayer.add(p.getItemOnCursor());
	
		for(int i=0;i<17;i++){
			ItemStack is = handler.getItem(i);
			if(is != null){
				forFirstPlayer.add(is);
			}
		}

		if(Bukkit.getPlayer(who) != null && who.equals(firstPlayer)){
			give(Bukkit.getPlayer(who), forFirstPlayer);
			give(p, forSecondPlayer);
		} else if(who.equals(firstPlayer)){
			give(p, forSecondPlayer);
		} else if(Bukkit.getPlayer(who) != null && who.equals(secondPlayer)){
			give(Bukkit.getPlayer(who), forSecondPlayer);
			give(p, forFirstPlayer);
		} else if(who.equals(secondPlayer)){
			give(p, forFirstPlayer);
		}
		
		EchangePlugin.getInstance().getEchanges().remove(firstPlayer);
		EchangePlugin.getInstance().getEchanges().remove(secondPlayer);
	}
	
	public void notifyUpdate(){
		Player p = Bukkit.getPlayer(firstPlayer);
		Player p2 = Bukkit.getPlayer(secondPlayer);
		
		if(p != null)
			p.updateInventory();
		else if(p2 != null)
			p2.updateInventory();
	}
	
	public ItemStack createAgreeItem(){
		ItemStack result = new ItemStack(Material.SLIME_BALL, 1);
		ItemMeta meta = result.getItemMeta();
		
		meta.setDisplayName(ChatUtils.colorReplace("&aJe suis d'accord avec l'échange !"));
		meta.setLore(Arrays.asList(new String[]{
				ChatUtils.colorReplace(" %dgreen%➥ &aEn attente de la validation de votre partenaire ...")
		}));
		
		result.setItemMeta(meta);
		
		return result;
	}
	
	public ItemStack createDisagreeItem(){
		ItemStack result = new ItemStack(Material.FIREBALL, 1);
		ItemMeta meta = result.getItemMeta();
		
		meta.setDisplayName(ChatUtils.colorReplace("&aJe suis d'accord avec l'échange !"));
		meta.setLore(Arrays.asList(new String[]{
			ChatUtils.colorReplace(" &4➥ &cClique pour valider !")
		}));
		
		result.setItemMeta(meta);
		
		return result;
	}
	
	private boolean canGive(Player p, List<ItemStack> items){
		int dispo = 0;
		
		for(int i=0;i<p.getInventory().getSize();i++){
			if(p.getInventory().getItem(i) == null){
				dispo++;
			}
		}

		return dispo >= items.size();
	}
	
	private void give(Player p, List<ItemStack> items){
		int current = 0;
		List<ItemStack> setItems = new ArrayList<>();
		for(int i=0;i<p.getInventory().getSize();i++){
			if(current == items.size()) break;
			
			if(p.getInventory().getItem(i) == null){
				setItems.add(items.get(current));
				p.getInventory().setItem(i, items.get(current));
				current++;
			}
		}
		for (ItemStack itemStack : items) {
			if (setItems.contains(itemStack)) continue;
			p.getInventory().addItem(itemStack);
		}
	}
}