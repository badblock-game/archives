package fr.badblock.bukkit.exchange;

import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scheduler.BukkitRunnable;

public class EchangeListener implements Listener {
	@EventHandler
	public void onDisconnect(PlayerQuitEvent e){
		Player player = e.getPlayer();
		Echange echange = EchangePlugin.getInstance().getEchanges().get(player.getUniqueId());

		if(echange != null){
			echange.abort(player.getUniqueId(), true);
		}
	}

	@EventHandler
	public void onCloseInventory(InventoryCloseEvent e){
		if(e.getPlayer().getType() != EntityType.PLAYER) return;

		Player player = (Player) e.getPlayer();
		Echange echange = EchangePlugin.getInstance().getEchanges().get(player.getUniqueId());

		if(echange != null){
			if (player.getItemOnCursor() != null) {
				player.getInventory().addItem(player.getItemOnCursor());
				player.setItemOnCursor(null);
			}
			echange.abort(player.getUniqueId(), true);
		}
	}

	@EventHandler
	public void onDrag(InventoryDragEvent e) {
		if(e.getWhoClicked().getType() != EntityType.PLAYER) return;

		Player clicker = (Player) e.getWhoClicked();
		Echange echange = EchangePlugin.getInstance().getEchanges().get(clicker.getUniqueId());

		if(echange == null) return;
		e.setCancelled(true);
		ChatUtils.sendMessage(clicker, "%red%Vous devez d�placer le stack avec votre souris dans votre zone pour pouvoir faire un �change.");
	}

	@EventHandler
	public void onClick(InventoryClickEvent e){
		if(e.getWhoClicked().getType() != EntityType.PLAYER) return;

		Player clicker = (Player) e.getWhoClicked();
		Echange echange = EchangePlugin.getInstance().getEchanges().get(clicker.getUniqueId());

		if(echange == null) return;
		if (e.getClickedInventory() == null) return;
		if(e.getClickedInventory().getType() != InventoryType.PLAYER){

			if(e.getSlot() < 18 && echange.getFirstPlayer().equals(clicker.getUniqueId())){
				if(e.getSlot() == 17){
					e.setCancelled(true);
					echange.setFirstAgree(true);
					echange.finalize();
				} else {
					echange.setFirstAgree(false);
					echange.setSecondAgree(false);

					new BukkitRunnable(){
						@Override
						public void run(){
							echange.notifyUpdate();
						}
					}.runTaskLater(EchangePlugin.getInstance(), 1L);
				}
			} else if(e.getSlot() > 26 && echange.getSecondPlayer().equals(clicker.getUniqueId())){
				if(e.getSlot() == 44){
					e.setCancelled(true);
					echange.setSecondAgree(true);
					echange.finalize();
				} else {
					echange.setFirstAgree(false);
					echange.setSecondAgree(false);

					new BukkitRunnable(){
						@Override
						public void run(){
							echange.notifyUpdate();
						}
					}.runTaskLater(EchangePlugin.getInstance(), 1L);
				}
			} else {
				e.setCancelled(true);
				ChatUtils.sendMessage(clicker, "%red%Vous ne pouvez pas d�poser ou prendre d'objet dans cette zone !");
			}
		} else if(e.getAction() == InventoryAction.MOVE_TO_OTHER_INVENTORY) {
			e.setCancelled(true);
			ChatUtils.sendMessage(clicker, "%red%Vous devez d�placer le stack avec votre souris dans votre zone pour pouvoir faire un �change.");
		}
	}
}
