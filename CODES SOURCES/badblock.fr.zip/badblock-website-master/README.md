# Badblock web site project

## Setup

1. ```git clone https://lusitania.badblock.fr/Website/badblock-website.git```
2. ```php composer.phar install``` 