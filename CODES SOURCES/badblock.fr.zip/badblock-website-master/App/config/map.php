<?php
return [
	'app.php',
	'minecraft.php',
	'api.php',
	'database.php',
    'array.php',
    'paiement.php'
];