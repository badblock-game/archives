<?php
return [
	'contact' => [
		'twitter' => 'https://twitter.com/BadBlockGame',
		'facebook' => 'https://www.facebook.com/BadBlockGame',
		'youtube' => 'https://www.youtube.com/channel/UCQGBfKWLa88_pQVHdCJbuIw',
        'discord' => 'https://badblock.fr/discord',
	]
];