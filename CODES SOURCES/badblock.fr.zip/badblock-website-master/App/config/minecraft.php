<?php
return [
	'minecraft' => [
		'host' => 'play.badblock.fr',
		'port' => 25565
	]
];