<!doctype html>
<title>BadBlock</title>
<body style="background-color:#dcdde1">
<link rel="icon" type="image/png" href="https://cdn.badblock.fr/images/logo_small.png" />
<meta http-equiv="refresh" content="60">
<meta charset="UTF-8">
<style>
  body { text-align: center; padding: 150px; }
  h1 { font-size: 25px; }
  body { font: 20px Helvetica, sans-serif; color: #333; }
  article { display: block; text-align: left; width: 900px; margin: 0 auto; }
  a { color: #dc8100; text-decoration: none; }
  a:hover { color: #333; text-decoration: none; }
</style>
<style type="text/css">.cfmessage{visibility: hidden;}</style>

<article>
        <div class="cfmessage"></div>
        <center><img src="https://cdn.badblock.fr/images/logo_small.png" alt="BadBlock Logo"></center>
    <div>
                <center>
        <p>Désolé pour le désagrément mais nous effectuons une maintenance pour améliorer le service. Veuillez nous excuser pour la gêne occasionnée.</p>
        <p>L'équipe BadBlock</p>
                <br><br><a href="mailto:sysadmin@badblock.fr" target="_top">ABUS</a> | <a href="https://status.badblock.fr" target="_top">ÉTAT DE SERVICE</a>
                </center>
    </div>
</article>