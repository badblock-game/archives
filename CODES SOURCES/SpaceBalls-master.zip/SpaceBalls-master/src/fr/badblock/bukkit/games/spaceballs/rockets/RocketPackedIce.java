package fr.badblock.bukkit.games.spaceballs.rockets;

public class RocketPackedIce {

}
