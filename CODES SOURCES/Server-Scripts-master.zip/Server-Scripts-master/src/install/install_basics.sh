apt-get install nload htop speedtest-cli sudo pigz
hostname $0
rm /etc/hostname
echo "$0" >> /etc/hostname