cd /opt/
wget https://badblock.fr/sdata/vRack.tar.gz
tar xvf vRack.tar.gz
rm vRack.tar.gz
cd vRack/
sh boot.sh
screen -ls