apt-get install zabbix-agent
nano /etc/zabbix/zabbix_agentd.conf