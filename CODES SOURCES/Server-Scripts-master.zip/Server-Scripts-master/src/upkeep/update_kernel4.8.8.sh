cd /boot
wget ftp://ftp.ovh.net/made-in-ovh/bzImage/4.8.8/System.map-4.8.8-xxxx-std-ipv6-64
wget ftp://ftp.ovh.net/made-in-ovh/bzImage/4.8.8/bzImage-4.8.8-xxxx-std-ipv6-64
update-grub