package fr.devhill.socketinventory.utils;

import java.security.Key;
import java.util.Random;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class Crypter {
	public static byte[] encrypt(byte[] password, byte[] key){
		try {
			Key clef = new SecretKeySpec(key, "Blowfish");
			Cipher cipher= Cipher.getInstance("Blowfish");
			cipher.init(Cipher.ENCRYPT_MODE, clef);

			return cipher.doFinal(password);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public static byte[] decrypt(byte[] password, byte[] key){
		try {
			Key clef = new SecretKeySpec(key, "Blowfish");
			Cipher cipher = Cipher.getInstance("Blowfish");
			cipher.init(Cipher.DECRYPT_MODE, clef);

			return cipher.doFinal(password);
		} catch (Exception e) {
			return null;
		}
	}

	public static String generateKey(int length) {
		StringBuilder tmp = new StringBuilder();
	    for(char ch = 'A'; ch <= 'Z'; ++ch)
	      tmp.append(ch);
	    for(char ch = 'a'; ch <= 'z'; ++ch)
	      tmp.append(ch);
	    for(char ch = '0'; ch <= '9'; ++ch)
		      tmp.append(ch);
	    
	    char[] symbols = tmp.toString().toCharArray();
	    char[] buf = new char[length];
	    Random random = new Random();
	    
	    for(int idx = 0; idx < buf.length; ++idx)
	        buf[idx] = symbols[random.nextInt(symbols.length)];
	     
	    return new String(buf);
	}
}
