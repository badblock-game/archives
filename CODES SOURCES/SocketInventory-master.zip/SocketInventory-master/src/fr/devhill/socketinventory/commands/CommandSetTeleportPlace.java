package fr.devhill.socketinventory.commands;

import org.bukkit.Location;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

import fr.devhill.socketinventory.SocketInventoryPlugin;
import fr.devhill.socketinventory.tasks.TeleportTask;

public class CommandSetTeleportPlace extends AbstractCommand {
	public CommandSetTeleportPlace(){
		super("setteleportplac", "socketinventory.commands.setteleportplace", "%red%/%gold%si setteleportplace", "%gold%Set the place where you will be teleport when using /si server", "/si setteleportplace", null);
	}

	@Override
	public void runCommand(CommandSender sender, String[] args) {
		if(!(sender instanceof Player)){
			sendMessage(sender, "%red%This command is only for players!");
			return;
		}
		
		Location l = ((Player) sender).getLocation();	
		
		FileConfiguration c = SocketInventoryPlugin.getInstance().getConfig();
		c.set("teleport.to.world", l.getWorld().getName());
		c.set("teleport.to.x", l.getX());
		c.set("teleport.to.y", l.getY());
		c.set("teleport.to.z", l.getZ());
		c.set("teleport.to.yaw", l.getYaw());
		c.set("teleport.to.pitch", l.getPitch());
		
		SocketInventoryPlugin.getInstance().saveConfig();
		TeleportTask.setTeleportTo(l);
	}
}
