package fr.devhill.socketinventory.commands;

import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import fr.devhill.socketinventory.utils.ChatUtils;
import fr.devhill.socketinventory.utils.JRawMessage;
import fr.devhill.socketinventory.utils.JRawMessage.ClickEventType;
import fr.devhill.socketinventory.utils.JRawMessage.HoverEventType;
import lombok.Getter;

public abstract class AbstractCommand {
	public static final String NO_PERM = "%red%Vous n'avez pas la permission d'executer cette commande !",
			NO_CONSOLE = "%red%Seul les joueurs peuvent utiliser cette commande !";
	public static final String PREFIX = "%darkaqua%[%aqua%SocketInventory%darkaqua%] ";
	private JRawMessage message;
	@Getter private String messageConsole, name, permission;

	public boolean hasPermission(CommandSender sender){
		return hasPermission(sender, permission);
	}
	
	public boolean hasPermission(CommandSender sender, String permission){
		if(permission.startsWith("socketinventory.commands") && sender.hasPermission("socketinventory.commands.*")){
			return true;
		} else if(permission.startsWith("socketinventory.commands.servers.") && sender.hasPermission("socketinventory.commands.servers.*")){
			return true;
		} else
			return sender.hasPermission("socketinventory.*")
					|| sender.hasPermission("*")
					|| sender.hasPermission(permission);
	}
	
	public void sendHelp(CommandSender sender){
		if(!hasPermission(sender)) return;
		if(sender instanceof Player){
			message.send((Player) sender);
		} else ChatUtils.sendMessage(sender, messageConsole);
	}
	
	protected void sendMessage(CommandSender sender, String msg){
		ChatUtils.sendMessage(sender, PREFIX + msg);
	}
	
	protected void broadcast(String msg){
		ChatUtils.broadcast(PREFIX + msg);
	}
	
	public AbstractCommand(String name, String permission, String description, String hover, String onClickShow, String onClickRun){
		message = new JRawMessage(description);
		messageConsole = ChatUtils.colorReplace(description);
		this.permission = permission;
		this.name = name;
		
		message.addHoverEvent(HoverEventType.SHOW_TEXT, hover);
		if(onClickShow != null)
			message.addClickEvent(ClickEventType.SUGGEST_COMMAND, onClickShow, false);
		else if(onClickRun != null)
			message.addClickEvent(ClickEventType.RUN_COMMAND, onClickRun, false);
	}
	
	public abstract void runCommand(CommandSender sender, String[] args);
}
