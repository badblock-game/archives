package fr.devhill.socketinventory.commands;

import org.bukkit.command.CommandSender;

public class CommandHelp extends AbstractCommand {
	public CommandHelp(){
		super("help", "socketinventory.commands.help", "%red%/%gold%si help", "%gold%Show you all commands", "/si help", null);
	}

	@Override
	public void runCommand(CommandSender sender, String[] args) {
		sendMessage(sender, "%red%==> SocketInventory by DevHill v1.0 <==");
		CommandsManager.getInstance().get("server").sendHelp(sender);
		CommandsManager.getInstance().get("setteleportplace").sendHelp(sender);
		CommandsManager.getInstance().get("reload").sendHelp(sender);
	}
}