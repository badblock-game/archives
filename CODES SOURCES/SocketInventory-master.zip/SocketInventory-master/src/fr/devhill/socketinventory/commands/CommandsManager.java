package fr.devhill.socketinventory.commands;

import java.util.LinkedHashMap;
import java.util.Map;

import org.bukkit.command.CommandSender;

import fr.devhill.socketinventory.utils.ChatUtils;

public class CommandsManager {
	private static CommandsManager instance;
	public static CommandsManager getInstance(){
		return instance;
	}
	
	private Map<String, AbstractCommand> commands;
	
	public void addCommand(AbstractCommand command, String... aliases){
		commands.put(command.getName().toLowerCase(), command);
		for(final String aliase : aliases){
			commands.put(aliase, command);
		}
	}
	public void sendHelp(CommandSender sender){
		for(AbstractCommand command : commands.values())
			command.sendHelp(sender);
	}
	public AbstractCommand get(String name){
		return commands.get(name.toLowerCase());
	}
	public void useCommand(CommandSender sender, String[] args){
		if(args.length == 0){
			useCommand(sender, new String[]{"help"});
			return;
		}
		
		AbstractCommand command = commands.get(args[0].toLowerCase());
		if(command == null){
			ChatUtils.sendMessage(sender, AbstractCommand.PREFIX + "%red%Bad use. Use /si help !");
		} else if(!command.hasPermission(sender)){
			ChatUtils.sendMessage(sender, "%red%You don't have permission to use this command!");
		} else {
			String[] otherArgs = new String[args.length - 1];
			for(int i=1;i<args.length;i++)
				otherArgs[i-1] = args[i];
			command.runCommand(sender, otherArgs);
		}
	}
	public CommandsManager(){
		instance = this;
		commands = new LinkedHashMap<String, AbstractCommand>();
		
		addCommand(new CommandServer(), "srv", "tp", "send");
		addCommand(new CommandSetTeleportPlace(), "settp");
		addCommand(new CommandReload(), "rel");
		addCommand(new CommandHelp(), "h", "?");
	}
}
