package fr.devhill.socketinventory.commands;

import org.bukkit.command.CommandSender;

import fr.devhill.socketinventory.SocketInventoryPlugin;

public class CommandReload extends AbstractCommand {
	public CommandReload(){
		super("reload", "socketinventory.commands.reload", "%red%/%gold%si reload", "%gold%Reload the plugin configuration", "/si reload", null);
	}

	@Override
	public void runCommand(CommandSender sender, String[] args) {
		SocketInventoryPlugin.getInstance().reloadConfig();
		SocketInventoryPlugin.getInstance().loadConfiguration();
		
		sendMessage(sender, "%green%Reloaded ! Warning : this reload don't change hosts. To change that, restart the server.");
	}
}