package fr.devhill.socketinventory.commands;

import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import fr.devhill.socketinventory.SocketInventoryPlugin;
import fr.devhill.socketinventory.tasks.TeleportTask;

public class CommandServer extends AbstractCommand {
	public CommandServer(){
		super("server", "socketinventory.commands.server", "%red%/%gold%si server %red%{server} (<player>)", "%gold%Send youre inventory and teleport you to %red%{server}", "/si server {server}", null);
	}

	@Override
	public void runCommand(CommandSender sender, String[] args) {
		Player player = null;
		if(args.length == 0){
			sendHelp(sender); return;
		}
		
		if(args.length > 1 && hasPermission(sender, "socketinventory.commands.server.others")){
			player = Bukkit.getPlayer(args[1]);
		} else if(sender instanceof Player){
			player = (Player) sender;
		}
		
		if(player == null){
			sendMessage(player, "%red%Can not find the targeted player! Aborting.");
			return;
		}
		
		
		String server = args[0].toLowerCase();
		if(!hasPermission(sender, "socketinventory.commands.servers." + server)){
			sendMessage(player, "%red%You don't have permission for this server!");
		} else new TeleportTask(player, server).runTaskTimer(SocketInventoryPlugin.getInstance(), 0, 20L);
	}
}