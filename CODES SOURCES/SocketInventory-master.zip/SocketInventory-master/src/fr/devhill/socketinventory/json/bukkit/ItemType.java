package fr.devhill.socketinventory.json.bukkit;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

public class ItemType {
	private Material material;
	private int data;
	
	public ItemType(Material material, int data){
		this.material = material;
		this.data = data;
	}
	public ItemType(Material material){
		this(material, 0);
	}
	public Material getMaterial(){
		return material;
	}
	public int getData(){
		return data;
	}
	@SuppressWarnings("deprecation")
	public boolean is(ItemStack item){
		ItemStack is = item.clone();
		Material m = Material.getMaterial(is.getTypeId());
	    if(m.isBlock() || m.getMaxDurability() < 1){}
	    else if(is.getDurability() == 0){} else {
	    	 is.setDurability((short)0);
	    }
		return is.getType() == material && is.getData().getData() == data;
	}
}
