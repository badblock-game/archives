package fr.devhill.socketinventory.sockets;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Queue;

import com.google.common.collect.Queues;

public class ServerTCP extends Thread {
	private static final int BACKLOG = 50;
	
	private List<InetSocketAddress> otherServers;
	
	protected Map<InetSocketAddress, MySocket> sockets;
	
	private final ServerSocket server;
	private boolean running = false;
	
	public ServerTCP(InetAddress address, int port, List<InetSocketAddress> otherServers) throws IOException {
		super("TCP Listener");
		
		System.out.println("SERVER CREATED: " + address + ":" + port);
		
		this.otherServers = otherServers;
		this.sockets = new HashMap<>();
		
		if(address == null)
			server = new ServerSocket(port);
		else server = new ServerSocket(port, BACKLOG, address);
	}
	
	@Override
	public void run(){
		running = true;
		while(running){
			try {
				Socket socket = server.accept();
				InetSocketAddress address = new InetSocketAddress(socket.getInetAddress(), socket.getPort());
				Queue<byte[]> packets = Queues.newLinkedBlockingDeque();
				
				if(sockets.containsKey(address)){
					packets = sockets.get(address).closeSocket(); continue;
				}
				
				MySocket socketTCP = new MySocket(socket, packets);
				sockets.put(address, socketTCP);
			} catch (IOException unused){}
		}
	}
	
	private MySocket createConnexion(InetSocketAddress address) throws IOException {
		MySocket socket = sockets.get(address);
		
		if(socket != null && socket.isSocketValid()){
			return socket;
		} else {
			Socket javasocket = new Socket();
			javasocket.connect(address);
		
			MySocket socketTCP = new MySocket(javasocket, socket == null ? Queues.newLinkedBlockingDeque() : socket.closeSocket());
			sockets.put(new InetSocketAddress(javasocket.getInetAddress(), javasocket.getPort()), socketTCP);
			
			return socketTCP;
		}
	}
	
	public void broadcastPacket(byte[] bytes){
		for(final InetSocketAddress address : otherServers){
			new Thread("Packet Sender"){
				@Override
				public void run(){
					try {
						System.out.println("TRYING SENDING INVENTORY TO " + address + " -.- " + bytes);
						MySocket socket = createConnexion(address);
						socket.sendPacket(bytes);
					} catch(Exception e) {
						System.out.println("Can not send player inventory to " + address + " :");
						e.printStackTrace();
					}
				}
			}.start();
		}
	}
	
	public void end(){
		running = false;
	}
}
