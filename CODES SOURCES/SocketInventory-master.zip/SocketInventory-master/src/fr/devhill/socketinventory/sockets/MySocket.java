package fr.devhill.socketinventory.sockets;

import java.io.IOException;
import java.net.Socket;
import java.util.Iterator;
import java.util.Queue;

import fr.devhill.socketinventory.SocketInventoryPlugin;

public class MySocket {
	private Socket socket;
	private Queue<byte[]> packets;
	private boolean socketValid;
	
	public MySocket(Socket socket, Queue<byte[]> packets) throws IOException
	{
		this.socket = socket;
		this.socketValid = true;
		
		new MySocket_ReadThread().run();
		new MySocket_WriteThread().run();
		
		this.packets = packets;
	}
	
	private void receive(byte[] packet)
	{
		System.out.println("CALLING RECEIVE DATA FROM SOCKETTCP " + packet.length);
		SocketInventoryPlugin.getInstance().receiveData(packet);
	}
	
	public void sendPacket(byte[] packet)
	{
		packets.add(packet);
	}
	
	public Queue<byte[]> closeSocket()
	{
		socketValid = false;
		return packets;
	}
	
	public boolean isSocketValid()
	{
		return socketValid && socket.isConnected() && !socket.isClosed();
	}
	
	private class MySocket_ReadThread extends Thread
	{
		private ByteInputStream stream;
		
		public MySocket_ReadThread() throws IOException
		{
			super("MySocket - Read");
			this.stream = new ByteInputStream(socket.getInputStream());
		}
		
		@Override
		public void run()
		{
			try {
				while(stream.readByte() == 0 && socketValid)
				{
					try
					{
						receive( stream.readBytesArray() );
					}
					catch (Exception e)
					{
						e.printStackTrace();
					}
				}
			} catch (IOException e) {} finally {
				try {
					if(!socket.isClosed())
						socket.close();
				} catch (IOException e){}
				
				socketValid = false;
			}
		}
	}
	
	private class MySocket_WriteThread extends Thread
	{
		private ByteOutputStream stream;
		
		public MySocket_WriteThread() throws IOException
		{
			super("MySocket - Write");
			this.stream = new ByteOutputStream(socket.getOutputStream());
		}
		
		@Override
		public void run()
		{
			while(socketValid && socket.isConnected() && !socket.isClosed()){
				try {
					while (!packets.isEmpty()) {
						Iterator<byte[]> iterator = packets.iterator();
						
						while (iterator.hasNext()) {
							byte[] packet = iterator.next();
							iterator.remove();
							if(packet == null) continue;
							
							try {
								stream.writeByte((byte) 0);
								stream.writeByteArray(packet);
							} catch(Throwable e){
								e.printStackTrace();
							}
						}
					}
					
					Thread.sleep(5);
				} catch (Exception e) {}
			}
		}
	}
}
