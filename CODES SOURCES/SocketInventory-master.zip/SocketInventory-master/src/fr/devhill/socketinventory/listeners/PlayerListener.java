package fr.devhill.socketinventory.listeners;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.bukkit.Location;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import fr.devhill.socketinventory.SocketInventoryPlugin;
import fr.devhill.socketinventory.data.DataProviders;
import fr.devhill.socketinventory.json.elements.JObject;
import fr.devhill.socketinventory.tasks.SendDataTask;
import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor public class PlayerListener implements Listener {
	@Getter private static Map<UUID, Location> knowPlayers = new HashMap<>();
	private SocketInventoryPlugin plugin = SocketInventoryPlugin.getInstance();
	
	@EventHandler
	public void onJoin(PlayerJoinEvent e){
		JObject object = plugin.getReceivedData(e.getPlayer().getUniqueId());
		if(object != null){
			System.out.println("READING DATA OF " + e.getPlayer().getName() + " [ PLAYERLISTENER ] : " + object.toString());
			DataProviders.read(e.getPlayer(), object);
			System.out.println("REMOVING FILE FOR " + e.getPlayer().getName());
			plugin.removeDataFile(e.getPlayer().getUniqueId());
		}
		
		new SendDataTask(e.getPlayer()).start();;
	}
	
	@EventHandler
	public void onQuit(PlayerQuitEvent e){
		if(knowPlayers.containsKey(e.getPlayer().getUniqueId())){
			Location previousLocation = knowPlayers.get(e.getPlayer().getUniqueId());
			e.getPlayer().teleport(previousLocation);
			
			knowPlayers.remove(e.getPlayer().getUniqueId());
		} else {
			System.out.println("SENDING INVENTORY FOR PLAYER " + e.getPlayer());
			plugin.sendPlayerInventory(e.getPlayer());
		}
	}
	
	@EventHandler
	public void onUseCommand(PlayerCommandPreprocessEvent e){
		if(knowPlayers.containsKey(e.getPlayer().getUniqueId()))
			e.setCancelled(true);
	}

	@EventHandler
	public void onDamage(EntityDamageEvent e){
		if(e.getEntityType() == EntityType.PLAYER){
			if(knowPlayers.containsKey(((Player) e.getEntity()).getUniqueId()))
				e.setCancelled(true);
		}
	}

	@EventHandler
	public void onDrop(PlayerDropItemEvent e){
		if(knowPlayers.containsKey(e.getPlayer().getUniqueId()))
			e.setCancelled(true);
	}

	@EventHandler
	public void onDrop(PlayerPickupItemEvent e){
		if(knowPlayers.containsKey(e.getPlayer().getUniqueId()))
			e.setCancelled(true);
	}

	@EventHandler
	public void onClick(InventoryClickEvent e){
		if(e.getWhoClicked().getType() == EntityType.PLAYER){
			if(knowPlayers.containsKey(((Player) e.getWhoClicked()).getUniqueId()))
				e.setCancelled(true);
		}
	}
}