package fr.devhill.socketinventory.data;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

import fr.devhill.socketinventory.json.elements.JObject;

public abstract class DataProvider {
	public abstract String getDataName();
	public abstract void readConfiguration(ConfigurationSection config);

	public abstract JObject writeData(Player player);
	public abstract void readData(Player player, JObject object);

	protected boolean get(ConfigurationSection config, String key, boolean def){
		if(!config.contains(key))
			config.set(key, def);
		return config.getBoolean(key);
	}

	protected boolean get(ConfigurationSection config, String key){
		return get(config, key, true);
	}
}
