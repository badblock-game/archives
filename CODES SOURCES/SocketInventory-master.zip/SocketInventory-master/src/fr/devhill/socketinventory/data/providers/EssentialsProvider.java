package fr.devhill.socketinventory.data.providers;

import java.math.BigDecimal;

import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

import com.earth2me.essentials.Essentials;
import com.earth2me.essentials.User;

import fr.devhill.socketinventory.data.DataProvider;
import fr.devhill.socketinventory.json.bukkit.JSON;
import fr.devhill.socketinventory.json.elements.JObject;
import lombok.Getter;

public class EssentialsProvider extends DataProvider {
	@Getter private static boolean essentialsPresent;

	public Essentials essentials = null;

	private boolean money,
					nickname, 
					lastUse_Kits, 
					mute, 
					jail, 
					godmode, 
					vanish;

	public EssentialsProvider(){
		try {
			setupEssentials();
			essentialsPresent = essentials != null;
		} catch(Throwable t){
			essentialsPresent = false;
		}
	}

	private void setupEssentials() throws Throwable {
		if(Bukkit.getPluginManager().getPlugin("Essentials") != null){
			essentials = (Essentials) Bukkit.getPluginManager().getPlugin("Essentials");
		}
	}

	@Override
	public String getDataName() {
		return "essentials";
	}

	@Override
	public void readConfiguration(ConfigurationSection config) {
		money = get(config, "money");
		nickname = get(config, "nickname");
		lastUse_Kits = get(config, "lastUse_Kits");
		mute = get(config, "mute");
		jail = get(config, "jail");
		godmode = get(config, "godmode");
		vanish = get(config, "vanish");
	}

	@Override
	public JObject writeData(Player player) {
		if(!isEssentialsPresent())
			return null;
		
		System.out.println("WRITING DATA OF " + player.getName() + " [ ESSENTIALS ]");

		JObject object = JSON.loadFromString("{}");
		User user = essentials.getUser(player);
		
		if(money)
			object.set("money", user.getMoney().doubleValue());
		if(nickname)
			object.set("nickname", user.getNickname());
		if(lastUse_Kits)
			for(String kit : essentials.getSettings().getKits().getKeys(false)) {
				long time = user.getKitTimestamp(kit);
				if(time != 0)
					object.set("lastUse_Kits.kit", time);
			}
		if(mute){
			object.set("mute.muted", user.isMuted());
			object.set("mute.timeout", user.getMuteTimeout());
		}
		if(jail){
			object.set("jail.jailed", user.isJailed());
			object.set("jail.timeout", user.getJailTimeout());
			object.set("jail.name", user.getJail());
		}
		if(godmode)
			object.set("godmode", user.isGodModeEnabled());
		if(vanish)
			object.set("vanish", user.isVanished());
		
		System.out.println("DATA WROTE: " + object.toString());
		
		return object;
	}

	@Override
	public void readData(Player player, JObject object) {
		if(!isEssentialsPresent())
			return;

		System.out.println("READING DATA OF " + player.getName() + " [ ESSENTIALS ], " + object.toString());
		
		User user = essentials.getUser(player);
		if(money && object.contains("money")){
			try {
				user.setMoney(new BigDecimal(object.getDouble("money")));
			} catch (Exception e) {}
		}
		
		if(nickname && object.contains("nickname")){
			user.setNickname(object.getString("nickname"));
		}
		
		if(lastUse_Kits && object.contains("lastUse_Kits")){
			for(String kit : object.getObject("lastUse_Kits").getValues().keySet()){
				try {
					user.setKitTimestamp(kit, object.getLong("lastUse_Kits." + kit));
				} catch(Exception unknowKit){}
			}
		}
		
		if(mute && object.contains("mute")){
			user.setMuted(object.getBoolean("mute.muted"));
			user.setMuteTimeout(object.getLong("mute.timeout"));
		}
		
		if(jail && object.contains("jail")){
			user.setJailed(object.getBoolean("jail.jailed"));
			user.setJailTimeout(object.getLong("jail.timeout"));
			user.setJail(object.getString("jail.name"));
		}
		
		if(godmode && object.contains("godmode")){
			user.setGodModeEnabled(object.getBoolean("godmode"));
		}
		
		if(vanish && object.contains("vanish")){
			user.setVanished(object.getBoolean("vanish"));
		}
	}
}
