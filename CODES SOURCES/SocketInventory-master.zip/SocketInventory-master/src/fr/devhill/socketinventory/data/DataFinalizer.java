package fr.devhill.socketinventory.data;

import java.io.IOException;
import java.util.logging.Level;
import java.util.regex.Pattern;

import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;

import fr.devhill.socketinventory.json.bukkit.JSON;
import fr.devhill.socketinventory.json.elements.JObject;
import fr.devhill.socketinventory.utils.Crypter;
import fr.devhill.socketinventory.utils.ZipUtils;

public class DataFinalizer {
	private String encryptKey;
	private boolean encrypt, compress;
	
	public DataFinalizer(ConfigurationSection section){
		encrypt = get(section, "encrypt", true);
		compress = get(section, "compress", true);

		if(!section.contains("encryptKey"))
			section.set("encryptKey", Crypter.generateKey(16));
		encryptKey = section.getString("encryptKey");
		
		Pattern p = Pattern.compile("[^a-zA-Z0-9]");
		if(p.matcher(encryptKey).find() || encryptKey.length() > 16){
			Bukkit.getLogger().log(Level.SEVERE, "Invalid compression key finded! You can't add non alphanumericals caracters and the key can not be longer than 16 caracters! Reseting.");
			encryptKey = Crypter.generateKey(16);
			section.set("encryptKey", encryptKey);
		}
	}
	
	private boolean get(ConfigurationSection config, String key, boolean def){
		if(!config.contains(key))
			config.set(key, def);
		return config.getBoolean(key);
	}
	
	public byte[] finalize(JObject object) throws IOException {
		byte[] result = object.toString().getBytes();
		
		if(encrypt){
			result = Crypter.encrypt(result, encryptKey.getBytes());
		}
		
		if(compress){
			result = ZipUtils.compress(result);
		}
		
		return result;
	}
	
	public JObject getResult(byte[] base) throws IOException {
		if(compress){
			base = ZipUtils.decompress(base);
		}
		
		if(encrypt){
			base = Crypter.decrypt(base, encryptKey.getBytes());
		}
		
		return JSON.loadFromString(new String(base));
	}
}
