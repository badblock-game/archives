package fr.devhill.socketinventory.data;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;

import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

import fr.devhill.socketinventory.SocketInventoryPlugin;
import fr.devhill.socketinventory.data.providers.EssentialsProvider;
import fr.devhill.socketinventory.data.providers.FactionsProvider;
import fr.devhill.socketinventory.data.providers.GameProvider;
import fr.devhill.socketinventory.data.providers.InventoryProvider;
import fr.devhill.socketinventory.data.providers.VaultProvider;
import fr.devhill.socketinventory.json.bukkit.JSON;
import fr.devhill.socketinventory.json.elements.JObject;

public class DataProviders {
	public static final DataProvider INVENTORY_PROVIDER = new InventoryProvider();
	public static final DataProvider GAME_PROVIDER = new GameProvider();
	public static final DataProvider VAULT_PROVIDER = new VaultProvider();
	public static final DataProvider ESSENTIALS_PROVIDER = new EssentialsProvider();
	public static final DataProvider FACTIONS_PROVIDER = new FactionsProvider();
	
	public static final DataProvider[] PROVIDERS = new DataProvider[]{
			INVENTORY_PROVIDER,
			GAME_PROVIDER,
			VAULT_PROVIDER,
			ESSENTIALS_PROVIDER,
			FACTIONS_PROVIDER
	};

	private static ConfigurationSection section;
	private static Map<String, DataProvider> PLUGINS_PROVIDERS = new HashMap<>();

	public static void registerProvider(DataProvider provider){
		PLUGINS_PROVIDERS.put(provider.getDataName(), provider);
		initProvider(provider, false);
		SocketInventoryPlugin.getInstance().saveConfig();
	}

	public static void unregisterProvider(String provider){
		if(PLUGINS_PROVIDERS.containsKey(provider))
			PLUGINS_PROVIDERS.remove(provider);
	}

	public static void initProviders(ConfigurationSection section){
		DataProviders.section = section;
		for(final DataProvider provider : PROVIDERS){
			initProvider(provider, true);
		}

		for(final DataProvider provider : PLUGINS_PROVIDERS.values()){
			initProvider(provider, false);
		}
	}
	
	private static void initProvider(DataProvider provider, boolean us){
		try {
			if(!section.contains(provider.getDataName())){
				section.createSection(provider.getDataName());
			}
			provider.readConfiguration(section.getConfigurationSection(provider.getDataName()));
		} catch(Exception e){
			Bukkit.getLogger().log(Level.SEVERE, "Invalid provider " + provider.getDataName() + " (configurating)." + (!us ? " This error come NOT from SocketInventory :" : ""));
			e.printStackTrace();
		}
	}
	
	public static JObject write(Player player){
		JObject result = JSON.loadFromString("{}");

		result.set("uniqueId", player.getUniqueId().toString());
		result.set("timestamp", System.currentTimeMillis());
		result.set("valid", true);

		for(final DataProvider provider : PROVIDERS){
			try {
				result.set(provider.getDataName(), provider.writeData(player));
			} catch(Exception e){
				Bukkit.getLogger().log(Level.SEVERE, "Invalid provider " + provider.getDataName() + " (writing) :");
				e.printStackTrace();
			}
		}

		for(final DataProvider provider : PLUGINS_PROVIDERS.values()){
			try {
				if(!result.contains(provider.getDataName()))
					result.set(provider.getDataName(), provider.writeData(player));
			} catch(Exception e){
				Bukkit.getLogger().log(Level.SEVERE, "Invalid provider " + provider.getDataName() + " (writing). This error come NOT from SocketInventory :");
				e.printStackTrace();
			}
		}
		
		return result;
	}

	public static JObject write(Player player, DataProvider... providers){
		JObject result = JSON.loadFromString("{}");

		result.set("uniqueId", player.getUniqueId().toString());
		result.set("timestamp", System.currentTimeMillis());
		result.set("valid", true);

		for(final DataProvider provider : providers){
			try {
				result.set(provider.getDataName(), provider.writeData(player));
			} catch(Exception e){
				Bukkit.getLogger().log(Level.SEVERE, "Invalid provider " + provider.getDataName() + " (writing) :");
				e.printStackTrace();
			}
		}

		return result;
	}
	
	public static void read(Player player, JObject object){
		for(final DataProvider provider : PROVIDERS){
			try {
				if(object.contains(provider.getDataName())){
					provider.readData(player, object.getObject(provider.getDataName()));
				}
			} catch(Exception e){
				Bukkit.getLogger().log(Level.SEVERE, "Invalid provider " + provider.getDataName() + " (reading) :");
				e.printStackTrace();
			}
		}

		for(final DataProvider provider : PLUGINS_PROVIDERS.values()){
			try {
				if(object.contains(provider.getDataName())){
					provider.readData(player, object.getObject(provider.getDataName()));
				}
			} catch(Exception e){
				Bukkit.getLogger().log(Level.SEVERE, "Invalid provider " + provider.getDataName() + " (reading). This error come NOT from SocketInventory :");
				e.printStackTrace();
			}
		}
	}
}
