package fr.devhill.socketinventory.data.providers;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import fr.devhill.socketinventory.data.DataProvider;
import fr.devhill.socketinventory.json.bukkit.JSON;
import fr.devhill.socketinventory.json.elements.JObject;

public class InventoryProvider extends DataProvider {
	private boolean inventory,
					armor, 
					enderchest;

	public InventoryProvider(){}

	@Override
	public String getDataName() {
		return "inventories";
	}

	@Override
	public void readConfiguration(ConfigurationSection config) {
		inventory = get(config, "inventory");
		armor = get(config, "armor");
		enderchest = get(config, "enderchest");
	}

	@Override
	public JObject writeData(Player player) {
		JObject object = JSON.loadFromString("{}");
		
		System.out.println("WRITING DATA OF " + player.getName() + " [ INVENTORY ]");
		
		if(inventory)
			object.set("inventory", (ItemStack[]) player.getInventory().getContents(), ItemStack.class);
		if(armor)
			object.set("armor", (ItemStack[]) player.getInventory().getArmorContents(), ItemStack.class);
		if(enderchest)
			object.set("enderchest", (ItemStack[]) player.getEnderChest().getContents(), ItemStack.class);
		
		return object;
	}

	@Override
	public void readData(Player player, JObject object) {
		
		System.out.println("READING DATA OF " + player.getName() + " [ INVENTORY ] , " + object.toString());
		
		if(inventory && object.contains("inventory")){
			ItemStack[] is = object.getArray("inventory").getList(ItemStack.class).toArray(new ItemStack[0]);;
			
			if(is != null && is.length == player.getInventory().getSize())
				player.getInventory().setContents(is);
		}
		
		if(armor && object.contains("armor")){
			ItemStack[] is = object.getArray("armor").getList(ItemStack.class).toArray(new ItemStack[0]);;
			
			if(is != null && is.length == player.getInventory().getArmorContents().length)
				player.getInventory().setArmorContents(is);
		}
		
		if(enderchest && object.contains("enderchest")){
			ItemStack[] is = object.getArray("enderchest").getList(ItemStack.class).toArray(new ItemStack[0]);;
			
			if(is != null && is.length == player.getEnderChest().getSize())
				player.getEnderChest().setContents(is);
		}
		
		player.updateInventory();
	}
}
