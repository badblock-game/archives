package fr.devhill.socketinventory.data.providers;

import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;

import fr.devhill.socketinventory.data.DataProvider;
import fr.devhill.socketinventory.json.bukkit.JSON;
import fr.devhill.socketinventory.json.elements.JObject;
import lombok.Getter;
import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;

public class VaultProvider extends DataProvider {
	@Getter private static boolean vaultPresent;
	
	public Economy economy = null;
	
	private boolean money,
					bank;
	
	public VaultProvider(){
		try {
			setupEconomy();
			vaultPresent = economy != null;
		} catch(Throwable t){
			vaultPresent = false;
		}
	}
	
	private void setupEconomy() throws Throwable {
        RegisteredServiceProvider<Economy> economyProvider = Bukkit.getServer().getServicesManager().getRegistration(net.milkbowl.vault.economy.Economy.class);
        if(economyProvider != null) {
            economy = economyProvider.getProvider();
        }
    }

	@Override
	public String getDataName() {
		return "vault";
	}

	@Override
	public void readConfiguration(ConfigurationSection config) {
		money = get(config, "money");
		bank = get(config, "bank");
	}

	@Override
	public JObject writeData(Player player) {
		if(!isVaultPresent())
			return null;
		
		JObject object = JSON.loadFromString("{}");
		if(money)
			object.set("money", economy.getBalance(player));
		if(bank && economy.hasBankSupport()){
			EconomyResponse rep = economy.bankBalance(player.getName());
			if(rep.transactionSuccess())
				object.set("bank", rep.balance);
		}
		
		return object;
	}

	@Override
	public void readData(Player player, JObject object) {
		if(!isVaultPresent())
			return;
		
		if(money && object.contains("money")){
			economy.withdrawPlayer(player, object.getDouble("money"));
		}
		
		if(bank && object.contains("bank") && economy.hasBankSupport()){
			economy.bankWithdraw(player.getName(), object.getDouble("bank"));
		}
	}
}
