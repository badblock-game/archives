package fr.devhill.socketinventory.data.providers;

import org.bukkit.GameMode;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Damageable;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import fr.devhill.socketinventory.data.DataProvider;
import fr.devhill.socketinventory.json.bukkit.JSON;
import fr.devhill.socketinventory.json.elements.JObject;

public class GameProvider extends DataProvider {
	
	private boolean exp,
					health,
					foodLevel,
					potionEffects,
					customNames, /* TODO Tab list and display names */
					speed,
					gamemode;


	public GameProvider(){}

	@Override
	public String getDataName() {
		return "game";
	}

	@Override
	public void readConfiguration(ConfigurationSection config) {
		exp = get(config, "exp");
		health = get(config, "health");
		foodLevel = get(config, "foodLevel");
		potionEffects = get(config, "potionEffects");
		speed = get(config, "speed");
		gamemode = get(config, "gamemode");
		customNames = get(config, "customNames");
	}

	@Override
	public JObject writeData(Player player) {
		JObject object = JSON.loadFromString("{}");

		System.out.println("WRITING DATA OF " + player.getName() + " [ GAME ]");
		
		if(exp){
			object.set("exp.level", player.getLevel());
			object.set("exp.inLvl", player.getExp());
		}
		
		if(health){
			object.set("health.current", ((Damageable) player).getHealth());
			object.set("health.max", ((Damageable) player).getMaxHealth());
			object.set("health.scale", player.getHealthScale());
		}
		if(foodLevel){
			object.set("food.foodLevel", player.getFoodLevel());
			object.set("food.saturation", player.getSaturation());
		}
		if(potionEffects){
			int i = 0;
			for(PotionEffect effect : player.getActivePotionEffects()) {
				object.set("potions." + i + ".effect", effect.getType().getName());
				object.set("potions." + i + ".duration", effect.getDuration());
				object.set("potions." + i + ".amplifier", effect.getAmplifier());
				object.set("potions." + i + ".isAmbient", effect.isAmbient());
				i++;
			}
		}
		if(speed){
			object.set("speed.walk", player.getWalkSpeed());
			object.set("speed.fly", player.getFlySpeed());
		}
		if(gamemode){
			object.set("gamemode", player.getGameMode().name());
		}
		if(customNames){
			object.set("names.displayname", player.getDisplayName());
			object.set("names.listname", player.getPlayerListName());
		}
		
		return object;
	}

	@Override
	public void readData(Player player, JObject object) {
		
		System.out.println("READING DATA OF " + player.getName() + " [ GAME ] , " + object.toString());
		
		if(health && object.contains("health")){
			((Damageable) player).setMaxHealth(object.getDouble("health.max"));
			((Damageable) player).setHealth(object.getDouble("health.current"));
			player.setHealthScale(object.getDouble("health.scale"));
		}
		
		if(foodLevel && object.contains("food")){
			player.setFoodLevel(object.getInt("food.foodLevel"));
			player.setSaturation(object.getInt("food.saturation"));
		}
		
		if(exp && object.contains("exp")){
			player.setLevel(object.getInt("exp.level"));
			player.setExp(object.getFloat("exp.inLvl"));
		}
		
		if(potionEffects && object.contains("potions")){
			for(String key : object.getObject("potions").getValues().keySet()){
				PotionEffect effect = new PotionEffect(
						PotionEffectType.getByName(object.getString("potions." + key + ".effect")), 
						object.getInt("potions." + key + ".duration"), 
						object.getInt("potions." + key + ".amplifier"),
						object.getBoolean("potions." + key + ".isAmbient"));
				
				player.addPotionEffect(effect);
			}
		}
		
		if(speed && object.contains("speed")){
			player.setWalkSpeed(object.getFloat("speed.walk"));
			player.setFlySpeed(object.getFloat("speed.fly"));
		}
		
		if(gamemode && object.contains("gamemode")){
			try {
				player.setGameMode(GameMode.valueOf(object.getString("gamemode")));
			} catch(Exception unknowGamemode){}
		}
		
		if(customNames && object.contains("name")){
			try {
				player.setDisplayName(object.getString("names.displayname"));
				player.setPlayerListName(object.getString("names.listname"));
			} catch(NullPointerException noName){}
		}
	}
}
