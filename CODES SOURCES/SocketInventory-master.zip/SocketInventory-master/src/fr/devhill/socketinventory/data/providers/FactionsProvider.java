package fr.devhill.socketinventory.data.providers;

import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

import com.massivecraft.factions.Factions;
import com.massivecraft.factions.entity.Faction;
import com.massivecraft.factions.entity.FactionColl;
import com.massivecraft.factions.entity.MPlayer;

import fr.devhill.socketinventory.data.DataProvider;
import fr.devhill.socketinventory.json.bukkit.JSON;
import fr.devhill.socketinventory.json.elements.JObject;
import lombok.Getter;

public class FactionsProvider extends DataProvider {
	@Getter private static boolean factionsPresent;

	private Factions factions;
	
	private boolean faction;

	public FactionsProvider(){
		try {
			setupFactions();
			factionsPresent = factions != null;
		} catch(Throwable t){
			factionsPresent = false;
		}
	}

	private void setupFactions() throws Throwable {
		if(Bukkit.getPluginManager().getPlugin("Factions") != null){
			factions = (Factions) Bukkit.getPluginManager().getPlugin("Factions");
		}
	}

	@Override
	public String getDataName() {
		return "factions";
	}

	@Override
	public void readConfiguration(ConfigurationSection config) {
		faction = get(config, "faction");
	}

	@Override
	public JObject writeData(Player player) {
		if(!isFactionsPresent() || !faction)
			return null;

		System.out.println("WRITE DATA OF " + player.getName() + " [ FACTIONS ]");
		
		JObject object = JSON.loadFromString("{}");
		MPlayer mPlayer = MPlayer.get(player);
		
		if(mPlayer == null) return object;
		object.set("player", JSON.loadFromObject(mPlayer));
		
		Faction faction = mPlayer.getFaction();
		if(!faction.isDefault()){
			object.set("faction", JSON.loadFromObject(faction));
		}
		
		return object;
	}

	@Override
	public void readData(Player player, JObject object) {
		if(!isFactionsPresent() || !faction)
			return;

		System.out.println("READING DATA OF " + player.getName() + " [ FACTIONS ] , " + object.toString());
		
		if(object.contains("faction")){
			String id = object.getObject("player").getString("factionId");
			System.out.println(id);
			JObject fac = object.getObject("faction");
			
			if(!FactionColl.get().containsId(id)){
				FactionColl.get().create(id);
			}
			
			Faction know = FactionColl.get().get(id);
			know.load(JSON.saveAsObject(fac, Faction.class));
		}
		
		MPlayer mPlayer = MPlayer.get(player);
		
		if(mPlayer == null) return;
		if(object.contains("player")){
			mPlayer.load(JSON.saveAsObject(object.getObject("player"), MPlayer.class));
		}
	}
}
