package fr.devhill.socketinventory;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import com.google.common.io.ByteArrayDataOutput;
import com.google.common.io.ByteStreams;

import fr.devhill.socketinventory.commands.CommandsManager;
import fr.devhill.socketinventory.data.DataFinalizer;
import fr.devhill.socketinventory.data.DataProviders;
import fr.devhill.socketinventory.json.bukkit.Loaders;
import fr.devhill.socketinventory.json.elements.JObject;
import fr.devhill.socketinventory.listeners.PlayerListener;
import fr.devhill.socketinventory.sockets.ServerTCP;
import fr.devhill.socketinventory.tasks.SaveFileTask;
import fr.devhill.socketinventory.tasks.SendDataTask;
import fr.devhill.socketinventory.tasks.SynchronizedTask;
import fr.devhill.socketinventory.tasks.TeleportTask;
import lombok.Getter;

public class SocketInventoryPlugin extends JavaPlugin {
	@Getter private static SocketInventoryPlugin instance;
	@Getter private File playersFolder;
	private DataFinalizer finalizer;
	private ServerTCP server;
	
	private Map<UUID, JObject> cache = new HashMap<>();
	
	@Override
	public void onEnable(){
		instance = this; new Loaders();
		
		loadConfiguration();
	
		playersFolder = new File(getDataFolder(), "receivedPlayers");
		
		if(!playersFolder.exists())
			playersFolder.mkdirs();
		
		File hostYML = new File(getDataFolder(), "hosts.yml");
		FileConfiguration config = YamlConfiguration.loadConfiguration(hostYML);
		
		String ip; int port;
		if(!config.contains("host")){
			config.set("host.ip", "127.0.0.1");
			config.set("host.port", 25564);
		}
		if(!config.contains("otherHosts")){
			config.set("otherHosts", Arrays.asList("127.0.0.1:25563", "127.0.0.1:25562"));
		}
		
		ip = config.getString("host.ip");
		port = config.getInt("host.port");
		
		List<InetSocketAddress> otherHosts = new ArrayList<>();
		for(final String full : config.getStringList("otherHosts")){
			try {
				String[] split = full.split(":");
				String theIp = split[0];
				int thePort = Integer.parseInt(split[1]);
				
				otherHosts.add(new InetSocketAddress(theIp, thePort));
			} catch(Exception e){
				getLogger().log(Level.SEVERE, "Invalid host : " + full);
			}
		}
		
		try {
			config.save(hostYML);

			if(ip != null && ip.isEmpty()) ip = null;
			server = new ServerTCP(ip == null ? null : InetAddress.getByName(ip), port, otherHosts);
			server.start();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		new CommandsManager();
		new SynchronizedTask().start();
		new SaveFileTask().start();
		
		getServer().getPluginManager().registerEvents(new PlayerListener(), this);
		getServer().getMessenger().registerOutgoingPluginChannel(this, "BungeeCord");
	}

	public void loadConfiguration(){
		if(!getConfig().contains("sendParameters")){
			getConfig().createSection("sendParameters");
		}
		finalizer = new DataFinalizer(getConfig().getConfigurationSection("sendParameters"));

		TeleportTask.configure(getConfig());
		SendDataTask.configure(getConfig());
		
		if(!getConfig().contains("datasToSend")){
			getConfig().createSection("datasToSend");
		}

		DataProviders.initProviders(getConfig().getConfigurationSection("datasToSend"));
		
		saveConfig();
	}

	@Override
	public void onDisable(){
		
	}

	public void sendPlayerInventory(final Player player){
		try {
			byte[] toSend = finalizer.finalize(DataProviders.write(player));
			System.out.println("SENDING " + toSend + " [ " + player.getName() + " ]");
			server.broadcastPacket(toSend);
		} catch (IOException e) {
			System.out.println("ERROR SENDING INVENTORY FOR PLAYER " + player.getName() + " !");
			e.printStackTrace();
		}
	}
	
	public void receiveData(byte[] received){
		try {
			JObject object = finalizer.getResult(received);
			System.out.println("RECEIVE DATA: " + object.toString());
			if(object.isEmpty()) return;
			
			UUID uniqueId = UUID.fromString(object.getString("uniqueId"));
			Player player = getServer().getPlayer(uniqueId);
			
			JObject actual = cache.get(uniqueId);
			
			if(actual != null && actual.getLong("timestamp") >= object.getLong("timestamp"))
			{
				return; // on ne met pas à jour, on a d'jà mieux :D
			}
			
			if(player != null)
			{
				SynchronizedTask.addToQueue(object);
			}
			else
			{				
				cache.put(uniqueId, object);
				
				File playerFile = new File(playersFolder, uniqueId.toString() + ".dat");
				SaveFileTask.save(playerFile, received);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public JObject getReceivedData(UUID uniqueId){
		try {
			JObject value = cache.get(uniqueId);
			
			if(value != null)
			{
				if(!value.getBoolean("valid"))
					return null;
				
				value.set("valid", false);
				return value;
			}
			else
			{
				File playerFile = new File(playersFolder, uniqueId.toString() + ".dat");
				if(!playerFile.exists()) return null;
				
				byte[] r = Files.readAllBytes(playerFile.toPath());
				return finalizer.getResult(r);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	public void removeDataFile(UUID uniqueId){
		System.out.println("REMOVING DATA FOR " + uniqueId);
		
		File playerFile = new File(playersFolder, uniqueId.toString() + ".dat");
		
		if(playerFile.exists())
		{
			System.out.println("REMOVED: " + playerFile.delete());
		}
	}
	
	public void send(Player player, String server){
		ByteArrayDataOutput out = ByteStreams.newDataOutput();
		out.writeUTF("ConnectOther");
		out.writeUTF(player.getName());
		out.writeUTF(server);
		
		player.sendPluginMessage(this, "BungeeCord", out.toByteArray());
	}
	
	@Override
	public boolean onCommand(CommandSender sender, Command command, String label, String[] args){
		CommandsManager.getInstance().useCommand(sender, args);
		return true;
	}
}
