package fr.devhill.socketinventory.tasks;

import java.util.Random;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import fr.devhill.socketinventory.SocketInventoryPlugin;
import lombok.Setter;

public class SendDataTask extends BukkitRunnable {
	private static Random random = new Random();
	
	@Setter private static int 		sendTime;
	

	public static void configure(ConfigurationSection c){
		if(!c.contains("send")){
			c.set("send.time", 600);
		}
		
		sendTime = c.getInt("send.time");
	}
	
	private final UUID 		uniqueId;
	private int				time;
	
	public SendDataTask(Player player){
		this.uniqueId = player.getUniqueId();
		time = sendTime;
	}
	
	@Override
	public void run(){
		final Player player = Bukkit.getPlayer(uniqueId);
		if(player == null){
			cancel(); return;
		}
		
		if(time == 0){
			time = sendTime;
			System.out.println("SENDING INV VIA SENDDATATASK FOR PLAYER " + player.getName());
			SocketInventoryPlugin.getInstance().sendPlayerInventory(player);
		}
	
		time--;
	}
	
	public void start(){
		runTaskTimer(SocketInventoryPlugin.getInstance(), random.nextInt(sendTime) + sendTime / 2, 20L);
	}
}
