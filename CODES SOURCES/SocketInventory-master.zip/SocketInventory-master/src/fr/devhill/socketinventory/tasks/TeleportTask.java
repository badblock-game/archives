package fr.devhill.socketinventory.tasks;

import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.bukkit.scheduler.BukkitRunnable;

import fr.devhill.socketinventory.SocketInventoryPlugin;
import fr.devhill.socketinventory.listeners.PlayerListener;
import fr.devhill.socketinventory.utils.ChatUtils;
import lombok.Setter;

public class TeleportTask extends BukkitRunnable implements Listener {
	@Setter private static Location teleportTo;
	@Setter private static int 		waitTime;
	@Setter private static String   waitMessage;
	

	public static void configure(ConfigurationSection c){
		if(!c.contains("teleport")){
			c.set("teleport.waitTime", 5);
			c.set("teleport.waitMessage", "&cYou will be teleported in %time% seconds!");
			
			c.set("teleport.to.world", Bukkit.getWorlds().get(0).getName());
			c.set("teleport.to.x", 0d);
			c.set("teleport.to.y", 0d);
			c.set("teleport.to.z", 0d);
			c.set("teleport.to.yaw", 0d);
			c.set("teleport.to.pitch", 0d);
		}
		
		teleportTo = new Location(Bukkit.getWorld(c.getString("teleport.to.world")),
				c.getDouble("teleport.to.x"),
				c.getDouble("teleport.to.y"),
				c.getDouble("teleport.to.z"),
				(float) c.getDouble("teleport.to.yaw"),
				(float) c.getDouble("teleport.to.pitch"));
		
		waitTime = c.getInt("teleport.waitTime");
		waitMessage = c.getString("teleport.waitMessage");
	}
	
	private int 			time;
	private final UUID 		uniqueId;
	private final String 	server;
	private final Location	previousLocation;
	
	public TeleportTask(Player player, String server){
		this.uniqueId = player.getUniqueId();
		this.server = server;
		this.time = waitTime;
		this.previousLocation = player.getLocation();
	
		player.teleport(teleportTo);
		
		PlayerListener.getKnowPlayers().put(uniqueId, previousLocation);
		System.out.println("SENDING INV TELEPORTTASK FOR " + player.getName());
		SocketInventoryPlugin.getInstance().sendPlayerInventory(player);
	}
	
	@Override
	public void run(){
		final Player player = Bukkit.getPlayer(uniqueId);
		if(player == null){
			cancel(); return;
		}
		
		if(time > 0) {
			ChatUtils.sendMessage(player, waitMessage.replace("%time%", Integer.toString(time)));
		} else if(time == 0){
			System.out.println("SEND PLAYER");
			SocketInventoryPlugin.getInstance().send(player, server);
		} else if(time == -3){
			player.teleport(previousLocation);
			PlayerListener.getKnowPlayers().remove(uniqueId);
			cancel();
		}
		
		time--;
	}
}