package fr.devhill.socketinventory.tasks;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Queue;

import com.google.common.collect.Queues;

import fr.devhill.socketinventory.SocketInventoryPlugin;
import net.minecraft.server.v1_8_R3.Tuple;

public class SaveFileTask extends Thread {
	private static SaveFileTask task;
	private Queue<Tuple<File, byte[]>> toSave = Queues.newLinkedBlockingDeque();
	
	public static void save(File file, byte[] toSave)
	{
		task.toSave.add(new Tuple<>(file, toSave));
	}
	
	public SaveFileTask() {
		task = this;
	}
	
	@Override
	public void run()
	{
		
		while(SocketInventoryPlugin.getInstance().isEnabled())
		{
			while(!toSave.isEmpty())
			{
				try
				{
					Tuple<File, byte[]> values = toSave.peek();
					
					FileOutputStream fos = new FileOutputStream( values.a() );
					fos.write(values.b()); fos.close();
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
				
				try {
					Thread.sleep(5L);
				} catch (InterruptedException e) { }
			}
		}
		
	}
}
