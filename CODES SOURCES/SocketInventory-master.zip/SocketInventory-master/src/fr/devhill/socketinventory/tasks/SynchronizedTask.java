package fr.devhill.socketinventory.tasks;

import java.util.LinkedList;
import java.util.Queue;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import fr.devhill.socketinventory.SocketInventoryPlugin;
import fr.devhill.socketinventory.data.DataProviders;
import fr.devhill.socketinventory.json.elements.JObject;

public class SynchronizedTask extends BukkitRunnable {
	private static Queue<JObject> toRead = new LinkedList<>();

	public static void addToQueue(JObject object){
		toRead.add(object);
	}
	
	@Override
	public void run(){
		JObject object = toRead.poll();
		
		if(object == null) return;
		
		UUID uniqueId = UUID.fromString(object.getString("uniqueId"));
		Player player = Bukkit.getPlayer(uniqueId);
		
		if(player != null){
			System.out.println("READING DATA OF " + player.getName() + " [ SYNCHROTASK ] : " + object.toString());
			DataProviders.read(player, object);
		}
	}
	
	public void start(){
		runTaskTimer(SocketInventoryPlugin.getInstance(), 0, 1L);
	}
}
