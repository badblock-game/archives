package fr.badblock.badkeys;

public class ProbaItem {

	public String	itemName;
	public int		probability;
	public String	command;
	
	public ProbaItem(String itemName, int probability, String command)
	{
		this.itemName = itemName;
		this.probability = probability;
		this.command = command;
	}
	
}
