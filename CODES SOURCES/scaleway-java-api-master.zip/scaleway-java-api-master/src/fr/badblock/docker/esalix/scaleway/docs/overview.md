
# Overview

This is a Java implementation of the Scaleway API which allows you to build and
deploy servers on the Scaleway cloud provider.

a simple example is below: