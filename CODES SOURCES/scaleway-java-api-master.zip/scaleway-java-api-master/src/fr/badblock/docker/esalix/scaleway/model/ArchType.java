package fr.badblock.docker.esalix.scaleway.model;

public enum ArchType {

	ARM,
	ARM64,
	X86;
	
}
