package fr.badblock.docker.esalix.scaleway.model;

/*
 * Copyright (c) 2016-2017 synapticloop.
 * 
 * All rights reserved.
 * 
 * This code may contain contributions from other parties which, where 
 * applicable, will be listed in the default build file for the project 
 * ~and/or~ in a file named CONTRIBUTORS.txt in the root of the project.
 * 
 * This source code and any derived binaries are covered by the terms and 
 * conditions of the Licence agreement ("the Licence").  You may not use this 
 * source code or any derived binaries except in compliance with the Licence.  
 * A copy of the Licence is available in the file named LICENSE.txt shipped with 
 * this source code or binaries.
 */

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;

@Getter
public enum ServerType {
	
	@JsonProperty("VC1S")  			VC1S		(ArchType.X86),
	@JsonProperty("VC1M")  			VC1M		(ArchType.X86),
	@JsonProperty("VC1L")  			VC1L		(ArchType.X86),
	@JsonProperty("C2S")   			C2S			(ArchType.X86),
	@JsonProperty("C2M")   			C2M			(ArchType.X86),
	@JsonProperty("C2L")   			C2L			(ArchType.X86),
	@JsonProperty("C1")    			C1			(ArchType.X86),
	@JsonProperty("ARM64-16GB")		ARM64_16GB	(ArchType.ARM64),
	@JsonProperty("ARM64-8GB")		ARM64_8GB	(ArchType.ARM64),
	@JsonProperty("X64-15GB")		X64_15GB	(ArchType.X86);

	private ArchType archType;
	
	ServerType (ArchType archType)
	{
		setArchType(archType);
	}
	
	private void setArchType(ArchType archType)
	{
		this.archType = archType;
	}
	
	public static ServerType get(String serverType)
	{
		for (ServerType fetchedServerType : values())
		{
			if (fetchedServerType.name().equalsIgnoreCase(serverType))
			{
				return fetchedServerType;
			}
		}
		return null;

	}
}
