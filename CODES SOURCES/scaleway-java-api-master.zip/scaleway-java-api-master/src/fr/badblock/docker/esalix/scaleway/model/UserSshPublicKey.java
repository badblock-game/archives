package fr.badblock.docker.esalix.scaleway.model;

public class UserSshPublicKey extends SshPublicKey {

	private String fingerprint;

	public String getFingerprint() { return fingerprint; }

	public void setFingerprint(String fingerprint) {
		this.fingerprint = fingerprint;
	}
}
