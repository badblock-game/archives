/**
 * 
 */
package fr.badblock.docker.esalix.scaleway.exception;