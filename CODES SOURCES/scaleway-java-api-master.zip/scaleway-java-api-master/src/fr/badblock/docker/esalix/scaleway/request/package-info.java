/**
 * 
 */
package fr.badblock.docker.esalix.scaleway.request;