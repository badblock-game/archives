package fr.badblock.docker.bungee;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.lang.reflect.Type;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import javax.xml.bind.DatatypeConverter;

import com.cloudflare.api.CloudflareAccess;
import com.cloudflare.api.requests.dns.DNSDeleteRecord;
import com.cloudflare.api.results.CloudflareError;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import fr.badblock.docker.bungee.configuration.Bungee;
import fr.badblock.docker.bungee.configuration.DockerConfiguration;
import fr.badblock.docker.bungee.db.BadblockDatabase;
import fr.badblock.docker.bungee.db.Request;
import fr.badblock.docker.bungee.db.Request.RequestType;
import fr.badblock.docker.bungee.logs.Log;
import fr.badblock.docker.bungee.logs.Log.LogType;
import net.sf.json.JSONObject;

public class BungeeDocker {

	public static final Type bungeeDataType 	= new TypeToken<HashMap<String, Bungee>>() {}.getType();

	private DockerConfiguration dockerConfiguration;
	private Gson				gson;
	private Map<String, Integer> times = new HashMap<>();			

	public BungeeDocker() {
		this.gson = new GsonBuilder().setPrettyPrinting().create();
		Log.log("Loading configuration...", LogType.INFO);
		setupConfiguration();
		CloudflareAccess access = new CloudflareAccess("badblock.staff@gmail.com", "1e366d56c42dce17fcdf5ffc2f021b7bb629b");
		BadblockDatabase.getInstance().connect(this.dockerConfiguration.getMysqlHostname(), this.dockerConfiguration.getMysqlPort(), this.dockerConfiguration.getMysqlUsername(), this.dockerConfiguration.getMysqlPassword(), this.dockerConfiguration.getMysqlDatabase());
		new Timer().schedule(new TimerTask() {
			@Override
			public void run() {
				BadblockDatabase.getInstance().addSyncRequest(new Request("SELECT * FROM absorbances WHERE environment = '" + dockerConfiguration.getEnvironment() + "'", RequestType.GETTER) {
					@Override
					public void done(ResultSet resultSet) {
						String ladderIp = null;
						String ip = null;
						int openedSlots = 0;
						int online = 0;
						List<String> availableInstances = new ArrayList<>();
						try {
							InetSocketAddress host = new InetSocketAddress("roundrobin.badblock.fr", 25565);
							@SuppressWarnings("resource")
							Socket socket = new Socket();
							socket.setSoTimeout(3000);
							socket.connect(host, 3000);
							DataOutputStream output = new DataOutputStream(socket.getOutputStream());
							DataInputStream input = new DataInputStream(socket.getInputStream());

							byte [] handshakeMessage = createHandshakeMessage("roundrobin.badblock.fr", 25565);

							writeVarInt(output, handshakeMessage.length);
							output.write(handshakeMessage);

							// C->S : Request
							output.writeByte(0x01);
							output.writeByte(0x00);

							@SuppressWarnings("unused")
							int size = readVarInt(input);
							int packetId = readVarInt(input);

							if (packetId == -1) {
								throw new IOException("Premature end of stream.");
							}

							if (packetId != 0x00) {
								throw new IOException("Invalid packetID");
							}
							int length = readVarInt(input);

							if (length == -1) {
								throw new IOException("Premature end of stream.");
							}

							if (length == 0) {
								throw new IOException("Invalid string length.");
							}

							byte[] in = new byte[length];
							input.readFully(in);
							String json = new String(in);
							long now = System.currentTimeMillis();
							output.writeByte(0x09);
							output.writeByte(0x01);
							output.writeLong(now);
							readVarInt(input);
							packetId = readVarInt(input);
							if (packetId == -1) {
								throw new IOException("Premature end of stream.");
							}

							if (packetId != 0x01) {
								throw new IOException("Invalid packetID");
							}
							double t = Double.parseDouble(json.split(":")[6].split(",")[0]);
							online = (int) t;
						}catch(Exception r) {
							r.printStackTrace();
						}
						int opened = 0;
						int done = 0;
						int totalIPs = 0;
						boolean undonethere = false;
						try {
							List<Integer> ids = new ArrayList<>();
							while (resultSet.next()) {
								long bungeeTimestamp = resultSet.getLong("bungeeTimestamp");
								boolean donee = Boolean.parseBoolean(resultSet.getString("done"));
								if (!donee && bungeeTimestamp > System.currentTimeMillis()) {
									availableInstances.add(resultSet.getString("ip"));
								}
								int machineId = resultSet.getInt("machineId");
								totalIPs++;
								// Up
								boolean delete = donee;
								if (delete || bungeeTimestamp < System.currentTimeMillis()) {
									boolean ok = delete;
									if (bungeeTimestamp > System.currentTimeMillis()) times.remove(resultSet.getString("ip"));
									if (!delete) {
										if (!times.containsKey(resultSet.getString("ip")))
											times.put(resultSet.getString("ip"), 1);
										else 
											times.put(resultSet.getString("ip"), times.get(resultSet.getString("ip")) + 1);
										ok = times.containsKey(resultSet.getString("ip")) && times.get(resultSet.getString("ip")) > 2;
									}
									if (ok) {
										int recordId = resultSet.getInt("recordId");
										if (recordId != 0) {
											DNSDeleteRecord dns = new DNSDeleteRecord(access, "badblock.fr", recordId);
											JSONObject object;
											try {
												object = dns.executeBasic();
												if (object != null) {
													BadblockDatabase.getInstance().addSyncRequest(new Request("INSERT INTO history(ip, action, log, date) VALUES('" + resultSet.getString("ip") + "', 'Deleted record in cloudflare (BungeeDocker / ID " + recordId + ")', '" + object.toString() + "', '" + new SimpleDateFormat("dd/MM/yyyy HH:mm:ss.SS").format(new Date()) + "')", RequestType.SETTER));
													BadblockDatabase.getInstance().addSyncRequest(new Request("UPDATE absorbances SET recordId = '0' WHERE ip = '" + resultSet.getString("ip") + "'", RequestType.SETTER));
												}else{
													BadblockDatabase.getInstance().addSyncRequest(new Request("INSERT INTO history(ip, action, log, date) VALUES('" + resultSet.getString("ip") + "', 'Fail: Deleted record in cloudflare (BungeeDocker / ID " + recordId + ")', 'null', '" + new SimpleDateFormat("dd/MM/yyyy HH:mm:ss.SS").format(new Date()) + "')", RequestType.SETTER));
													Log.log("Unable to delete recordId " + recordId + " (" + resultSet.getString("ip") + ")", LogType.WARNING);
												}
											} catch (CloudflareError e) {
												e.printStackTrace();
											}
											try {
												dns.close();
											} catch (IOException e) {
												e.printStackTrace();
											}
										}

									}
								}else times.remove(resultSet.getString("ip"));
								if (bungeeTimestamp > System.currentTimeMillis()) {
									opened++;
									if (machineId == dockerConfiguration.getMachineID())
										ids.add(resultSet.getInt("id"));
									// Done
									if (!donee) {
										openedSlots += resultSet.getInt("slots");
										undonethere = true;
									}else done++;
								}else if ((!donee || bungeeTimestamp < System.currentTimeMillis()) && machineId == dockerConfiguration.getMachineID())
								{
									ip = resultSet.getString("ip");
									ladderIp = resultSet.getString("ladderIp");
								}
							}
							boolean needEntry = !undonethere || openedSlots < online;
							if (needEntry) {
								if (ip == null) {
									Log.log("All IPs are taken, please wait or check if something went wrong.", LogType.WARNING);
								}else{
									Log.log("There we are! We need an absorbance, we will search for the bungeeID..", LogType.INFO);
									int i = -1;
									try {
										Runtime rt = Runtime.getRuntime();
										Process p = rt.exec("screen -ls");
										try {
											p.waitFor();
										} catch (InterruptedException e) {
											e.printStackTrace();
										}
										BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
										String line = null;
										List<Integer> nbs = new ArrayList<>();
										while ((line = reader.readLine()) != null) {
											for (int a = 0; a < 1000; a++) {
												String b = a < 10 ? "00" + a : a < 100 ? "0" + a : Integer.toString(a);
												if (line.contains("cs" + b)) {
													nbs.add(a);
													break;
												}
											}
										}
										for (int b = 1; b < 1000; b++) {
											if (!nbs.contains(b)) {
												i = b;
												break;
											}
										}
										if (line == null) line = null; // juste pour pas avoir d'unused
									}catch(Exception e) {
										e.printStackTrace();
									}
									String[] splitter = ip.split(":");
									long bungeeTimestamp = System.currentTimeMillis() + 30_000L;
									Log.log("------------------------", LogType.SUCCESS);
									Log.log("\\New Absorbance/", LogType.SUCCESS);
									Log.log("------------------------", LogType.SUCCESS);
									Log.log("AbsorbID: " + i, LogType.SUCCESS);
									Log.log("IPData  : " + ip, LogType.SUCCESS);
									Log.log("OpenedAB: " + done + "/" + opened + "/" + totalIPs, LogType.SUCCESS);
									Log.log("------------------------", LogType.SUCCESS);
									String bungeeName = "cs" + (i < 10 ? (new String(DatatypeConverter.parseHexBinary("3030"), "UTF-8") + i) : i < 100 ? (new String(DatatypeConverter.parseHexBinary("30"), "UTF-8") + i) : i);
									try {
										Runtime rt = Runtime.getRuntime();
										Process p = rt.exec("sh quit.sh " + bungeeName);
										p.waitFor();
										copyFolder(new File(dockerConfiguration.getPackagePath() + "/abs"), new File("system/" + bungeeName + "/"));
										// Server properties
										String fileName = "system/" + bungeeName + "/plugins/BungeeOthers/config.yml";
										try {
											String l = "";
											List<String> lines = Files.readAllLines(Paths.get(fileName), StandardCharsets.UTF_8);
											for (String line : lines) {
												if (line.startsWith("machineId"))
													l += "machineId: " + dockerConfiguration.getMachineID() + "\n";
												else if (line.startsWith("bungeeName"))
													l += "bungeeName: " + bungeeName + "\n";
												else l += line + "\n";
											}
											File properties = new File(fileName);
											properties.delete();
											PrintWriter writer = new PrintWriter("system/" + bungeeName + "/plugins/BungeeOthers/config.yml", "UTF-8");
											writer.print(l);
											writer.close();
										} catch (IOException e) {
											Log.log("Error on editing config.yml: " + e.getMessage(), LogType.WARNING);
											e.printStackTrace();
											return;
										}
										fileName = "system/" + bungeeName + "/plugins/LadderPlugin/config.yml";
										try {
											String l = "";
											List<String> lines = Files.readAllLines(Paths.get(fileName), StandardCharsets.UTF_8);
											boolean ipT = false;
											String finalIp = splitter[0];
											String finalPort = splitter[1];
											if (ladderIp != null && !ladderIp.isEmpty())
											{
												String[] spli = ladderIp.split(":");
												finalIp = spli[0];
												finalPort = spli[1];
											}
											boolean portT = false;
											for (String line : lines) {
												if (line.startsWith("  ip") && !ipT) {
													l += "  ip: " + finalIp + "\n";
													ipT = true;
												}else if (line.startsWith("  port") && !portT) {
													l += "  port: " + finalPort + "\n";
													portT = true;
												}else l += line + "\n";
											}
											File properties = new File(fileName);
											properties.delete();
											PrintWriter writer = new PrintWriter("system/" + bungeeName + "/plugins/LadderPlugin/config.yml", "UTF-8");
											writer.print(l);
											writer.close();
										} catch (IOException e) {
											Log.log("Error on editing config.yml: " + e.getMessage(), LogType.WARNING);
											e.printStackTrace();
											return;
										}
										fileName = "system/" + bungeeName + "/config.yml";
										try {
											String l = "";
											List<String> lines = Files.readAllLines(Paths.get(fileName), StandardCharsets.UTF_8);
											for (String line : lines) {
												if (line.startsWith("  host"))
													l += "  host: " + ip + "\n";
												else l += line + "\n";
											}
											File properties = new File(fileName);
											properties.delete();
											PrintWriter writer = new PrintWriter("system/" + bungeeName + "/config.yml", "UTF-8");
											writer.print(l);
											writer.close();
										} catch (IOException e) {
											Log.log("Error on editing config.json: " + e.getMessage(), LogType.WARNING);
											e.printStackTrace();
											return;
										}
										// CLEAN DU PORT
										p = rt.exec("sh start.sh " + bungeeName + " " + new File("system/" + bungeeName + "/").getAbsolutePath() + "/");
										p.waitFor();
									} catch (Exception err) {
										err.printStackTrace();
									}
									BadblockDatabase.getInstance().addSyncRequest(new Request("UPDATE absorbances SET id = '" + i + "', bungeeTimestamp = '" + bungeeTimestamp + "', done = 'false' WHERE ip = '" + ip + "'", RequestType.SETTER));
								}
							}
							try {
								StringBuilder string = new StringBuilder();
								List<String> lines = Files.readAllLines(Paths.get("haproxy.cfg"), StandardCharsets.UTF_8);
								for (String line : lines) {
									if (line.contains("{servers}")) {
										for (String ipp : availableInstances)
											string.append("    server " + ipp.replace(":", "_") + " " + ipp + " check-send-proxy check send-proxy-v2" + System.lineSeparator());
									}else{
										string.append(line + System.lineSeparator());
									}
								}
								try{
									File fil = new File("/etc/haproxy/haproxy.cfg");
									if (fil.exists()) fil.delete();
									PrintWriter writer = new PrintWriter("/etc/haproxy/haproxy.cfg", "UTF-8");
									writer.print(string);
									writer.close();
									Thread.sleep(2000);
									Runtime.getRuntime().exec("/etc/init.d/haproxy reload");
								} catch (IOException e) {
									e.printStackTrace();
								}
							}catch(Exception error) {
								error.printStackTrace();
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});/*"bungee_" + dockerConfiguration.getMachineID(), bungeeDataType, new Callback<HashMap<String, Bungee>>() {
					@Override
					public void done(HashMap<String, Bungee> result, Throwable error) {
						Entry<String, Bungee> startEntry = null;
						boolean needEntry = true;
						int opened = 0;
						int done = 0;
						int totalIPs = 0;
						for (Entry<String, Bungee> entry : result.entrySet()) {
							totalIPs++;
							// Up
							if (entry.getValue().bungeeTimestamp > System.currentTimeMillis()) {
								opened++;
								// Done
								if (!entry.getValue().done) {
									needEntry = false;
								}else done++;
							}else if ((!entry.getValue().done || entry.getValue().bungeeTimestamp < System.currentTimeMillis()) && entry.getValue().machineId == dockerConfiguration.getInstanceId()) startEntry = entry;
						}
						if (needEntry) {
							if (startEntry == null) {
								Log.log("All IPs are taken, please wait or check if something went wrong.", LogType.WARNING);
							}else{
								Log.log("There we are! We need an absorbance, we will search for the bungeeID..", LogType.INFO);
								int i = 0;
								boolean doesntexists = false;
								while (!doesntexists) {
									i++;
									boolean f = true;
									for (Entry<String, Bungee> entry : result.entrySet()) {
										if (entry.getValue().bungeeName != null && !entry.getValue().bungeeName.isEmpty() && entry.getValue().bungeeTimestamp > System.currentTimeMillis()) {
											String idString = "";
											for (char c : entry.getValue().bungeeName.toCharArray())
												if (Character.isDigit(c)) idString += c;
											int id = -1;
											try {
												id = Integer.parseInt(idString);
											}catch(Exception err) {
												id = 0;
											}
											if (id == i) f = false;
										}
									}
									doesntexists = f;
								}
								String[] splitter = startEntry.getKey().split(":");
								startEntry.getValue().bungeeTimestamp = System.currentTimeMillis() + 30_000L;
								startEntry.getValue().bungeeName = "cs" + i;
								Log.log("------------------------", LogType.SUCCESS);
								Log.log("\\New Absorbance/", LogType.SUCCESS);
								Log.log("------------------------", LogType.SUCCESS);
								Log.log("AbsorbID: " + i, LogType.SUCCESS);
								Log.log("IPData  : " + startEntry.getKey(), LogType.SUCCESS);
								Log.log("OpenedAB: " + done + "/" + opened + "/" + totalIPs, LogType.SUCCESS);
								Log.log("------------------------", LogType.SUCCESS);
								try {
									Runtime rt = Runtime.getRuntime();
									Process p = rt.exec("sh quit.sh " + startEntry.getValue().bungeeName);
									p.waitFor();
									copyFolder(new File(dockerConfiguration.getPackagePath() + "/abs"), new File("system/" + startEntry.getValue().bungeeName + "/"));
									// Server properties
									String fileName = "system/" + startEntry.getValue().bungeeName + "/plugins/BungeeOthers/config.yml";
									try {
										String l = "";
										List<String> lines = Files.readAllLines(Paths.get(fileName), Charset.defaultCharset());
										for (String line : lines) {
											if (line.startsWith("  machineId"))
												l += "  machineId: " + dockerConfiguration.getMachineID() + "\n";
											else if (line.startsWith("  bungeeName"))
												l += "  bungeeName: " + startEntry.getValue().bungeeName + "\n";
											else l += line + "\n";
										}
										File properties = new File(fileName);
										properties.delete();
										PrintWriter writer = new PrintWriter("system/" + startEntry.getValue().bungeeName + "/plugins/BungeeOthers/config.yml", "UTF-8");
										writer.print(l);
										writer.close();
									} catch (IOException e) {
										Log.log("Error on editing config.yml: " + e.getMessage(), LogType.WARNING);
										e.printStackTrace();
										return;
									}
									fileName = "system/" + startEntry.getValue().bungeeName + "/plugins/LadderPlugin/config.yml";
									try {
										String l = "";
										List<String> lines = Files.readAllLines(Paths.get(fileName), Charset.defaultCharset());
										boolean ipT = false;
										boolean portT = false;
										for (String line : lines) {
											if (line.startsWith("  ip") && !ipT) {
												l += "  ip: " + splitter[0] + "\n";
												ipT = true;
											}else if (line.startsWith("  port") && !portT) {
												l += "  port: " + splitter[1] + "\n";
												portT = true;
											}else l += line + "\n";
										}
										File properties = new File(fileName);
										properties.delete();
										PrintWriter writer = new PrintWriter("system/" + startEntry.getValue().bungeeName + "/plugins/LadderPlugin/config.yml", "UTF-8");
										writer.print(l);
										writer.close();
									} catch (IOException e) {									Log.log("Error on editing config.yml: " + e.getMessage(), LogType.WARNING);
										e.printStackTrace();
										return;
									}
									fileName = "system/" + startEntry.getValue().bungeeName + "/config.yml";
									try {
										String l = "";
										List<String> lines = Files.readAllLines(Paths.get(fileName), Charset.defaultCharset());
										for (String line : lines) {
											if (line.startsWith("  host"))
												l += "  host: " + startEntry.getKey() + "\n";
											else l += line + "\n";
										}
										File properties = new File(fileName);
										properties.delete();
										PrintWriter writer = new PrintWriter("system/" + startEntry.getValue().bungeeName + "/config.yml", "UTF-8");
										writer.print(l);
										writer.close();
									} catch (IOException e) {
										Log.log("Error on editing config.json: " + e.getMessage(), LogType.WARNING);
										e.printStackTrace();
										return;
									}
									// CLEAN DU PORT
									p = rt.exec("sh start.sh " + startEntry.getValue().bungeeName + " " + new File("system/" + startEntry.getValue().bungeeName + "/").getAbsolutePath() + "/");
									p.waitFor();
								} catch (Exception err) {
									err.printStackTrace();
								}
								result.put(startEntry.getKey(), startEntry.getValue());
								redisConnector.setAsync("bungee_" + dockerConfiguration.getMachineID(), result);
							}
						}
					}
				}, false);*/
			}
		}, 1000, 5000);
	}

	public static byte [] createHandshakeMessage(String host, int port) throws IOException {
		ByteArrayOutputStream buffer = new ByteArrayOutputStream();

		DataOutputStream handshake = new DataOutputStream(buffer);
		handshake.writeByte(0x00); //packet id for handshake
		writeVarInt(handshake, 42); //protocol version
		writeString(handshake, host, StandardCharsets.UTF_8);
		handshake.writeShort(port); //port
		writeVarInt(handshake, 1); //state (1 for handshake)

		return buffer.toByteArray();
	}

	public static void writeString(DataOutputStream out, String string, Charset charset) throws IOException {
		byte [] bytes = string.getBytes(charset);
		writeVarInt(out, bytes.length);
		out.write(bytes);
	}

	public static void writeVarInt(DataOutputStream out, int paramInt) throws IOException {
		while (true) {
			if ((paramInt & 0xFFFFFF80) == 0) {
				out.writeByte(paramInt);
				return;
			}

			out.writeByte(paramInt & 0x7F | 0x80);
			paramInt >>>= 7;
		}
	}

	public static int readVarInt(DataInputStream in) throws IOException {
		int i = 0;
		int j = 0;
		while (true) {
			int k = in.readByte();
			i |= (k & 0x7F) << j++ * 7;
			if (j > 5) throw new RuntimeException("VarInt too big");
			if ((k & 0x80) != 128) break;
		}
		return i;
	}

	/**
	 * Setup the configuration of NetworkDocker
	 */
	void setupConfiguration() {
		File configuration = new File("configuration.json");
		if (!configuration.exists()) {
			Log.log("No configuration file found, creating it...", LogType.INFO);
			try {
				configuration.createNewFile();
				FileWriter fileWriter = new FileWriter(configuration.getAbsolutePath());
				BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
				dockerConfiguration = new DockerConfiguration();
				bufferedWriter.write(gson.toJson(dockerConfiguration));
				bufferedWriter.close();
				fileWriter.close();
				Log.log("Configuration file created!", LogType.SUCCESS);
			} catch (Exception error) {
				Log.log("Error when creating configuration file (" + error.getMessage() + ")", LogType.WARNING);
				error.printStackTrace();
				try {
					Thread.sleep(Long.MAX_VALUE);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				return;
			}
		} else {
			try (BufferedReader bufferedReader = new BufferedReader(new FileReader("configuration.json"))) {
				String global = "";
				String line;
				while ((line = bufferedReader.readLine()) != null)
					global += line + System.lineSeparator();
				dockerConfiguration = gson.fromJson(global, new TypeToken<DockerConfiguration>() {
				}.getType());
				Log.log("Configuration file loaded!", LogType.SUCCESS);
			} catch (IOException error) {
				Log.log("Error when loading configuration file (" + error.getMessage() + ")", LogType.WARNING);
				error.printStackTrace();
				try {
					Thread.sleep(Long.MAX_VALUE);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				return;
			}
		}
	}

	public static void copyFolder(File src, File dest) {
		if (src.isDirectory()) {
			if (!dest.exists()) {
				dest.mkdir();
			}

			String files[] = src.list();

			for (String file : files) {
				File srcFile = new File(src, file);
				File destFile = new File(dest, file);
				copyFolder(srcFile, destFile);
			}
		} else {
			try {
				Files.copy(src.toPath(), dest.toPath());
			} catch (IOException e) {
			}
			/*
			 * InputStream in = new FileInputStream(src); OutputStream out = new
			 * FileOutputStream(dest);
			 * 
			 * byte[] buffer = new byte[1024];
			 * 
			 * int length; while ((length = in.read(buffer)) > 0){
			 * out.write(buffer, 0, length); }
			 * 
			 * in.close(); out.close();
			 */
		}
	}

}
