package fr.badblock.docker.bungee;

public class Main {

	public static void main(String[] args) {
		new BungeeDocker();
	}

}
