package fr.badblock.docker.bungee;

public class BungeeState {

	
	
}
