package fr.badblock.docker.bungee.configuration;

import java.util.HashMap;
import java.util.Map;

import com.google.gson.annotations.Expose;

/**
 * The configuration of the docker Injected with json.
 * 
 * @author xMalware
 */
public class DockerConfiguration {

	// Private fields
	@Expose
	private final Map<String, String> mysql = new HashMap<>();

	private String packagePath;
	private int machineId;
	private int environment;

	/**
	 * Private constructor of a default configuration
	 */
	public DockerConfiguration() {
		mysql.put("hostname", "host01.srv.badblock.fr");
		mysql.put("username", "root");
		mysql.put("password", "BadPassword2015");
		mysql.put("database", "root");
		mysql.put("port", "3306");
	}

	/**
	 * Getting redis fields
	 * 
	 * @return
	 */
	private Map<String, String> getMysqlFields() {
		return this.mysql;
	}

	/**
	 * Getting the rabbit hostname
	 * 
	 * @return
	 */
	public String getMysqlHostname() {
		return this.getMysqlFields().containsKey("hostname") ? this.getMysqlFields().get("hostname") : "";
	}
	
	/**
	 * Getting the instance ID
	 * 
	 * @return
	 */
	public int getEnvironment() {
		return this.environment;
	}

	/**
	 * Getting the machine id
	 * 
	 * @return
	 */
	public int getMachineID() {
		return this.machineId;
	}

	/**
	 * Getting the package path
	 * 
	 * @return
	 */
	public String getPackagePath() {
		return this.packagePath;
	}

	/**
	 * Getting the rabbit password
	 * 
	 * @return
	 */
	public String getMysqlPassword() {
		return this.getMysqlFields().containsKey("password") ? this.getMysqlFields().get("password") : "";
	}

	/**
	 * Getting the FTP username
	 * 
	 * @return
	 */
	public String getMysqlUsername() {
		return this.getMysqlFields().containsKey("username") ? this.getMysqlFields().get("username") : "";
	}

	/**
	 * Getting the FTP hostname
	 * 
	 * @return
	 */
	public String getMysqlDatabase() {
		return this.getMysqlFields().containsKey("database") ? this.getMysqlFields().get("database") : "";
	}

	/**
	 * Getting the FTP hostname
	 * 
	 * @return
	 */
	public int getMysqlPort() {
		return this.getMysqlFields().containsKey("port") ? Integer.parseInt(this.getMysqlFields().get("port")) : 0;
	}

}
