package fr.badblock.docker.bungee.configuration;

public class Bungee {
	
	public String 	bungeeName;
	public long   	bungeeTimestamp;
	public boolean  done;
	public int		machineId;
	
}
