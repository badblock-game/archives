package fr.badblock.bukkit.games.fight.configuration;

import java.util.List;

import fr.badblock.gameapi.configuration.values.MapLocation;
import lombok.NoArgsConstructor;

@NoArgsConstructor
public class FightConfiguration {
	
	public String 	   		   fallbackServer   = "lobby";
	public String			   defaultKit		= "defaultKit";
	public boolean			   enabledAutoTeamManager = false;
	public int				   minPlayersAutoTeam = 1;
	public int				   maxPlayersAutoTeam = 4;
	public int    	   		   maxPlayersInTeam = 4;
	public int    	   		   minPlayers		= 2;
	public List<MapLocation>   spawn			= null;
	
}
