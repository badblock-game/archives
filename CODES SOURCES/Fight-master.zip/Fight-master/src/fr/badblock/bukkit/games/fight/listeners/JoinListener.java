package fr.badblock.bukkit.games.fight.listeners;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import fr.badblock.bukkit.games.fight.PluginFight;
import fr.badblock.bukkit.games.fight.entities.FightTeamData;
import fr.badblock.bukkit.games.fight.players.FightScoreboard;
import fr.badblock.bukkit.games.fight.runnables.BossBarRunnable;
import fr.badblock.bukkit.games.fight.runnables.PreStartRunnable;
import fr.badblock.bukkit.games.fight.runnables.StartRunnable;
import fr.badblock.gameapi.BadListener;
import fr.badblock.gameapi.GameAPI;
import fr.badblock.gameapi.events.PlayerGameInitEvent;
import fr.badblock.gameapi.events.api.SpectatorJoinEvent;
import fr.badblock.gameapi.players.BadblockPlayer;
import fr.badblock.gameapi.players.BadblockPlayer.BadblockMode;
import fr.badblock.gameapi.players.BadblockTeam;
import fr.badblock.gameapi.players.data.InGameKitData;
import fr.badblock.gameapi.players.kits.PlayerKit;
import fr.badblock.gameapi.utils.BukkitUtils;
import fr.badblock.gameapi.utils.i18n.TranslatableString;
import fr.badblock.gameapi.utils.i18n.messages.GameMessages;

public class JoinListener extends BadListener {

	public long time = -1;

	@EventHandler
	public void onSpectatorJoin(SpectatorJoinEvent e){
		e.getPlayer().teleport(PluginFight.getInstance().getMapConfiguration().getSpawnLocation());

		new FightScoreboard(e.getPlayer());
	}

	@EventHandler
	public void onJoin(PlayerJoinEvent e) {
		e.setJoinMessage(null);
		BadblockPlayer player = (BadblockPlayer) e.getPlayer();
		new BossBarRunnable(player.getUniqueId()).runTaskTimer(GameAPI.getAPI(), 0, 20L);

		if (!player.getBadblockMode().equals(BadblockMode.SPECTATOR)) {
			player.setGameMode(GameMode.SURVIVAL);
			player.sendTranslatedTitle("fight.join.title");
			player.teleport(PluginFight.getInstance().spawn.getHandle());
			player.sendTimings(0, 80, 20);
			player.sendTranslatedTabHeader(new TranslatableString("fight.tab.header"), new TranslatableString("fight.tab.footer"));

			GameMessages.joinMessage(GameAPI.getGameName(), player.getTabGroupPrefix().getAsLine(player) + player.getName(), Bukkit.getOnlinePlayers().size(), PluginFight.getInstance().getMaxPlayers()).broadcast();
		}
	}

	@EventHandler
	public void onLogin(PlayerLoginEvent e){

		if(inGame()){
			return;
		}

		PreStartRunnable.doJob();
		StartRunnable.joinNotify(Bukkit.getOnlinePlayers().size(), PluginFight.getInstance().getMaxPlayers());
		PluginFight fight = PluginFight.getInstance();
		if (Bukkit.getOnlinePlayers().size() + 1 >= fight.getMaxPlayers()) {
			if (fight.getConfiguration().enabledAutoTeamManager) {
				int max = fight.getConfiguration().maxPlayersAutoTeam * fight.getAPI().getTeams().size();
				if (fight.getMaxPlayers() < max) {
					fight.getAPI().getTeams().forEach(team -> team.setMaxPlayers(team.getMaxPlayers() + 1));
					fight.setMaxPlayers(fight.getMaxPlayers() + fight.getAPI().getTeams().size());
					try {
						BukkitUtils.setMaxPlayers(fight.getMaxPlayers());
					} catch (Exception err) {
						err.printStackTrace();
					}
				}
			}
		}
		System.out.println("OnLogin: Fight");
	}

	@EventHandler
	public void onPlayerGameInit(PlayerGameInitEvent event) {
		handle(event.getPlayer());
	}

	@EventHandler
	public void onQuit(PlayerQuitEvent e){
		e.setQuitMessage(null);
	}

	public static void handle(BadblockPlayer player) {
		BadblockTeam team = player.getTeam();
		if (team == null) return;
		Location location = team.teamData(FightTeamData.class).getSpawnLocation();
		player.leaveVehicle();
		player.eject();
		player.changePlayerDimension(BukkitUtils.getEnvironment( PluginFight.getInstance().getMapConfiguration().getDimension() ));
		player.teleport(location);
		player.setGameMode(GameMode.SURVIVAL);
		player.getCustomObjective().generate();

		PlayerKit kit = player.inGameData(InGameKitData.class).getChoosedKit();

		if(kit != null){
			kit.giveKit(player);
		} else {
			PluginFight.getInstance().giveDefaultKit(player);
		}
	}

}
