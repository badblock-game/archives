package fr.badblock.bukkit.games.fight.listeners;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerQuitEvent;

import fr.badblock.bukkit.games.fight.PluginFight;
import fr.badblock.bukkit.games.fight.players.FightScoreboard;
import fr.badblock.bukkit.games.fight.runnables.StartRunnable;
import fr.badblock.gameapi.BadListener;
import fr.badblock.gameapi.GameAPI;
import fr.badblock.gameapi.game.rankeds.RankedCalc;
import fr.badblock.gameapi.game.rankeds.RankedManager;
import fr.badblock.gameapi.players.BadblockPlayer;
import fr.badblock.gameapi.players.BadblockPlayer.BadblockMode;
import fr.badblock.gameapi.players.BadblockTeam;
import fr.badblock.gameapi.utils.BukkitUtils;
import fr.badblock.gameapi.utils.i18n.TranslatableString;
import fr.badblock.gameapi.utils.i18n.messages.GameMessages;

public class QuitListener extends BadListener {
	@EventHandler
	public void onQuit(PlayerQuitEvent e){
		PluginFight fight = PluginFight.getInstance();
		if (StartRunnable.gameTask == null && BukkitUtils.getPlayers().size() - 1 < fight.getConfiguration().minPlayers) {
			StartRunnable.stopGame();
			StartRunnable.time = StartRunnable.time > 30 ? StartRunnable.time : 30;
		}

		BadblockPlayer player = (BadblockPlayer) e.getPlayer();
		if (!player.getGameMode().equals(GameMode.SPECTATOR) && !player.getBadblockMode().equals(BadblockMode.SPECTATOR))
		{
			GameMessages.quitMessage(GameAPI.getGameName(), player.getTabGroupPrefix().getAsLine(player) + player.getName(), Bukkit.getOnlinePlayers().size(), PluginFight.getInstance().getMaxPlayers()).broadcast();
		}
		
		if (!inGame()) return;
		
		BadblockTeam   team   = player.getTeam();

		if(team == null) return;

		String rankedGameName = RankedManager.instance.getCurrentRankedGameName();
		RankedManager.instance.calcPoints(rankedGameName, player, new RankedCalc()
		{

			@Override
			public long done() {
				double kills = RankedManager.instance.getData(rankedGameName, player, FightScoreboard.KILLS);
				double deaths = RankedManager.instance.getData(rankedGameName, player, FightScoreboard.DEATHS);
				double total = kills / (1 + deaths);
				return (long) total;
			}

		});
		RankedManager.instance.fill(rankedGameName);
		
		if(team.getOnlinePlayers().size() == 0){
			GameAPI.getAPI().getGameServer().cancelReconnectionInvitations(team);
			GameAPI.getAPI().unregisterTeam(team);
			
			new TranslatableString("fight.team-loose", team.getChatName()).broadcast();
		}
	}
}
