package fr.badblock.bukkit.games.fight.configuration;

import java.io.File;

import org.bukkit.Location;

import fr.badblock.bukkit.games.fight.entities.FightTeamData;
import fr.badblock.gameapi.GameAPI;
import fr.badblock.gameapi.configuration.BadConfiguration;
import fr.badblock.gameapi.configuration.values.MapLocation;
import fr.badblock.gameapi.configuration.values.MapNumber;
import fr.badblock.gameapi.players.BadblockTeam;
import lombok.Data;

@Data
public class FightMapConfiguration {

	private int time;
	private int dimension;
	
	/*
	 * Spawn pour les joueurs morts ou arrivant après le début
	 */
	private Location 		  spawnLocation;
	
	private BadConfiguration  config;
	
	public FightMapConfiguration(BadConfiguration config){
		this.config = config;

		time			= config.getValue("time", MapNumber.class, new MapNumber(0)).getHandle().intValue();
		dimension		= config.getValue("dimension", MapNumber.class, new MapNumber(0)).getHandle().intValue();
		spawnLocation   = config.getValue("spawnLocation", MapLocation.class, new MapLocation()).getHandle();

		for(BadblockTeam team : GameAPI.getAPI().getTeams()){
			team.teamData(FightTeamData.class).load(config.getSection(team.getKey()));
		}
	}
	
	public void save(File file){
		config.save(file);
	}
}
