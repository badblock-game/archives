package fr.badblock.bukkit.games.fight.players;

import fr.badblock.gameapi.players.data.InGameData;
import lombok.NoArgsConstructor;

@NoArgsConstructor
public class FightData implements InGameData {
	public int  kills 		= 0;
	public int  deaths		= 0;
	
	public double givenDamages;
	
	public int getScore(){
		return (kills * 20) / (deaths == 0 ? 1 : (deaths));
	}
	
}