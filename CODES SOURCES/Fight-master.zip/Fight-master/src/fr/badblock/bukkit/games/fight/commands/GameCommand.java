package fr.badblock.bukkit.games.fight.commands;

import org.bukkit.command.CommandSender;

import fr.badblock.bukkit.games.fight.PluginFight;
import fr.badblock.bukkit.games.fight.runnables.StartRunnable;
import fr.badblock.gameapi.GameAPI;
import fr.badblock.gameapi.command.AbstractCommand;
import fr.badblock.gameapi.players.BadblockPlayer;
import fr.badblock.gameapi.players.BadblockTeam;
import fr.badblock.gameapi.utils.BukkitUtils;
import fr.badblock.gameapi.utils.i18n.TranslatableString;

public class GameCommand extends AbstractCommand {
	public GameCommand() {
		super("game", new TranslatableString("commands.gfight.usage"), "animation.gamecommand");
		allowConsole(false);
	}

	@Override
	public boolean executeCommand(CommandSender sender, String[] args) {
		if(args.length == 0) {
			return false;
		}

		BadblockPlayer player = (BadblockPlayer) sender;
		PluginFight plug = PluginFight.getInstance();

		switch(args[0].toLowerCase()){
		case "force":
			String msge = "commands.gfight.start";

			if(!StartRunnable.started()){
				StartRunnable.startGame();
				StartRunnable.time = 10;
			} else msge += "-fail";

			player.sendTranslatedMessage(msge);
			break;
		case "start":
			String msg = "commands.gfight.start";

			if(!StartRunnable.started()){
				StartRunnable.startGame();
			} else msg += "-fail";

			player.sendTranslatedMessage(msg);
			break;
		case "stop":
			msg = "commands.gfight.stop";

			if(StartRunnable.started()){
				StartRunnable.stopGame();
			} else msg += "-fail";

			player.sendTranslatedMessage(msg);
			break;
		case "playersperteam":
			if(args.length != 2)
				return false;

			int perTeam = 4;

			try {
				perTeam = Integer.parseInt(args[1]);
			} catch(Exception e){
				return false;
			}

			for(BadblockTeam team : GameAPI.getAPI().getTeams())
				team.setMaxPlayers(perTeam);

			plug.getConfiguration().maxPlayersInTeam = perTeam;
			plug.setMaxPlayers(GameAPI.getAPI().getTeams().size() * perTeam);
			try {
				BukkitUtils.setMaxPlayers(GameAPI.getAPI().getTeams().size() * perTeam);
			} catch (Exception e) {
				e.printStackTrace();
			}

			player.sendTranslatedMessage("commands.gfight.modifycount");
			break;
		default: return false;
		}

		return true;
	}
}