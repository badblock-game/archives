package fr.badblock.bukkit.games.fight.players;

import java.util.Map;

import org.bukkit.ChatColor;
import org.bukkit.DyeColor;

import com.google.common.collect.Maps;

import fr.badblock.gameapi.GameAPI;
import fr.badblock.gameapi.players.BadblockPlayer;
import fr.badblock.gameapi.players.BadblockPlayer.BadblockMode;
import fr.badblock.gameapi.players.BadblockTeam;
import fr.badblock.gameapi.players.scoreboard.BadblockScoreboardGenerator;
import fr.badblock.gameapi.players.scoreboard.CustomObjective;
import fr.badblock.gameapi.utils.general.MathsUtils;

public class FightScoreboard extends BadblockScoreboardGenerator {
	
	public static final String KILLS 	  = "kills",
			DEATHS 	  = "deaths";

	private CustomObjective objective;
	private BadblockPlayer  player;

	private static Map<DyeColor, ChatColor> dyeChatMap;
	static
	{
		dyeChatMap = Maps.newHashMap();
		dyeChatMap.put(DyeColor.BLACK, ChatColor.DARK_GRAY);
		dyeChatMap.put(DyeColor.BLUE, ChatColor.DARK_BLUE);
		dyeChatMap.put(DyeColor.BROWN, ChatColor.GOLD);
		dyeChatMap.put(DyeColor.CYAN, ChatColor.AQUA);
		dyeChatMap.put(DyeColor.GRAY, ChatColor.GRAY);
		dyeChatMap.put(DyeColor.GREEN, ChatColor.DARK_GREEN);
		dyeChatMap.put(DyeColor.LIGHT_BLUE, ChatColor.BLUE);
		dyeChatMap.put(DyeColor.LIME, ChatColor.GREEN);
		dyeChatMap.put(DyeColor.MAGENTA, ChatColor.LIGHT_PURPLE);
		dyeChatMap.put(DyeColor.ORANGE, ChatColor.GOLD);
		dyeChatMap.put(DyeColor.PINK, ChatColor.LIGHT_PURPLE);
		dyeChatMap.put(DyeColor.PURPLE, ChatColor.DARK_PURPLE);
		dyeChatMap.put(DyeColor.RED, ChatColor.DARK_RED);
		dyeChatMap.put(DyeColor.SILVER, ChatColor.GRAY);
		dyeChatMap.put(DyeColor.WHITE, ChatColor.WHITE);
		dyeChatMap.put(DyeColor.YELLOW, ChatColor.YELLOW);
	}

	public static ChatColor dyeToChat(DyeColor dclr)
	{
		if (dyeChatMap.containsKey(dclr))
			return dyeChatMap.get(dclr);
		return ChatColor.MAGIC;
	}
	
	public FightScoreboard(BadblockPlayer player){
		this.objective = GameAPI.getAPI().buildCustomObjective("fight");
		this.player    = player;

		objective.showObjective(player);
		String gameName = GameAPI.getGameName();
		objective.setDisplayName("&b&o" + gameName);
		objective.setGenerator(this);

		objective.generate();
		doBadblockFooter(objective);
	}

	@Override
	public void generate(){
		objective.changeLine(15, "&8&m----------------------");

		int i = 14;

		objective.changeLine(i--, "");

		for(BadblockTeam team : GameAPI.getAPI().getTeams()){
			if (player != null && player.getTeam() != null && player.getTeam().equals(team))
			{
				continue;
			}
			for (BadblockPlayer teamPlayer : team.getOnlinePlayers())
			{
				double o = MathsUtils.round(teamPlayer.getHealth(), 1);
				double mx = teamPlayer.getMaxHealth();
				ChatColor color = o <= 0.1*mx ? ChatColor.DARK_RED : o <= 0.25*mx ? ChatColor.RED : o <= 0.5*mx ? ChatColor.YELLOW : 
					o <= 0.75*mx ? ChatColor.AQUA : o <= 0.90*mx ? ChatColor.GREEN : ChatColor.DARK_GREEN;
				//tring color = o == mx ? "§2" : o <= mx * 0.75 ? "§b" : o <= mx * 0.50 ? "§e" : o <= mx * 0.25 ? "§c" : o <= mx * 
				objective.changeLine(i, dyeToChat(team.getDyeColor()) + " " + teamPlayer.getName() + " §8> " + color + o + " §c❤");
			}
			i--;
		}

		if(player.getBadblockMode() != BadblockMode.SPECTATOR){
			objective.changeLine(i,  ""); i--;

			objective.changeLine(i,  i18n("fight.scoreboard.kills", stat(KILLS))); i--;
			objective.changeLine(i,  i18n("fight.scoreboard.deaths", stat(DEATHS))); i--;
			double ratio = MathsUtils.round((double) stat(KILLS) / (double) Math.max(1, stat(DEATHS)), 2);
			objective.changeLine(i,  i18n("fight.scoreboard.ratio", ratio)); i--;
		}

		for(int a=3;a<=i;a++)
			objective.removeLine(a);

		objective.changeLine(2,  "&8&m----------------------");
	}

	private int stat(String name){
		return (int) player.getPlayerData().getStatistics("fight", name);
	}

	private String i18n(String key, Object... args){
		return GameAPI.i18n().get(player.getPlayerData().getLocale(), key, args)[0];
	}
}
