package fr.badblock.bukkit.games.fight.entities;

import org.bukkit.Location;

import fr.badblock.gameapi.configuration.BadConfiguration;
import fr.badblock.gameapi.configuration.values.MapLocation;
import fr.badblock.gameapi.players.data.TeamData;
import lombok.Getter;

public class FightTeamData implements TeamData {
	@Getter private Location 	   	  spawnLocation;

	public void load(BadConfiguration config){
		spawnLocation = config.getValue("respawnLocation", MapLocation.class, new MapLocation()).getHandle();
	}

	public void save(BadConfiguration config){
		config.setValue("spawnLocation", new MapLocation(spawnLocation));
	}

}
