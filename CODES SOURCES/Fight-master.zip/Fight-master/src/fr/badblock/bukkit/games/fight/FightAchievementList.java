package fr.badblock.bukkit.games.fight;

import fr.badblock.gameapi.achievements.AchievementList;
import fr.badblock.gameapi.achievements.PlayerAchievement;
import fr.badblock.gameapi.run.BadblockGame;

public class FightAchievementList
{
	
	public static AchievementList instance = new AchievementList(BadblockGame.FIGHT);
	
	/*
	 * Tuer X personnes
	 */
	public static final PlayerAchievement TOWER_KILL_1 = instance.addAchievement(new PlayerAchievement("fight_kill_1", 10, 5, 10));
	public static final PlayerAchievement TOWER_KILL_2 = instance.addAchievement(new PlayerAchievement("fight_kill_2", 50, 25, 100));
	public static final PlayerAchievement TOWER_KILL_3 = instance.addAchievement(new PlayerAchievement("fight_kill_3", 250, 100, 1000));
	public static final PlayerAchievement TOWER_KILL_4 = instance.addAchievement(new PlayerAchievement("fight_kill_4", 500, 250, 10000));
	
}
