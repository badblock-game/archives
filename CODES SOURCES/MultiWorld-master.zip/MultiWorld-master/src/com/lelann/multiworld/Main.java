package com.lelann.multiworld;

import java.io.File;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

import com.lelann.multiworld.commands.MPCommandManager;
import com.lelann.multiworld.commands.MWCommandManager;
import com.lelann.multiworld.listener.MultiListener;
import com.lelann.multiworld.listener.MultiPortalListener;
import com.lelann.multiworld.portals.PortalsManager;
import com.lelann.multiworld.worlds.MultiWorldManager;

public class Main extends JavaPlugin {
	private static Main instance;
	public static Main getInstance(){
		return instance;
	}
	@Override
	public void onLoad(){
		instance = this;

		if(!getDataFolder().exists()) getDataFolder().mkdirs();
	}
	@Override
	public void onEnable(){
		new MWCommandManager();
		new MPCommandManager();
		
		new MultiWorldManager(new File(getDataFolder(), "worlds.yml")).saveLoadedWorlds();
		new PortalsManager(new File(getDataFolder(), "portals.yml")).saveLoadedPortals();

		getServer().getPluginManager().registerEvents(new MultiPortalListener(), this);
		getServer().getPluginManager().registerEvents(new MultiListener(), this);
	
	     this.getServer().getMessenger().registerOutgoingPluginChannel(this, "BungeeCord");
	}
	
	@Override
	public void onDisable(){
		for(int i=0;i<getServer().getWorlds().size();i++){
			getServer().getWorlds().get(i).save();
		}
	}
	
	@Override
	public boolean onCommand(CommandSender sender, Command command, String label, String[] args){
		if(label.equalsIgnoreCase("mw") || label.equalsIgnoreCase("multiworld")){
			MWCommandManager.getInstance().useCommand(sender, args);
		} else {
			MPCommandManager.getInstance().useCommand(sender, args);
		}
		return true;
	}
}
