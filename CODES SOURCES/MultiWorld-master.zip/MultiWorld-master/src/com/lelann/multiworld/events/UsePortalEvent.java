package com.lelann.multiworld.events;

import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

import com.lelann.multiworld.portals.Portal;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor public class UsePortalEvent extends Event {
	private static final HandlerList handlers = new HandlerList();

	@Getter private Player player;
	@Getter private Portal portal;
	@Getter@Setter private long waitingTime = 0L;
	
	@Override
	public HandlerList getHandlers() {
		return handlers;
	}

	public static HandlerList getHandlerList() {
		return handlers;
	}
}
