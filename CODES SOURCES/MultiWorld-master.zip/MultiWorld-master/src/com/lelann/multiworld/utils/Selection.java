package com.lelann.multiworld.utils;

import org.bukkit.Location;
import org.bukkit.World;

public class Selection{
	private Location firstLocation;
	private Location secondLocation;

	public Selection(Location premiereSelection, Location deuxiemeSelection){
		this.firstLocation = premiereSelection;
		this.secondLocation = deuxiemeSelection;
	}
	public Location getFirstLocation(){
		return firstLocation;
	}
	public Location getSecondLocation(){
		return secondLocation;
	}
	public World getWorld(){
		return firstLocation.getWorld();
	}
	/* Permet d'obtenir la distance entre une position l1 et l2 */
	private double distance(double l1, double l2){
		if(l1 < l2){
			return l2 - l1 - 1;
		} else {
			return l1 - l2 - 1;
		}
	}

	private boolean isBetween(Location location){
		final Location l1 = firstLocation; /* Je fais �a pour que les noms soient plus petits c'est plus pratique l� de suite */
		final Location l2 = secondLocation;
		final double distanceX = distance(l1.getBlockX(), l2.getBlockX());
		final double distanceY = distance(l1.getBlockY(), l2.getBlockY());
		final double distanceZ = distance(l1.getBlockZ(), l2.getBlockZ());

		/* Si la distance entre le X de la Loc l1 et le X de la loc location est plus grande que la distance entre le X de l1 et l2
		     ou
			 Si la distance entre le X de la Loc l2 et le X de la loc location est plus grande que la distance entre le X de l1 et l2
		 */
		if(distance(l1.getBlockX(), location.getBlockX()) > distanceX || distance(l2.getBlockX(), location.getBlockX()) > distanceX){
			return false; /* On en d�duit que le point X n'est pas dans la zone : on retourne faux */
		}
		/* De m�me pour les Y */
		if(distance(l1.getBlockY(), location.getBlockY()) > distanceY || distance(l2.getBlockY(), location.getBlockY()) > distanceY){
			return false; 
		}
		/* De m�me pour les Z */
		if(distance(l1.getBlockZ(), location.getBlockZ()) > distanceZ || distance(l2.getBlockZ(), location.getBlockZ()) > distanceZ){
			return false; 
		}
		return true; /* La position semble �tre entre l1 et l2, on retourne vrai */
	}
	public boolean isBetweenLarge(Location location){
		final Location l1 = firstLocation; /* Je fais �a pour que les noms soient plus petits c'est plus pratique l� de suite */
		final Location l2 = secondLocation;
		final double distanceX = distance(l1.getX(), l2.getX()) + 3;
		final double distanceY = distance(l1.getY(), l2.getY()) + 3;
		final double distanceZ = distance(l1.getZ(), l2.getZ()) + 3;

		if(distance(l1.getBlockX(), location.getBlockX()) > distanceX || distance(l2.getBlockX(), location.getBlockX()) > distanceX){
			return false; /* On en d�duit que le point X n'est pas dans la zone : on retourne faux */
		}
		if(distance(l1.getBlockY(), location.getBlockY()) > distanceY || distance(l2.getBlockY(), location.getBlockY()) > distanceY){
			return false; 
		}
		if(distance(l1.getBlockZ(), location.getBlockZ()) > distanceZ || distance(l2.getBlockZ(), location.getBlockZ()) > distanceZ){
			return false; 
		}
		return true; /* La position semble �tre entre l1 et l2, on retourne vrai */
	}
	public boolean isInSelection(Location location){
		return isBetween(location);
	}
}
