package com.lelann.multiworld.utils;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

public class ItemType {
	private Material material;
	private int data;
	
	public ItemType(Material material, int data){
		this.material = material;
		this.data = data;
	}
	public Material getMaterial(){
		return material;
	}
	public int getData(){
		return data;
	}
	@SuppressWarnings("deprecation")
	public boolean is(ItemStack item){
		ItemStack is = item.clone();
		Material m = Material.getMaterial(is.getTypeId());
	    if(m.isBlock() || m.getMaxDurability() < 1){}
	    else if(is.getDurability() == 0){} else {
	    	 is.setDurability((short)0);
	    }
		return is.getType() == material && is.getData().getData() == data;
	}
	@Override
	public boolean equals(Object o){
		if(!(o instanceof ItemType))
			return false;
		else {
			ItemType it = (ItemType) o;
			return it.data == data && it.material == material;
		}
	}
}
