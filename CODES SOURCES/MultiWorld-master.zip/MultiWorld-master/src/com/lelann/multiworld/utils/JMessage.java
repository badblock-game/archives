package com.lelann.multiworld.utils;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

import com.lelann.multiworld.utils.json.JSON;
import com.lelann.multiworld.utils.json.element.JObject;

public class JMessage {
	public static JObject loadJMessage(String msg){
		return createJObject(getColors(ChatUtils.colorReplace(msg)));
	}
	public static JObject addHoverEvent(JObject obj, HoverEventType type, String value, boolean parseValue){
		if(type == null || value == null){
			obj.set("hoverEvent", null);
		} else {
			obj.set("hoverEvent.action", type.name().toLowerCase());
			obj.set("hoverEvent.value", parseValue ? loadJMessage(value) : value);
		}
		return obj;
	}
	public static JObject addHoverEvent(JObject obj, HoverEventType type, String value){
		return addHoverEvent(obj, type, value, true);
	}
	public static JObject addClickEvent(JObject obj, ClickEventType type, String value, boolean parseValue){
		if(type == null || value == null){
			obj.set("clickEvent", null);
		} else {
			obj.set("clickEvent.action", type.name().toLowerCase());
			obj.set("clickEvent.value", parseValue ? loadJMessage(value) : value);
		}
		return obj;
	}
	public static JObject addClickEvent(JObject obj, ClickEventType type, String value){
		return addClickEvent(obj, type, value, true);
	}
	public static void sendMessage(Player p, JObject obj){
		Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "tellraw " + p.getName() + " " + obj.toString());
	}
	private static JObject createJObject(String[] msgs){
		JObject result = JSON.loadFromString("{}");
		String part = msgs[0];
		ChatColor theColor = null;
		String message = null;
		if(part.length() >= 2){
			String color = part.substring(0, 2);
			theColor = ChatColor.getByChar(color.toCharArray()[1]);
			message = part.substring(2);
		} else {
			message = part;
		}

		if(theColor == null){
			JObject theObject = JSON.loadFromString("{}");
			theObject.set("text", message);
			
			result = theObject;
		} else {
			JObject theObject = JSON.loadFromString("{}");
			theObject.set("text", message);
			String colorName = theColor.name().toLowerCase();
			if(colorName.equals("magic"))
				colorName = "obfuscated";
			
			if(theColor.isColor())
				theObject.set("color", colorName);
			else 
				theObject.set(colorName, "true");
			result = theObject;
		}
		
		if(msgs.length > 1){
			String[] others = new String[msgs.length - 1];
			for(int i=1;i<msgs.length;i++){
				others[i - 1] = msgs[i];
			}
			result.getArray("extra").add(createJObject(others));
		}
		return result;
	}
	private static String[] getColors(String msg){
		boolean waitingColor = false;
		List<String> msgs = new ArrayList<String>();
		String lastMsg = "";

		for(char c : msg.toCharArray()){
			if(waitingColor){
				ChatColor color = ChatColor.getByChar(c);
				if(color != null){
					if(!lastMsg.isEmpty())
						msgs.add(lastMsg);
					lastMsg = "�" + c;
				} else {
					lastMsg += "�" + c;
				}
				waitingColor = false;
			} else if(c == '�'){
				waitingColor = true;
			} else {
				lastMsg += c;
			}
		}
		msgs.add(lastMsg);
		return msgs.toArray(new String[0]);
	}
	
	public enum HoverEventType{
		SHOW_TEXT,
		SHOW_ACHIEVEMENT,
		SHOW_ITEM;
	}
	public enum ClickEventType{
		OPEN_URL,
		OPEN_FILE,
		RUN_COMMAND,
		SUGGEST_COMMAND;
	}
}
