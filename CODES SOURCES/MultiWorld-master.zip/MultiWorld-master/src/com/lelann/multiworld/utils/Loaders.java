package com.lelann.multiworld.utils;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.FireworkEffect;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BookMeta;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.inventory.meta.FireworkEffectMeta;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.inventory.meta.MapMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.material.MaterialData;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import com.lelann.multiworld.utils.json.JSON;
import com.lelann.multiworld.utils.json.element.JElementLoader;
import com.lelann.multiworld.utils.json.element.JObject;

public class Loaders {
	public Loaders(){
		Class<?> c = null;
		try {
			c = Class.forName("org.bukkit.craftbukkit." + Bukkit.getBukkitVersion() + ".inventory.CraftItemStack");
		} catch (ClassNotFoundException e1) {}
		if(c != null)
		JElementLoader.setLoader(c, new JElementLoader(){
			@Override
			public JObject save(Object o) {
				return JElementLoader.getLoader(ItemStack.class).save(o);
			}

			@Override
			public Object load(JObject o) {
				return JElementLoader.getLoader(ItemStack.class).load(o);
			}
		});
		JElementLoader.setLoader(ItemType.class, new JElementLoader(){
			@Override
			public JObject save(Object o) {
				JObject jo = JSON.loadFromString("{}");
				ItemType it = (ItemType) o;
				
				jo.set("type", it.getMaterial().name());
				jo.set("data", it.getData());
				
				return jo;
			}

			@Override
			public Object load(JObject o) {
				Material material = Material.matchMaterial(o.getString("type"));
				byte data = (byte) o.getInt("data");
				
				return new ItemType(material, data);
			}
		});
		
		JElementLoader.setLoader(ItemStack.class, new JElementLoader(){
			@SuppressWarnings("deprecation")
			@Override
			public JObject save(Object o) {
				JObject jo = JSON.loadFromString("{}");
				if(o == null){
					jo.set("type", "AIR");
					return jo;
				}
				ItemStack is = (ItemStack) o;
				
				Material type = is.getType();
				int amount = is.getAmount();
				String displayName = is.getItemMeta() == null ? null : is.getItemMeta().getDisplayName();
				List<String> lore = is.getItemMeta() == null ? null : is.getItemMeta().getLore();
				Map<Enchantment, Integer> enchantments = is.getEnchantments();
				Map<String, Integer> enchantmentsStr = new LinkedHashMap<String, Integer>();
				for(Enchantment e : enchantments.keySet()){
					enchantmentsStr.put(e.getName(), enchantments.get(e));
				}
				int durability = is.getDurability();
				
				Material material = Material.getMaterial(is.getTypeId());
			    if(material.isBlock() || material.getMaxDurability() < 1){}
			    else if(is.getDurability() == 0){} else {
			    	 is.setDurability((short)0);
			    }
			    byte data = is.getData().getData();
			    
			    jo.set("type", type);
				jo.set("data", (int)data);
				jo.set("displayName", displayName);
				jo.set("amount", amount);
				jo.set("lore", lore);
				jo.set("durability", durability);
				jo.set("enchantments", enchantmentsStr);
				
				ItemMeta im = is.getItemMeta();
				if(im instanceof BookMeta){
					BookMeta bm = (BookMeta) im;
					jo.set("meta.pages", bm.getPages());
					jo.set("meta.author", bm.getAuthor());
					jo.set("meta.title", bm.getTitle());
				} else if(im instanceof EnchantmentStorageMeta){
					EnchantmentStorageMeta esm = (EnchantmentStorageMeta) im;
					
					enchantments = esm.getStoredEnchants();
					enchantmentsStr = new LinkedHashMap<String, Integer>();
					for(Enchantment e : enchantments.keySet()){
						enchantmentsStr.put(e.getName(), enchantments.get(e));
					}
					
					jo.set("meta.enchantments", enchantmentsStr);
				} else if(im instanceof FireworkEffectMeta){
					FireworkEffectMeta fem = (FireworkEffectMeta) im;
					jo.set("meta", fem.getEffect());
				} else if(im instanceof FireworkMeta){
					FireworkMeta fm = (FireworkMeta) im;
					jo.set("meta.effects", fm.getEffects());
					jo.set("meta.power", fm.getPower());
				} else if(im instanceof LeatherArmorMeta){
					LeatherArmorMeta lam = (LeatherArmorMeta) im;
					jo.set("meta.color", lam.getColor());
				} else if(im instanceof MapMeta){
					MapMeta mm = (MapMeta) im;
					jo.set("meta.scaling", mm.isScaling());
				} else if(im instanceof PotionMeta){
					PotionMeta pm = (PotionMeta) im;
					jo.set("meta.effects", pm.getCustomEffects());
				} else if(im instanceof SkullMeta){
					SkullMeta sm = (SkullMeta) im;
					jo.set("meta.owner", sm.getOwner());
				}
				
				return jo;
			}

			@SuppressWarnings("deprecation")
			@Override
			public Object load(JObject o) {
				if(!o.contains("type"))
					return new ItemStack(Material.AIR);
				Material type = Material.matchMaterial(o.getString("type"));
				if(type == Material.AIR || type == null)
					return new ItemStack(Material.AIR);
				byte data = (byte)o.getInt("data");
				String displayName = o.getString("displayName");
				int amount = o.getInt("amount");
				List<String> lore = o.getStringList("lore");
				short durability = o.getShort("durability");
				Map<Enchantment, Integer> enchantments = new HashMap<Enchantment, Integer>();
				for(String s : o.getObject("enchantments").getValues().keySet()){
					Enchantment e = Enchantment.getByName(s);
					if(e == null){
						try{
							e = Enchantment.getById(Integer.parseInt(s));
						}catch(Exception unused){}
					}
					if(e != null)
						enchantments.put(e, o.getInt("enchantments." + s));
				}
				
				ItemStack result = new MaterialData(type, data).toItemStack(amount);
				result.setDurability(durability);
				
				ItemMeta im = result.getItemMeta();
					im.setLore(lore);
					im.setDisplayName(displayName);
				if(o.contains("meta")) {
					if(im instanceof BookMeta){
						BookMeta bm = (BookMeta) im;
						List<String> pages = o.getStringList("meta.pages");
						String author = o.getString("meta.author");
						String title = o.getString("meta.title");
						
						bm.setPages(pages);
						bm.setAuthor(author);
						bm.setTitle(title);
						
						result.setItemMeta(bm);
					} else if(im instanceof EnchantmentStorageMeta){
						EnchantmentStorageMeta esm = (EnchantmentStorageMeta) im;
						
						for(String s : o.getObject("meta.enchantments").getValues().keySet()){
							Enchantment e = Enchantment.getByName(s);
							if(e == null){
								try{
									e = Enchantment.getById(Integer.parseInt(s));
								}catch(Exception unused){}
							}
							if(e != null)
								esm.addStoredEnchant(e, o.getInt("meta.enchantments." + s), true);
						}
						result.setItemMeta(esm);
					} else if(im instanceof FireworkEffectMeta){
						FireworkEffectMeta fem = (FireworkEffectMeta) im;
						fem.setEffect(JSON.saveAsObject(o.getObject("meta"), FireworkEffect.class));
						result.setItemMeta(fem);
					} else if(im instanceof FireworkMeta){
						FireworkMeta fm = (FireworkMeta) im;
							fm.addEffects(o.getArray("meta.effects").getList(FireworkEffect.class));
							fm.setPower(o.getInt("meta.power"));
						
						result.setItemMeta(fm);
					} else if(im instanceof LeatherArmorMeta){
						LeatherArmorMeta lam = (LeatherArmorMeta) im;
							lam.setColor(JSON.saveAsObject(o.getObject("meta.color"), Color.class));
						result.setItemMeta(lam);
					} else if(im instanceof MapMeta){
						MapMeta mm = (MapMeta) im;
							mm.setScaling(o.getBoolean("meta.scaling"));
						result.setItemMeta(mm);
					} else if(im instanceof PotionMeta){
						PotionMeta pm = (PotionMeta) im;
						for(PotionEffect pe : o.getArray("meta.effects").getList(PotionEffect.class)){
							pm.addCustomEffect(pe, true);
						}
						
						result.setItemMeta(pm);
					} else if(im instanceof SkullMeta){
						SkullMeta sm = (SkullMeta) im;
						sm.setOwner(o.getString("meta.owner"));
						
						result.setItemMeta(sm);
					} else result.setItemMeta(im);
				} else result.setItemMeta(im);
				result.addEnchantments(enchantments);
				
				return result;
			}
			
		});
		JElementLoader.setLoader(PotionEffect.class, new JElementLoader(){

			@Override
			public JObject save(Object o) {
				PotionEffect pe = (PotionEffect) o;
				JObject obj = JSON.loadFromString("{}");
				
				obj.set("amplifier", pe.getAmplifier());
				obj.set("duration", pe.getDuration());
				obj.set("type", pe.getType());
				obj.set("ambient", pe.isAmbient());
				
				return obj;
			}

			@Override
			public Object load(JObject o) {
				try{
					PotionEffect pe = new PotionEffect(
						JSON.saveAsObject(o.getObject("type"), PotionEffectType.class),
						o.getInt("duration"),
						o.getInt("amplifier"),
						o.getBoolean("ambient")
						);
					return pe;
				} catch(Exception e){}
				return null;
			}
			
		});
		JElementLoader.setLoader(Color.class, new JElementLoader(){

			@Override
			public JObject save(Object o) {
				Color c = (Color)o;
				JObject jo = JSON.loadFromString("{}");
				
				jo.set("r", c.getRed());
				jo.set("g", c.getGreen());
				jo.set("b", c.getBlue());

				return jo;
			}

			@Override
			public Object load(JObject o) {
				Color c = Color.fromRGB(o.getInt("r"), o.getInt("g"), o.getInt("b"));
				return c;
			}
			
		});
		JElementLoader.setLoader(FireworkEffect.class, new JElementLoader(){
			@Override
			public JObject save(Object o) {
				JObject jo = JSON.loadFromString("{}");
				FireworkEffect effect = (FireworkEffect) o;
					jo.set("colors", effect.getColors());
					jo.set("fadecolors", effect.getFadeColors());
					jo.set("effect", effect.getType().name());
				
				return jo;
			}

			@Override
			public Object load(JObject o) {
				FireworkEffect.Builder builder = FireworkEffect.builder();
				builder.withColor(o.getArray("colors").getList(Color.class));
				builder.withFade(o.getArray("fadecolors").getList(Color.class));
				builder.with(FireworkEffect.Type.valueOf(o.getString("effect")));
			
				return builder.build();
			}
			
		});
		JElementLoader.setLoader(Location.class, new JElementLoader(){

			@Override
			public JObject save(Object o) {
				JObject jo = JSON.loadFromString("{}");
				Location loc = (Location)o;
				
				jo.set("world", loc.getWorld().getName());
				jo.set("x", loc.getX());
				jo.set("y", loc.getY());
				jo.set("z", loc.getZ());
				jo.set("yaw", loc.getYaw());
				jo.set("pitch", loc.getPitch());
				
				return jo;
			}

			@Override
			public Object load(JObject o) {
				String worldName = o.getString("world");
				if(worldName == null) return null;
				World w = Bukkit.getWorld(worldName);
				if(w == null) return null;
				
				return new Location(w, o.getDouble("x"), o.getDouble("y"), o.getDouble("z"), o.getFloat("yaw"), o.getFloat("pitch"));
			}
			
		});
	}
}
