package com.lelann.multiworld.listener;

import org.bukkit.Material;
import org.bukkit.block.BlockState;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockFromToEvent;
import org.bukkit.event.block.BlockPhysicsEvent;
import org.bukkit.event.entity.EntityCreatePortalEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;

import com.lelann.multiworld.portals.Portal;
import com.lelann.multiworld.portals.PortalsManager;
import com.lelann.multiworld.portals.RandomPortal;

public class MultiPortalListener implements Listener {
	@EventHandler
	public void onMove(PlayerMoveEvent e){
		if(isSame(e.getTo().getX(), e.getFrom().getX())
				&& isSame(e.getTo().getY(), e.getFrom().getY())
				&& isSame(e.getTo().getZ(), e.getFrom().getZ())){
			return;
		}
		Portal p = PortalsManager.getInstance().getPortal(e.getTo());
		if(p != null){
			p.teleport(e.getPlayer());
		}
	}
	
	@EventHandler
	public void onJoin(PlayerJoinEvent e){
		Portal p = PortalsManager.getInstance().getPortal(e.getPlayer().getLocation());
		if(p != null){
			e.getPlayer().teleport(e.getPlayer().getLocation().getWorld().getSpawnLocation());
		}
	}
	
	@EventHandler
	public void onPortalCreate(EntityCreatePortalEvent e){
		if(e.isCancelled()) {
			return;
		}
		boolean cancel = false;
		for(BlockState b : e.getBlocks()){
			Portal p = PortalsManager.getInstance().getPortal(b.getBlock().getLocation());
			if(p != null){
				cancel = true; break;
			}
		}
		if(cancel) e.setCancelled(true);
	}
	
	@EventHandler
	public void onWaterOrLavaFlow(BlockFromToEvent e){
		if(e.isCancelled()) {
			return;
		}
		Portal p = PortalsManager.getInstance().getPortal(e.getBlock().getLocation());

		if(p != null){
			Portal p2 = PortalsManager.getInstance().getPortal(e.getToBlock().getLocation());
			if(p2 == null) e.setCancelled(true);
			else if(!p2.getName().equals(p.getName())) e.setCancelled(true);
		}
	}

	@EventHandler
	public void blockPhysics(BlockPhysicsEvent e) {
		if(e.isCancelled()) {
			return;
		}
		if((e.getChangedType() == Material.PORTAL) || (e.getBlock().getType() == Material.PORTAL)){
			Portal p = PortalsManager.getInstance().getPortal(e.getBlock().getLocation());
			if(p != null)
				e.setCancelled(true);
		}
	}

	@EventHandler
	public void onDamage(EntityDamageEvent e){
		if(e.getEntityType() == EntityType.PLAYER){
			Player p = (Player) e.getEntity();
			if(RandomPortal.getToProtectPlayers().contains(p.getUniqueId())){
				e.setCancelled(true);
			}
		}
	}

	public boolean isSame(double first, double second){
		return ((int) first == (int) second);
	}
}
