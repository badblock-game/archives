package com.lelann.multiworld.listener;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.ExplosionPrimeEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.weather.WeatherChangeEvent;

import com.lelann.multiworld.utils.CreatureType;
import com.lelann.multiworld.worlds.MultiWorld;
import com.lelann.multiworld.worlds.MultiWorldManager;

public class MultiListener implements Listener {
	private MultiWorldManager m = MultiWorldManager.getInstance();
	@EventHandler
	public void onLostFood(FoodLevelChangeEvent e){
		if(e.getEntity() instanceof Player){
			if(e.getFoodLevel() < 20){
				MultiWorld world = m.getWorld(e.getEntity());
				if(world == null) return;
				if(!world.canPlayerLosterFood())
					e.setFoodLevel(20);
			}
		}
	}
	@EventHandler
	public void onChangeWorld(PlayerTeleportEvent e){
		MultiWorld world = m.getWorld(e.getTo());
		if(world == null) return;

		if(e.getTo().equals(e.getTo().getWorld().getSpawnLocation())){
			e.setTo(world.getSpawn());
		}
	}

	@EventHandler
	public void onPlaceBlock(BlockPlaceEvent e){
		MultiWorld world = m.getWorld(e.getBlock());
		if(world == null) return;	
		if(!e.getPlayer().isOp() && !world.isBuild()){
			e.setCancelled(true);
		}
	}
	
	@EventHandler
	public void onBukkitFill(PlayerBucketFillEvent e){
		MultiWorld world = m.getWorld(e.getBlockClicked());
		if(world == null) return;	
		if(!e.getPlayer().isOp() && !world.isBuild()){
			e.setCancelled(true);
		}
	}
	
	@EventHandler
	public void onBukkitEmpty(PlayerBucketEmptyEvent e){
		MultiWorld world = m.getWorld(e.getBlockClicked());
		if(world == null) return;	
		if(!e.getPlayer().isOp() && !world.isBuild()){
			e.setCancelled(true);
		}
	}
	
	@EventHandler
	public void onChangeBlock(EntityChangeBlockEvent e){
		MultiWorld world = m.getWorld(e.getBlock());
		if(world == null) return;
		
		CreatureType creature = CreatureType.getByBukkit(e.getEntityType());
		if(creature != null && !world.isMobGrief()){ // if is a mob
			e.setCancelled(true);
		}
	}
	
	@EventHandler
	public void onExplosion(EntityExplodeEvent e){
		if(e.getEntityType() == EntityType.WITHER || e.getEntityType() == EntityType.ENDER_DRAGON || e.getEntityType() == EntityType.FIREBALL){
			MultiWorld world = m.getWorld(e.getEntity());
			if(world == null) return;	
			if(!world.isMobGrief()){
				e.setCancelled(true);
			}
		} else if(e.getEntityType() == EntityType.WITHER_SKULL){
			MultiWorld world = m.getWorld(e.getEntity());
			if(world == null) return;	
			if(!world.isWitherSpawn()){
				e.setCancelled(true);
			}
		} else if(e.getEntityType() == EntityType.CREEPER){
			MultiWorld world = m.getWorld(e.getEntity());
			if(world == null) return;	
			if(!world.isCreeperExplosions()){
				e.setCancelled(true);
			}
		} else if(e.getEntityType() == EntityType.PRIMED_TNT || e.getEntityType() == EntityType.MINECART_TNT){
			MultiWorld world = m.getWorld(e.getEntity());
			if(world == null) return;	
			if(!world.isTntExplosions()){
				e.setCancelled(true);
			}
		}
	}
	
	@EventHandler
	public void onExplosion(ExplosionPrimeEvent e){
		if(e.getEntityType() == EntityType.WITHER || e.getEntityType() == EntityType.FIREBALL){
			MultiWorld world = m.getWorld(e.getEntity());
			if(world == null) return;	
			if(!world.isMobGrief()){
				e.setCancelled(true);
			}
		} else if(e.getEntityType() == EntityType.WITHER_SKULL){
			MultiWorld world = m.getWorld(e.getEntity());
			if(world == null) return;	
			if(!world.isWitherSpawn()){
				e.setCancelled(true);
			}
		} else if(e.getEntityType() == EntityType.CREEPER){
			MultiWorld world = m.getWorld(e.getEntity());
			if(world == null) return;	
			if(!world.isCreeperExplosions()){
				e.setCancelled(true);
			}
		} else if(e.getEntityType() == EntityType.PRIMED_TNT || e.getEntityType() == EntityType.MINECART_TNT){
			MultiWorld world = m.getWorld(e.getEntity());
			if(world == null) return;	
			if(!world.isTntExplosions()){
				e.setCancelled(true);
			}
		}
	}

	@EventHandler
	public void onBreakBlock(BlockBreakEvent e){
		MultiWorld world = m.getWorld(e.getBlock());
		if(world == null) return;	
		if(!e.getPlayer().isOp() && !world.isBuild()){
			e.setCancelled(true);
		}
	}

	@EventHandler
	public void onInteract(PlayerInteractEvent e){
		if(e.getAction() == Action.RIGHT_CLICK_AIR || e.getAction() == Action.RIGHT_CLICK_BLOCK){
			if(e.getItem() != null && e.getItem().getType() == Material.ENDER_PEARL){
				MultiWorld world = m.getWorld(e.getPlayer().getLocation());
				if(world == null) return;	
				if(!e.getPlayer().isOp() && !world.isBuild()){
					e.setCancelled(true);
				}
			}
		}
	}

	@EventHandler
	public void onCreatureSpawn(CreatureSpawnEvent e){
		if(e.getSpawnReason() != SpawnReason.SPAWNER && e.getSpawnReason() != SpawnReason.SPAWNER_EGG && e.getSpawnReason() != SpawnReason.CUSTOM){
			MultiWorld world = m.getWorld(e.getLocation());
			if(world == null) return;
			CreatureType creature = CreatureType.getByBukkit(e.getEntityType());
			
			if(creature == null) return;
			if(creature.isHostile() && !world.areMonstersAllowed())
				e.setCancelled(true);
			else if(!world.isWitherSpawn() && e.getEntityType() == EntityType.WITHER)
				e.setCancelled(true);
			else if(creature.isFriendly() && !world.areAnimalsAllowed()) 
				e.setCancelled(true);
		}
	}
	
	@EventHandler
	public void onWeatherChange(WeatherChangeEvent e){
		if(e.toWeatherState()){
			MultiWorld world = m.getWorld(e.getWorld());
			if(world == null) return;	
			if(!world.isWeatherAllowed())
				e.setCancelled(true);
		}
	}
	
	@EventHandler
	public void onUseCommand(PlayerCommandPreprocessEvent e){
		MultiWorld world = m.getWorld(e.getPlayer().getLocation());
		if(world == null || world.getForbiddenCommands().isEmpty()) return;

		String[] cmds = e.getMessage().toLowerCase().split(" ");
		
		for(final String cmd : world.getForbiddenCommands()){
			int i = 0;
			for(String c : cmd.split(" ")){
				if(cmds.length > i && cmds[i].equals(c)){
					e.getPlayer().sendMessage(ChatColor.RED + "Vous ne pouvez pas utiliser cette commande ici !");
					e.setCancelled(true); return;
				}
			}
		}
	}
}
