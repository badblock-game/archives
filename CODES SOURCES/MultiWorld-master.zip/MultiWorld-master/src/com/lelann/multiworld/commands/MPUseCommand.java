package com.lelann.multiworld.commands;

import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import com.lelann.multiworld.portals.Portal;
import com.lelann.multiworld.portals.PortalsManager;

public class MPUseCommand extends SubCommand {
	public MPUseCommand() {
		super("forceuse", "multiworld.portals.forceuse", "%gold%/mwp forceuse %aqua%<portal> <player>", 
				"%gold%Permet de forcer un joueur � utiliser un portail."
				, "/mwp forceuse <portal> <player>", null);
	}

	@Override
	public void runCommand(CommandSender sender, String[] args) {
		if(args.length < 2){
			sendHelp(sender);
			return;
		}
		
		PortalsManager m = PortalsManager.getInstance();
		Portal p = m.getPortal(args[0]);
	
		if(p == null){
			sendMessage(sender, "%red%Le portail '" + args[0] + "' n'existe pas !");
		} else {
			Player player = Bukkit.getPlayer(args[1]);
			if(player == null){
				sendMessage(sender, "%red%Le joueur est introuvable.");
			} else {
				p.preSend(player);
				if(sender instanceof Player)
					sendMessage(sender, "%green%Le joueur a bien �t� envoy� !");
			}
		}
	}
}