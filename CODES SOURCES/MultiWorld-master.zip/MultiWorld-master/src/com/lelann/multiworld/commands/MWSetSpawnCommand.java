package com.lelann.multiworld.commands;

import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import com.lelann.multiworld.worlds.MultiWorld;
import com.lelann.multiworld.worlds.MultiWorldManager;

public class MWSetSpawnCommand extends SubCommand {
	public MWSetSpawnCommand() {
		super("setspawn", "multiworld.setspawn", "%gold%/mw %aqua%setspawn", 
				"%gold%D�finit le spawn (Bukkit et MultiWorld) du monde dans lequel %red%vous �tes%gold%."
				, "/mw setspawn", null);
	}

	@Override
	public void runCommand(CommandSender sender, String[] args) {
		MultiWorldManager m = MultiWorldManager.getInstance();
		if(!(sender instanceof Player)){
			sendMessage(sender, "%red%Cette commande est reserv�e aux joueurs.");
		} else {
			Player player = (Player) sender;
			MultiWorld mw = m.getWorld(player);

			if(mw == null)
				player.getWorld().setSpawnLocation((int)player.getLocation().getX(), (int)player.getLocation().getY(), (int)player.getLocation().getZ());
			else mw.setSpawnLocation(player.getLocation());
			m.saveLoadedWorlds();
			sendMessage(sender, "%green%Spawn du monde '" + player.getWorld().getName() + "' d�finit !");
		}
	}
}