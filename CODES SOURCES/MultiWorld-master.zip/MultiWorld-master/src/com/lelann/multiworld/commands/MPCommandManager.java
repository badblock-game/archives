package com.lelann.multiworld.commands;

import java.util.LinkedHashMap;
import java.util.Map;

import org.bukkit.command.CommandSender;

import com.lelann.multiworld.utils.ChatUtils;

public class MPCommandManager {
	private static MPCommandManager instance;
	public static MPCommandManager getInstance(){
		return instance;
	}
	
	private Map<String, SubCommand> subCommands;
	
	public void addCommand(SubCommand command){
		subCommands.put(command.getName().toLowerCase(), command);
	}
	public void sendHelp(CommandSender sender){
		ChatUtils.sendMessagePlayer(sender, "%red%- MultiWorld Badblock : liste des commandes -");
		for(SubCommand command : subCommands.values())
			command.sendHelp(sender);
	}
	public void useCommand(CommandSender sender, String[] args){
		if(args.length == 0){
			sendHelp(sender);
			return;
		}
		
		SubCommand command = subCommands.get(args[0].toLowerCase());
		if(command == null){
			sendHelp(sender);
		} else if(!command.hasPermission(sender)){
			ChatUtils.sendMessagePlayer(sender, "%red%Vous n'avez pas la permission d'utiliser cette commande !");
		} else {
			String[] otherArgs = new String[args.length - 1];
			for(int i=1;i<args.length;i++)
				otherArgs[i-1] = args[i];
			command.runCommand(sender, otherArgs);
		}
	}
	public MPCommandManager(){
		instance = this;
		subCommands = new LinkedHashMap<String, SubCommand>();
		addCommand(new MPCreateCommand());
		addCommand(new MPRemoveCommand());
		addCommand(new MPSetDestinationCommand());
		addCommand(new MPSetPermissionCommand());
		addCommand(new MPListCommand());
		addCommand(new MPUseCommand());
	}
}
