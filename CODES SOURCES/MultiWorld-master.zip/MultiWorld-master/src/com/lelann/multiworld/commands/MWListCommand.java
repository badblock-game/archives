package com.lelann.multiworld.commands;

import org.bukkit.World;
import org.bukkit.command.CommandSender;

public class MWListCommand extends SubCommand {
	public MWListCommand() {
		super("list", "multiworld.list", "%gold%/mw list", 
				"%gold%Permet de voir la liste des mondes %red%charg�s%gold%."
				, null, "/mw list");
	}

	@Override
	public void runCommand(CommandSender sender, String[] args) {
		String msg = "%gold%Les mondes activ�s (%red%" + getServer().getWorlds().size() + "%gold%) sont :";
		for(World w : getServer().getWorlds()){
			msg += ";%red%- %gold%" + w.getName();
		}
		
		sendMessage(sender, msg);
	}
}