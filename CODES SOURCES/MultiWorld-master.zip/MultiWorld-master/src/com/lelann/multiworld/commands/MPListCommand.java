package com.lelann.multiworld.commands;

import org.bukkit.command.CommandSender;

import com.lelann.multiworld.portals.Portal;
import com.lelann.multiworld.portals.PortalsManager;

public class MPListCommand extends SubCommand {

	public MPListCommand() {
		super("list", "multiworld.portals.list", "%gold%/mwp list", 
				"%gold%Permet de voir la liste des %red%portails%gold%."
				, null, "/mwp list");
	}

	@Override
	public void runCommand(CommandSender sender, String[] args) {
		String msg = "%gold%Les portails (%red%" + PortalsManager.getInstance().getPortals().length + "%gold%) sont : ";
		int number = 0;
		for(Portal p : PortalsManager.getInstance().getPortals()){
			if(number % 2 == 0)
				if(number != 0)
				 msg += "%red%, " + p.getName();
				else msg += "%red%" + p.getName();
			else msg += "%aqua%, " + p.getName();
			
			number++;
		}
		
		sendMessage(sender, msg);
	}
}