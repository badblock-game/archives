package com.lelann.multiworld.commands;

import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import com.lelann.multiworld.worlds.MultiWorldManager;

public class MWTPCommand extends SubCommand {

	public MWTPCommand() {
		super("tp", "multiworld.tp", "%gold%/mw tp %aqua%<world> %gold%(%aqua%<player>%gold%)", 
				"%gold%T�l�porte le joueur %red%<player> %gold%(ou vous si non pr�cis�) %gold%dans le monde %red%<world>%gold%."
				, "/mw tp <world> (<player>)", null);
	}

	@Override
	public void runCommand(CommandSender sender, String[] args) {
		if(args.length < 1){
			sendHelp(sender);
			return;
		}
		MultiWorldManager m = MultiWorldManager.getInstance();
		World w = m.getBukkitWorld(args[0]);
		if(w == null){
			sendMessage(sender, "%red%Le monde '" + args[0] + "' n'est pas charg� !");
			return;
		}
		Player p = null;
		if(args.length >= 2){
			p = getServer().getPlayer(args[1]);
			if(p == null){
				sendMessage(sender, "%red%Le joueur specifi� n'est pas connect� !");
				return;
			}
		} else if(!(sender instanceof Player)){
			sendMessage(sender, "%red%Vous devez �tre un joueur pour utiliser cette commande !");
			return;
		} else {
			p = (Player) sender;
		}

		sendMessage(p, "%green%T�l�portation ...");
		p.teleport(w.getSpawnLocation());

		if(!p.getName().equals(sender.getName())){
			sendMessage(p, "%green%Le joueur a �t� t�l�port� !");
		}
	}
}