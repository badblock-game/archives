package com.lelann.multiworld.commands;

import org.bukkit.World;
import org.bukkit.command.CommandSender;

import com.lelann.multiworld.worlds.MultiWorldManager;

public class MWRemoveCommand extends SubCommand {
	public MWRemoveCommand() {
		super("remove", "multiworld.remove", "%gold%/mw remove %aqua%<world>", 
				"%gold%Permet de d�sactiver le monde %red%<world> %gold%sans le %red%supprimer%gold%."
				, "/mw remove <world>", null);
	}

	@Override
	public void runCommand(CommandSender sender, String[] args) {
		if(args.length == 0){
			sendHelp(sender);
			return;
		}
		MultiWorldManager m = MultiWorldManager.getInstance();
		World w = m.getBukkitWorld(args[0]);
		String defaultWorld = getServer().getWorlds().get(0).getName();
		if(w == null){
			sendMessage(sender, "%red%Le monde '" + args[0] + "' n'est pas charg� !");
		} else if(w.getUID().equals(getServer().getWorlds().get(0).getUID()) || w.getName().equals(defaultWorld + "_nether") || w.getName().equals(defaultWorld + "_the_end")){
			sendMessage(sender, "%red%Impossible de d�sactiver un monde principal !");
		} else {
			m.removePlayersInWorld(w);
			getServer().unloadWorld(w, true);
			//		getServer().getWorlds().remove(w);

			m.saveLoadedWorlds();
			sendMessage(sender, "%green%Le monde '" + w.getName() + "' a �t� d�sactiv� !");
		}
	}
}