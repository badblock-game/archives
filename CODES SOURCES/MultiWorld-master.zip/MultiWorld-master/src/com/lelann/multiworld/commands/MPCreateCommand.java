package com.lelann.multiworld.commands;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import com.lelann.multiworld.portals.BungeePortal;
import com.lelann.multiworld.portals.CommandPortal;
import com.lelann.multiworld.portals.MultiPortal;
import com.lelann.multiworld.portals.NormalPortal;
import com.lelann.multiworld.portals.Portal;
import com.lelann.multiworld.portals.Portal.PortalType;
import com.lelann.multiworld.portals.PortalsManager;
import com.lelann.multiworld.portals.RandomPortal;
import com.sk89q.worldedit.bukkit.WorldEditPlugin;
import com.sk89q.worldedit.bukkit.selections.Selection;

public class MPCreateCommand extends SubCommand {
	public MPCreateCommand() {
		super("create", "multiworld.portals.create", "%gold%/mwp create %aqua%<name> <random|normal|multi|bungee|command>", 
				"%gold%Ajout d'un portail portant le nom %red%<name>%gold% � partir de votre s�l�ction WorldEdit (//wand)"
				, "/mwp create <name>", null);
	}

	@Override
	public void runCommand(CommandSender sender, String[] args) {
		if(args.length < 2){
			sendHelp(sender);
			return;
		}
		if(!(sender instanceof Player)){
			sendMessage(sender, "%red%Cette commande est r�serv�e aux joueurs !");
			return;
		}
		Player player = (Player) sender;
		PortalsManager m = PortalsManager.getInstance();
		Portal p = m.getPortal(args[0]);
	
		if(p != null){
			sendMessage(sender, "%red%Le portail '" + args[0] + "' existe d�j� !");
		} else {
			PortalType type = PortalType.get(args[1]);
			if(type == null){
				sendHelp(player); return;
			}
			
			WorldEditPlugin worldEdit = (WorldEditPlugin) Bukkit.getServer().getPluginManager().getPlugin("WorldEdit");
			Selection selection = worldEdit.getSelection(player);

			if (selection != null) {
				Location min = selection.getMinimumPoint();
				Location max = selection.getMaximumPoint();
				
				Portal portal = null;
				
				if(type == PortalType.NORMAL){
					 portal = new NormalPortal(args[0].toLowerCase(), new com.lelann.multiworld.utils.Selection(min, max));
				} else if(type == PortalType.RANDOM){
					 portal = new RandomPortal(args[0].toLowerCase(), new com.lelann.multiworld.utils.Selection(min, max));
				} else if(type == PortalType.BUNGEE){
					 portal = new BungeePortal(args[0].toLowerCase(), new com.lelann.multiworld.utils.Selection(min, max));
				} else if(type == PortalType.MULTI){
					 portal = new MultiPortal(args[0].toLowerCase(), new com.lelann.multiworld.utils.Selection(min, max));
				} else if(type == PortalType.COMMAND){
					 portal = new CommandPortal(args[0].toLowerCase(), new com.lelann.multiworld.utils.Selection(min, max));
				}
				
				
				m.addPortal(args[0].toLowerCase(), portal);
				m.saveLoadedPortals();
				
				sendMessage(sender, "%green%Le portail a �t� ajout� sous le nom '" + args[0].toLowerCase() + "' !");
			} else {
				sendMessage(sender, "%red%Veuillez faire une s�l�ction avec WorldEdit (//wand) !");
			}
		}
	}
}