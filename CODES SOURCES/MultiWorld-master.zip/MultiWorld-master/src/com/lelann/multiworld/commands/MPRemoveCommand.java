package com.lelann.multiworld.commands;

import org.bukkit.command.CommandSender;

import com.lelann.multiworld.portals.Portal;
import com.lelann.multiworld.portals.PortalsManager;

public class MPRemoveCommand extends SubCommand {

	public MPRemoveCommand() {
		super("remove", "multiworld.portals.remove", "%gold%/mwp remove %aqua%<portal>", 
				"%gold%Permet de supprimer le portail %red%<portal>%gold% d�finitivement."
				, "/mwp remove <portal>", null);
	}

	@Override
	public void runCommand(CommandSender sender, String[] args) {
		if(args.length == 0){
			sendHelp(sender);
			return;
		}
		PortalsManager m = PortalsManager.getInstance();
		Portal p = m.getPortal(args[0]);
	
		if(p == null){
			sendMessage(sender, "%red%Le portail '" + args[0] + "' n'existe pas !");
		} else {
			m.removePortal(p.getName());
			m.saveLoadedPortals();
			sendMessage(sender, "%green%Le portail '" + args[0] + "' a été supprimé !");
		}
	}
}