package com.lelann.multiworld.commands;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import com.lelann.multiworld.portals.BungeePortal;
import com.lelann.multiworld.portals.CommandPortal;
import com.lelann.multiworld.portals.MultiPortal;
import com.lelann.multiworld.portals.NormalPortal;
import com.lelann.multiworld.portals.Portal;
import com.lelann.multiworld.portals.Portal.PortalType;
import com.lelann.multiworld.portals.PortalsManager;
import com.lelann.multiworld.portals.RandomPortal;
import com.sk89q.worldedit.bukkit.WorldEditPlugin;
import com.sk89q.worldedit.bukkit.selections.Selection;

public class MPSetDestinationCommand extends SubCommand {

	public MPSetDestinationCommand() {
		super("setdestination", "multiworld.portals.setdestination", "%gold%/mwp setdestination %aqua%<portal>", 
				"%gold%Permet de d�finir la destination du portail %red%<portal>%gold% � l'endroit o� vous �tes."
				, "/mwp setdestination <portal>", null);
	}

	@Override
	public void runCommand(CommandSender sender, String[] args) {
		if(args.length == 0){
			sendHelp(sender);
			return;
		}
		if(!(sender instanceof Player)){
			sendMessage(sender, "%red%Cette commande est r�serv�e aux joueurs !");
			return;
		}
		Player player = (Player) sender;
		PortalsManager m = PortalsManager.getInstance();
		Portal p = m.getPortal(args[0]);
	
		if(p == null){
			sendMessage(sender, "%red%Le portail '" + args[0] + "' n'existe pas !");
		} else {
			if(p.getType() == PortalType.NORMAL){
				NormalPortal np = (NormalPortal) p;
				np.setDestination(player.getLocation());
			} else if(p.getType() == PortalType.MULTI){
				MultiPortal mp = (MultiPortal) p;
				mp.getDestinations().add(player.getLocation());
			} else if(p.getType() == PortalType.RANDOM){
				RandomPortal rp = (RandomPortal) p;
				WorldEditPlugin worldEdit = (WorldEditPlugin) Bukkit.getServer().getPluginManager().getPlugin("WorldEdit");
				Selection selection = worldEdit.getSelection(player);

				if (selection != null) {
					Location min = selection.getMinimumPoint();
					Location max = selection.getMaximumPoint();

					rp.setDestination(new com.lelann.multiworld.utils.Selection(min, max));
				} else {
					sendMessage(sender, "%red%Veuillez faire une s�l�ction avec WorldEdit (//wand) !"); return;
				}
			} else if(p.getType() == PortalType.BUNGEE){
				BungeePortal rp = (BungeePortal) p;
				if(args.length < 2){
					sendMessage(sender, "&cVeuillez pr�ciser le serveur !");
				} else {
					rp.setDestination(args[1]);
				}
			} else if(p.getType() == PortalType.COMMAND){
				CommandPortal rp = (CommandPortal) p;
				if(args.length < 2){
					sendMessage(sender, "&cVeuillez pr�ciser la commande ! Commencez-l� par p: pour faire une commande execut�e par le joueur.");
				} else {
					rp.getCommands().add(args[1].replace("_", " "));
				}
			}
			
			m.saveLoadedPortals();
			sendMessage(sender, "%green%La destination du portail '" + args[0] + "' a �t� d�finie !");
		}
	}
}