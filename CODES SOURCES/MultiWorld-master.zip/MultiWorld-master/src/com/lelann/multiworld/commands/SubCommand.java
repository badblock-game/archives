package com.lelann.multiworld.commands;

import org.bukkit.Bukkit;
import org.bukkit.Server;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import com.lelann.multiworld.utils.ChatUtils;
import com.lelann.multiworld.utils.JMessage;
import com.lelann.multiworld.utils.JMessage.ClickEventType;
import com.lelann.multiworld.utils.JMessage.HoverEventType;
import com.lelann.multiworld.utils.json.element.JObject;

public abstract class SubCommand {
	private JObject message;
	private String messageConsole, name, permission;

	public String getName(){
		return name;
	}
	public Server getServer(){
		return Bukkit.getServer();
	}
	public boolean hasPermission(CommandSender sender){
		return sender.hasPermission("multiworld.*")
					|| (sender.hasPermission("multiworld.portals.*") && permission.startsWith("multiworld.portals"))
					|| sender.isOp()
					|| sender.hasPermission("*")
					|| sender.hasPermission(permission);
	}
	public void sendHelp(CommandSender sender){
		if(sender instanceof Player){
			JMessage.sendMessage((Player) sender, message);
		} else ChatUtils.sendMessagePlayer(sender, messageConsole);
	}
	protected void sendMessage(CommandSender sender, String msg){
		ChatUtils.sendMessagePlayer(sender, msg);
	}
	public SubCommand(String name, String permission, String description, 
			String hover, String onClickShow, String onClickRun){
		message = JMessage.loadJMessage(description);
		messageConsole = ChatUtils.colorReplace(description);
		this.name = name;
		
		JMessage.addHoverEvent(message, HoverEventType.SHOW_TEXT, hover);
		if(onClickShow != null)
			JMessage.addClickEvent(message, ClickEventType.SUGGEST_COMMAND, onClickShow, false);
		else if(onClickRun != null)
			JMessage.addClickEvent(message, ClickEventType.RUN_COMMAND, onClickRun, false);
	}
	public abstract void runCommand(CommandSender sender, String[] args);
}
