package com.lelann.multiworld.commands;

import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import com.lelann.multiworld.worlds.MultiWorld;
import com.lelann.multiworld.worlds.MultiWorldManager;

public class MWInfoCommand extends SubCommand {
	public MWInfoCommand() {
		super("info", "multiworld.info", "%gold%/mw info", 
				"%gold%Permet d'avoir des informations sur le monde %red%dans lequel vous �tes%gold%."
				, null, "/mw info");
	}

	@Override
	public void runCommand(CommandSender sender, String[] args) {
		MultiWorldManager m = MultiWorldManager.getInstance();
		if(!(sender instanceof Player)){
			sendMessage(sender, "%red%Cette commande est reserv�e aux joueurs.");
			return;
		}
		Player player = (Player) sender;
		World w = player.getLocation().getWorld();
		MultiWorld mw = m.getWorld(player);

		String msg = "%gold%-----------------------";
		msg += ";%gold%Vous �tes actuellement dans le monde %dred%'%red%" + w.getName() + "%dred%' %gold%!";
		msg += ";%gold%M�t�o activ�e %red%: " + (mw.isWeatherAllowed() ? "%green%Oui" : "%red%Non");
		msg += ";%gold%Spawn de monstres activ� %red%: " + (mw.areMonstersAllowed() ? "%green%Oui" : "%red%Non");
		msg += ";%gold%Spawn d'animaux activ� %red%: " + (mw.areAnimalsAllowed() ? "%green%Oui" : "%red%Non");
		msg += ";%gold%Perte de faim activ�e %red%: " + (mw.canPlayerLosterFood() ? "%green%Oui" : "%red%Non");
		msg += ";%gold%Seed %red%: " + w.getSeed();

		String spawn = "x = " + w.getSpawnLocation().getBlockX() + ", y = " + w.getSpawnLocation().getBlockY() + ", z = " + w.getSpawnLocation().getBlockZ();
		msg += ";%gold%Spawn %red%: %aqua%" + spawn;
		msg += ";%gold%-----------------------";

		sendMessage(sender, msg);
	}
}