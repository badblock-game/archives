package com.lelann.multiworld.commands;

import java.io.File;

import org.bukkit.command.CommandSender;

import com.lelann.multiworld.worlds.MultiWorld;
import com.lelann.multiworld.worlds.MultiWorldManager;

public class MWImportCommand extends SubCommand {

	public MWImportCommand() {
		super("import", "multiworld.import", "%gold%/mw import %aqua%<name>", 
				"%gold%Permet d'importer le monde %red%<name>%gold% � partir d'un monde existant (si ce n'est pas un monde il sera g�n�r�)."
				, "/mw import <name>", null);
	}

	@Override
	public void runCommand(final CommandSender sender, final String[] args) {
		MultiWorldManager m = MultiWorldManager.getInstance();
		if(args.length == 0){
			sendHelp(sender);
		} else if(m.getBukkitWorld(args[0]) != null){
			sendMessage(sender, "%red%Le monde sp�cifier est d�j� charg� !");
		} else if(!new File(args[0]).exists()){
			sendMessage(sender, "%red%Le dossier sp�cifier n'existe pas !");
		} else if(!m.loadWorld(args[0]) || m.getBukkitWorld(args[0]) == null){
			sendMessage(sender, "%red%Impossible de charger le monde. Pour plus de d�tails regarder la console et vérifier que le nom entr� correspond � un dossier pr�sent dans la racine du serveur.");
		} else {
			sendMessage(sender, "%green%Le monde '" + args[0] + "' a �t� import� correctement !");

			MultiWorld world = new MultiWorld(m.getBukkitWorld(args[0]));
			m.addWorld(world.getName(), world);
			m.saveLoadedWorlds();
		}
	}
}
