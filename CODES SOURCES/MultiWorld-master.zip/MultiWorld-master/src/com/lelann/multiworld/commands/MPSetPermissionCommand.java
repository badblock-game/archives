package com.lelann.multiworld.commands;

import org.bukkit.command.CommandSender;

import com.lelann.multiworld.portals.Portal;
import com.lelann.multiworld.portals.PortalsManager;

public class MPSetPermissionCommand extends SubCommand {

	public MPSetPermissionCommand() {
		super("setpermission", "multiworld.portals.setpermission", "%gold%/mwp setpermission %aqua%<portal> <permission>", 
				"%gold%Permet de d�finir la permission %red%<permission> %gold%n�cessaire pour utiliser le portail %red%<portal>%gold%."
				, "/mwp setpermission <portal> <permission>", null);
	}

	@Override
	public void runCommand(CommandSender sender, String[] args) {
		if(args.length < 2){
			sendHelp(sender);
			return;
		}
		PortalsManager m = PortalsManager.getInstance();
		Portal p = m.getPortal(args[0]);
	
		if(p == null){
			sendMessage(sender, "%red%Le portail '" + args[0] + "' n'existe pas !");
		} else {
			p.setPermission(args[1]);
			m.saveLoadedPortals();
			sendMessage(sender, "%green%La permission n�cessaire pour utiliser le portail '" + args[0] + "' a �t� d�finie � " + args[1] + " !");
		}
	}
}