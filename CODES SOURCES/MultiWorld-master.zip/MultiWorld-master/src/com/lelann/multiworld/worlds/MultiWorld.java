package com.lelann.multiworld.worlds;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;

import com.lelann.multiworld.Main;

import lombok.Getter;

public class MultiWorld {
	private String worldName;
	private boolean animals, monsters, weather, food;
	@Getter private boolean build, enderpearl, mobGrief, witherSpawn, creeperExplosions, tntExplosions;
	private Location spawn;
	
	@Getter private List<String> forbiddenCommands;

	public MultiWorld(World w){
		if(w == null) return;
		worldName = w.getName();

		ConfigurationSection c = Main.getInstance().getConfig().getConfigurationSection(w.getName());
		if(c == null){
			animals = true;
			monsters = true;
			weather = true;
			food = true;
			build = true;
			enderpearl = true;
			mobGrief = false;

			spawn = w.getSpawnLocation();
			forbiddenCommands = new ArrayList<>();
		} else {
			worldName = c.getString("worldName");
			animals = c.getBoolean("canAnimalsSpawn");
			monsters = c.getBoolean("canMonstersSpawn");
			weather = c.getBoolean("canWeatherChange");
			food = c.getBoolean("canPlayersLostFood");
			build = c.getBoolean("canPlayersBuild");
			enderpearl = c.getBoolean("canPlayersUseEnderpearls");
			mobGrief = c.getBoolean("canMobsGrief");
			witherSpawn = c.getBoolean("canWithersSpawn");
			creeperExplosions = c.getBoolean("canCreepersExplode");
			creeperExplosions = c.getBoolean("canTNTsExplode");
			
			forbiddenCommands = c.getStringList("forbiddenCommands");

			if(!c.contains("spawn"))
				spawn = w.getSpawnLocation();
			else spawn = new Location(w, c.getDouble("spawn.x"), c.getDouble("spawn.y"), c.getDouble("spawn.z"), (float)c.getDouble("spawn.yaw"), (float)c.getDouble("spawn.pitch"));
		}
	}
	public static MultiWorld loadWorld(ConfigurationSection c){
		if(!c.getBoolean("isActivated"))
			return null;
		MultiWorld result = new MultiWorld(null);

		result.worldName = c.getString("worldName");
		result.animals = c.getBoolean("canAnimalsSpawn");
		result.monsters = c.getBoolean("canMonstersSpawn");
		result.weather = c.getBoolean("canWeatherChange");
		result.food = c.getBoolean("canPlayersLostFood");
		result.build = c.getBoolean("canPlayersBuild");
		result.enderpearl = c.getBoolean("canPlayersUseEnderpearls");
		result.mobGrief = c.getBoolean("canMobsGrief");
		result.witherSpawn = c.getBoolean("canWithersSpawn");
		result.creeperExplosions = c.getBoolean("canCreepersExplode");
		result.tntExplosions = c.getBoolean("canTNTsExplode");
		result.forbiddenCommands = c.getStringList("forbiddenCommands");
		
		
		if(result.getBukkitWorld() == null && !MultiWorldManager.getInstance().loadWorld(result.worldName)){
			return null;
		} else {
			if(c.contains("spawn"))
				result.spawn = new Location(result.getBukkitWorld(), c.getDouble("spawn.x"), c.getDouble("spawn.y"), c.getDouble("spawn.z"), (float)c.getDouble("spawn.yaw"), (float)c.getDouble("spawn.pitch"));
			else result.spawn = result.getBukkitWorld().getSpawnLocation();
			return result;
		}
	}
	public World getBukkitWorld(){
		if(worldName == null) return null;
		return Bukkit.getWorld(worldName);
	}
	public void setSpawnLocation(Location l){
		World w = getBukkitWorld();
		if(w == null) return;

		spawn = l;
		w.setSpawnLocation((int)l.getX(), (int)l.getY(), (int)l.getZ());
	}
	public String getName(){
		return worldName;
	}
	public boolean areAnimalsAllowed(){
		return animals;
	}
	public boolean areMonstersAllowed(){
		return monsters;
	}
	public boolean isWeatherAllowed(){
		return weather;
	}
	public boolean canPlayerLosterFood(){
		return food;
	}
	public Location getSpawn(){
		return spawn;
	}
}
