package com.lelann.multiworld.worlds;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.World.Environment;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;

import com.lelann.multiworld.utils.ChatUtils;

public class MultiWorldManager {
	private static MultiWorldManager instance;
	public static MultiWorldManager getInstance(){
		return instance;
	}
	
	private FileConfiguration config;
	private File configFile;
	
	public void saveConfig(){
		try {
			config.save(configFile);
		} catch (IOException unused) {}
	}
	public MultiWorldManager(File configFile){
		instance = this;
		
		this.configFile = configFile;
		this.config = YamlConfiguration.loadConfiguration(configFile);
		this.worlds = new LinkedHashMap<String, MultiWorld>();
		
		for(World w : Bukkit.getWorlds()){
			ConfigurationSection cs = config.getConfigurationSection(w.getName());
			if(cs == null){
				MultiWorld mw = new MultiWorld(w);
				worlds.put(w.getName(), mw);
			} else {
				MultiWorld mw = MultiWorld.loadWorld(cs);
				if(mw != null)
					worlds.put(w.getName(), mw);
			}
		}
		for(String key : config.getKeys(false)){
			if(getWorld(key) != null) continue;
			ConfigurationSection cs = config.getConfigurationSection(key);
			if(cs == null) continue;

			MultiWorld mw = MultiWorld.loadWorld(cs);
			if(mw != null){
				worlds.put(mw.getName(), mw);
			}
		}
	}
	
	private Map<String, MultiWorld> worlds;
	public void addWorld(String w, MultiWorld mw){
		worlds.put(w, mw);
	}
	public void addWorld(World w, MultiWorld mw){
		addWorld(w.getName(), mw);
	}
	public void removeWorld(String w){
		if(worlds.containsKey(w)){
			worlds.remove(w);
		}
	}
	public void removeWorld(World w){
		removeWorld(w);
	}
	public MultiWorld[] getWorlds(){
		return worlds.values().toArray(new MultiWorld[0]);
	}
	public MultiWorld getWorld(String world){
		return worlds.get(world);
	}
	public MultiWorld getWorld(World world){
		return getWorld(world.getName());
	}
	public MultiWorld getWorld(Location location){
		return getWorld(location.getWorld());
	}
	public MultiWorld getWorld(Entity e){
		return getWorld(e.getLocation());
	}
	public MultiWorld getWorld(Block b){
		return getWorld(b.getLocation());
	}
	public void saveLoadedWorlds(){
		List<String> toRemove = new ArrayList<String>();
		for(MultiWorld mw : worlds.values()){
			String deb = mw.getName() + ".";

			config.set(deb + "worldName", mw.getName());
			config.set(deb + "canAnimalsSpawn", mw.areAnimalsAllowed());
			config.set(deb + "canMonstersSpawn", mw.areMonstersAllowed());
			config.set(deb + "canWeatherChange", mw.isWeatherAllowed());
			config.set(deb + "canPlayersLostFood", mw.canPlayerLosterFood());
			config.set(deb + "canPlayersBuild", mw.isBuild());
			config.set(deb + "canPlayersUseEnderpearls", mw.isEnderpearl());
			config.set(deb + "canMobsGrief", mw.isMobGrief());
			config.set(deb + "canWithersSpawn", mw.isWitherSpawn());
			config.set(deb + "canCreepersExplode", mw.isCreeperExplosions());
			config.set(deb + "canTNTsExplode", mw.isTntExplosions());
			config.set(deb + "forbiddenCommands", mw.getForbiddenCommands());
			
			if(mw.getSpawn() != null){
				config.set(deb + "spawn.x", mw.getSpawn().getX());
				config.set(deb + "spawn.y", mw.getSpawn().getY());
				config.set(deb + "spawn.z", mw.getSpawn().getZ());
				config.set(deb + "spawn.yaw", mw.getSpawn().getYaw());
				config.set(deb + "spawn.pitch", mw.getSpawn().getPitch());
			}
			if(mw.getBukkitWorld() == null){
				config.set(deb + "isActivated", false);
				toRemove.add(mw.getName());
			} else config.set(deb + "isActivated", true);
		}
		for(String s : toRemove){
			worlds.remove(s);
		}
		saveConfig();
	}
	public World getBukkitWorld(String arg){
		return Bukkit.getWorld(arg);
	}
	public boolean loadWorld(String world){
		if(world == null) return false;
		if(world.contains(File.separator)) return false;
		if(world.equals("plugins") || world.equals("logs")) return false;
		if(!new File(world, "level.dat").exists()) return false;

		try {
			WorldCreator creator = WorldCreator.name(world);
			if(new File(world, "region").exists()){
			} else if(new File(world, "DIM0").exists()){
				creator = creator.environment(Environment.NETHER);
			} else if(new File(world, "DIM1").exists()){
				creator = creator.environment(Environment.THE_END);
			} else return false;
			Bukkit.getWorlds().add(creator.createWorld());
			return true;
		} catch(Exception e){
			e.printStackTrace();
			return false;
		}
	}
	
	public void removePlayersInWorld(World w){
		for(Player p : Bukkit.getOnlinePlayers()){
			if(p.getWorld().getUID().equals(w.getUID())){
				p.teleport(Bukkit.getWorlds().get(0).getSpawnLocation());
				ChatUtils.sendMessagePlayer(p, "%green%Vous avez été téléporté en dehors du monde dans lequel vous étiez car celui-ci a été désactivé !");
			}
		}
	}
}
