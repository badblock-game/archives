package com.lelann.multiworld.portals;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

import com.google.common.io.ByteArrayDataOutput;
import com.google.common.io.ByteStreams;
import com.lelann.multiworld.Main;
import com.lelann.multiworld.utils.ChatUtils;
import com.lelann.multiworld.utils.Selection;

import lombok.Getter;
import lombok.Setter;

public class BungeePortal extends Portal {
	@Getter@Setter private String destination;
	
	public BungeePortal(String name, Selection portal) {
		super(name, portal);
		this.type = PortalType.BUNGEE;
	}

	@Override
	public void teleport(Player p) {
		if(destination == null){
			ChatUtils.sendMessagePlayer(p, "%red%Ce portail ne m�ne nul part !");
		} else if(!p.hasPermission(permission) && !p.hasPermission("multiworld.*") && !p.hasPermission("multiworld.portals.*") && !p.hasPermission("*")){
			ChatUtils.sendMessagePlayer(p, "%red%Vous n'avez pas la permission d'utiliser ce portail.");
		} else preSend(p);
	}
	
	@Override
	protected void send(Player p){
		  ByteArrayDataOutput out = ByteStreams.newDataOutput();
		  out.writeUTF("Connect");
		  out.writeUTF(destination);
		  
		  p.sendPluginMessage(Main.getInstance(), "BungeeCord", out.toByteArray());
	}
	
	@Override
	protected void load(ConfigurationSection c) {
		try {
			destination = c.getString("destination");
		} catch(Exception e){
			destination = null;
		}		
	}

	@Override
	protected void save(ConfigurationSection c) {
		if(destination == null) return;
		c.set("destination", destination);
	}
}
