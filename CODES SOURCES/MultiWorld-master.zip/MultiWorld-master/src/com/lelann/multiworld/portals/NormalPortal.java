package com.lelann.multiworld.portals;

import lombok.Getter;
import lombok.Setter;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

import com.lelann.multiworld.utils.ChatUtils;
import com.lelann.multiworld.utils.Selection;

public class NormalPortal extends Portal {
	@Getter@Setter private Location destination;
	
	public NormalPortal(String name, Selection portal) {
		super(name, portal);
		this.type = PortalType.NORMAL;
	}

	@Override
	public void teleport(Player p) {
		if(destination == null){
			ChatUtils.sendMessagePlayer(p, "%red%Ce portail ne m�ne nul part !");
		} else if(!p.hasPermission(permission) && !p.hasPermission("multiworld.*") && !p.hasPermission("multiworld.portals.*") && !p.hasPermission("*")){
			ChatUtils.sendMessagePlayer(p, "%red%Vous n'avez pas la permission d'utiliser ce portail.");
		} else preSend(p);
	}
	
	@Override
	protected void send(Player p){
		p.teleport(destination);
	}

	@Override
	protected void load(ConfigurationSection c) {
		try {
			World w = Bukkit.getWorld(c.getString("destination.world"));
			destination = new Location(w, c.getDouble("destination.x"), c.getDouble("destination.y"), c.getDouble("destination.z"), (float)c.getDouble("destination.yaw"), (float)c.getDouble("destination.pitch"));
		} catch(Exception e){
			destination = null;
		}		
	}

	@Override
	protected void save(ConfigurationSection c) {
		if(destination == null) return;
		
		c.set("destination.world", destination.getWorld().getName());
		c.set("destination.x", destination.getX());
		c.set("destination.y", destination.getY());
		c.set("destination.z", destination.getZ());
		c.set("destination.yaw", destination.getYaw());
		c.set("destination.pitch", destination.getPitch());
	}
}
