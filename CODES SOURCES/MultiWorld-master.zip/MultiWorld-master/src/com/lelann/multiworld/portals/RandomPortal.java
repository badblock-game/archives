package com.lelann.multiworld.portals;

import java.util.ArrayList;
import java.util.List;
import java.util.Queue;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import com.google.common.collect.Queues;
import com.lelann.multiworld.Main;
import com.lelann.multiworld.utils.ChatUtils;
import com.lelann.multiworld.utils.NumberUtils;
import com.lelann.multiworld.utils.Selection;

import lombok.Getter;
import lombok.Setter;

public class RandomPortal extends Portal {
	@Getter private static List<UUID> toProtectPlayers = new ArrayList<UUID>();
	@Getter@Setter private Selection destination;
	
	private Queue<Location> locations = Queues.newLinkedBlockingDeque();
	
	public RandomPortal(String name, Selection portal) {
		super(name, portal);
		this.type = PortalType.RANDOM;
	}

	@Override
	public void teleport(Player p) {
		if(destination == null){
			ChatUtils.sendMessagePlayer(p, "%red%Ce portail ne m�ne nul part !");
		} else if(!p.hasPermission(permission) && !p.hasPermission("multiworld.*") && !p.hasPermission("multiworld.portals.*") && !p.hasPermission("*")){
			ChatUtils.sendMessagePlayer(p, "%red%Vous n'avez pas la permission d'utiliser ce portail.");
		} else {
			prepareLocation();
			preSend(p, 1L);
		}
	}
	
	@Override
	protected void send(Player p){
		final UUID uuid = p.getUniqueId();
		toProtectPlayers.add(uuid);
		
		p.teleport( getLocation() );
		
		new BukkitRunnable(){
			@Override
			public void run(){
				toProtectPlayers.remove(uuid);
			}
		}.runTaskLater(Main.getInstance(), 20L * 30);
	}

	protected Location getLocation(){
		return locations.poll();
	}
	
	protected void prepareLocation() {
		int x = 0, x2 = 0;
		if(destination.getFirstLocation().getX() > destination.getSecondLocation().getX()){
			x2 = (int)destination.getFirstLocation().getX();
			x = (int)destination.getSecondLocation().getX();
		} else {
			x = (int)destination.getFirstLocation().getX();
			x2 = (int)destination.getSecondLocation().getX();
		}
		
		int z = 0, z2 = 0;
		if(destination.getFirstLocation().getZ() > destination.getSecondLocation().getZ()){
			z2 = (int)destination.getFirstLocation().getZ();
			z = (int)destination.getSecondLocation().getZ();
		} else {
			z = (int)destination.getFirstLocation().getZ();
			z2 = (int)destination.getSecondLocation().getZ();
		}
		
		Location l = new Location(destination.getFirstLocation().getWorld(), NumberUtils.random(x, x2), 256, NumberUtils.random(z, z2));
		l.getChunk().load();
		
		l = l.getWorld().getHighestBlockAt(l).getLocation();
		locations.add(l);
	}

	@Override
	protected void load(ConfigurationSection c) {
		World w = Bukkit.getWorld(c.getString("destfb.world"));
		destination = new Selection(
				new Location(w, c.getDouble("destfb.x"), c.getDouble("destfb.y"), c.getDouble("destfb.z"), (float)c.getDouble("destfb.yaw"), (float)c.getDouble("destfb.pitch")),
				new Location(w, c.getDouble("destsb.x"), c.getDouble("destsb.y"), c.getDouble("destsb.z"), (float)c.getDouble("destsb.yaw"), (float)c.getDouble("destsb.pitch")));
	}
	
	@Override
	protected void save(ConfigurationSection c) {
		if(destination == null) return;
		
		c.set("destfb.world", destination.getWorld().getName());
		c.set("destfb.x", destination.getFirstLocation().getX());
		c.set("destfb.y", destination.getFirstLocation().getY());
		c.set("destfb.z", destination.getFirstLocation().getZ());
		c.set("destfb.yaw", destination.getFirstLocation().getYaw());
		c.set("destfb.pitch", destination.getFirstLocation().getPitch());
		
		c.set("destsb.world", destination.getWorld().getName());
		c.set("destsb.x", destination.getSecondLocation().getX());
		c.set("destsb.y", destination.getSecondLocation().getY());
		c.set("destsb.z", destination.getSecondLocation().getZ());
		c.set("destsb.yaw", destination.getSecondLocation().getYaw());
		c.set("destsb.pitch", destination.getSecondLocation().getPitch());
	}
}