package com.lelann.multiworld.portals;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

import com.lelann.multiworld.utils.ChatUtils;
import com.lelann.multiworld.utils.NumberUtils;
import com.lelann.multiworld.utils.Selection;

import lombok.Getter;
import lombok.Setter;

public class MultiPortal extends Portal {
	@Getter@Setter private List<Location> destinations;

	public MultiPortal(String name, Selection portal) {
		super(name, portal);
		this.type = PortalType.MULTI;
		this.destinations = new ArrayList<Location>();
	}

	@Override
	public void teleport(Player p) {
		if(destinations.isEmpty()){
			ChatUtils.sendMessagePlayer(p, "%red%Ce portail ne m�ne nul part !");
		} else if(!p.hasPermission(permission) && !p.hasPermission("multiworld.*") && !p.hasPermission("multiworld.portals.*") && !p.hasPermission("*")){
			ChatUtils.sendMessagePlayer(p, "%red%Vous n'avez pas la permission d'utiliser ce portail.");
		} else preSend(p);
	}

	@Override
	protected void send(Player p){
		p.teleport(destinations.get(NumberUtils.random(0, destinations.size())));
	}

	@Override
	protected void load(ConfigurationSection c) {
		destinations = new ArrayList<Location>();
		try {
			int i = 0;
			while(c.contains("destination." + i)){
				World w = Bukkit.getWorld(c.getString("destination." + i + ".world"));
				destinations.add(new Location(w, c.getDouble("destination." + i + ".x"), c.getDouble("destination." + i + ".y"), c.getDouble("destination." + i + ".z"), (float)c.getDouble("destination." + i + ".yaw"), (float)c.getDouble("destination." + i + ".pitch")));
				i++;
			}
		} catch(Exception e){
			destinations.clear();
		}		
	}

	@Override
	protected void save(ConfigurationSection c) {
		if(destinations == null) return;

		for(int i=0;i<destinations.size();i++){
			Location destination = destinations.get(i);
			c.set("destination." + i + ".world", destination.getWorld().getName());
			c.set("destination." + i + ".x", destination.getX());
			c.set("destination." + i + ".y", destination.getY());
			c.set("destination." + i + ".z", destination.getZ());
			c.set("destination." + i + ".yaw", destination.getYaw());
			c.set("destination." + i + ".pitch", destination.getPitch());
		}
	}
}
