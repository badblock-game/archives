package com.lelann.multiworld.portals;

import java.io.File;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;

public class PortalsManager {
	private static PortalsManager instance;
	public static PortalsManager getInstance(){
		return instance;
	}

	private FileConfiguration config;
	private File configFile;

	public void saveConfig(){
		try {
			config.save(configFile);
		} catch (IOException unused) {}
	}
	
	public PortalsManager(File configFile){
		instance = this;

		this.configFile = configFile;
		this.config = YamlConfiguration.loadConfiguration(configFile);
		this.portals = new LinkedHashMap<String, Portal>();

		for(String key : config.getKeys(false)){
			ConfigurationSection cs = config.getConfigurationSection(key);
			if(cs == null) continue;

			Portal p = Portal.loadPortal(cs);
			if(p != null){
				portals.put(p.getName(), p);
			}
		}
	}

	private Map<String, Portal> portals;
	
	public void addPortal(String p, Portal po){
		portals.put(p, po);
	}
	
	public void removePortal(String p){
		if(portals.containsKey(p)){
			portals.remove(p);
		}
	}
	
	public Portal[] getPortals(){
		return portals.values().toArray(new Portal[0]);
	}
	
	public Portal getPortal(String portal){
		return portals.get(portal.toLowerCase());
	}
	
	public Portal getPortal(Location l){
		for(final Portal p : getPortals()){
			if(p.isIn(l))
				return p;
		}
		return null;
	}
	
	public Portal getPortal(Entity e){
		return getPortal(e.getLocation());
	}
	
	public void saveLoadedPortals(){
		for(final String key : config.getKeys(false)){
			config.set(key, null);
		}
		
		for(Portal p : portals.values()){
			p.savePortal(config.createSection(p.getName()));
		}
		
		saveConfig();
	}
}
