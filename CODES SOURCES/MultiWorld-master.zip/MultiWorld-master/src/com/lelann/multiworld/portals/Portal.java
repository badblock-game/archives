package com.lelann.multiworld.portals;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import com.lelann.multiworld.Main;
import com.lelann.multiworld.events.UsePortalEvent;
import com.lelann.multiworld.utils.ChatUtils;
import com.lelann.multiworld.utils.Selection;

import lombok.Getter;
import lombok.Setter;

public abstract class Portal {
	@Getter@Setter protected Selection selection;
	@Getter@Setter protected String name, permission;
	@Getter@Setter protected PortalType type;
	@Getter@Setter protected long ticksNotAllowed = 0;
	
	private List<UUID> cooldowneds = new ArrayList<>();
	
	public boolean isIn(Location l){
		return l.getWorld().equals(selection.getWorld()) && selection.isInSelection(l);
	}

	public abstract void teleport(Player p);
	protected abstract void send(Player p);
	
	public void preSend(final Player p, long w){
		if(cooldowneds.contains(p.getUniqueId())){
			ChatUtils.sendMessagePlayer(p, "&cVous ne pouvez utiliser ce portail que toutes les " + ticksNotAllowed + " minutes !");
			return;
		}
		
		UsePortalEvent event = new UsePortalEvent(p, this, w);
		Bukkit.getPluginManager().callEvent(event);
		
		long time = event.getWaitingTime();
		
		if(time <= 0){
			send(p);
			
			final UUID uniqueId = p.getUniqueId();
			
			if(ticksNotAllowed != 0){
				cooldowneds.add(uniqueId);
				
				new BukkitRunnable(){
					@Override
					public void run(){
						cooldowneds.remove(uniqueId);
					}
				}.runTaskLater(Main.getInstance(), ticksNotAllowed * 60 * 20);
			}
		} else {
			new BukkitRunnable(){
				@Override
				public void run(){
					send(p);
					
					final UUID uniqueId = p.getUniqueId();
					
					if(ticksNotAllowed != 0){
						cooldowneds.add(uniqueId);
						
						new BukkitRunnable(){
							@Override
							public void run(){
								cooldowneds.remove(uniqueId);
							}
						}.runTaskLater(Main.getInstance(), ticksNotAllowed * 60 * 20);
					}
				}
			}.runTaskLater(Main.getInstance(), time);
		}
	}
	
	public void preSend(final Player p){
		preSend(p, 0L);
	}
	
	protected abstract void load(ConfigurationSection c);
	protected abstract void save(ConfigurationSection c);

	public Portal(String name, Selection portal){
		this.name = name;
		this.selection = portal;
		this.permission = "multiworld.portal.default";
	}

	public static Portal loadPortal(ConfigurationSection c){
		PortalType type = PortalType.get(c.getString("portalType"));
		Portal result = null;

		if(type == PortalType.NORMAL){
			result = new NormalPortal(null, null);
		} else if(type == PortalType.RANDOM){
			result = new RandomPortal(null, null);
		} else if(type == PortalType.BUNGEE){
			result = new BungeePortal(null, null);
		} else if(type == PortalType.MULTI){
			result = new MultiPortal(null, null);
		} else if(type == PortalType.COMMAND){
			result = new CommandPortal(null, null);
		}

		result.name = c.getString("portalName");
		result.permission = c.getString("neededPermission");
		result.ticksNotAllowed = c.getLong("cooldown");
		
		try {
			World w = Bukkit.getWorld(c.getString("fb.world"));
			result.selection = new Selection(
					new Location(w, c.getDouble("fb.x"), c.getDouble("fb.y"), c.getDouble("fb.z"), (float)c.getDouble("fb.yaw"), (float)c.getDouble("fb.pitch")),
					new Location(w, c.getDouble("sb.x"), c.getDouble("sb.y"), c.getDouble("sb.z"), (float)c.getDouble("sb.yaw"), (float)c.getDouble("sb.pitch")));
		} catch(Exception unused){ return null; }

		result.load(c);
		return result;
	}

	public void savePortal(ConfigurationSection c){
		c.set("portalType", getType().getType());
		c.set("portalName", getName());
		c.set("neededPermission", getPermission());
		c.set("cooldown", getTicksNotAllowed());
		
		c.set("fb.world", getSelection().getFirstLocation().getWorld().getName());
		c.set("fb.x", getSelection().getFirstLocation().getX());
		c.set("fb.y", getSelection().getFirstLocation().getY());
		c.set("fb.z", getSelection().getFirstLocation().getZ());
		c.set("fb.yaw", getSelection().getFirstLocation().getYaw());
		c.set("fb.pitch", getSelection().getFirstLocation().getPitch());

		c.set("sb.world", getSelection().getSecondLocation().getWorld().getName());
		c.set("sb.x", getSelection().getSecondLocation().getX());
		c.set("sb.y", getSelection().getSecondLocation().getY());
		c.set("sb.z", getSelection().getSecondLocation().getZ());
		c.set("sb.yaw", getSelection().getSecondLocation().getYaw());
		c.set("sb.pitch", getSelection().getSecondLocation().getPitch());

		save(c);
	}

	public static enum PortalType {
		NORMAL("NORMAL"),
		RANDOM("RANDOM"),
		MULTI("MULTI"),
		BUNGEE("BUNGEE"),
		COMMAND("COMMAND");

		@Getter private String type;
		private PortalType(String type){
			this.type = type;
		}
		
		public static PortalType get(String name){
			if(name != null)
				for(PortalType pt : values()){
					if(pt.name().equalsIgnoreCase(name)) return pt;
				}

			return NORMAL;
		}
	}
}
