package com.lelann.multiworld.portals;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

import com.lelann.multiworld.utils.ChatUtils;
import com.lelann.multiworld.utils.Selection;

import lombok.Getter;
import lombok.Setter;

public class CommandPortal extends Portal {
	@Getter@Setter private List<String> commands;

	public CommandPortal(String name, Selection portal) {
		super(name, portal);
		this.type = PortalType.COMMAND;
		this.commands = new ArrayList<String>();
	}

	@Override
	public void teleport(Player p) {
		if(commands.isEmpty()){
			ChatUtils.sendMessagePlayer(p, "%red%Ce portail ne m�ne nul part !");
		} else if(!p.hasPermission(permission) && !p.hasPermission("multiworld.*") && !p.hasPermission("multiworld.portals.*") && !p.hasPermission("*")){
			ChatUtils.sendMessagePlayer(p, "%red%Vous n'avez pas la permission d'utiliser ce portail.");
		} else preSend(p);
	}

	@Override
	protected void send(Player p){
		for(String command : commands){
			CommandSender sender = Bukkit.getConsoleSender();
			String cmd = command;
			
			if(command.startsWith("p:")){
				cmd = command.substring(2);
				sender = p;
			}
			
			cmd = cmd.replace("%p", p.getName());
			Bukkit.dispatchCommand(sender, cmd);
		}
	}

	@Override
	protected void load(ConfigurationSection c) {
		try {
			commands = c.getStringList("commands");
		} catch(Exception e){
			commands.clear();
		}		
	}

	@Override
	protected void save(ConfigurationSection c) {
		if(commands == null) return;
		
		c.set("commands", commands);
	}
}