package fr.badblock.bukkit.games.buildcontest.inventory.gui;

import java.util.ArrayList;
import java.util.Arrays;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryView;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import fr.badblock.bukkit.games.buildcontest.data.BuildContestData;
import fr.badblock.bukkit.games.buildcontest.inventory.InventoryManager;
import fr.badblock.gameapi.GameAPI;
import fr.badblock.gameapi.players.BadblockPlayer;
import lombok.Getter;
import lombok.Setter;

public abstract class AbstractInventoryGUI {
	
	@Getter@Setter
	protected AbstractInventoryGUI back;
	
	@Getter@Setter
	protected Inventory current;
	
	@Getter
	protected Player player;
	
	private boolean bypass = false;
	
	private Material NEXT = Material.SULPHUR;
	private Material PREV = Material.ARROW;
	private Material RETURN = Material.MAGMA_CREAM;
	
	public AbstractInventoryGUI(Player p) {
		this.player = p;
	}
	
	public void build(Inventory inv) {
		setCurrent(inv);
	}
	
	public void bypass(boolean bypass) {
		this.bypass = bypass;
	}
	
	public boolean bypass() {
		return bypass;
	}
	
	public void build(Inventory inv, LayoutGui layout) {
		setCurrent(inv);
		layout.build(inv);
		registerItemClicks(layout);
	}
	
	public void clearGui() {
		/* On ne doit pas clear les �l�ments des layouts */
		for(int index = 0; index < current.getSize(); index++) {
			ItemStack stack = current.getContents()[index];
			if(!LayoutGui.is(stack)) {
				current.clear(index);
			}
		}
	}
	
	public boolean isBlock(ItemStack stack) {
		return replaceItemWithBlock(stack).getType().isBlock();
	}
	
	public ItemStack replaceBlockWithItem(ItemStack stack) {
		if(stack == null) return stack;
		switch (stack.getType()) {
		case WATER:
			return new ItemStack(Material.WATER_BUCKET);
	
		case LAVA:
			return new ItemStack(Material.LAVA_BUCKET);
			
		default:
			return new ItemStack(stack);
		}
	}
	
	public ItemStack replaceItemWithBlock(ItemStack stack) {
		if(stack == null) return stack;
		switch (stack.getType()) {
		case WATER_BUCKET:
			return new ItemStack(Material.WATER);
	
		case LAVA_BUCKET:
			return new ItemStack(Material.LAVA);
			
		default:
			return new ItemStack(stack);
		}
	}
	
	public void updateItem(int slot, ItemStack stack) {
		getCurrent().setItem(slot, stack);
	}
	
	public int findFreeSlotAfter(int start) {
		for(int i = start; i < getCurrent().getSize(); i++) {
			if(getCurrent().getItem(i) == null || getCurrent().getItem(i).getType() == Material.AIR) {
				return i;
			}
		}
		return start;
	}
	
	public String i18n(String key, Object... args){
		return GameAPI.i18n().get(((BadblockPlayer) player).getPlayerData().getLocale(), key, args)[0];
	}
	
	public String[] i18nList(String key, Object... args){
		return GameAPI.i18n().get(((BadblockPlayer) player).getPlayerData().getLocale(), key, args);
	}
	
	public ItemStack create(ItemStack base, int slot) {
		registerItemClick(base);
		getCurrent().setItem(slot, base);
		return base;
	}
	
	public ItemStack createItemStack(Material material, int amount, int data, String name, String... desc){
		
		ItemStack item = new ItemStack(material, amount, (byte) data);
		ItemMeta itemmeta = item.getItemMeta();
		
		itemmeta.setDisplayName(name);
		itemmeta.setLore(Arrays.asList(desc));
		
		item.setItemMeta(itemmeta);
		
		return item;
	}
	
	public ItemStack createItemStack(ItemStack base, String name, String... desc){
		
		ItemStack item = base;
		ItemMeta itemmeta = item.getItemMeta();
		
		itemmeta.setDisplayName(name);
		itemmeta.setLore(Arrays.asList(desc));
		
		item.setItemMeta(itemmeta);
		
		return item;
	}
	
	public abstract void onItemClick(ItemStack stack, InventoryAction action, ClickType click, ItemStack cursor, int slot,
			InventoryView view);
	
	public void registerItemClick(ItemStack stack) {
		ArrayList<ItemStack> clicks = InventoryManager.clickeables.get(this);
		if(clicks == null) {
			clicks = new ArrayList<>();
		}
		clicks.add(stack);
		InventoryManager.update(this, clicks);
	}
	
	private void registerItemClicks(LayoutGui layout) {
		if(layout.borders) {
			registerItemClick(LayoutGui.separator);
		}
		
		for(ItemStack item : layout.getClickeables()) {
			registerItemClick(item);
		}
	}
	
	public void open() {
		player.openInventory(current);
		((BadblockPlayer) getPlayer()).inGameData(BuildContestData.class).current = this;
	}
	
	public void open(Player p) {
		p.openInventory(current);
		((BadblockPlayer) p).inGameData(BuildContestData.class).current = this;
	}
	
	public void displayBack() {
		if(back != null) {
			player.openInventory(back.current);
			((BadblockPlayer) getPlayer()).inGameData(BuildContestData.class).current = back;
		}
	}
	
	public boolean isHead(ItemStack stack) {
		return stack.getType() == Material.SKULL_ITEM;
	}
	
	public boolean isReturn(ItemStack stack) {
		return stack.getType() == RETURN;
	}
	
	public boolean isNext(ItemStack stack) {
		return stack.getType() == NEXT;
	}
	
	public boolean isPrev(ItemStack stack) {
		return stack.getType() == PREV;
	}
	
	public void callPrev(ItemStack stack) {
		if(isReturn(stack)) {
			displayBack();
		}
	}
	
	public void display(AbstractInventoryGUI gui) {
		gui.setBack(this);
		gui.open();
		((BadblockPlayer) getPlayer()).inGameData(BuildContestData.class).current = gui;
		InventoryManager.add(gui);
	}
	
}
