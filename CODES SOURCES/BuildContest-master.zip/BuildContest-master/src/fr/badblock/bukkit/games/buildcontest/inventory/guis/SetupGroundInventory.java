package fr.badblock.bukkit.games.buildcontest.inventory.guis;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryView;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import fr.badblock.bukkit.games.buildcontest.inventory.gui.GuiItem;
import fr.badblock.bukkit.games.buildcontest.inventory.gui.LayoutGui;
import fr.badblock.bukkit.games.buildcontest.inventory.gui.SharedGUI;
import fr.badblock.bukkit.games.buildcontest.team.Team;
import fr.badblock.gameapi.GameAPI;

public class SetupGroundInventory extends SharedGUI {

	public ItemStack cancel;
	public ItemStack ok;
	
	private ChangeGroundInventory cgi;
	
	public SetupGroundInventory(Team team, ChangeGroundInventory gui) {
		super(team);
		this.cgi = gui;
	}

	public SetupGroundInventory buildInv() {
		Inventory inv = Bukkit.createInventory(null, 9*3, i18n("buildcontest.inventory.setupground.displayname"));
		build(inv, LayoutGui.LAYOUT_BOTTOM_OK);
		bypass(true);
		
		GuiItem cancel = LayoutGui.LAYOUT_BOTTOM_OK.items[1];
		GuiItem ok = LayoutGui.LAYOUT_BOTTOM_OK.items[0];
		
		this.cancel = cancel.getStack();
		this.ok = ok.getStack();
		
		return this;
	}
	
	@Override
	public void onItemClick(ItemStack stack, InventoryAction action, ClickType click, ItemStack cursor, int slot, InventoryView view) {
		
	}
	
	private void setItems() {
		int currentSlot = 0;
		for(int i = 0; i < 17; i++) {
			if(getCurrent().getItem(i) == null) {
				i++;
			}
			getCurrent().setItem(currentSlot, getCurrent().getItem(i));
			currentSlot++;
		}
	}
	
	public List<ItemStack> getSetupBlocks() {
		List<ItemStack> temp = new ArrayList<>();
		for(int i = 0; i < 17; i++) {
			ItemStack current = getCurrent().getItem(i);
			if(current != null && isBlock(current)) {
				current = replaceItemWithBlock(current);
				for(int t = 0; t < current.getAmount(); t++) {
					temp.add(current);
				}
			}
		}
		return temp;
	}

	@SuppressWarnings("deprecation")
	@Override
	public void onItemClick(Player p, ItemStack stack, InventoryAction action, ClickType click, ItemStack cursor,
			int slot, InventoryView view) {
		
		if(stack.isSimilar(cancel)) {
			displayBack(p);
		} else if(stack.isSimilar(ok)) {
			cgi.blocks.clear();
			cgi.blocks = getSetupBlocks();
			cgi.onBlockSetuped();
			displayBack(p);
		} else {
			if(!stack.isSimilar(LayoutGui.separator)) {
				//Autre item : supprimer de la liste des blocks
				if(cursor != null && cursor.getType() != Material.AIR) {
					int amount = cursor.getAmount();
					if(stack.getType() == cursor.getType()) {
						if(click.isLeftClick()) {
							ItemStack plus = new ItemStack(stack);
							plus.setAmount(stack.getAmount() + amount);
							getCurrent().setItem(slot, plus);
							view.setCursor(null);
						}
					}
				} else {
					if(click.isRightClick()) {
						if(stack.getAmount() <= 1) {
							getCurrent().remove(stack);
							setItems();
						} else {
							Bukkit.getScheduler().runTaskLater(GameAPI.getAPI(), new BukkitRunnable() {
								
								@Override
								public void run() {
									if(cursor == null) return;
									
									view.setCursor(null);
									
								}
							}, 1L);
						}
					}
				}
			}
		}
		
	}

}
