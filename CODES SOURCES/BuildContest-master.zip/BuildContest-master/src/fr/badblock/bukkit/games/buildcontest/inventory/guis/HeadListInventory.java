package fr.badblock.bukkit.games.buildcontest.inventory.guis;

import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryView;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import fr.badblock.bukkit.games.buildcontest.inventory.gui.AbstractInventoryGUI;
import fr.badblock.bukkit.games.buildcontest.inventory.gui.GuiItem;
import fr.badblock.bukkit.games.buildcontest.inventory.gui.LayoutGui;
import fr.badblock.bukkit.games.buildcontest.utils.Skull;
import fr.badblock.bukkit.games.buildcontest.utils.Skulls;
import net.md_5.bungee.api.ChatColor;

public class HeadListInventory extends AbstractInventoryGUI {
	
	private int pages = 1;
	private int currentPage = 1;
	private int itemPerPage = 45;
	
	private String cat;
	
	private ItemStack[][] itemsPerPage;
	private List<ItemStack> total = new ArrayList<>();
	
	public HeadListInventory(Player p, String cat) {
		super(p);
		this.cat = cat;
	}

	public HeadListInventory buildHeads() {
		buildInv();
		loadHeads();
		balanceItems();
		updateInv();
		return this;
	}
	
	private HeadListInventory buildInv() {
		Inventory current = Bukkit.createInventory(null, 54, i18n("buildcontest.inventory.categoryKey") + cat);
		this.build(current, LayoutGui.LAYOUT_ALL_BOTTOM);
		return this;
	}
	
	private void updateInv() {
		GuiItem prev = LayoutGui.LAYOUT_ALL_BOTTOM.items[0];
		GuiItem next = LayoutGui.LAYOUT_ALL_BOTTOM.items[1];
		
		int pPos = ((prev.getY()-1) * 9) + (prev.getX()-1);
		int nPos = ((next.getY()-1) * 9) + (next.getX()-1);
		
		if(pages == 1) {
			getCurrent().setItem(nPos, LayoutGui.separator);
			getCurrent().setItem(pPos, LayoutGui.separator);
		} else if(pages > 1) {
			if(currentPage == 1) {
				getCurrent().setItem(pPos, LayoutGui.separator);
				getCurrent().setItem(nPos, next.getStack());
			} else if(currentPage > 1 && currentPage < pages) {
				getCurrent().setItem(pPos, prev.getStack());
				getCurrent().setItem(nPos, next.getStack());
			} else if(currentPage == pages) {
				getCurrent().setItem(pPos, prev.getStack());
				getCurrent().setItem(nPos, LayoutGui.separator);
			}
		}
		
	}
	
	private void balanceItems() {
		pages = (int) Math.ceil(total.size() / (double) itemPerPage);
		itemsPerPage = new ItemStack[pages][];
		
		if(pages > 1) {
			for(int now = 0; now < pages; now++) {
				int size = (total.size() > itemPerPage ? (total.size() - (now * itemPerPage)) : total.size());
				itemsPerPage[now] = new ItemStack[size+1];
				for(int index = 0; index < size; index++) {
					itemsPerPage[now][index] = total.get((now * itemPerPage) + index);
				}
			}
		} else {
			int size = total.size();
			itemsPerPage[0] = new ItemStack[size];
			for(int index = 0; index < size; index++) {
				itemsPerPage[0][index] = total.get(index);
			}
		}
	}
	
	@Override
	public void open() {
		super.open();
		updateCurrentPage();
	}
	
	public void updateCurrentPage() {
		clearGui();
		ItemStack[] items = itemsPerPage[currentPage-1];
		if(items != null && items.length > 0) {
			for(ItemStack item : items) {
				if(item == null) break;
				else getCurrent().addItem(item);
			}
		}
		updateInv();
	}
	
	private void loadHeads() {
		total.clear();
		HashMap<String, String> values = Skulls.getCategories().get(cat);

		for(Entry<String, String> entry : values.entrySet()) {
			
			byte[] decoded = Base64.getDecoder().decode(entry.getValue());
			String data = new String(decoded);
			String url = data.substring(28, data.length() - 4);
			
			ItemStack head = Skull.getCustomSkull(url);
			ItemMeta meta = head.getItemMeta();
			meta.setDisplayName("�b" + entry.getKey());
			head.setItemMeta(meta);
			total.add(head);
		}
		
		/* Tri des t�tes */
		List<String> untried = new ArrayList<>();
		for(ItemStack st : total) {
			untried.add(ChatColor.stripColor(st.getItemMeta().getDisplayName()));
		}
		
		List<ItemStack> temp = new ArrayList<>();
		
		untried.sort(String::compareToIgnoreCase);
		for(String name : untried) {
			for(ItemStack st : total) {
				if(ChatColor.stripColor(st.getItemMeta().getDisplayName()).equals(name)) {
					temp.add(st);
					break;
				}
			}
		}
		
		total = temp;
		
	}
	
	@Override
	public void onItemClick(ItemStack stack, InventoryAction action, ClickType type, ItemStack cursor, int slot, InventoryView view) {
		if(isNext(stack)) {
			if(!hasNext())
				return;
			
			currentPage++;
			updateCurrentPage();
		} else if(isPrev(stack)) {
			if(!hasPrev())
				return;

			currentPage--;
			updateCurrentPage();
		} else if(isReturn(stack)) {
			displayBack();
		} else if(isHead(stack)) {
			
			/* Give the head */
			getPlayer().getInventory().addItem(stack);
			
		}
	}
	
	
	
	public boolean hasNext() {
		return currentPage < pages;
	}
	
	public boolean hasPrev() {
		return currentPage > 1;
	}
	
}
