package fr.badblock.bukkit.games.buildcontest.runnables;

import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import fr.badblock.bukkit.games.buildcontest.BuildContestPlugin;
import fr.badblock.bukkit.games.buildcontest.BuildStage;
import fr.badblock.bukkit.games.buildcontest.achievements.scoreboard.BuildContestScoreboard;
import fr.badblock.bukkit.games.buildcontest.config.BuildContestMapConfiguration;
import fr.badblock.gameapi.GameAPI;
import fr.badblock.gameapi.game.GameState;
import fr.badblock.gameapi.players.BadblockPlayer;
import lombok.Getter;

public class GameRunnable extends BukkitRunnable {
	public static boolean damage = false;

	public boolean forceEnd 		 = false;
	@Getter
	private int    time 			 = -1;
	
	@Getter
	public static VoteRunnable voteRunnable = null;

	public GameRunnable(BuildContestMapConfiguration config){
		GameAPI.getAPI().getGameServer().setGameState(GameState.RUNNING);
		GameAPI.getAPI().getGameServer().saveTeamsAndPlayersForResult();
		
		GameAPI.getAPI().getJoinItems().doClearInventory(false);
		GameAPI.getAPI().getJoinItems().end();
		
		time = BuildContestPlugin.getInstance().getConfiguration().buildTime; 
	}

	@Override
	public void run() {
		// Fin du build
		if(forceEnd || time <= 0) {
			
			//gamestate to -> vote
			BuildContestPlugin.getInstance().setBuildStage(BuildStage.VOTE);
			
			//ajouter les players ou il faut tp
			
			for(Player player : Bukkit.getOnlinePlayers()){
				BadblockPlayer bp = (BadblockPlayer) player;
				bp.heal();
				bp.clearInventory();
				bp.setInvulnerable(true);

				bp.setAllowFlight(true);
				bp.setFlying(true);
				
//				VoteOption.loadFromConfig();

			}
			
			// on cr�� un nouveau chrono pour le premier vote
			voteRunnable = new VoteRunnable(BuildContestPlugin.getInstance().getConfiguration());
			voteRunnable.runTaskTimer(GameAPI.getAPI(), 20L, 20L);

			cancel();
			return;
		} else if(BuildContestPlugin.getInstance().getPlayers().size() == 1){
			//TODO
			return;
		} else if(BuildContestPlugin.getInstance().getPlayers().size() == 0){
			cancel();
			Bukkit.shutdown();
			return;
		}

		if(time % 60 == 0 && time >= 60) {
			Bukkit.getOnlinePlayers().forEach(player -> {
				BadblockPlayer pl = (BadblockPlayer) player;
//				pl.sendActionBar("�7Il reste �b" + time/60 + "�7 minutes !");
//				pl.sendTitle("�7Il vous reste", "�b" + time/60 + "�7 minutes !");
				pl.sendTranslatedActionBar("buildcontest.messages.timeremaining", (time/60) + " minute" + (time/60 > 1 ? "s" : ""));
				pl.sendTranslatedTitle("buildcontest.titles.timeremaining", (time/60) + " minute" + (time/60 > 1 ? "s" : ""));
				pl.playSound(Sound.NOTE_PLING);
			});
		} else if(time == 10 || time <= 5 && time > 0){
			
			Bukkit.getOnlinePlayers().forEach(player -> {
				BadblockPlayer pl = (BadblockPlayer) player;
//				pl.sendTranslatedActionBar("�7Il reste �b" + time + "�7 " + "seconde" + (time > 1 ? "s" : "") + " !");
//				pl.sendTranslatedActionBar("buildcontest.messages.timeremaining", time);
//				pl.sendTitle("�7Il vous reste", "�b" + time + "�7 seconde" + (time > 1 ? "s" : "") + " !");
				pl.sendTranslatedTitle("buildcontest.titles.timeremaining", time + " seconde" + (time > 1 ? "s" : ""));
				pl.sendTranslatedActionBar("buildcontest.messages.timeremaining", time + " seconde" + (time > 1 ? "s" : ""));
				
				if(time == 1) {
					pl.playSound(pl.getLocation(), Sound.NOTE_PLING, 1.0f, 2.0f);
				} else {
					pl.playSound(Sound.NOTE_PLING);
				}
			});
			
		}
		
		if(Bukkit.getOnlinePlayers().size() == 1) {
			Bukkit.shutdown();
		}
		
		for(BuildContestScoreboard scoreboards : BuildContestPlugin.getInstance().getScoreboards().values()) {
			scoreboards.update();
		}
		
		time--;
	}

}
