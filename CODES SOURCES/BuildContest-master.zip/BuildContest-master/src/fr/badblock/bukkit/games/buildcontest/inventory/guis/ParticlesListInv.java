package fr.badblock.bukkit.games.buildcontest.inventory.guis;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.inventory.InventoryView;
import org.bukkit.inventory.ItemStack;

import fr.badblock.bukkit.games.buildcontest.inventory.gui.ListGUI;
import fr.badblock.bukkit.games.buildcontest.particles.Particle;
import fr.badblock.bukkit.games.buildcontest.particles.Particles;
import fr.badblock.bukkit.games.buildcontest.team.Team;

public class ParticlesListInv extends ListGUI {

	public ParticlesListInv(Team team) {
		super(team);
	}
	
	public ParticlesListInv buildInv() {
		this.buildInv(i18n("buildcontest.inventory.particleslistinv.displayname"), getListFromParticles());
		return this;
	}

	private List<ItemStack> getListFromParticles() {
		List<ItemStack> temp = new ArrayList<>();
		Particles.particles.forEach(particle -> {
			temp.add(particle.getDisplay());
		});
		return temp;
	}
	
	@Override
	public void onItemClick(ItemStack stack, InventoryAction action, ClickType type, ItemStack cursor, int slot, InventoryView view) {
		
	}
	
	@Override
	public void onItemClick(Player p, ItemStack stack, InventoryAction action, ClickType type, ItemStack cursor, int slot, InventoryView view) {
		super.onItemClick(p, stack, action, type, cursor, slot, view);
		
		if(isParticle(stack)) {
			p.getInventory().addItem(stack);
		}
		
	}
	
	private boolean isParticle(ItemStack stack) {
		if(stack == null) return false;
		for(Particle p : Particles.particles) {
			if(p.getDisplay().isSimilar(stack)) {
				return true;
			}
		}
		return false;
	}
	
}
