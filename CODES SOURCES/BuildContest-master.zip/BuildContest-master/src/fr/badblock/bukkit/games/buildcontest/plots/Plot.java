package fr.badblock.bukkit.games.buildcontest.plots;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.UUID;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import fr.badblock.bukkit.games.buildcontest.BuildContestPlugin;
import fr.badblock.bukkit.games.buildcontest.inventory.InventoryManager;
import fr.badblock.bukkit.games.buildcontest.inventory.guis.ChangeGroundInventory;
import fr.badblock.bukkit.games.buildcontest.particles.Particles;
import fr.badblock.bukkit.games.buildcontest.team.Team;
import fr.badblock.bukkit.games.buildcontest.team.TeamManager;
import fr.badblock.gameapi.players.BadblockPlayer;
import fr.badblock.gameapi.utils.selections.CuboidSelection;
import fr.badblock.gameapi.utils.threading.TaskManager;
import lombok.Data;

@Data
public class Plot {

	private Player owner;
	private Location center, loc1, loc2;
	private CuboidSelection area;
	
	private int time;
	private Material floor = Material.GRASS;
	private int floorData = 0;
	
	private boolean hasStorm, hasThunder, hasWeather;
	
	private Team team;
	
	public Plot(Player owner, Location center, Location loc1, Location loc2) {
		this.team = TeamManager.getTeam(owner);
		this.owner = owner;
		this.center = center;
		this.loc1 = loc1;
		this.loc2 = loc2;
		defArea();
	}
	
	public Plot(Team team, Location center, Location loc1, Location loc2) {
		this.team = team;
		this.center = center;
		this.loc1 = loc1;
		this.loc2 = loc2;
		defArea();
	}

	private void defArea() {
		area = new CuboidSelection(loc1, loc2);
	}
	
	public boolean hasStorm() {
		return hasStorm;
	}
	
	public boolean hasThunder() {
		return hasThunder;
	}
	
	public boolean hasWeather() {
		return hasStorm || hasThunder;
	}
	
	public int getXLen() {
		return loc2.getBlockX() - loc1.getBlockX();
	}
	
	public int getZLen() {
		return loc2.getBlockZ() - loc1.getBlockZ();
	}
	
	public Player getOwner() {
		if(owner != null) return owner;
		else {
			if(team.getPlayers().get(0) != null) return team.getPlayers().get(0);
			else return team.getPlayers().get(1);
		}
	}
	
	@SuppressWarnings("deprecation")
	public void setFloor(Material mat, int data) {
		this.floor = mat;
		this.floorData = data;
		String name = "setFloor." + UUID.randomUUID().toString();
		TaskManager.scheduleSyncRepeatingTask(name, new Runnable() {

			List<Block> blocks = getBlocks(BuildContestPlugin.getInstance().getMapConfiguration().getFloorY().intValue());
			Iterator<Block> iterator = blocks.iterator();
			
			@Override
			public void run() {
				if (!iterator.hasNext()) {
					TaskManager.cancelTaskByName(name);
					return;
				}
				long startTime = System.currentTimeMillis();
				while (iterator.hasNext()) {
					long time = System.currentTimeMillis() - startTime;
					if (time >= 5) return;
					Block block = iterator.next();
					if (block == null) return;
					block.setTypeIdAndData(mat.getId(), (byte) data, true);
					block.getState().update(true);
				}
			}
			
		}, 1, 1);
	}
	
	public List<Block> getBlocks() {
		
		List<Block> blocks = new ArrayList<>();
		
		int topBlockX = (loc1.getBlockX() < loc2.getBlockX() ? loc2.getBlockX() : loc1.getBlockX());
        int bottomBlockX = (loc1.getBlockX() > loc2.getBlockX() ? loc2.getBlockX() : loc1.getBlockX());
 
        int topBlockY = (loc1.getBlockY() < loc2.getBlockY() ? loc2.getBlockY() : loc1.getBlockY());
        int bottomBlockY = (loc1.getBlockY() > loc2.getBlockY() ? loc2.getBlockY() : loc1.getBlockY());
 
        int topBlockZ = (loc1.getBlockZ() < loc2.getBlockZ() ? loc2.getBlockZ() : loc1.getBlockZ());
        int bottomBlockZ = (loc1.getBlockZ() > loc2.getBlockZ() ? loc2.getBlockZ() : loc1.getBlockZ());
 
        for(int x = bottomBlockX; x <= topBlockX; x++)
        {
            for(int z = bottomBlockZ; z <= topBlockZ; z++)
            {
                for(int y = bottomBlockY; y <= topBlockY; y++)
                {
                    blocks.add(loc1.getWorld().getBlockAt(new Location(loc1.getWorld(), x, y, z)));
                }
            }
        }
        
        return blocks;
	}
	
	public List<Block> getRealBlocks() {
		
		Location loc1 = this.loc1.clone().add(0, 1, 0);
		
		List<Block> blocks = new ArrayList<>();
		
		int topBlockX = (loc1.getBlockX() < loc2.getBlockX() ? loc2.getBlockX() : loc1.getBlockX());
        int bottomBlockX = (loc1.getBlockX() > loc2.getBlockX() ? loc2.getBlockX() : loc1.getBlockX());
 
        int topBlockY = (loc1.getBlockY() < loc2.getBlockY() ? loc2.getBlockY() : loc1.getBlockY());
        int bottomBlockY = (loc1.getBlockY() > loc2.getBlockY() ? loc2.getBlockY() : loc1.getBlockY());
 
        int topBlockZ = (loc1.getBlockZ() < loc2.getBlockZ() ? loc2.getBlockZ() : loc1.getBlockZ());
        int bottomBlockZ = (loc1.getBlockZ() > loc2.getBlockZ() ? loc2.getBlockZ() : loc1.getBlockZ());
 
        for(int x = bottomBlockX; x <= topBlockX; x++)
        {
            for(int z = bottomBlockZ; z <= topBlockZ; z++)
            {
                for(int y = bottomBlockY; y <= topBlockY; y++)
                {
                    blocks.add(loc1.getWorld().getBlockAt(new Location(loc1.getWorld(), x, y, z)));
                }
            }
        }
        
        return blocks;
	}
	
	public List<Block> getBlocks(int y) {
		
		List<Block> blocks = new ArrayList<>();
		
		int topBlockX = (loc1.getBlockX() < loc2.getBlockX() ? loc2.getBlockX() : loc1.getBlockX());
        int bottomBlockX = (loc1.getBlockX() > loc2.getBlockX() ? loc2.getBlockX() : loc1.getBlockX());
 
        int topBlockZ = (loc1.getBlockZ() < loc2.getBlockZ() ? loc2.getBlockZ() : loc1.getBlockZ());
        int bottomBlockZ = (loc1.getBlockZ() > loc2.getBlockZ() ? loc2.getBlockZ() : loc1.getBlockZ());
 
        for(int x = bottomBlockX; x <= topBlockX; x++)
        {
            for(int z = bottomBlockZ; z <= topBlockZ; z++)
            {
                blocks.add(loc1.getWorld().getBlockAt(new Location(loc1.getWorld(), x, y, z)));
            }
        }
        
        return blocks;
	}

	public void reset() {
		String name = "resetBlocks." + UUID.randomUUID().toString();
		TaskManager.scheduleSyncRepeatingTask(name, new Runnable() {

			List<Block> blocks = getRealBlocks();
			Iterator<Block> iterator = blocks.iterator();
			
			@Override
			public void run() {
				if (!iterator.hasNext()) {
					TaskManager.cancelTaskByName(name);
					return;
				}
				long startTime = System.currentTimeMillis();
				while (iterator.hasNext()) {
					long time = System.currentTimeMillis() - startTime;
					if (time >= 5) return;
					Block block = iterator.next();
					if (block == null) return;
					block.setType(Material.AIR);
					block.getState().update(true);
				}
			}
			
		}, 1, 1);
		setFloor(Material.GRASS, 0);
		ChangeGroundInventory inv = InventoryManager.getGroundGui(getOwner());
		if(inv != null) {
			inv.resetGround();
		}
		Particles.destroyAll((BadblockPlayer) getOwner());
		
	}

	@SuppressWarnings("deprecation")
	public void setFloorRandom(List<ItemStack> blocks) {
		this.floor = blocks.get(0).getType();
		this.floorData = blocks.get(0).getData().getData();
		String name = "setFloorRandom." + UUID.randomUUID().toString();
		TaskManager.scheduleSyncRepeatingTask(name, new Runnable() {

			List<Block> floorBlocks = getBlocks(BuildContestPlugin.getInstance().getMapConfiguration().getFloorY().intValue());
			Iterator<Block> iterator = floorBlocks.iterator();
			Random r = new Random();
			
			@Override
			public void run() {
				if (!iterator.hasNext()) {
					TaskManager.cancelTaskByName(name);
					return;
				}
				long startTime = System.currentTimeMillis();
				if(blocks.size() > 0)
					while (iterator.hasNext()) {
						long time = System.currentTimeMillis() - startTime;
						if (time >= 5) return;
						Block block = iterator.next();
						if (block == null) return;
						ItemStack random = blocks.get(r.nextInt(blocks.size()));
						block.setType(random.getType());
						block.setData(random.getData().getData());
						block.getState().update(true);
					}
			}
			
		}, 1, 1);
	}
	
}
