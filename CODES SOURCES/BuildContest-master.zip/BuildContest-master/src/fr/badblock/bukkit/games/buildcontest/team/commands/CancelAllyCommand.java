package fr.badblock.bukkit.games.buildcontest.team.commands;

import org.bukkit.DyeColor;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;

import fr.badblock.bukkit.games.buildcontest.BuildContestPlugin;
import fr.badblock.bukkit.games.buildcontest.team.InvitationManager;
import fr.badblock.bukkit.games.buildcontest.team.TeamManager;
import fr.badblock.bukkit.games.buildcontest.utils.ComponentMessage;
import fr.badblock.gameapi.GameAPI;
import fr.badblock.gameapi.command.AbstractCommand;
import fr.badblock.gameapi.players.BadblockPlayer;
import fr.badblock.gameapi.players.BadblockPlayer.GamePermission;
import fr.badblock.gameapi.utils.i18n.TranslatableString;
import net.md_5.bungee.api.chat.BaseComponent;

public class CancelAllyCommand extends AbstractCommand {

	public CancelAllyCommand() {
		super("cancelallywith", new TranslatableString("commands.gbuildcontest.allycommand.error"), GamePermission.PLAYER, GamePermission.PLAYER, GamePermission.PLAYER);
		allowConsole(false);
	}

	@SuppressWarnings("deprecation")
	@Override
	public boolean executeCommand(CommandSender sender, String[] args) {
		if(args.length == 0)
			return true;
		
		BadblockPlayer player = (BadblockPlayer) sender;
		//String t = args[0];
		//BadblockPlayer target = (BadblockPlayer) Bukkit.getPlayer(t);
		
		if(InvitationManager.getInvitation(player) == null) {
			return true;
		}
		
		BadblockPlayer second = InvitationManager.getInvitation(player).getInvitedWith(player);
		
		if(TeamManager.getTeam(player) != null) {
			//a d�j� une team
			//player.sendMessage("�7Vous �tes d�j� en team !");
			ComponentMessage message = new ComponentMessage(new TranslatableString("buildcontest.messages.teams.alreadyinteam").getAsLine(player));
			ComponentMessage clickToBreak = new ComponentMessage(new TranslatableString("buildcontest.messages.teams.clicktoleave.message").getAsLine(player), new TranslatableString("buildcontest.messages.teams.clicktoleave.onhover").getAsLine(player), "/breakmyteamwith " + TeamManager.getTeam(player).getPlayerWith(player).getName());
			BaseComponent[] base = ComponentMessage.create(true, true, message, clickToBreak);
			player.spigot().sendMessage(base);
			return true;
		}
		
		if(InvitationManager.cancelInvitation(player)) {
		
			player.sendTranslatedMessage("buildcontest.messages.teams.youhavecanceltheinvitation");
			second.sendTranslatedMessage("buildcontest.messages.teams.playercancelhisinvitation", player.getName());
			
			GameAPI.getAPI().createItemStackFactory().type(Material.INK_SACK)
					.durability((short) DyeColor.SILVER.getData())
					.displayName(BuildContestPlugin.getInstance().getState("buildcontest.inventory.joinitems.allywith.displayName", 0))
					.lore(new TranslatableString("buildcontest.inventory.joinitems.allywith.description", BuildContestPlugin.getInstance().getState("buildcontest.inventory.joinitems.allywith.states", 0)))
					.doWithI18n(player.getPlayerData().getLocale())
					.updateItemStack(1, player.getInventory().getItem(1));
		
		} else {
			player.sendTranslatedMessage("buildcontest.messages.teams.youdonthaveinvitation");
		}
		
		return true;
	}
	
}
