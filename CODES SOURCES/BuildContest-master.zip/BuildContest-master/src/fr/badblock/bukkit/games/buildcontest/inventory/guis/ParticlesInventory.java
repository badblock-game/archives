package fr.badblock.bukkit.games.buildcontest.inventory.guis;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryView;
import org.bukkit.inventory.ItemStack;

import fr.badblock.bukkit.games.buildcontest.inventory.gui.LayoutGui;
import fr.badblock.bukkit.games.buildcontest.inventory.gui.SharedGUI;
import fr.badblock.bukkit.games.buildcontest.team.Team;
import fr.badblock.bukkit.games.buildcontest.team.TeamManager;
import fr.badblock.bukkit.games.buildcontest.utils.ArchiUtils;

public class ParticlesInventory extends SharedGUI {

	private ItemStack YOUR_PARTICLES, PARTICLES_LIST;
	
	private PlayerParticleInv playerParticleInv;
	private ParticlesListInv particlesListInv;
	
	public ParticlesInventory(Team team) {
		super(team);
	}

	public ParticlesInventory buildInv() {
		Inventory inv = Bukkit.createInventory(null, 9*3, i18n("buildcontest.inventory.particlesinv.displayname"));
		build(inv, LayoutGui.LAYOUT_RETURN_ONLY);
		
		YOUR_PARTICLES = create(ArchiUtils.createItem(Material.FIREWORK_CHARGE, 1, 0, i18n("buildcontest.inventory.particlesinv.items.yourparticles.displayname"), ""), 12);
		PARTICLES_LIST = create(ArchiUtils.createItem(Material.FIREWORK, 1, 0, i18n("buildcontest.inventory.particlesinv.items.particleslist.displayname"), ""), 14);
		
		playerParticleInv = new PlayerParticleInv(TeamManager.getTeam(getPlayer())).buildInv();
		particlesListInv = new ParticlesListInv(TeamManager.getTeam(getPlayer())).buildInv();
		
		return this;
	}
	
	@Override
	public void onItemClick(Player p, ItemStack stack, InventoryAction action, ClickType click, ItemStack cursor, int slot, InventoryView view) {
		if(stack != null) {
			if(stack.isSimilar(YOUR_PARTICLES)) {
				openPlayerParticleInv(p);
			} else if(stack.isSimilar(PARTICLES_LIST)) {
				openParticlesListInv(p);
			}
		}
	}
	
	private void openPlayerParticleInv(Player p) {
		display(p, playerParticleInv);
	}
	
	private void openParticlesListInv(Player p) {
		display(p, particlesListInv);
	}

	public PlayerParticleInv getPlayerParticleInv() {
		return playerParticleInv;
	}

	@Override
	public void onItemClick(ItemStack stack, InventoryAction action, ClickType click, ItemStack cursor, int slot,
			InventoryView view) {
		// TODO Auto-generated method stub
		
	}

}
