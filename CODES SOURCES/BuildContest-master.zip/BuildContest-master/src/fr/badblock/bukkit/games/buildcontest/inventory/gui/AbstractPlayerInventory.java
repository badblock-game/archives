package fr.badblock.bukkit.games.buildcontest.inventory.gui;

import java.util.ArrayList;

import org.bukkit.entity.Player;
import org.bukkit.event.block.Action;
import org.bukkit.inventory.ItemStack;

import fr.badblock.bukkit.games.buildcontest.inventory.InventoryManager;
import fr.badblock.gameapi.GameAPI;
import fr.badblock.gameapi.players.BadblockPlayer;
import lombok.Getter;

public abstract class AbstractPlayerInventory {

	@Getter
	private Player player;
	
	public AbstractPlayerInventory(Player player) {
		this.player = player;
		InventoryManager.hotbars.put(this, new ArrayList<>());
	}
	
	public void create(ItemStack stack, int slot) {
		getPlayer().getInventory().setItem(slot, stack);
		registerItemClick(stack);
	}
	
	public void registerItemClick(ItemStack stack) {
		ArrayList<ItemStack> clicks = InventoryManager.hotbars.get(this);
		if(clicks == null) {
			clicks = new ArrayList<>();
		}
		clicks.add(stack);
		InventoryManager.update(this, clicks);
	}
	
	public abstract void onItemClick(ItemStack stack, Action action);
	
	public String i18n(String key, Object... args){
		return GameAPI.i18n().get(((BadblockPlayer) player).getPlayerData().getLocale(), key, args)[0];
	}
	
}
