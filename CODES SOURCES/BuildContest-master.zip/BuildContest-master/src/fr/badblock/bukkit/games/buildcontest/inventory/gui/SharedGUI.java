package fr.badblock.bukkit.games.buildcontest.inventory.gui;

import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.inventory.InventoryView;
import org.bukkit.inventory.ItemStack;

import fr.badblock.bukkit.games.buildcontest.data.BuildContestData;
import fr.badblock.bukkit.games.buildcontest.inventory.InventoryManager;
import fr.badblock.bukkit.games.buildcontest.team.Team;
import fr.badblock.gameapi.players.BadblockPlayer;
import lombok.Getter;

public abstract class SharedGUI extends AbstractInventoryGUI {

	/* Meilleur moyen : faire un shared gui, l'owner de la team sera la souce de la langue */
	@Getter
	private Team team;
	
	public SharedGUI(Team team) {
		super(team.getPlayers().get(0));
		this.team = team;
	}
	
	public abstract void onItemClick(Player p, ItemStack stack, InventoryAction action, ClickType click, ItemStack cursor, int slot,
			InventoryView view);
	
	@Deprecated
	@Override
	public abstract void onItemClick(ItemStack stack, InventoryAction action, ClickType click, ItemStack cursor, int slot,
			InventoryView view);
	
	public void display(Player p, AbstractInventoryGUI gui) {
		gui.setBack(this);
		gui.open(p);
		((BadblockPlayer) p).inGameData(BuildContestData.class).current = gui;
		InventoryManager.add(gui);
	}
	
	public void displayBack(Player p) {
		if(this.back != null) {
			p.openInventory(back.current);
			((BadblockPlayer) p).inGameData(BuildContestData.class).current = back;
		}
	}
	
}
