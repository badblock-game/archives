package fr.badblock.bukkit.games.buildcontest.team;

import org.bukkit.entity.Player;

import fr.badblock.gameapi.players.BadblockPlayer;
import lombok.Getter;
import lombok.Setter;

/**
 * 
 * @author Coco
 * G�re les invitations en team
 *
 */
public class InvitationManager {

	@Getter@Setter
	public static boolean can = true;
	
	public static boolean createInvitation(Player first, Player second) {
		return can && TeamInvitation.put(first, second);
	}
	
	public static boolean cancelInvitation(Player first) {
		TeamInvitation playerInvit = TeamInvitation.get(first);
		if(playerInvit == null) return false;
		playerInvit.cancel();
		return true;
	}

	public static boolean isInvited(BadblockPlayer player) {
		return can && TeamInvitation.get(player) != null;
	}

	public static boolean isInInvitationWith(BadblockPlayer player, BadblockPlayer target) {
		return isInvited(player) && TeamInvitation.get(player).getPlayers().contains(target.getName());
	}

	public static TeamInvitation getInvitation(BadblockPlayer player) {
		return TeamInvitation.get(player);
	}
	
}
