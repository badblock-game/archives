package fr.badblock.bukkit.games.buildcontest.schematic;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;

import fr.badblock.bukkit.games.buildcontest.jnbt.ByteArrayTag;
import fr.badblock.bukkit.games.buildcontest.jnbt.CompoundTag;
import fr.badblock.bukkit.games.buildcontest.jnbt.IntTag;
import fr.badblock.bukkit.games.buildcontest.jnbt.NBTInputStream;
import fr.badblock.bukkit.games.buildcontest.jnbt.NBTOutputStream;
import fr.badblock.bukkit.games.buildcontest.jnbt.ShortTag;
import fr.badblock.bukkit.games.buildcontest.jnbt.StringTag;
import fr.badblock.bukkit.games.buildcontest.jnbt.Tag;

public class SchematicHelper {

	@SuppressWarnings("deprecation")
	public static void pasteSchematic(Player p, Schematic schematic) {
		byte[] blocks = schematic.getBlocks();
		byte[] datas = schematic.getData();
		
		int xpos = p.getLocation().getBlockX();
		int ypos = p.getLocation().getBlockY();
		int zpos = p.getLocation().getBlockZ();
		
		xpos++;
		
		int width = schematic.getWidth();
		int length = schematic.getLength();
		
		for(int x = 0; x < schematic.getWidth(); x++) {
			for(int y = 0; x < schematic.getHeight(); y++) {
				for(int z = 0; z < schematic.getLength(); z++) {
					int index = y * width * length + z * width + x;
					p.getLocation().getWorld().getBlockAt(x + xpos, y + ypos, z + zpos).setTypeIdAndData(blocks[index], datas[index], true);
					p.getLocation().getWorld().getBlockAt(x + xpos, y + ypos, z + zpos).getState().update(true);
				}
			}
		}
	}
	
	@SuppressWarnings("deprecation")
	public static void pasteSchematic(World world, Location loc, Schematic schematic)
    {
        byte[] blocks = schematic.getBlocks();
        byte[] blockData = schematic.getData();
 
        short length = schematic.getLength();
        short width = schematic.getWidth();
        short height = schematic.getHeight();
 
        for (int x = 0; x < width; ++x) {
            for (int y = 0; y < height; ++y) {
                for (int z = 0; z < length; ++z) {
                    int index = y * width * length + z * width + x;
                    Block block = new Location(world, x + loc.getX(), y + loc.getY(), z + loc.getZ()).getBlock();
                    block.setTypeIdAndData(blocks[index], blockData[index], true);
                }
            }
        }
    }
	
    public static void saveSchematic(Schematic schematic, File file) throws Exception {
    	//Test to create a fake schematic
    	FileOutputStream output = new FileOutputStream(file);
    	NBTOutputStream nbtStream = new NBTOutputStream(output);
    	
    	Map<String, Tag> map = new HashMap<>();
    	
    	byte[] byteBlocks = schematic.getBlocks();
    	byte[] byteData = schematic.getData();
    	
    	ByteArrayTag blocks = new ByteArrayTag("Blocks", byteBlocks);
    	ByteArrayTag datas = new ByteArrayTag("Data", byteData);
    	
    	StringTag materials = new StringTag("Materials", "Alpha");
    	
    	Tag width = new ShortTag("Width", schematic.getWidth());
    	Tag length = new ShortTag("Length", schematic.getLength());
    	Tag height = new ShortTag("Height", schematic.getHeight());
    	
    	Tag WEOriginX = new IntTag("WEOriginX", schematic.getOriginX());
    	Tag WEOriginY = new IntTag("WEOriginY", schematic.getOriginY());
    	Tag WEOriginZ = new IntTag("WEOriginZ", schematic.getOriginZ());
    	
    	map.put("Height", height);
    	map.put("Length", length);
    	map.put("Width", width);
    	
    	map.put("WEOriginX", WEOriginX);
    	map.put("WEOriginY", WEOriginY);
    	map.put("WEOriginZ", WEOriginZ);
    	
    	map.put("Blocks", blocks);
    	map.put("Data", datas);
    	
    	map.put("Materials", materials);
    	
    	CompoundTag schematicTag = new CompoundTag("Schematic", map);
    	
    	nbtStream.writeTag(schematicTag);
    	nbtStream.close();
    	
    	//CompoundTag schematicTag = new CompoundTag("Schematic", value)
    }
    
    public static Schematic loadSchematic(File file) throws IOException
    {
        FileInputStream stream = new FileInputStream(file);
        @SuppressWarnings("resource")
		NBTInputStream nbtStream = new NBTInputStream(stream);

        CompoundTag schematicTag = (CompoundTag) nbtStream.readTag();
        if (!schematicTag.getName().equals("Schematic")) {
            throw new IllegalArgumentException("Tag \"Schematic\" does not exist or is not first");
        }

        Map<String, Tag> schematic = schematicTag.getValue();
        if (!schematic.containsKey("Blocks")) {
            throw new IllegalArgumentException("Schematic file is missing a \"Blocks\" tag");
        }

        short width = getChildTag(schematic, "Width", ShortTag.class).getValue();
        short length = getChildTag(schematic, "Length", ShortTag.class).getValue();
        short height = getChildTag(schematic, "Height", ShortTag.class).getValue();

        String materials = getChildTag(schematic, "Materials", StringTag.class).getValue();
        if (!materials.equals("Alpha")) {
            throw new IllegalArgumentException("Schematic file is not an Alpha schematic");
        }

        byte[] blocks = getChildTag(schematic, "Blocks", ByteArrayTag.class).getValue();
        byte[] blockData = getChildTag(schematic, "Data", ByteArrayTag.class).getValue();
        return new Schematic(blocks, blockData, width, length, height);
    }
    
    

    /**
     * Get child tag of a NBT structure.
     *
     * @param items The parent tag map
     * @param key The name of the tag to get
     * @param expected The expected type of the tag
     * @return child tag casted to the expected type
     * expected type
     */
    private static <T extends Tag> T getChildTag(Map<String, Tag> items, String key, Class<T> expected) throws IllegalArgumentException
    {
        if (!items.containsKey(key)) {
            throw new IllegalArgumentException("Schematic file is missing a \"" + key + "\" tag");
        }
        Tag tag = items.get(key);
        if (!expected.isInstance(tag)) {
            throw new IllegalArgumentException(key + " tag is not of tag type " + expected.getName());
        }
        return expected.cast(tag);
    }
}
