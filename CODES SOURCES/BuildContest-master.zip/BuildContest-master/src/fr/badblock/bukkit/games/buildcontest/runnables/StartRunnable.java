package fr.badblock.bukkit.games.buildcontest.runnables;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import fr.badblock.bukkit.games.buildcontest.BuildContestPlugin;
import fr.badblock.bukkit.games.buildcontest.achievements.scoreboard.BuildContestScoreboard;
import fr.badblock.bukkit.games.buildcontest.config.BuildContestMapConfiguration;
import fr.badblock.bukkit.games.buildcontest.data.BuildContestData;
import fr.badblock.bukkit.games.buildcontest.plots.Plot;
import fr.badblock.bukkit.games.buildcontest.team.InvitationManager;
import fr.badblock.bukkit.games.buildcontest.team.Team;
import fr.badblock.bukkit.games.buildcontest.team.TeamManager;
import fr.badblock.bukkit.games.buildcontest.tools.ToolList;
import fr.badblock.gameapi.GameAPI;
import fr.badblock.gameapi.players.BadblockPlayer;
import fr.badblock.gameapi.players.BadblockPlayer.BadblockMode;
import fr.badblock.gameapi.utils.i18n.TranslatableString;
import fr.badblock.gameapi.utils.i18n.messages.GameMessages;
import lombok.AllArgsConstructor;

@AllArgsConstructor
public class StartRunnable extends BukkitRunnable {
	public static final int 		  TIME_BEFORE_START = 300;
	public static     	StartRunnable task 		        = null;
	public static    	GameRunnable  gameTask		    = null;
	
	public static int time = TIME_BEFORE_START;

	private String chooseMap() {
		Random random = new Random();
		return BuildContestPlugin.getInstance().getMaps().get(random.nextInt(BuildContestPlugin.getInstance().getMaps().size()));
	}
	
	private void setEveryoneInTeam() {
		//Adding all players in team : 2Player teams and Solo teams
		for(Player player : BuildContestPlugin.getInstance().getSoloPlayers()) {
			TeamManager.addSoloTeam(player);
			BadblockPlayer bPlayer = (BadblockPlayer) player;
			bPlayer.inGameData(BuildContestData.class).points = 4;
		}
		
	}
	
	private void setTeamPositions() {
		//Full random
		List<Team> teams = new ArrayList<Team>(TeamManager.getTeams());
		int size = teams.size();
		int realSize = size;
		Random r = new Random();
		for(int i = 0; i < size; i++) {
			Team random = teams.get(r.nextInt(realSize));
			teams.remove(random);
			realSize--;
			BuildContestPlugin.getInstance().TEAMS_TO_TP.put(i, random);
			System.out.println("Setting to place " + i + " : " + random);
		}
		
	}
	
	@Override
	public void run() {
		if(time == 0){
			
			BuildContestPlugin.getInstance().setInLobby(false);
			if(BuildContestPlugin.getInstance().getTNTRun() != null)
				BuildContestPlugin.getInstance().getTNTRun().disable();
			
			String winner = chooseMap();
					
			for(Player player : Bukkit.getOnlinePlayers()){
				BadblockPlayer bp = (BadblockPlayer) player;
				BuildContestScoreboard sb = new BuildContestScoreboard((BadblockPlayer) player);
				BuildContestPlugin.getInstance().getScoreboards().put(((BadblockPlayer) player), sb);
				bp.sendTranslatedMessage("buildcontest.messages.mapchoosed", BuildContestPlugin.getInstance().getMapNames().get(winner));
			}
			
			setEveryoneInTeam();
			setTeamPositions();
			InvitationManager.setCan(false);
			
			//String winner = GameAPI.getAPI().getBadblockScoreboard().getWinner().getInternalName();
			File   file   = new File(BuildContestPlugin.MAP, winner + ".json");

			BuildContestMapConfiguration config = new BuildContestMapConfiguration(GameAPI.getAPI().loadConfiguration(file));
			config.save(file);
			BuildContestPlugin.getInstance().setMapConfiguration(config);
			Iterator<Location> iterator = config.getAreaCenterLocations().iterator();
			
			for(Team team : TeamManager.getTeams()) {
				//boolean solo = team.getPlayers().size() == 1;
				
				if (iterator.hasNext()) {
					Location loc = iterator.next();
					
					BuildContestPlugin.getInstance().TEAM_PLOT.put(team, loc);
					//OLD BuildContestPlugin.getInstance().playerstpvote.add(team);
					
					for(Player player : team.getPlayers()) {
						BadblockPlayer bPlayer = (BadblockPlayer) player;
						bPlayer.playSound(Sound.ORB_PICKUP);
						bPlayer.setBadblockMode(BadblockMode.PLAYER);
						BuildContestPlugin.getInstance().getPlayers().add(bPlayer);
						// Loc ici //
						
						bPlayer.inGameData(BuildContestData.class).area = loc.clone().add(0, 1, 0); 
						
						// ------- //
								
						int size = config.getSideLength().intValue();
						double x = loc.getX();
						double z = loc.getZ();
						
						double x1 = x - (size / 2);
						double x2 = x + (size / 2);
								
						double z1 = z - (size / 2);
						double z2 = z + (size / 2);
							
						int y = config.getFloorY().intValue();
						int ymax = config.getMaxY().intValue();
								
						World world = loc.getWorld();
								
						Location p1 = new Location(world, x1, y, z1);
						Location p2 = new Location(world, x2, ymax, z2);
								
						Plot plot = new Plot(team, loc, p1, p2);
						BuildContestPlugin.getInstance().addPlot(plot);
								
						// ------- //
						player.setAllowFlight(true);
					
						player.getInventory().clear();
						
						player.setGameMode(GameMode.CREATIVE);
						
						Location toTp = bPlayer.inGameData(BuildContestData.class).area.clone();
						toTp.setY(config.getMaxY().intValue() - 2);
						toTp.setPitch(player.getLocation().getPitch());
						toTp.setYaw(player.getLocation().getYaw());
						player.teleport(toTp);
						
						player.getInventory().setItem(8, ToolList.OPEN_TOOLS.getStack(bPlayer));
						
						player.setFlying(true);
						
						plot.reset();
								
						player.setFlying(true);
					}
				}
				
			}
			
			/*for(Player player : Bukkit.getOnlinePlayers()) {
				BadblockPlayer bPlayer = (BadblockPlayer) player;
				bPlayer.playSound(Sound.ORB_PICKUP);
				if (iterator.hasNext()) {
					BuildContestPlugin.getInstance().getPlayers().add(bPlayer);
					// Loc ici //
					Location loc = iterator.next();
					bPlayer.inGameData(BuildContestData.class).area = loc.clone().add(0, 1, 0); 
					
					BuildContestPlugin.getInstance().playerplot.put(bPlayer.getName(), loc);
					BuildContestPlugin.getInstance().playerstpvote.add(bPlayer.getName());
					
					// ------- //
							
					int size = config.getSideLength().intValue();
					double x = loc.getX();
					double z = loc.getZ();
					
					double x1 = x - (size / 2);
					double x2 = x + (size / 2);
							
					double z1 = z - (size / 2);
					double z2 = z + (size / 2);
						
					int y = config.getFloorY().intValue();
					int ymax = config.getMaxY().intValue();
							
					World world = loc.getWorld();
							
					Location p1 = new Location(world, x1, y, z1);
					Location p2 = new Location(world, x2, ymax, z2);
							
					Plot plot = new Plot(player, loc, p1, p2);
					BuildContestPlugin.getInstance().addPlot(plot);
							
					// ------- //
					player.setAllowFlight(true);
				
					player.getInventory().clear();
					
					player.setGameMode(GameMode.CREATIVE);
					Location toTp = bPlayer.inGameData(BuildContestData.class).area.clone();
					toTp.setY(config.getMaxY().intValue() - 2);
					toTp.setPitch(player.getLocation().getPitch());
					toTp.setYaw(player.getLocation().getYaw());
					player.teleport(toTp);
					
					player.getInventory().setItem(8, ToolList.OPEN_TOOLS.getStack());
					
					player.setFlying(true);
					
					plot.reset();
							
					player.setFlying(true);
				}
			}*/
			
			
			gameTask = new GameRunnable(config);
			gameTask.runTaskTimer(GameAPI.getAPI(), 20L, 20L);
			
			cancel();
		} else if(time % 10 == 0 || time <= 5){
			sendTime(time);
		}
		
		if(time <= 10){
			
			if(GameAPI.isJoinable()){
			
				GameAPI.setJoinable(false);
			
			}
		}

		if(time == 5) {
			GameAPI.getAPI().getBadblockScoreboard().endVote();
			BuildContestPlugin.getInstance().setTheme(GameAPI.getAPI().getBadblockScoreboard().getWinner().getInternalName());
		}

		sendTimeHidden(time);

		time--;
	}

	protected void start(){
		sendTime(time);

		runTaskTimer(GameAPI.getAPI(), 0, 20L);
	}
	
	public int getTime() {
		return time;
	}
	
	public void resetTime(){
		time = 180;
		
	}

	private void sendTime(int time){
		ChatColor color = getColor(time);
		TranslatableString title = GameMessages.startIn(time, color);

		for(Player player : Bukkit.getOnlinePlayers()){
			BadblockPlayer bPlayer = (BadblockPlayer) player;

			bPlayer.playSound(Sound.NOTE_PLING);
			bPlayer.sendTranslatedTitle(title.getKey(), title.getObjects());
			bPlayer.sendTimings(2, 30, 2);
		}
	}

	private void sendTimeHidden(int time){
		ChatColor color = getColor(time);
		TranslatableString actionbar = GameMessages.startInActionBar(time, color);

		for(Player player : Bukkit.getOnlinePlayers()){
			BadblockPlayer bPlayer = (BadblockPlayer) player;

			if(time > 0)
				bPlayer.sendTranslatedActionBar(actionbar.getKey(), actionbar.getObjects());
			bPlayer.setLevel(time);
			bPlayer.setExp(0.0f);
		}
	}

	private ChatColor getColor(int time){
		if(time == 1)
			return ChatColor.DARK_RED;
		else if(time <= 5)
			return ChatColor.RED;
		else return ChatColor.AQUA;
	}

	public static void joinNotify(int currentPlayers, int maxPlayers){
		
		if(currentPlayers < BuildContestPlugin.getInstance().getConfiguration().minPlayers) return;
			 
		startGame();
		
		int a = time - (TIME_BEFORE_START / Bukkit.getMaxPlayers());
		
		if (time >= 60 && (a <= 60 || Bukkit.getOnlinePlayers().size() >= Bukkit.getMaxPlayers())) time = 60;
		
		else if (time >= 60) time = a;
		
		else if((Bukkit.getOnlinePlayers().size() <= 2)){
		
			if(time < 60) time = 60;
		
		}	 
	}
	
	public static void startGame(){
		if(task == null){
			
			task = new StartRunnable();
			task.start();
		
		}
	
	}

	public static void stopGame(){
		if(gameTask != null){
			gameTask.forceEnd = true;
			time = TIME_BEFORE_START;
		} else if(task != null){
			task.cancel();
			time = time > 60 ? time : 60;
			GameAPI.setJoinable(true);
		}

		task = null;
		gameTask = null;
	}

	public static boolean started(){
		return task != null;
	}

	public static void cancelStart() {
		if(started()){
			task.cancel();
			task = null;
		}
	}
	
	public String i18n(Player player, String key, Object... args){
		return GameAPI.i18n().get(((BadblockPlayer) player).getPlayerData().getLocale(), key, args)[0];
	}
}
