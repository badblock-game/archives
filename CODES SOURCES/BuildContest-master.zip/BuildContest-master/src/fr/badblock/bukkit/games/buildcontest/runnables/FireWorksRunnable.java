package fr.badblock.bukkit.games.buildcontest.runnables;

import org.bukkit.Location;
import org.bukkit.scheduler.BukkitRunnable;

import fr.badblock.bukkit.games.buildcontest.plots.Plot;
import fr.badblock.bukkit.games.buildcontest.utils.ArchiUtils;
import fr.badblock.bukkit.games.buildcontest.utils.FireworkUtils;

public class FireWorksRunnable extends BukkitRunnable {

	private Plot winner;
	int times = 0;
	
	public FireWorksRunnable(Plot winner) {
		this.winner = winner;
	}
	
	@Override
	public void run() {
		Location random = ArchiUtils.getRandomLoc(winner.getLoc1().getBlockY()+1, winner.getBlocks());
		FireworkUtils.spawnRandomFirework(random);
		times++;
		
		if(times >= 20) {
			cancel();
		}
	}
	
}
