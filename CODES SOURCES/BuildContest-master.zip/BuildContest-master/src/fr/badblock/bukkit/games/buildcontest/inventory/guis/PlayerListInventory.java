package fr.badblock.bukkit.games.buildcontest.inventory.guis;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.inventory.ItemStack;

import fr.badblock.bukkit.games.buildcontest.BuildContestPlugin;
import fr.badblock.bukkit.games.buildcontest.team.InvitationManager;
import fr.badblock.bukkit.games.buildcontest.team.TeamManager;
import fr.badblock.bukkit.games.buildcontest.utils.ComponentMessage;
import fr.badblock.gameapi.GameAPI;
import fr.badblock.gameapi.players.BadblockPlayer;
import fr.badblock.gameapi.utils.i18n.TranslatableString;
import fr.badblock.gameapi.utils.itemstack.CustomInventory;
import fr.badblock.gameapi.utils.itemstack.ItemAction;
import fr.badblock.gameapi.utils.itemstack.ItemEvent;
import net.md_5.bungee.api.chat.BaseComponent;

public class PlayerListInventory {
	
	private BadblockPlayer p;
	private CustomInventory inv;
	
	public PlayerListInventory(BadblockPlayer p) {
		this.p = p;
	}
	
	int slot = 0;
	public PlayerListInventory create() {
		inv = GameAPI.getAPI().createCustomInventory(BuildContestPlugin.getDispoPlayers() / 9 + (BuildContestPlugin.getDispoPlayers() % 9 == 0 ? 0 : 1), i18n("buildcontest.inventory.playerlist.displayname"));
		Bukkit.getOnlinePlayers().forEach(player -> {
			BadblockPlayer pl = (BadblockPlayer) player;
			if(!pl.getName().equals(p.getName()) && TeamManager.getTeam(pl) == null) {
				ItemStack stack = GameAPI.getAPI().createItemStackFactory().type(Material.SKULL_ITEM).durability((short) 3).displayName("�b> �7" + player.getName()).create(1);
				inv.addClickableItem(slot, stack, new ItemEvent() {
					
					@Override
					public boolean call(ItemAction action, BadblockPlayer p) {
						
						if(TeamManager.getTeam(p) != null) {
							//a d�j� une team
							ComponentMessage message = new ComponentMessage(new TranslatableString("buildcontest.messages.teams.alreadyinteam").getAsLine(p));
							ComponentMessage clickToBreak = new ComponentMessage(new TranslatableString("buildcontest.messages.teams.clicktoleave.message").getAsLine(p), new TranslatableString("buildcontest.messages.teams.clicktoleave.onhover").getAsLine(p), "/breakmyteamwith " + TeamManager.getTeam(p).getPlayerWith(p).getName());
							BaseComponent[] base = ComponentMessage.create(true, true, message, clickToBreak);
							p.spigot().sendMessage(base);
							return true;
						}
						
						if(Bukkit.getOnlinePlayers().size() <= 2) {
							p.sendTranslatedMessage("buildcontest.messages.notenoughplayerstomakeateam");
							return true;
						}
						
						if(InvitationManager.createInvitation(pl, p)) {
						
							pl.playSound(Sound.ORB_PICKUP);
							pl.sendTranslatedMessage("buildcontest.messages.teams.invitationreceived", p.getName());
							
							ComponentMessage message1 = new ComponentMessage(new TranslatableString("buildcontest.messages.teams.askacceptinvitation").getAsLine(p));
							
							ComponentMessage yes = new ComponentMessage(new TranslatableString("buildcontest.messages.teams.yes.message").getAsLine(p), new TranslatableString("buildcontest.messages.teams.yes.onhover").getAsLine(p), "/iwanttoallywith " + p.getName());
							ComponentMessage no = new ComponentMessage(new TranslatableString("buildcontest.messages.teams.no.message").getAsLine(p), new TranslatableString("buildcontest.messages.teams.no.onhover").getAsLine(p), "/idontwanttoallywith " + p.getName());
							
							ComponentMessage between = new ComponentMessage(" �7- ");
							
							BaseComponent[] all = ComponentMessage.create(true, false, message1, yes, between, no);
							
							pl.spigot().sendMessage(all);
							
							ComponentMessage m1 = new ComponentMessage(new TranslatableString("buildcontest.messages.teams.invitationsent", pl.getName()).getAsLine(p));
							ComponentMessage cancel = new ComponentMessage(new TranslatableString("buildcontest.messages.teams.cancel.message").getAsLine(p), new TranslatableString("buildcontest.messages.teams.cancel.onhover").getAsLine(p), "/cancelallywith " + p.getName());
							
							BaseComponent[] all2 = ComponentMessage.create(true, true, m1, cancel);
							
							p.spigot().sendMessage(all2);
							
							p.closeInventory();
							
							//Set in orange
							GameAPI.getAPI().createItemStackFactory().type(Material.INK_SACK)
							.durability((short) 14)
							.displayName(BuildContestPlugin.getInstance().getState("buildcontest.inventory.joinitems.allywith.displayName", 1, p.getName()))
							.lore(new TranslatableString("buildcontest.inventory.joinitems.allywith.description", BuildContestPlugin.getInstance().getState("buildcontest.inventory.joinitems.allywith.states", 1, p.getName())))
							.doWithI18n(p.getPlayerData().getLocale())
							.updateItemStack(1, p.getInventory().getItem(1));
							
						} else {
							
							p.sendTranslatedMessage("buildcontest.messages.teams.alreadyhaveinvitation");
							
						}
						
						return true;
					}
				});
				slot++;
			}
		});
		return this;
		
	}
	
	public String i18n(String key, Object... args){
		return GameAPI.i18n().get(((BadblockPlayer) p).getPlayerData().getLocale(), key, args)[0];
	}

	public void open() {
		inv.openInventory(p);
	}

}
