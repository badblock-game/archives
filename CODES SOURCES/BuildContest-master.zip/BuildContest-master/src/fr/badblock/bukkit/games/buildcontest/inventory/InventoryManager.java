package fr.badblock.bukkit.games.buildcontest.inventory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import fr.badblock.bukkit.games.buildcontest.inventory.gui.AbstractInventoryGUI;
import fr.badblock.bukkit.games.buildcontest.inventory.gui.AbstractPlayerInventory;
import fr.badblock.bukkit.games.buildcontest.inventory.guis.BuildToolsInventory;
import fr.badblock.bukkit.games.buildcontest.inventory.guis.ChangeGroundInventory;
import fr.badblock.bukkit.games.buildcontest.inventory.guis.ChangeTimeInventory;
import fr.badblock.bukkit.games.buildcontest.team.TeamManager;
import fr.badblock.bukkit.games.buildcontest.utils.ArchiUtils;

public class InventoryManager {

	public static HashMap<AbstractInventoryGUI, ArrayList<ItemStack>> clickeables = new HashMap<>();
	public static HashMap<AbstractPlayerInventory, ArrayList<ItemStack>> hotbars = new HashMap<>();
	
	public static HashMap<String, BuildToolsInventory> toolInvByPlayer = new HashMap<>();
	
	public static int CHANGE_GROUND, CHANGE_TIME, ADD_PARTICLES;
	
	public static HashMap<String, ArrayList<AbstractInventoryGUI>> guisByPlayer = new HashMap<>();
	
	static {
		CHANGE_GROUND = 1;
		CHANGE_TIME = 2;
		ADD_PARTICLES = 3;
	}
	
	public static void add(AbstractInventoryGUI gui) {
		clickeables.put(gui, new ArrayList<>());
	}
	
	public static void update(AbstractInventoryGUI gui, ArrayList<ItemStack> clicks) {
		clickeables.put(gui, clicks);
	}
	
	public static void set(Player p, List<AbstractInventoryGUI> guis) {
		guisByPlayer.put(p.getName(), ArchiUtils.toArrayList(guis));
	}
	
	public static void openInv(Player player, int which) {
		
		if(!guisByPlayer.containsKey(player.getName())) {
			ArrayList<AbstractInventoryGUI> guis = new ArrayList<>(3);
			guisByPlayer.put(player.getName(), guis);
		}
		
		AbstractInventoryGUI gui = guisByPlayer.get(player.getName()).get(which);
		if(gui == null) {
			if(which == CHANGE_GROUND) 
				gui = new ChangeGroundInventory(TeamManager.getTeam(player));
			else if(which == CHANGE_TIME)
				gui = new ChangeTimeInventory(player);
			
			ArrayList<AbstractInventoryGUI> guis = guisByPlayer.get(player.getName());
			guis.set(which-1, gui);
			guisByPlayer.put(player.getName(), guis);
			add(gui);
			gui.open();
			
		} else {
			gui.open();
		}
	}

	public static void update(AbstractPlayerInventory inv, ArrayList<ItemStack> clicks) {
		hotbars.put(inv, clicks);
	}

	public static void openBuildToolsGui(Player player) {
//		BuildToolsInventory gui = new BuildToolsInventory(getPlayer()).buildToolGui();
//		InventoryManager.add(gui);
		
		BuildToolsInventory gui = toolInvByPlayer.get(player.getName());
		if(gui == null) {
			gui = new BuildToolsInventory(player).buildToolGui();
			toolInvByPlayer.put(player.getName(), gui);
			add(gui);
			gui.open(player);
		} else {
			gui.open(player);
		}
	}

	public static ChangeGroundInventory getGroundGui(Player owner) {
		BuildToolsInventory buildTools = toolInvByPlayer.get(owner.getName());
		if(buildTools == null) return null;
		AbstractInventoryGUI gui = buildTools.getCurrentGui();
		if(gui instanceof ChangeGroundInventory) {
			ChangeGroundInventory inv = (ChangeGroundInventory) gui;
			return inv;
		}
		return null;
	}

//	public static PlayerParticleInv getPlayerInv(Player p) {
//		return toolInvByPlayer.get(p.getName()).getParticleGui().getPlayerParticleInv();
//	}
	
}
