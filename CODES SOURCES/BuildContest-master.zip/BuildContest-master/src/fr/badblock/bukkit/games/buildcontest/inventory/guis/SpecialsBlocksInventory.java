package fr.badblock.bukkit.games.buildcontest.inventory.guis;

import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.inventory.InventoryView;
import org.bukkit.inventory.ItemStack;

import fr.badblock.bukkit.games.buildcontest.blocks.SpecialsBlocks;
import fr.badblock.bukkit.games.buildcontest.inventory.gui.ListGUI;
import fr.badblock.bukkit.games.buildcontest.team.Team;

public class SpecialsBlocksInventory extends ListGUI {

	public SpecialsBlocksInventory(Team team) {
		super(team);
	}
	
	public SpecialsBlocksInventory createGui() {
		
		this.buildInv(i18n("buildcontest.inventory.specialblocks.displayname"), SpecialsBlocks.getAllBlocks());
		return this;
		
	}
	
	@Override
	public void onItemClick(Player p, ItemStack stack, InventoryAction action, ClickType type, ItemStack cursor, int slot, InventoryView view) {
		super.onItemClick(p, stack, action, type, cursor, slot, view);
		
		if(SpecialsBlocks.isBlock(stack)) {
			p.getInventory().addItem(stack);
		}
		
	}

}
