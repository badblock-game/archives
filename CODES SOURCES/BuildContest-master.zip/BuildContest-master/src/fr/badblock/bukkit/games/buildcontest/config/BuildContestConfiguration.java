package fr.badblock.bukkit.games.buildcontest.config;

import java.util.ArrayList;

import org.bukkit.Bukkit;

import fr.badblock.gameapi.configuration.values.MapLocation;
import lombok.Data;

@Data
  public class BuildContestConfiguration {

	public String 	   		   fallbackServer   	= "lobby";
	public int    	   		   maxPlayers	    	= 16;
	public int                 requiredPlayersToStart = 2;
	public int    	   		   votePerPlayerTime	= 10;
	public int    	   		   buildTime		    = 20;
	public ArrayList<String>   themes				= new ArrayList<>();
	public MapLocation 		   spawn				= new MapLocation(Bukkit.getWorlds().get(0).getSpawnLocation());
	public int                 maxPlayersInTeam     = 2;
	public boolean teamEnabled = false;
	
	public int 				   minPlayers 			= 4;
	
	
}
