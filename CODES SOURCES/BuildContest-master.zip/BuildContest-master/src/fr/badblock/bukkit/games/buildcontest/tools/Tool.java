package fr.badblock.bukkit.games.buildcontest.tools;

import java.util.Arrays;

import org.bukkit.ChatColor;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import fr.badblock.gameapi.GameAPI;
import fr.badblock.gameapi.players.BadblockPlayer;
import lombok.Data;

@Data
public class Tool {

	private ItemStack stack;
	private ToolAction action;
	
	private String i18ndisplay;
	private String[] i18nlore;
	
	public Tool(ItemStack stack, ToolAction action) {
		this.stack = stack;
		this.action = action;
	}
	
	public ItemStack getStack(BadblockPlayer p) {
		ItemMeta meta = stack.getItemMeta();
		String display = meta.getDisplayName();
		String lore = meta.getLore().get(0);
		
		display = ChatColor.stripColor(display);
		lore = ChatColor.stripColor(lore);
		
		i18ndisplay = GameAPI.getAPI().getI18n().get(p.getPlayerData().getLocale(), display)[0];
		i18nlore = GameAPI.getAPI().getI18n().get(p.getPlayerData().getLocale(), lore);
		
		meta.setDisplayName(i18ndisplay);
		meta.setLore(Arrays.asList(i18nlore));
		
		stack.setItemMeta(meta);
		return stack;
	}
	
	public ItemStack getStack() {
		ItemMeta meta = stack.getItemMeta();
		
		meta.setDisplayName(i18ndisplay);
		meta.setLore(Arrays.asList(i18nlore));
		
		stack.setItemMeta(meta);
		return stack;
	}
	
}
