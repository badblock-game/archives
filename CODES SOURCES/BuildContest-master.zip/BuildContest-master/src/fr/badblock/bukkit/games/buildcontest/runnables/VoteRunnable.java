package fr.badblock.bukkit.games.buildcontest.runnables;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.WeatherType;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import fr.badblock.bukkit.games.buildcontest.BuildContestPlugin;
import fr.badblock.bukkit.games.buildcontest.BuildStage;
import fr.badblock.bukkit.games.buildcontest.achievements.BuildContestAchievementList;
import fr.badblock.bukkit.games.buildcontest.achievements.scoreboard.BuildContestScoreboard;
import fr.badblock.bukkit.games.buildcontest.config.BuildContestConfiguration;
import fr.badblock.bukkit.games.buildcontest.data.BuildContestData;
import fr.badblock.bukkit.games.buildcontest.inventory.vote.VoteInventory;
import fr.badblock.bukkit.games.buildcontest.inventory.vote.VoteOption;
import fr.badblock.bukkit.games.buildcontest.plots.Plot;
import fr.badblock.bukkit.games.buildcontest.schematic.Schematic;
import fr.badblock.bukkit.games.buildcontest.schematic.SchematicHelper;
import fr.badblock.bukkit.games.buildcontest.team.Team;
import fr.badblock.bukkit.games.buildcontest.team.TeamManager;
import fr.badblock.bukkit.games.buildcontest.utils.ArchiJsonUtils;
import fr.badblock.gameapi.GameAPI;
import fr.badblock.gameapi.achievements.PlayerAchievement;
import fr.badblock.gameapi.game.rankeds.RankedCalc;
import fr.badblock.gameapi.game.rankeds.RankedManager;
import fr.badblock.gameapi.players.BadblockPlayer;
import fr.badblock.gameapi.utils.BukkitUtils;

public class VoteRunnable extends BukkitRunnable {
	
	public int time = -1;
	public int current = 0;
	private boolean first = true;
	private boolean failed = false;
	
	public BuildContestConfiguration config;
	
	public VoteRunnable(BuildContestConfiguration config) {
		this.config = config;
	}
	
	public static Team[] getTop(int top) {
		
		System.out.println("want top " + top + " !");
		
		Team[] winners = new Team[top];
		List<Team> temp = new ArrayList<>();
		for(Team pl : TeamManager.getTeams()) {
			temp.add(pl);
		}
		for(int current = 0; current < top; current++) {
			int highest = 0;
			int index = 0;
			int tempi = 0;
			for(Team p : temp) {
				if(p.getOwner() == null) {
					continue;
				}
				BuildContestData data = p.getOwner().inGameData(BuildContestData.class);
				int points = data.getPoints();
				if(points > highest) {
					highest = points;
					index = tempi;
				}
				tempi++;
			}
			winners[current] = temp.get(index);
			temp.remove(index);
		}
		return winners;
	}
	
	private HashMap<BadblockPlayer, Integer> PLAYER_POSITION = new HashMap<>();
	
	public int getPosition(BadblockPlayer p) {
		
		if( PLAYER_POSITION.get(p) != null) return PLAYER_POSITION.get(p);
		
		Team[] teams = getTop(TeamManager.countSoloTeams() + TeamManager.countDuoTeams());
		int playerPos = 0;
		for(int pos = 0; pos < teams.length; pos++) {
			for(Player pl : teams[pos].getPlayers()) {
				if(pl.getName().equals(p.getName())) {
					playerPos = pos+1;
				}
			}
		}
		
		PLAYER_POSITION.put(p, playerPos);
		return PLAYER_POSITION.get(p);
	}
	
	private boolean isInCurrent(Player p) {
		return BuildContestPlugin.getInstance().getCurrent().getPlayers().contains(p);
	}
	
	private boolean endTurn() {
		return time <= 0;
	}
	
	private boolean firstRun() {
		return first;
	}
	
	private int getRemainPlayers() {
		return BuildContestPlugin.getInstance().TEAMS_TO_TP.size();
	}
	
	@Override
	public void run() {
		
		if(endTurn()) {
			
			if(!firstRun() && !failed) {
				
				BadblockPlayer current = (BadblockPlayer) BuildContestPlugin.getInstance().getCurrent().getOwner();
				
				BuildContestPlugin.getInstance().getPlayers().forEach(player -> {
					
					/* on ajoute les points de chaque joueur � la personne qui passe maintenant */
					
					if(!isInCurrent(player)) {
					
						current.inGameData(BuildContestData.class).points += player.inGameData(BuildContestData.class).temp_points;
					
					}
					
					/* On ajoute les points que le joueur a donn� � givedPoints */
					
					player.inGameData(BuildContestData.class).givedPoints += player.inGameData(BuildContestData.class).temp_points;
					
					
					/* On informe le joueur qu'il n'a pas vot� */
					
					if(!isInCurrent(player)) {
						
						String vote = player.inGameData(BuildContestData.class).temp_vote;
						
						if(vote == null || vote.length() == 0) {
							player.sendTranslatedMessage("buildcontest.messages.notvoted");
						}
					
					}
					
					/* On reset */
				
					player.inGameData(BuildContestData.class).temp_points = 0;
					player.inGameData(BuildContestData.class).temp_vote = "";
					
					
				});
			}
			
			if(failed) {
				failed = false;
			}
			
			if(firstRun()) {
//				VoteOption.loadFromConfig();
				
				BuildContestPlugin.getInstance().getPlayers().forEach(player -> {
					VoteInventory inv = new VoteInventory(player).build();
					BuildContestPlugin.getInstance().inventories.put(player.getName(), inv);
				});
				
				first = false;
			}
			
			System.out.println("size: " + BuildContestPlugin.getInstance().TEAMS_TO_TP.size());
			
			if(getRemainPlayers() <= 0) {
				
				//FINISH
				
				BuildContestPlugin.getInstance().setBuildStage(BuildStage.END);
				
				/* comptabilisation des points donn�s par chaque joueurs */
				
				int minToGive = (20 / 100) * ((VoteOption.get().points.length) * BuildContestPlugin.getInstance().getRealPlayersCount());
				
				BuildContestPlugin.getInstance().getPlayers().forEach(player -> {
					
					int givePoints = player.inGameData(BuildContestData.class).givedPoints;
					
					if(givePoints < minToGive) {
						BuildContestPlugin.getInstance().getPlayers().forEach(p -> {
							if(!p.getName().equals(player.getName())) {
								/* on ajoute 2pts � chaque joueur diff�rent du radin */
								p.inGameData(BuildContestData.class).points += 2;
							}
						});
					}
					
				});
				
				/* on get le top 5 */
				
				Team[] winners = getTop(BuildContestPlugin.getInstance().getRealPlayersCount() >= 5 ? 5 : BuildContestPlugin.getInstance().getRealPlayersCount());
				String body = "buildcontest.messages.announce_winners_body";
				String child = "buildcontest.messages.announce_winners_childs";
				
				if(winners.length == 0) {
					Bukkit.shutdown();
				}
				
				BuildContestPlugin.getInstance().setWinner(winners[0]);
				
				for(BuildContestScoreboard scoreboards : BuildContestPlugin.getInstance().getScoreboards().values()) {
					scoreboards.update();
				}
				
				BuildContestData currentData = winners[0].getOwner().inGameData(BuildContestData.class);
				int time = currentData.time;
				String weather = currentData.weather;
				boolean isRain = weather == "rain" ? true : false;
				
				/* ----------------------------------- */
//				
				
				Bukkit.getOnlinePlayers().forEach(online -> {
					BadblockPlayer bp = (BadblockPlayer) online;

					online.resetPlayerTime();
					online.resetPlayerWeather();
						
					online.setPlayerTime(time, true);
					online.setPlayerWeather(isRain ? WeatherType.DOWNFALL : WeatherType.CLEAR);
					
					online.getInventory().clear();
					
					Location toTp = BuildContestPlugin.getInstance().getPlot(winners[0]).getCenter().clone();
					toTp.setY(BuildContestPlugin.getInstance().getMapConfiguration().getMaxY().intValue() - 2);
					toTp.setYaw(online.getLocation().getYaw());
					toTp.setPitch(online.getLocation().getPitch());
					online.teleport(toTp);
					online.setFlying(true);
					
					String[] messages = GameAPI.getAPI().getI18n().get(bp.getPlayerData().getLocale(), body);
					for(String message : messages) {
						if(message.contains("[winners]")) {
							// The place for child
							int place = 1;
							boolean isP = false;
							for(Team player : winners) {
								BuildContestData data = player.getOwner().inGameData(BuildContestData.class);
								bp.sendTranslatedMessage(child, place, player.getName(), data.getPoints());
								
								if(player.getName().contains(online.getName())) {
									isP = true;
								}
								
								place++;
							}
							if(!isP) {
								bp.sendTranslatedMessage("buildcontest.messages.youare");
								bp.sendTranslatedMessage(child, getPosition(bp), bp.getName(), bp.inGameData(BuildContestData.class).getPoints());
							}
							
						} else {
							bp.sendMessage(message);
						}	
					}
					
					bp.heal();
					bp.clearInventory();
					bp.setInvulnerable(true);
					
				});
				
				int[] listbadcoins = {30, 20, 15, 10, 5, 2};
				Team[] all = getTop(BuildContestPlugin.getInstance().getRealPlayersCount());
				for(int current = 0; current < all.length; current++) {
					Team t = all[current];
					
					for(Player pl : t.getPlayers()) {
						BadblockPlayer bp = (BadblockPlayer) pl;
						if(!bp.getName().equals(winners[0].getName())) {
							bp.getPlayerData().incrementStatistic("buildcontest", BuildContestScoreboard.LOOSES);
							bp.getPlayerData().incrementTempRankedData(RankedManager.instance.getCurrentRankedGameName(), BuildContestScoreboard.LOOSES, 1);
						}
						
						int coinsIndex = current >= 5 ? 5 : current;
						double badcoins = listbadcoins[coinsIndex];
						double xp = badcoins * 1.5d;
						
						if(badcoins > 20 * bp.getPlayerData().getBadcoinsMultiplier())
							badcoins = 20 * bp.getPlayerData().getBadcoinsMultiplier();
						if(xp > 50 * bp.getPlayerData().getXpMultiplier())
							xp = 50 * bp.getPlayerData().getXpMultiplier();
	
						int rbadcoins = badcoins < 2 ? 2 : (int) badcoins;
						int rxp		  = xp < 5 ? 5 : (int) xp;
	
						bp.getPlayerData().addBadcoins(rbadcoins, true);
						bp.getPlayerData().addXp(rxp, true);
	
						new BukkitRunnable(){
	
							@Override
							public void run(){
								if(bp.isOnline()){
									bp.sendTranslatedActionBar("buildcontest.win", rbadcoins, rxp);
								}
							}
	
						}.runTaskTimer(GameAPI.getAPI(), 0, 30L);
						
						bp.saveGameData();
					}
					
				}
				
				for(int index = 0; index < winners.length; index++) {
					Team t = winners[index];
					PlayerAchievement succes = index == 0 ? BuildContestAchievementList.FINISH_FIRST
							: (index == 1 ? BuildContestAchievementList.FINISH_SECOND
							: (index == 2 ? BuildContestAchievementList.FINISH_THIRD
							: (index == 3 ? BuildContestAchievementList.FINISH_FOURTH
							: (index == 4 ? BuildContestAchievementList.FINISH_FIFTH : null))));
					for(Player pl : t.getPlayers()) {
						BadblockPlayer now = (BadblockPlayer) pl;
						now.getPlayerData().incrementAchievements(now, succes);
						now.saveGameData();
					}
				}
				
				/* Ajouter une victoire au premier */
				
				Team firstTeam = winners[0];
				
				for(Player pl : firstTeam.getPlayers()) {
					BadblockPlayer first = (BadblockPlayer) pl;
					first.getPlayerData().incrementStatistic("buildcontest", BuildContestScoreboard.WINS);
					first.getPlayerData().incrementTempRankedData(RankedManager.instance.getCurrentRankedGameName(), BuildContestScoreboard.WINS, 1);
					first.getPlayerData().incrementAchievements(first, BuildContestAchievementList.BC_WIN_1, BuildContestAchievementList.BC_WIN_2, BuildContestAchievementList.BC_WIN_3, BuildContestAchievementList.BC_WIN_4);
					first.saveGameData();
				}
				
				/* Ajouter une partie jou�e a chacun */
				
				Bukkit.getOnlinePlayers().forEach(player ->{
					
					BadblockPlayer bp = (BadblockPlayer) player;
					bp.getPlayerData().incrementAchievements(bp, BuildContestAchievementList.BC_PARTICIPATE_1, BuildContestAchievementList.BC_PARTICIPATE_2, BuildContestAchievementList.BC_PARTICIPATE_3, BuildContestAchievementList.BC_PARTICIPATE_4);
					bp.saveGameData();
					
				});
				
				//Creating and uploading infos:
				
				Team[] top4 = getTop(BuildContestPlugin.getInstance().getRealPlayersCount() >= 4 ? 4 : BuildContestPlugin.getInstance().getRealPlayersCount());
				String[] names = new String[top4.length];
				for(int i = 0; i < top4.length; i++) {
					names[i] = top4[i].getName();
				}
				
				File jsonPlayers = ArchiJsonUtils.createPlayersJson();
				File jsonPoints = ArchiJsonUtils.createPointsJson();
				File jsonWinners = ArchiJsonUtils.createWinnersJson(names);
				
				new UploadRunnable(BuildContestPlugin.getInstance().getGameId(), jsonPlayers).uploadJson();
				new UploadRunnable(BuildContestPlugin.getInstance().getGameId(), jsonPoints).uploadJson();
				new UploadRunnable(BuildContestPlugin.getInstance().getGameId(), jsonWinners).uploadJson();
				
				File themeFile = ArchiJsonUtils.createThemeFile();
				new UploadRunnable(BuildContestPlugin.getInstance().getGameId(), themeFile).uploadJson();
				
				//Start of uploading all schematics to current game
				
				//Loading schematics
				HashMap<String, File> buildings = new HashMap<>();
				for(Plot p : BuildContestPlugin.getInstance().getPlots()) {
					String player = p.getTeam().getName().replace(" + ", "");
					String schemName = player;
					if(winners[0].getName().contains(p.getOwner().getName())) {
						schemName = "winner";
					}
					File f = new File(BuildContestPlugin.getInstance().getDataFolder() + "/temp", schemName + ".schematic");
					Schematic schematic = new Schematic(p.getLoc1(), p.getLoc2());
					try {
						SchematicHelper.saveSchematic(schematic, f);
						buildings.put(player, f);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				
				//Uploading schematics
				for(String pname : buildings.keySet()) {
					File file = buildings.get(pname);
					new UploadRunnable(BuildContestPlugin.getInstance().getGameId(), file).uploadFile();
				}
				
				fireworks();
				cancel();
				
				String results_url = "https://results.badblock.fr/buildcontest?id=" + BuildContestPlugin.getInstance().getGameId().toString();
				
				Bukkit.getOnlinePlayers().forEach(player -> {
					
					BadblockPlayer bplayer = (BadblockPlayer) player;
					
					bplayer.sendTranslatedMessage("buildcontest.messages.endresultmessage", results_url);
					
				});
				

				// Work with rankeds
				String rankedGameName = RankedManager.instance.getCurrentRankedGameName();
				for (BadblockPlayer player : BukkitUtils.getPlayers())
				{
					RankedManager.instance.calcPoints(rankedGameName, player, new RankedCalc()
					{

						@Override
						public long done() {
							double wins = RankedManager.instance.getData(rankedGameName, player, BuildContestScoreboard.WINS);
							double looses = RankedManager.instance.getData(rankedGameName, player, BuildContestScoreboard.LOOSES);
							double total = wins >= 1 ? wins * 3 : looses * -3;
							return (long) total;
						}

					});
				}
				RankedManager.instance.fill(rankedGameName);
				
				new KickRunnable().runTaskTimer(GameAPI.getAPI(), 0L, 20L);
				
			} else {
				
				Team next = BuildContestPlugin.getInstance().TEAMS_TO_TP.get(current);
				
				if(next == null) {
					current++;
					failed = true;
					return;
				}
				
				if(next.getPlayers().size() == 0) {
					BuildContestPlugin.getInstance().TEAMS_TO_TP.remove(current);
					TeamManager.removeTeam(next);
					BuildContestPlugin.getInstance().getPlots().remove(BuildContestPlugin.getInstance().getPlot(next));
					return;
				}
				
				Player player = Bukkit.getPlayer(next.getPlayers().get(0).getName());
				BadblockPlayer plb = (BadblockPlayer) player;
				
				Plot plot = BuildContestPlugin.getInstance().getPlot(next);
				
				BuildContestData currentData = plb.inGameData(BuildContestData.class);
				int time = currentData.time;
				String weather = currentData.weather;
				boolean isRain = weather == "rain" ? true : false;
				
				/* ----------------------------------- */
				
				for(BadblockPlayer p : BuildContestPlugin.getInstance().getPlayers()) {
					
					p.resetPlayerTime();
					p.resetPlayerWeather();
					
					p.setPlayerTime(time, true);
					p.setPlayerWeather(isRain ? WeatherType.DOWNFALL : WeatherType.CLEAR);
					
					Location center = plot.getCenter().clone();
					center.setY(BuildContestPlugin.getInstance().getMapConfiguration().getMaxY().intValue() - 2);
					center.setYaw(p.getLocation().getYaw());
					center.setPitch(p.getLocation().getPitch());
					
					p.teleport(center);
					
					p.setGameMode(GameMode.SURVIVAL);
					p.setAllowFlight(true);
					
					BuildContestPlugin.getInstance().setCurrent(next);
					
					p.sendTranslatedTitle("buildcontest.titles.on_player_building", next.getName());
					
					p.setFlying(true);
					
				}
				
				for(VoteInventory inv : BuildContestPlugin.getInstance().inventories.values()) {
					inv.build();
				}
				
				removeFirst();
				
				this.time = config.votePerPlayerTime;
				
				sleep();
				current++;
			}	
			
		}
		
	}
	
	private void removeFirst() {
		BuildContestPlugin.getInstance().TEAMS_TO_TP.remove(current);
	}
	
	private int task;
	public void sleep() {
		task = Bukkit.getScheduler().scheduleSyncRepeatingTask(GameAPI.getAPI(), new Runnable() {
			
			@Override
			public void run() {
				time--;
				
				if(time <= 0) {
					Bukkit.getScheduler().cancelTask(task);
				}
				
				for(BuildContestScoreboard scoreboards : BuildContestPlugin.getInstance().getScoreboards().values()) {
					scoreboards.update();
				}
				
				BuildContestPlugin.getInstance().getPlayers().forEach(player -> {
					player.sendTranslatedActionBar("buildcontest.messages.teleportnext", time);
				});
				
			}
		}, 20L, 20L);
	}
	
	private void fireworks() {
		new FireWorksRunnable(BuildContestPlugin.getInstance().getPlot(BuildContestPlugin.getInstance().getWinner())).runTaskTimer(GameAPI.getAPI(), 10L, 10L);
	}
	
}
