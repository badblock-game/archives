package fr.badblock.bukkit.games.buildcontest.minigame;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.FallingBlock;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.util.Vector;

import fr.badblock.bukkit.games.buildcontest.BuildContestPlugin;
import fr.badblock.gameapi.BadListener;
import fr.badblock.gameapi.GameAPI;
import fr.badblock.gameapi.players.BadblockPlayer;
import fr.badblock.gameapi.utils.threading.TaskManager;

public class TNTRunListener extends BadListener {
	
	public static List<Block> toRestore = new ArrayList<>();
	private static HashMap<String, Integer> afk = new HashMap<>();
	private static HashMap<String, Location> prevLocs = new HashMap<>();
	
	static {
		tickAFK();
	}
	
	public static boolean areSimilare(Location l1, Location l2) {
		return (l1.getBlockX() == l2.getBlockX() && l1.getBlockY() == l2.getBlockY() && l1.getBlockZ() == l2.getBlockZ());
	}
	
	/*Block base = player.getLocation().getBlock().getRelative(BlockFace.DOWN);
						for(int x = -1; x < 1; x++) {
							for(int z = -1; z < 1; z++) {
								Block b = base.getWorld().getBlockAt(base.getLocation().clone().add(x, 0, z));
								b.setType(Material.AIR);
								b.getState().update(true);
							}
						}
						*/
	
	public static void tickAFK() {
		TNTRun minigame = BuildContestPlugin.getInstance().getTNTRun();
		
		
		String name = "TNTRunListener.startCheck";
		TaskManager.scheduleSyncRepeatingTask(name, new Runnable() {
			
			@Override
			public void run() {
				
				if(!BuildContestPlugin.getInstance().isInLobby()) {
					TaskManager.cancelTaskByName(name);
					return;
				}
				
				if(!minigame.started()) return;
				minigame.getInGame().forEach(player -> {
					if(afk.get(player.getName()) == null) afk.put(player.getName(), 0);
					if(prevLocs.get(player.getName()) == null) prevLocs.put(player.getName(), player.getLocation());
					afk.put(player.getName(), afk.get(player.getName())+1);
					
				});
				
				afk.keySet().forEach(key -> {
					if(!minigame.getInGame().contains(((BadblockPlayer) Bukkit.getPlayer(key)))) return;
					int value = afk.get(key);
					if(value >= 2) {
						Block base = Bukkit.getPlayer(key).getLocation().getBlock().getRelative(BlockFace.DOWN);
						for(int x = -2; x < 2; x++) {
							for(int z = -2; z < 2; z++) {
								Block b = base.getWorld().getBlockAt(base.getLocation().clone().add(x, 0, z));
								if(minigame.isFloor(b)) {
									b.setType(Material.AIR);
									b.getState().update(true);
									toRestore.add(b);
								}
							}
						}
					}
				});
				
			}
		}, 20, 20);
	}
	
	@EventHandler
	public void move(PlayerMoveEvent e) {
		if(BuildContestPlugin.getInstance().getTNTRun() == null) {
			return;
		}
		
		if(!BuildContestPlugin.getInstance().isInLobby()) {
			return;
		}
		
		BadblockPlayer pl = (BadblockPlayer) e.getPlayer();
		TNTRun minigame = BuildContestPlugin.getInstance().getTNTRun();
		if(minigame.isInGame(pl)) {
			
			if(minigame.started()) {
				Location now = e.getPlayer().getLocation();
				if(prevLocs.get(pl.getName()) != null && !areSimilare(now, prevLocs.get(pl.getName()))) {
					afk.put(pl.getName(), 0);
					prevLocs.put(pl.getName(), pl.getLocation());
				}
				Block under = e.getPlayer().getLocation().getBlock().getRelative(BlockFace.DOWN);
				if(minigame.isFloor(under)) {
					toRestore.add(under);
					runLater(new Runnable() {
						
						@SuppressWarnings("deprecation")
						@Override
						public void run() {
							FallingBlock b = pl.getWorld().spawnFallingBlock(under.getLocation().clone().add(0, -0.1, 0), under.getType(), under.getData());
							b.setTicksLived(12);
							b.setDropItem(false);
							b.setVelocity(new Vector(0, 0, 0));
							under.setType(Material.AIR);
							under.getState().update(true);
							runLater(new Runnable() {
								@Override
								public void run() {
									b.remove();
								}
							}, 12);
						}
					}, 5);
				}
			}
			
			Block b = e.getTo().getBlock();
			if(!minigame.getArea().contains(b) && !minigame.started()) {
				if(minigame.isInGame(pl)) {
					minigame.notifyLeave(pl);
				}
			}
			
		} else {
			Block b = e.getTo().getBlock();
			if(minigame.getArea().contains(b)) {
				if(!minigame.started())
					minigame.notifyJoined(pl);
				else {
					pl.teleport(BuildContestPlugin.getInstance().getConfiguration().getSpawn().getHandle());
					pl.sendTranslatedMessage("buildcontest.messages.tntrun.gamestartedsorry");
				}
			}
		}
		
	}
	
	public static void runLater(Runnable runnable, int delay) {
		TaskManager.scheduler.scheduleSyncDelayedTask(GameAPI.getAPI(), runnable, delay);
	}
	
	@EventHandler
	public void damage(EntityDamageEvent e) {
		if(e.getEntity() instanceof Player) {
			if(e.getCause() == DamageCause.VOID) {
				BadblockPlayer pl = (BadblockPlayer) e.getEntity();
				TNTRun minigame = BuildContestPlugin.getInstance().getTNTRun();
				if(minigame.isStarted() && minigame.isInGame(pl)) {
					minigame.notifyLose(pl);
					pl.teleport(BuildContestPlugin.getInstance().getConfiguration().getSpawn().getHandle());
				} else if(!minigame.isStarted()) {
					pl.teleport(BuildContestPlugin.getInstance().getConfiguration().getSpawn().getHandle());
				}
			}
		}
	}
	
}
