package fr.badblock.bukkit.games.buildcontest.runnables;

import org.bukkit.Location;
import org.bukkit.scheduler.BukkitRunnable;

import fr.badblock.bukkit.games.buildcontest.particles.Particle;
import lombok.Getter;
import lombok.Setter;

public class ParticleRunnable extends BukkitRunnable {

	@Getter@Setter
	private Particle particle;
	
	@Getter@Setter
	private Location loc;
	
	public ParticleRunnable(Particle particle, Location loc) {
		this.particle = particle;
		this.loc = loc;
	}
	
	@Override
	public void run() {
		particle.getAction().tick(loc);
	}
	
}
