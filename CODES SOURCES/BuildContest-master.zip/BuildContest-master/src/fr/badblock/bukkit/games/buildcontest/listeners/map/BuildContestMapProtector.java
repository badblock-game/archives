package fr.badblock.bukkit.games.buildcontest.listeners.map;

import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Item;
import org.bukkit.event.block.Action;

import fr.badblock.bukkit.games.buildcontest.BuildContestPlugin;
import fr.badblock.bukkit.games.buildcontest.BuildStage;
import fr.badblock.bukkit.games.buildcontest.plots.Plot;
import fr.badblock.bukkit.games.buildcontest.team.TeamManager;
import fr.badblock.gameapi.GameAPI;
import fr.badblock.gameapi.game.GameState;
import fr.badblock.gameapi.players.BadblockPlayer;
import fr.badblock.gameapi.players.BadblockPlayer.BadblockMode;
import fr.badblock.gameapi.servers.MapProtector;

public class BuildContestMapProtector implements MapProtector {
	private boolean inGame(){
		return GameAPI.getAPI().getGameServer().getGameState() == GameState.RUNNING && BuildContestPlugin.getInstance().getBuildStage().equals(BuildStage.BUILD);
	}

	@Override
	public boolean blockPlace(BadblockPlayer player, Block block) {
		
		if(player.hasAdminMode()) return true;
		
		if((inGame() && player.getBadblockMode().equals(BadblockMode.PLAYER) && block.getY() > BuildContestPlugin.getInstance().getMapConfiguration().getFloorY().intValue())) {
			//Check if in bounds
			Plot plot = BuildContestPlugin.getInstance().getPlot(TeamManager.getTeam(player));
			
			if(plot == null) return false;
			
			return plot.getArea().isInSelection(block);
			
		} else {
			return false;
		}
		
//		return (inGame() && player.getBadblockMode().equals(BadblockMode.PLAYER) && block.getY() > BuildContestPlugin.getInstance().getMapConfiguration().getYMinLimit().intValue()) || player.hasAdminMode();
	}

	@Override
	public boolean blockBreak(BadblockPlayer player, Block block) {
		
		if(player.hasAdminMode()) return true;
		
		if((inGame() && player.getBadblockMode().equals(BadblockMode.PLAYER) && block.getY() > BuildContestPlugin.getInstance().getMapConfiguration().getFloorY().intValue())) {
			
			//Check if in bounds
			Plot plot = BuildContestPlugin.getInstance().getPlot(TeamManager.getTeam(player));
			if(plot == null) return false;
			return plot.getArea().isInSelection(block);
			
		} else {
			return false;
		}
		
//		return(inGame() && player.getBadblockMode().equals(BadblockMode.PLAYER) && block.getY() > BuildContestPlugin.getInstance().getMapConfiguration().getYMinLimit().intValue()) || player.hasAdminMode();
	}

	@Override
	public boolean modifyItemFrame(BadblockPlayer player, Entity itemFrame) {
		return inGame() || player.hasAdminMode();
	}

	@Override
	public boolean canLostFood(BadblockPlayer player) {
		return false;
	}

	@Override
	public boolean canUseBed(BadblockPlayer player, Block bed) {
		return false;
	}

	@Override
	public boolean canUsePortal(BadblockPlayer player) {
		return false;
	}

	@Override
	public boolean canDrop(BadblockPlayer player) {
		return inGame() || player.hasAdminMode();
	}

	@Override
	public boolean canPickup(BadblockPlayer player) {
		return inGame() || player.hasAdminMode();
	}

	@Override
	public boolean canFillBucket(BadblockPlayer player) {
		return inGame() || player.hasAdminMode();
	}

	@Override
	public boolean canEmptyBucket(BadblockPlayer player) {
		return inGame() || player.hasAdminMode();
	}

	@Override
	public boolean canInteract(BadblockPlayer player, Action action, Block block) {
		return inGame() || player.hasAdminMode();
	}

	@Override
	public boolean canInteractArmorStand(BadblockPlayer player, ArmorStand entity) {
		return true;
	}

	@Override
	public boolean canInteractEntity(BadblockPlayer player, Entity entity) {
		return (entity.getType() != EntityType.ARMOR_STAND || entity.getType() != EntityType.ITEM_FRAME);
	}

	@Override
	public boolean canEnchant(BadblockPlayer player, Block table) {
		return true;
	}

	@Override
	public boolean canBeingDamaged(BadblockPlayer player) {
		return false;
	}

	@Override
	public boolean healOnJoin(BadblockPlayer player) {
		return true;
	}

	@Override
	public boolean canBlockDamage(Block block) {
		return false;
	}

	@Override
	public boolean allowFire(Block block) {
		return false;
	}

	@Override
	public boolean allowMelting(Block block) {
		return false;
	}

	@Override
	public boolean allowBlockFormChange(Block block) {
		return true;
	}

	@Override
	public boolean allowPistonMove(Block block) {
		return false;
	}

	@Override
	public boolean allowBlockPhysics(Block block) {
		return true;
	}

	@Override
	public boolean allowLeavesDecay(Block block) {
		return false;
	}

	@Override
	public boolean allowRaining() {
		return false;
	}

	@Override
	public boolean modifyItemFrame(Entity itemframe) {
		return true;
	}

	@Override
	public boolean canSoilChange(Block soil) {
		return false;
	}

	@Override
	public boolean canSpawn(Entity entity) {
		return true;
	}

	@Override
	public boolean canCreatureSpawn(Entity creature, boolean isPlugin) {
		return isPlugin;
	}

	@Override
	public boolean canItemSpawn(Item item) {
		return true;
	}

	@Override
	public boolean canItemDespawn(Item item) {
		return true;
	}

	@Override
	public boolean allowExplosion(Location location) {
		return false;
	}

	@Override
	public boolean allowInteract(Entity entity) {
		return (entity.getType() != EntityType.ARMOR_STAND || entity.getType() != EntityType.ITEM_FRAME);
	}

	@Override
	public boolean canCombust(Entity entity) {
		return false;
	}

	@Override
	public boolean canEntityBeingDamaged(Entity entity) {
		return (entity.getType() != EntityType.ARMOR_STAND || entity.getType() != EntityType.ITEM_FRAME);
	}

	@Override
	public boolean destroyArrow() {
		return true;
	}
	
	@Override
	public boolean canEntityBeingDamaged(Entity entity, BadblockPlayer badblockPlayer) {
		return (entity.getType() != EntityType.ARMOR_STAND || entity.getType() != EntityType.ITEM_FRAME);
	}

}
