package fr.badblock.bukkit.games.buildcontest.data;

import org.bukkit.Location;

import fr.badblock.bukkit.games.buildcontest.inventory.gui.AbstractInventoryGUI;
import fr.badblock.gameapi.players.data.InGameData;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class BuildContestData implements InGameData {

	public Location area;
	public int votes;
	
	public int points;
	public int givedPoints;
	
	public int temp_points;
	public String temp_vote;
	
	public String weather = "sun";
	
	public int time = 700;
	
	public AbstractInventoryGUI current;
	public int amountParticles = 0;
	
}
