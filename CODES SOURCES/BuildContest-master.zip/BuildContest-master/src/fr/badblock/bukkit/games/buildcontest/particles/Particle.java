package fr.badblock.bukkit.games.buildcontest.particles;

import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import lombok.Data;

@Data
public class Particle {

	private String name;
	private ItemStack display;
	private ParticleAction action;
	
	public Particle(String name, ItemStack display, ParticleAction action) {
		this.name = name;
		
		ItemMeta meta = display.getItemMeta();
		meta.setDisplayName(name);
		display.setItemMeta(meta);
		
		this.display = display;
		this.action = action;
	}
	
}
