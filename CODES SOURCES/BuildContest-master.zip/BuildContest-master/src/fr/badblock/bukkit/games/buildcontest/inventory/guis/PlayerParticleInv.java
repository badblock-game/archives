package fr.badblock.bukkit.games.buildcontest.inventory.guis;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.inventory.InventoryView;
import org.bukkit.inventory.ItemStack;

import fr.badblock.bukkit.games.buildcontest.inventory.gui.ListFormat;
import fr.badblock.bukkit.games.buildcontest.inventory.gui.ListGUI;
import fr.badblock.bukkit.games.buildcontest.particles.Particle;
import fr.badblock.bukkit.games.buildcontest.particles.Particles;
import fr.badblock.bukkit.games.buildcontest.team.Team;

public class PlayerParticleInv extends ListGUI {

	private List<Particle> particles = new ArrayList<>();
	
	public PlayerParticleInv(Team team) {
		super(team);
	}

	public PlayerParticleInv buildInv() {
		this.buildInv(i18n("buildcontest.inventory.yourparticlesinv.displayname"), getListFromParticles());
		this.setListFormat(ListFormat.NOT_STACKABLE);
		return this;
	}

	public List<ItemStack> getListFromParticles() {
		List<ItemStack> temp = new ArrayList<>();
		particles.forEach(particle -> {
			temp.add(particle.getDisplay());
		});
		return temp;
	}
	
	@Override
	public void onItemClick(ItemStack stack, InventoryAction action, ClickType click, ItemStack cursor, int slot, InventoryView view) {
		super.onItemClick(stack, action, click, cursor, slot, view);
		//TODO: si clic droit = supprimer, si clic gauche = tp
		if(isParticle(stack)) {
			if(click == ClickType.RIGHT) {
//				getRunnableByParticle(Particles.getParticle(stack), slot).cancel();
				removeSlot(slot);
			}
		}
		
	}
	
	public void removeSlot(int slot) {
		total.remove(slot);
		balanceItems();
		updateCurrentPage();
	}
	
	public boolean isParticle(ItemStack stack) {
		for(Particle p : Particles.particles) {
			if(p.getDisplay().isSimilar(stack)) {
				return true;
			}
		}
		return false;
	}

	public List<Particle> getParticles() {
		return particles;
	}

	public void addParticle(Particle particle) {
		particles.add(particle);
		setList(getListFromParticles());
	}
//	
//	public ParticleRunnable getRunnableByParticle(Particle particle, int index) {
//		List<ParticleRunnable> runnables = Particles.runnables.get(getPlayer().getName());
//		return runnables.get(index);
//	}

}
