package fr.badblock.bukkit.games.buildcontest.listeners;

import java.security.SecureRandom;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import fr.badblock.bukkit.games.buildcontest.BuildContestPlugin;
import fr.badblock.bukkit.games.buildcontest.minigame.TNTRun;
import fr.badblock.bukkit.games.buildcontest.runnables.BossBarRunnable;
import fr.badblock.bukkit.games.buildcontest.runnables.PreStartRunnable;
import fr.badblock.bukkit.games.buildcontest.runnables.StartRunnable;
import fr.badblock.gameapi.BadListener;
import fr.badblock.gameapi.GameAPI;
import fr.badblock.gameapi.players.BadblockPlayer;
import fr.badblock.gameapi.players.BadblockPlayer.BadblockMode;
import fr.badblock.gameapi.utils.i18n.TranslatableString;
import fr.badblock.gameapi.utils.i18n.messages.GameMessages;

public class JoinListener extends BadListener {
	
	@EventHandler
	public void onJoin(PlayerJoinEvent e) {
		e.setJoinMessage(null);
		
		BadblockPlayer p = (BadblockPlayer) e.getPlayer();
		
		if(inGame()) {
			
			p.setGameMode(GameMode.SPECTATOR);
			p.teleport(BuildContestPlugin.getInstance().getPlayers().get(new SecureRandom().nextInt(BuildContestPlugin.getInstance().getPlayers().size())));
			/* tp spec */
			
		//	p.teleport(BuildContestPlugin.getInstance().getConfiguration());
			
		} else {
			
			p.setGameMode(GameMode.SURVIVAL);
			p.sendTranslatedTitle("buildcontest.jointitle");
			p.teleport(BuildContestPlugin.getInstance().getConfiguration().spawn.getHandle());
			p.sendTranslatedTabHeader(new TranslatableString("buildcontest.tab.header"), new TranslatableString("buildcontest.tab.footer"));
			p.getInventory().setItem(0, BuildContestPlugin.getInstance().voteTheme);
			
			//VoteScoreboard sb = new VoteScoreboard(p);
			//BuildContestPlugin.getInstance().voteScoreboards.add(sb);
			
			GameMessages.joinMessage(GameAPI.getGameName(), p.getTabGroupPrefix().getAsLine(p) + p.getName(), Bukkit.getOnlinePlayers().size(), BuildContestPlugin.getInstance().getMaxPlayers()).broadcast();
			
			PreStartRunnable.doJob();
			StartRunnable.joinNotify(Bukkit.getOnlinePlayers().size(), BuildContestPlugin.getInstance().getMaxPlayers());
			p.setBadblockMode(BadblockMode.PLAYER);
		}
	
		
		new BossBarRunnable(p.getUniqueId()).runTaskTimer(GameAPI.getAPI(), 0L, 20L);
		
	}
	
	@EventHandler
	public void onQuit(PlayerQuitEvent e){
		e.setQuitMessage(null);
		
		/*if((Bukkit.getOnlinePlayers().size() - 1) < BuildContestPlugin.getInstance().getConfiguration().requiredPlayersToStart){

			StartRunnable.cancelStart();
			
		} else if(inGame()){
			
			/*if(Bukkit.getOnlinePlayers().size() <= 1){
				
				Bukkit.getOnlinePlayers().forEach(player -> {
					BadblockPlayer pl = (BadblockPlayer) player;
					pl.sendTranslatedMessage("buildcontest.messages.winbyleaving");
					
				});
				
			}*/
			
		//}
		
		if(!inGame()) {
			TNTRun run = BuildContestPlugin.getInstance().getTNTRun();
			if(run != null && run.getInGame().contains((BadblockPlayer) e.getPlayer())) {
				run.notifyLose((BadblockPlayer) e.getPlayer()); 
			}
		}
		
		if((Bukkit.getOnlinePlayers().size() - 1) < 1) {
			StartRunnable.cancelStart();
		} else if((Bukkit.getOnlinePlayers().size()-1) < 2) {
			if(StartRunnable.gameTask != null) {
				StartRunnable.gameTask.forceEnd = true;
			} else {
				StartRunnable.cancelStart();
			}
		}
		
	}

}
