package fr.badblock.bukkit.games.buildcontest.utils;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import org.bukkit.Bukkit;
import org.bukkit.Location;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;

import fr.badblock.bukkit.games.buildcontest.BuildContestPlugin;
import fr.badblock.bukkit.games.buildcontest.data.BuildContestData;
import fr.badblock.bukkit.games.buildcontest.runnables.VoteRunnable;
import fr.badblock.bukkit.games.buildcontest.team.Team;
import fr.badblock.gameapi.utils.general.JsonUtils;

public class ArchiJsonUtils {

	public static JsonObject createJsonObject(String[] properties, String[] values) {
		JsonObject obj = new JsonObject();
		for(int i = 0; i < properties.length; i++) {
			obj.addProperty(properties[i], values[i]);
		}
		return obj;
	}
	
	public static JsonArray addObjectToArray(JsonArray source, JsonObject obj) {
		source.add(obj);
		return source;
	}

	public static ArrayList<Location> loadPlotsFromMap(String map_name) {
		ArrayList<Location> locas = new ArrayList<>();
		File mapsFile = BuildContestPlugin.MAP;
		File mapFile = new File(mapsFile, map_name + ".json");
		
		if(!mapFile.exists()) {
			return null;
		} else {
			
			JsonObject object = JsonUtils.loadObject(mapFile);
			JsonArray locs = object.get("areaLocations").getAsJsonArray();
			
			for(int index = 0; index < locs.size(); index++) {
				JsonElement elem = locs.get(index);
				JsonObject o = elem.getAsJsonObject();
				String world = o.get("world").getAsString();
				double x = o.get("x").getAsDouble();
				double y = o.get("y").getAsDouble();
				double z = o.get("z").getAsDouble();
				double yaw = o.get("yaw").getAsDouble();
				double pitch = o.get("pitch").getAsDouble();
				Location loc = new Location(Bukkit.getWorld(world), x, y, z, (float) yaw, (float) pitch);
				locas.add(loc);
			}
			return locas;
		}
	}

	public static JsonObject addPlotForMap(String map_name, Location centerPlot) {
		File mapsFile = BuildContestPlugin.MAP;
		File mapFile = new File(mapsFile, map_name + ".json");
		
		if(!mapFile.exists()) {
			return null;
		}
		
		JsonObject object = JsonUtils.loadObject(mapFile);
		JsonArray locs = object.get("areaLocations").getAsJsonArray();
		
		JsonObject o = new JsonObject();
		o.addProperty("world", centerPlot.getWorld().getName());
		o.addProperty("x", centerPlot.getX());
		o.addProperty("y", centerPlot.getY());
		o.addProperty("z", centerPlot.getZ());
		o.addProperty("yaw", centerPlot.getYaw());
		o.addProperty("pitch", centerPlot.getPitch());
		
		locs.add(o);
		object.remove("areaLocations");
		object.add("areaLocations", locs);
		
		return object;
	}
	
	public static JsonObject addMinigameLoc(Location loc) {
		File file = BuildContestPlugin.MINIGAME;
		
		if(!file.exists()) {
			return null;
		}
		
		JsonObject object = JsonUtils.loadObject(file);
		JsonArray locs = object.get("area").getAsJsonArray();
		
		if(locs.size() > 2) {
			return null;
		}
		
		JsonObject o = new JsonObject();
		o.addProperty("world", loc.getWorld().getName());
		o.addProperty("x", loc.getX());
		o.addProperty("y", loc.getY());
		o.addProperty("z", loc.getZ());
		o.addProperty("yaw", loc.getYaw());
		o.addProperty("pitch", loc.getPitch());
		
		locs.add(o);
		object.remove("area");
		object.add("area", locs);
		
		return object;
	}

	public static File createPlayersJson() {
		File temp = new File(BuildContestPlugin.getInstance().getDataFolder(), "temp/players.json");
		JsonObject all = new JsonObject();
		JsonArray array = new JsonArray();
		
		for(Team top : VoteRunnable.getTop(BuildContestPlugin.getInstance().getRealPlayersCount())) {
			JsonPrimitive player = new JsonPrimitive(top.getName());
			array.add(player);
		}
		
		/*BuildContestPlugin.getInstance().getPlayers().forEach(p -> {
			JsonPrimitive player = new JsonPrimitive(p.getName());
			array.add(player);
		});*/
		all.add("players", array);
		JsonUtils.save(temp, all, true);
		return temp;
	}

	public static File createPointsJson() {
		File temp = new File(BuildContestPlugin.getInstance().getDataFolder(), "temp/points.json");
		JsonObject all = new JsonObject();
		JsonObject array = new JsonObject();
		for(Team top : VoteRunnable.getTop(BuildContestPlugin.getInstance().getRealPlayersCount())) {
			if(top != null && top.getOwner() != null)
				array.addProperty(top.getName(), top.getOwner().inGameData(BuildContestData.class).points);
		}
		
		/*BuildContestPlugin.getInstance().getPlayers().forEach(p -> {
			array.addProperty(p.getName(), p.inGameData(BuildContestData.class).points);
		});*/
		all.add("points", array);
		JsonUtils.save(temp, all, true);
		return temp;
	}

	public static File createWinnersJson(String[] names) {
		File temp = new File(BuildContestPlugin.getInstance().getDataFolder(), "temp/winners.json");
		JsonObject all = new JsonObject();
		JsonArray array = new JsonArray();
		for(String name : names) {
			JsonPrimitive winner = new JsonPrimitive(name);
			array.add(winner);
		}
		all.add("winners", array);
		JsonUtils.save(temp, all, true);
		return temp;
	}

	public static File createThemeFile() {
		File temp = new File(BuildContestPlugin.getInstance().getDataFolder(), "temp/theme.txt");
		try {
			FileWriter writer = new FileWriter(temp);
			writer.write(BuildContestPlugin.getInstance().getTheme());
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return temp;
	}
	
	
}
