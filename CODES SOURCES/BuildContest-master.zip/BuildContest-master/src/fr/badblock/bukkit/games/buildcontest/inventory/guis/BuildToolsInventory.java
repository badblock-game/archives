package fr.badblock.bukkit.games.buildcontest.inventory.guis;

import java.util.Arrays;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryView;
import org.bukkit.inventory.ItemStack;

import fr.badblock.bukkit.games.buildcontest.data.BuildContestData;
import fr.badblock.bukkit.games.buildcontest.inventory.InventoryManager;
import fr.badblock.bukkit.games.buildcontest.inventory.gui.AbstractInventoryGUI;
import fr.badblock.bukkit.games.buildcontest.inventory.gui.LayoutGui;
import fr.badblock.bukkit.games.buildcontest.inventory.gui.SharedGUI;
import fr.badblock.bukkit.games.buildcontest.team.TeamManager;
import fr.badblock.gameapi.players.BadblockPlayer;
import lombok.Getter;
import lombok.Setter;

public class BuildToolsInventory extends SharedGUI {
	
	private ItemStack DECO_OPTION, FLOOR_OPTION, TIME_OPTION, PARTICLES_OPTION;
	
	private DecorationInventory DECO_INV;
	private ChangeGroundInventory GROUND_INV;
	private ChangeTimeInventory TIME_INV;
	private ParticlesListInv PARTICLES_INV;
	
	@Getter@Setter
	private AbstractInventoryGUI currentGui = null;
	
	public BuildToolsInventory(Player p) {
		super(TeamManager.getTeam(p));
	}

	public BuildToolsInventory buildToolGui() {
		
		Inventory inv = Bukkit.createInventory(null, 27, i18n("buildcontest.inventory.buildtools.displayname"));
		this.build(inv, LayoutGui.LAYOUT_BASIC);
		
		createOptions();
		
		setupSecondaryGuis();
		
		return this;
	}
	
	public void createOptions() {
//		ItemStack head = Skull.getCustomSkull("http://textures.minecraft.net/texture/349c63bc508723328a19e597f40862d27ad5c1d545663ac24466582f568d9");
//		head = createItemStack(head, "�bM�7ini-�bB�7locks", "�7Dans ce menu, vous trouverez", "�7tous les mini blocks utiles � une", "�7construction impressionnante !");
//		HEAD_OPTION = create(head, 10);
		ItemStack deco = createItemStack(Material.LOG, 1, 0, i18n("buildcontest.inventory.buildtools.items.deco.displayname"), i18nList("buildcontest.inventory.buildtools.items.deco.description"));
		DECO_OPTION = create(deco, 10);
		
		ItemStack floor = createItemStack(Material.DIRT, 1, 0, i18n("buildcontest.inventory.buildtools.items.gestion.displayname"), i18nList("buildcontest.inventory.buildtools.items.gestion.description"));
		FLOOR_OPTION = create(floor, 12);
		
		ItemStack time = createItemStack(Material.WATCH, 1, 0, i18n("buildcontest.inventory.buildtools.items.changetime.displayname"), i18nList("buildcontest.inventory.buildtools.items.changetime.description"));
		TIME_OPTION = create(time, 14);
		
		ItemStack particles = createItemStack(Material.FIREWORK, 1, 0, i18n("buildcontest.inventory.buildtools.items.particles.displayname"), i18nList("buildcontest.inventory.buildtools.items.particles.description"));
		PARTICLES_OPTION = create(particles, 16);
	}
	
	public void setupSecondaryGuis() {
		/* T�tes */
		DECO_INV = new DecorationInventory(TeamManager.getTeam(getPlayer())).buildInv();
		
		GROUND_INV = new ChangeGroundInventory(TeamManager.getTeam(getPlayer()));
		GROUND_INV.buildInv();
		
		TIME_INV = new ChangeTimeInventory(getPlayer());
		TIME_INV.buildInv();
		
		PARTICLES_INV = new ParticlesListInv(TeamManager.getTeam(getPlayer())).buildInv();
		
		InventoryManager.set(getPlayer(), Arrays.asList(GROUND_INV, TIME_INV, null));
	}

	@Override
	public void onItemClick(ItemStack stack, InventoryAction action, ClickType type, ItemStack cursor, int slot, InventoryView view) {
		
	}

	@Override
	public void onItemClick(Player p, ItemStack stack, InventoryAction action, ClickType click, ItemStack cursor,
			int slot, InventoryView view) {
		if(stack.isSimilar(DECO_OPTION)) {
			display(p, DECO_INV);
			currentGui = DECO_INV;
		}
		
		if(stack.isSimilar(TIME_OPTION)){
			display(p, TIME_INV);
			currentGui = TIME_INV;
		}
		
		if(stack.isSimilar(FLOOR_OPTION)){
			display(p, GROUND_INV);
			currentGui = GROUND_INV;
		}
		
		if(stack.isSimilar(PARTICLES_OPTION)){
			display(p, PARTICLES_INV);
			currentGui = PARTICLES_INV;
		}
		
		getTeam().getPlayers().forEach(player -> {
			((BadblockPlayer) player).inGameData(BuildContestData.class).current = currentGui;
		});
		
	}
	
	@Override
	public void open(Player p) {
		super.open(p);
		//On recr�e les options pour �viter les bugs
		createOptions();
	}
	
	@Override
	public void open() {
		super.open();
		//On recr�e les options pour �viter les bugs
		createOptions();
	}

}
