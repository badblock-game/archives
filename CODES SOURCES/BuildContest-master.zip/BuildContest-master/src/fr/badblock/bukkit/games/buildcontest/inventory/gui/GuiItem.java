package fr.badblock.bukkit.games.buildcontest.inventory.gui;

import java.util.Arrays;

import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import lombok.Data;

@Data
public class GuiItem {

	private ItemStack stack;
	private int x;
	private int y;
	
	private String[] lore;
	private String name;
	
	public GuiItem(ItemStack stack, String name, int x, int y, String... lore) {
		this.stack = stack;
		this.x = x;
		this.y = y;
		this.name = name;
		this.lore = lore;
		defItemMeta();
	}
	
	public ItemStack getStack() {
		ItemMeta meta = stack.getItemMeta();
		if(name != null)
			meta.setDisplayName(name);
		if(lore != null)
			meta.setLore(Arrays.asList(lore));
		stack.setItemMeta(meta);
		return stack;
	}
	
	private void defItemMeta() {
		ItemMeta meta = stack.getItemMeta();
		if(name != null)
			meta.setDisplayName(name);
		if(lore != null)
			meta.setLore(Arrays.asList(lore));
		stack.setItemMeta(meta);
	}
	
}
