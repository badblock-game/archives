package fr.badblock.bukkit.games.buildcontest.config;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.bukkit.Location;

import fr.badblock.gameapi.configuration.BadConfiguration;
import fr.badblock.gameapi.configuration.values.MapLocation;
import fr.badblock.gameapi.configuration.values.MapNumber;
import lombok.Data;

@Data
public class BuildContestMapConfiguration {

	private List<Location> areaCenterLocations;
	private Location 	   spectatorLocation;
	private Number		   yMinLimit;
	private Number		   maxY;
	
	private Number sideLength;
	private Number floorY;
	
	private BadConfiguration  config;
	
	/*
	 * map config:
	 * 
	 * size: 10 blocks (c�t�) oblig� un carr�
	 * floor: coord_y
	 * 
	 * 
	 */
	
	public BuildContestMapConfiguration(BadConfiguration config){
		this.config = config;
		
		spectatorLocation     = config.getValue("spectatorLocation", MapLocation.class, new MapLocation()).getHandle();
		areaCenterLocations   = config.getValueList("areaLocations", MapLocation.class, new ArrayList<>()).getHandle();
//		relativeAreaBounds    = config.getValue("relativeAreaBounds", MapNumber.class, new MapNumber()).getHandle().intValue();
		sideLength = config.getValue("sideLength", MapNumber.class, new MapNumber()).getHandle().intValue();
		floorY = config.getValue("floorY", MapNumber.class, new MapNumber()).getHandle().intValue();
		maxY = config.getValue("maxY", MapNumber.class, new MapNumber()).getHandle().intValue();
		yMinLimit    		  = config.getValue("yMinLimit", MapNumber.class, new MapNumber()).getHandle().intValue();
		
	}

	public void save(File file){
		config.save(file);
	}
	
}
