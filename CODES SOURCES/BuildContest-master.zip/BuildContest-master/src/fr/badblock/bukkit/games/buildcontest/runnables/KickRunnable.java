package fr.badblock.bukkit.games.buildcontest.runnables;

import org.bukkit.Bukkit;
import org.bukkit.scheduler.BukkitRunnable;

import fr.badblock.bukkit.games.buildcontest.BuildContestPlugin;
import fr.badblock.gameapi.utils.BukkitUtils;

public class KickRunnable extends BukkitRunnable {
	private int time = 20;
	
	@Override
	public void run(){
		if(time <= 0 && time > -3){
			
			BukkitUtils.forEachPlayers(player -> player.sendPlayer(BuildContestPlugin.getInstance().getConfiguration().fallbackServer));
			
		} else if(time == -3){
			Bukkit.shutdown();
		}
		
		time--;
	}
}
