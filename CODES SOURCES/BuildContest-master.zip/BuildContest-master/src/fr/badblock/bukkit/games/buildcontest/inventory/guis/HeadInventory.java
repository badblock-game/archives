package fr.badblock.bukkit.games.buildcontest.inventory.guis;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryView;
import org.bukkit.inventory.ItemStack;

import fr.badblock.bukkit.games.buildcontest.inventory.gui.AbstractInventoryGUI;
import fr.badblock.bukkit.games.buildcontest.inventory.gui.LayoutGui;
import fr.badblock.bukkit.games.buildcontest.utils.ArchiUtils;
import fr.badblock.bukkit.games.buildcontest.utils.Skulls;

public class HeadInventory extends AbstractInventoryGUI {

	/*
	 * HashMap<String, HashMap<String, String>> Categories = new HashMap<>();
		HashMap<String, String> demo = new HashMap<>();
		demo.put("Blue Wool", "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvM2YzZTQwNjI5MTE3NGQyNGNkZjBmOTUzZjhhMTc0YTgyYmIzNDg5ZGNlOGY2NzlhNDQzZWYxYWFlMDE2OTA2MSJ9fX0=");
		Categories.put("Food", demo);
		
		configuration.categories = Categories;
	 */
	
	private List<String> categories = new ArrayList<>();
	private HashMap<Integer, HeadListInventory> listInvs = new HashMap<>();
	
	public HeadInventory(Player p) {
		super(p);
	}
	
	public HeadInventory buildInv() {
		Inventory inv = Bukkit.createInventory(null, 9*4, i18n("buildcontest.inventory.headinv.displayname"));
		build(inv, LayoutGui.LAYOUT_RETURN_ONLY);
		
		loadCategories();
		
		return this;
	}
	
	private void loadCategories() {
		HashMap<String, HashMap<String, String>> cats = Skulls.getCategories();
		List<String> list = ArchiUtils.getList(cats.keySet());
		list.sort(String::compareToIgnoreCase);
		for(String key : list) {
			categories.add(key); 
		}
		int size = categories.size();
		int start = 10;
		for(int i = 0; i < size; i++) {
			int slot = start + i;
			String cat = categories.get(i);
			slot = findFreeSlotAfter(slot);
			updateItem(slot, ArchiUtils.createItem(Skulls.get().materials.get(cat), 1, Skulls.get().bytes.get(cat), "�7" + cat, ""));
			listInvs.put(slot, new HeadListInventory(getPlayer(), cat).buildHeads());
		}
	}

	@Override
	public void onItemClick(ItemStack stack, InventoryAction action, ClickType click, ItemStack cursor, int slot, InventoryView view) {
		if(stack != null) {
			HeadListInventory inv = listInvs.get(slot);
			if(inv == null) return;
			
			display(inv);
			
		}
	}

}
