package fr.badblock.bukkit.games.buildcontest;

public enum BuildStage {

	VOTE, BUILD, END;
	
}
