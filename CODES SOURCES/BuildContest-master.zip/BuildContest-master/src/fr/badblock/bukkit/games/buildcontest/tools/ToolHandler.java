package fr.badblock.bukkit.games.buildcontest.tools;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEvent;

import fr.badblock.gameapi.BadListener;
import fr.badblock.gameapi.players.BadblockPlayer;

public class ToolHandler extends BadListener {

	@EventHandler
	public void onInterract(PlayerInteractEvent e) {
		if(e.getItem() != null) {
			Tool tool = Tools.getTool(e.getItem(), (BadblockPlayer) e.getPlayer());
			if(tool == null) return;
			tool.getAction().setPlayer(e.getPlayer());
			tool.getAction().onClick();
		}
	}
	
	@EventHandler
	public void onClick(InventoryClickEvent e) {
		if(e.getClickedInventory() != null && e.getClickedInventory().equals(e.getWhoClicked().getInventory())) {
			if(e.getCurrentItem() != null) {
				Tool tool = Tools.getTool(e.getCurrentItem(), (BadblockPlayer) e.getWhoClicked());
				if(tool == null) return;
				e.setCancelled(true);
			}
		} else {
			if(e.getCurrentItem() != null) {
				Tool tool = Tools.getTool(e.getCurrentItem(), (BadblockPlayer) e.getWhoClicked());
				if(tool == null) return;
				tool.getAction().setPlayer((Player) e.getWhoClicked());
				tool.getAction().onClick();
			}
		}
	}
	
	@EventHandler
	public void place(BlockPlaceEvent e) {
		if(e.getItemInHand() != null) {
			Tool tool = Tools.getTool(e.getItemInHand(),(BadblockPlayer) e.getPlayer());
			if(tool == null) return;
			e.setCancelled(true);
			((BadblockPlayer) e.getPlayer()).sendTranslatedActionBar("buildcontest.messages.cannotplacethisitem");
		}
	}
	
}
