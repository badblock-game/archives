package fr.badblock.bukkit.games.buildcontest.runnables;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.UUID;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;

import fr.badblock.bukkit.games.buildcontest.BuildContestPlugin;

public class UploadRunnable {
	
	private UUID gameId;
	private File schematic;
	
	public UploadRunnable(UUID gameId, File schematic) {
		this.gameId = gameId;
		this.schematic = schematic;
	}

	public void uploadJson() {
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				
				String server = BuildContestPlugin.getInstance().getResultsConfiguration().ip;
		        int port = BuildContestPlugin.getInstance().getResultsConfiguration().port;
		        String user = BuildContestPlugin.getInstance().getResultsConfiguration().user;
		        String pass = BuildContestPlugin.getInstance().getResultsConfiguration().pass;
		        
		        FTPClient ftpClient = new FTPClient();
		        try {
		 
		            ftpClient.connect(server, port);
		            ftpClient.login(user, pass);
		            ftpClient.enterLocalPassiveMode();
					
		            ftpClient.setFileType(FTP.BINARY_FILE_TYPE);
		 
		            String firstRemoteFile = "/buildcontest/games/" + gameId.toString() + "/" + schematic.getName();
		            InputStream inputStream = new FileInputStream(schematic);
		 
		            ftpClient.makeDirectory("/buildcontest/games/" + gameId.toString());
		            ftpClient.makeDirectory("/buildcontest/games/" + gameId.toString() + "/build");
		            
		            System.out.println("[UPLOADER] [INFO] Starting uploading file " + schematic.getName() + " to " + firstRemoteFile + " !");
		            boolean done = ftpClient.storeFile(firstRemoteFile, inputStream);
		            inputStream.close();
		            if (done) {
		            	System.out.println("[UPLOADER] [INFO] Upload successful !");
		            } else {
		            	System.out.println("[UPLOADER] [ERROR] Upload failed !");
		            }
		 
		        } catch (IOException ex) {
		        	System.out.println("[UPLOADER] [ERROR] Got an error: " + ex.getMessage());
		            ex.printStackTrace();
		        } finally {
		        	try {
						if (ftpClient.isConnected()) {
							ftpClient.logout();
							ftpClient.disconnect();
						}
					} catch (IOException ex) {
						ex.printStackTrace();        
					}
		        }
				
			}
		}).start();
	}
	
	public void uploadFile() {
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				
				String server = BuildContestPlugin.getInstance().getResultsConfiguration().ip;
				int port = BuildContestPlugin.getInstance().getResultsConfiguration().port;
		        String user = BuildContestPlugin.getInstance().getResultsConfiguration().user;
		        String pass = BuildContestPlugin.getInstance().getResultsConfiguration().pass;
		 
		        FTPClient ftpClient = new FTPClient();
		        try {
		 
		            ftpClient.connect(server, port);
		            ftpClient.login(user, pass);
		            ftpClient.enterLocalPassiveMode();
					
		            ftpClient.setFileType(FTP.BINARY_FILE_TYPE);
		 
		            String firstRemoteFile = "/buildcontest/games/" + gameId.toString() + "/build/" + schematic.getName();
		            InputStream inputStream = new FileInputStream(schematic);
		            
		            System.out.println("[UPLOADER] [INFO] Starting uploading file " + schematic.getName() + " to " + firstRemoteFile + " !");
		            boolean done = ftpClient.storeFile(firstRemoteFile, inputStream);
		            inputStream.close();
		            if (done) {
		            	System.out.println("[UPLOADER] [INFO] Upload successful !");
		            } else {
		            	System.out.println("[UPLOADER] [ERROR] Upload failed !");
		            }
		 
		        } catch (IOException ex) {
		        	System.out.println("[UPLOADER] [ERROR] Got an error: " + ex.getMessage());
		            ex.printStackTrace();
		        } finally {
		        	try {
						if (ftpClient.isConnected()) {
							ftpClient.logout();
							ftpClient.disconnect();
						}
					} catch (IOException ex) {
						ex.printStackTrace();        
					}
		        }
				
			}
		}).start();
	}

}
