package fr.badblock.bukkit.games.buildcontest.particles;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import fr.badblock.bukkit.games.buildcontest.data.BuildContestData;
import fr.badblock.bukkit.games.buildcontest.runnables.ParticleRunnable;
import fr.badblock.gameapi.GameAPI;
import fr.badblock.gameapi.players.BadblockPlayer;

public class Particles {

	public static List<Particle> particles = new ArrayList<>();
	
	public static HashMap<String, HashMap<Location, ParticleRunnable>> runnables = new HashMap<>();
	
	public static Particle registerParticle(Particle particle) {
		particles.add(particle);
		return particle;
	}
	
	public static Particle getParticle(ItemStack from) {
		for(Particle particle : particles) {
			if(particle.getDisplay().isSimilar(from)) {
				return particle;
			}
		}
		return null;
	}

	public static void tick(Player pl, Particle particle, Location loc) {
		BadblockPlayer p = (BadblockPlayer) pl;
		
		
		int size = p.inGameData(BuildContestData.class).amountParticles;
		if(size >= 10) {
			((BadblockPlayer) p).sendTranslatedActionBar("buildcontest.messages.toomuchparticles");
			return;
		}
		
		ParticleRunnable runnable = new ParticleRunnable(particle, loc);
		runnable.runTaskTimer(GameAPI.getAPI(), 1L, 1L);
		HashMap<Location, ParticleRunnable> map = runnables.get(p.getName());
		
		if(map == null) map = new HashMap<>(); 
		
		map.put(loc, runnable);
		
		runnables.put(p.getName(), map);
		
		p.inGameData(BuildContestData.class).amountParticles++;
	}

	public static boolean isParticlePresent(BadblockPlayer p, Location location) {
		if(runnables.get(p.getName()) == null) return false;
		for(Location locs : runnables.get(p.getName()).keySet()) {
			if(locs.equals(location)) {
				return true;
			}
		}
		return false;
	}

	public static void destroy(BadblockPlayer p, Location location) {
		HashMap<Location, ParticleRunnable> map = runnables.get(p.getName());
		map.get(location).cancel();
		map.remove(location);
		p.inGameData(BuildContestData.class).amountParticles--;
	}
	
	public static void destroyAll(BadblockPlayer p) {
		HashMap<Location, ParticleRunnable> map = runnables.get(p.getName());
		
		if(map == null || map.isEmpty()) return;
		
		for(ParticleRunnable runnable : map.values()) {
			runnable.cancel();
		}
		List<Location> locs = new ArrayList<>();
		for(Location l : map.keySet()) {
			locs.add(l);
		}
		for(Location l : locs) {
			map.remove(l);
		}
		locs.clear();
		p.inGameData(BuildContestData.class).amountParticles = 0;
		runnables.put(p.getName(), new HashMap<>());
	}

	public static boolean is(ItemStack stack) {
		for(Particle par : particles) {
			if(par.getDisplay().isSimilar(stack)) {
				return true;
			}
		}
		return false;
	}

}
