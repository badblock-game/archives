package fr.badblock.bukkit.games.buildcontest.utils;

import java.io.File;
import java.util.HashMap;
import java.util.Map.Entry;

import org.bukkit.inventory.ItemStack;

import fr.badblock.bukkit.games.buildcontest.BuildContestPlugin;
import fr.badblock.bukkit.games.buildcontest.inventory.SkullConfiguration;
import fr.badblock.gameapi.utils.general.JsonUtils;
import lombok.Getter;
import lombok.Setter;

public class Skulls {

	private static String OPTIONS = "skulls.json";
	private static SkullConfiguration configuration;

	@Getter
	@Setter
	private ItemStack stack;
	@Getter
	@Setter
	private String name;
	@Getter
	@Setter
	private int points;

	public static SkullConfiguration get() {
		return configuration;
	}

	public static void loadFromConfig() {
		File configFile = new File(BuildContestPlugin.getInstance().getDataFolder(), OPTIONS);
		configuration = JsonUtils.load(configFile, SkullConfiguration.class);
		
		/* Si jamais le fichier est delete */
		
//		HashMap<String, String> demo = new HashMap<>();
//		demo.put("Test", "Demo");
//		configuration.valuesByNames = demo;
		
//		HashMap<String, HashMap<String, String>> Categories = new HashMap<>();
//		HashMap<String, String> demo = new HashMap<>();
//		demo.put("Blue Wool", "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvM2YzZTQwNjI5MTE3NGQyNGNkZjBmOTUzZjhhMTc0YTgyYmIzNDg5ZGNlOGY2NzlhNDQzZWYxYWFlMDE2OTA2MSJ9fX0=");
//		Categories.put("Food", demo);
//		
//		configuration.categories = Categories;
		
		JsonUtils.save(configFile, configuration, true);
	}

	public static HashMap<String, HashMap<String, String>> getCategories() {
		return configuration.categories;
	}

	public static String getValueByName(String name) {
		for(HashMap<String, String> map : getCategories().values()) {
			for (Entry<String, String> set : map.entrySet()) {
				if (set.getKey().equals(name)) {
					set.getValue();
				}
			}
		}
		return null;
	}

}
