package fr.badblock.bukkit.games.buildcontest.listeners;

import org.bukkit.event.EventHandler;
import org.bukkit.event.player.AsyncPlayerChatEvent;

import fr.badblock.bukkit.games.buildcontest.BuildContestPlugin;
import fr.badblock.bukkit.games.buildcontest.BuildStage;
import fr.badblock.gameapi.BadListener;
import fr.badblock.gameapi.players.BadblockPlayer;

public class ChatListener extends BadListener {

	@EventHandler
	public void onPlayerChat(AsyncPlayerChatEvent e) {
		BadblockPlayer player = (BadblockPlayer) e.getPlayer();
		if(BuildContestPlugin.getInstance().getBuildStage() == BuildStage.VOTE) {
			e.setCancelled(true);
			player.sendTranslatedActionBar("buildcontest.messages.cannottalkwhilevoting");
		}
	}
	
}
