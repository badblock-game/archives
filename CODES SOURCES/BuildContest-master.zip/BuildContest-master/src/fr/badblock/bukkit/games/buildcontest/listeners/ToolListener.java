package fr.badblock.bukkit.games.buildcontest.listeners;

import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import fr.badblock.bukkit.games.buildcontest.blocks.SpecialsBlocks;
import fr.badblock.gameapi.BadListener;
import net.md_5.bungee.api.ChatColor;

public class ToolListener extends BadListener {

	@EventHandler
	public void onInterract(PlayerInteractEvent e) {
		
		if(e.getItem() != null && e.getItem().getType() == Material.BARRIER) { e.setCancelled(true); e.getPlayer().getInventory().remove(e.getItem()); return; }
	}
	
	@SuppressWarnings("deprecation")
	@EventHandler
	public void placeSpecial(BlockPlaceEvent e) {
		
		if(e.getItemInHand() != null && e.getItemInHand().getType() == Material.BARRIER) { e.setCancelled(true); e.getPlayer().getInventory().remove(e.getItemInHand()); return; }
		
		ItemStack stack = e.getItemInHand();
		if(stack != null) {
			if(SpecialsBlocks.isBlock(stack)) {
				ItemMeta meta = stack.getItemMeta();
				String matAndData = ChatColor.stripColor(meta.getLore().get(0));
				int id = Integer.parseInt(matAndData.split(":")[0]);
				byte data = Byte.parseByte(matAndData.split(":")[1]);
				e.getBlock().setTypeIdAndData(id, data, true);
				e.getBlock().getState().update(true);
			}
		}
		
	}
	
}
