package fr.badblock.bukkit.games.buildcontest.particles;

import java.util.Random;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

import fr.badblock.gameapi.GameAPI;
import fr.badblock.gameapi.particles.ParticleEffect;
import fr.badblock.gameapi.particles.ParticleEffectType;
import fr.badblock.gameapi.players.BadblockPlayer;

public class ParticleList {

	public static ParticleList instance = new ParticleList();
	
	public static Particle FIRE = Particles.registerParticle(new Particle("§6C'est le feu !", new ItemStack(Material.BLAZE_POWDER), new ParticleAction() {
		
		Random r = new Random();
		
		@Override
		public void tick(Location l) {
//			Location loc = l.clone().add(0.5, 0.5, 0.5);
			ParticleEffect effect = GameAPI.getAPI().createParticleEffect(ParticleEffectType.FLAME);
			effect.setAmount(2);
			for(BadblockPlayer pl : GameAPI.getAPI().getOnlinePlayers()) {
				for(int i = 0; i < effect.getAmount(); i++) {
					Location loca = l.clone().add(r.nextDouble(), r.nextDouble(), r.nextDouble());
					pl.sendParticle(loca, effect);
				}
			}
		}
		
	}));
	
	public static Particle CLOUD = Particles.registerParticle(new Particle("§6Nuage", new ItemStack(Material.SUGAR), new ParticleAction() {
		
		Random r = new Random();
		
		@Override
		public void tick(Location l) {
//			Location loc = l.clone().add(0.5, 0.5, 0.5);
			ParticleEffect effect = GameAPI.getAPI().createParticleEffect(ParticleEffectType.CLOUD);
			effect.setAmount(2);
			for(BadblockPlayer pl : GameAPI.getAPI().getOnlinePlayers()) {
				for(int i = 0; i < effect.getAmount(); i++) {
					Location loca = l.clone().add(r.nextDouble(), r.nextDouble(), r.nextDouble());
					pl.sendParticle(loca, effect);
				}
			}
		}
		
	}));
	
	public static Particle BUBBLE = Particles.registerParticle(new Particle("§6Des ptites bulles !", new ItemStack(Material.INK_SACK, 1, (byte) 4), new ParticleAction() {
		
		Random r = new Random();
		
		@Override
		public void tick(Location l) {
//			Location loc = l.clone().add(0.5, 0.5, 0.5);
			ParticleEffect effect = GameAPI.getAPI().createParticleEffect(ParticleEffectType.WATER_BUBBLE);
			effect.setAmount(2);
			for(BadblockPlayer pl : GameAPI.getAPI().getOnlinePlayers()) {
				for(int i = 0; i < effect.getAmount(); i++) {
					Location loca = l.clone().add(r.nextDouble(), r.nextDouble(), r.nextDouble());
					pl.sendParticle(loca, effect);
				}
			}
		}
		
	}));
	
	public static Particle LAVA = Particles.registerParticle(new Particle("§6De la lave hum?", new ItemStack(Material.LAVA_BUCKET), new ParticleAction() {
		
		Random r = new Random();
		
		@Override
		public void tick(Location l) {
//			Location loc = l.clone().add(0.5, 0.5, 0.5);
			ParticleEffect effect = GameAPI.getAPI().createParticleEffect(ParticleEffectType.LAVA);
			effect.setAmount(2);
			for(BadblockPlayer pl : GameAPI.getAPI().getOnlinePlayers()) {
				for(int i = 0; i < effect.getAmount(); i++) {
					Location loca = l.clone().add(r.nextDouble(), r.nextDouble(), r.nextDouble());
					pl.sendParticle(loca, effect);
				}
			}
		}
		
	}));
	
	public static Particle HEART = Particles.registerParticle(new Particle("§6Je t'aime ♥", new ItemStack(Material.REDSTONE), new ParticleAction() {
		
		Random r = new Random();
		
		@Override
		public void tick(Location l) {
//			Location loc = l.clone().add(0.5, 0.5, 0.5);
			ParticleEffect effect = GameAPI.getAPI().createParticleEffect(ParticleEffectType.HEART);
			effect.setAmount(2);
			for(BadblockPlayer pl : GameAPI.getAPI().getOnlinePlayers()) {
				for(int i = 0; i < effect.getAmount(); i++) {
					Location loca = l.clone().add(r.nextDouble(), r.nextDouble(), r.nextDouble());
					pl.sendParticle(loca, effect);
				}
			}
		}
		
	}));
	
	public static Particle ANGRY = Particles.registerParticle(new Particle("§6Un éclair?", new ItemStack(Material.MONSTER_EGG, 1, (byte) 120), new ParticleAction() {
		
		Random r = new Random();
		
		@Override
		public void tick(Location l) {
//			Location loc = l.clone().add(0.5, 0.5, 0.5);
			ParticleEffect effect = GameAPI.getAPI().createParticleEffect(ParticleEffectType.VILLAGER_ANGRY);
			effect.setAmount(10);
			for(BadblockPlayer pl : GameAPI.getAPI().getOnlinePlayers()) {
				for(int i = 0; i < effect.getAmount(); i++) {
					Location loca = l.clone().add(r.nextDouble(), r.nextDouble(), r.nextDouble());
					pl.sendParticle(loca, effect);
				}
			}
		}
		
	}));
	
	public static Particle MUSIC = Particles.registerParticle(new Particle("§6Tout en musique :D", new ItemStack(Material.RECORD_3), new ParticleAction() {
		
		Random r = new Random();
		
		@Override
		public void tick(Location l) {
//			Location loc = l.clone().add(0.5, 0.5, 0.5);
			ParticleEffect effect = GameAPI.getAPI().createParticleEffect(ParticleEffectType.NOTE);
			effect.setSpeed(1.0f);
			effect.setAmount(2);
			for(BadblockPlayer pl : GameAPI.getAPI().getOnlinePlayers()) {
				for(int i = 0; i < effect.getAmount(); i++) {
					Location loca = l.clone().add(r.nextDouble(), r.nextDouble(), r.nextDouble());
					pl.sendParticle(loca, effect);
				}
			}
		}
		
	}));
	
	public static Particle ENCHANTEMENT = Particles.registerParticle(new Particle("§6Enchanté !", new ItemStack(Material.NETHER_STAR), new ParticleAction() {
		
		Random r = new Random();
		
		@Override
		public void tick(Location l) {
//			Location loc = l.clone().add(0.5, 0.5, 0.5);
			ParticleEffect effect = GameAPI.getAPI().createParticleEffect(ParticleEffectType.ENCHANTMENT_TABLE);
			effect.setSpeed(1.0f);
			effect.setAmount(2);
			for(BadblockPlayer pl : GameAPI.getAPI().getOnlinePlayers()) {
				for(int i = 0; i < effect.getAmount(); i++) {
					Location loca = l.clone().add(r.nextDouble(), r.nextDouble(), r.nextDouble());
					pl.sendParticle(loca, effect);
				}
			}
		}
		
	}));
	
	public static Particle PORTAL = Particles.registerParticle(new Particle("§6Un portail?", new ItemStack(Material.PORTAL), new ParticleAction() {
		
		Random r = new Random();
		
		@Override
		public void tick(Location l) {
//			Location loc = l.clone().add(0.5, 0.5, 0.5);
			ParticleEffect effect = GameAPI.getAPI().createParticleEffect(ParticleEffectType.PORTAL);
			effect.setSpeed(1.0f);
			effect.setAmount(2);
			for(BadblockPlayer pl : GameAPI.getAPI().getOnlinePlayers()) {
				for(int i = 0; i < effect.getAmount(); i++) {
					Location loca = l.clone().add(r.nextDouble(), r.nextDouble(), r.nextDouble());
					pl.sendParticle(loca, effect);
				}
			}
		}
		
	}));
	
	public static Particle SLIME = Particles.registerParticle(new Particle("§6Slimeeee", new ItemStack(Material.SLIME_BALL), new ParticleAction() {
		
		Random r = new Random();
		
		@Override
		public void tick(Location l) {
//			Location loc = l.clone().add(0.5, 0.5, 0.5);
			ParticleEffect effect = GameAPI.getAPI().createParticleEffect(ParticleEffectType.SLIME);
			effect.setSpeed(1.0f);
			effect.setAmount(2);
			for(BadblockPlayer pl : GameAPI.getAPI().getOnlinePlayers()) {
				for(int i = 0; i < effect.getAmount(); i++) {
					Location loca = l.clone().add(r.nextDouble(), r.nextDouble(), r.nextDouble());
					pl.sendParticle(loca, effect);
				}
			}
		}
		
	}));
	
}
