package fr.badblock.bukkit.games.buildcontest.inventory.vote;

import java.util.Arrays;

import org.bukkit.event.block.Action;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import fr.badblock.bukkit.games.buildcontest.BuildContestPlugin;
import fr.badblock.bukkit.games.buildcontest.data.BuildContestData;
import fr.badblock.bukkit.games.buildcontest.inventory.gui.AbstractPlayerInventory;
import fr.badblock.bukkit.games.buildcontest.team.Team;
import fr.badblock.gameapi.players.BadblockPlayer;

public class VoteInventory extends AbstractPlayerInventory {
	
	private Inventory gui;
	public int givedOld = 0;
	
	public VoteInventory(BadblockPlayer p) {
		super(p);
	}
	
	public VoteInventory build() {
		gui = getPlayer().getInventory();
		
		//Adding items to hotbar*
		int i = 1;
		
		for(VoteOption option : VoteOption.options) {
			
			if(i == 4)
				i++;
			
			ItemStack theStack = option.getStack();
			ItemMeta meta = theStack.getItemMeta();
			
			String name = option.getName();
			String desc = i18n(option.getDesc());
			
			meta.setDisplayName(name);
			meta.setLore(Arrays.asList(desc));
			
			theStack.setItemMeta(meta);
			
			
			gui.setItem(i, theStack);
			i++;
			
		}
		return this;
	}

	private int getPoints(ItemStack st) {
		for(VoteOption option : VoteOption.options) {
			if(option.getStack().getDurability() == st.getDurability() && option.getStack().getType() == st.getType()) {
				return option.getPoints();
			}
		}
		return 0;
	}
	
	private boolean isVoteItem(ItemStack st) {
		for(VoteOption option : VoteOption.options) {
			if(option.getStack().isSimilar(st)) {
				return true;
			}
		}
		return false;
	}
	
	@Override
	public void onItemClick(ItemStack stack, Action action) {
		if(action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK) {
			if(stack != null && isVoteItem(stack)) {
				BadblockPlayer pl = (BadblockPlayer) getPlayer();
				Team current = BuildContestPlugin.getInstance().getCurrent();
				
				if(!current.getName().contains(pl.getName())) {
					
					int points = getPoints(stack);
					
					
					/* On informe le joueur de ce qu'il a vot� */
					
					pl.sendTranslatedMessage("buildcontest.messages.voted", stack.getItemMeta().getDisplayName());
					
					pl.inGameData(BuildContestData.class).temp_vote = stack.getItemMeta().getDisplayName();
					
					/* On set les points que le joueur veut donner */
					
					pl.inGameData(BuildContestData.class).temp_points = points;
					
					
					((BadblockPlayer) getPlayer()).sendTranslatedActionBar("buildcontest.messages.voteapply", stack.getItemMeta().getDisplayName());
				} else {
					((BadblockPlayer) getPlayer()).sendTranslatedActionBar("buildcontest.messages.cannotvoteforself");
				}
			}
		}
		
	}
	
}
