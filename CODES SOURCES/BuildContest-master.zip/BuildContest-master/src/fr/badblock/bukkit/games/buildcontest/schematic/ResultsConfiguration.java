package fr.badblock.bukkit.games.buildcontest.schematic;

public class ResultsConfiguration {

	public String ip = "ip-badblock-fr";
	public String user = "results";
	public String pass = "pass";
	public int port = 21;
	
}
