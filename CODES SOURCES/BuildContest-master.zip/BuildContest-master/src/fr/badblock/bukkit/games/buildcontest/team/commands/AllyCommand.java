package fr.badblock.bukkit.games.buildcontest.team.commands;

import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;

import fr.badblock.bukkit.games.buildcontest.team.InvitationManager;
import fr.badblock.bukkit.games.buildcontest.team.TeamInvitation;
import fr.badblock.bukkit.games.buildcontest.team.TeamManager;
import fr.badblock.bukkit.games.buildcontest.utils.ComponentMessage;
import fr.badblock.gameapi.command.AbstractCommand;
import fr.badblock.gameapi.players.BadblockPlayer;
import fr.badblock.gameapi.players.BadblockPlayer.GamePermission;
import fr.badblock.gameapi.utils.i18n.TranslatableString;
import net.md_5.bungee.api.chat.BaseComponent;

public class AllyCommand extends AbstractCommand {

	public AllyCommand() {
		super("iwanttoallywith", new TranslatableString("commands.gbuildcontest.allycommand.error"), GamePermission.PLAYER, GamePermission.PLAYER, GamePermission.PLAYER);
		allowConsole(false);
	}

	@Override
	public boolean executeCommand(CommandSender sender, String[] args) {
		if(args.length == 0)
			return true;
		
		BadblockPlayer player = (BadblockPlayer) sender;
		String t = args[0];
		BadblockPlayer target = (BadblockPlayer) Bukkit.getPlayer(t);
		
		if(TeamManager.getTeam(player) != null) {
			//a d�j� une team
			ComponentMessage message = new ComponentMessage(new TranslatableString("buildcontest.messages.teams.alreadyinteam").getAsLine(player));
			ComponentMessage clickToBreak = new ComponentMessage(new TranslatableString("buildcontest.messages.teams.clicktoleave.message").getAsLine(player), new TranslatableString("buildcontest.messages.teams.clicktoleave.onhover").getAsLine(player), "/breakmyteamwith " + TeamManager.getTeam(player).getPlayerWith(player).getName());
			BaseComponent[] base = ComponentMessage.create(true, true, message, clickToBreak);
			player.spigot().sendMessage(base);
			return true;
		}
		
		if(TeamManager.getTeam(target) != null) {
			player.sendTranslatedMessage("buildcontest.messages.teams.targetalreadyinteam");
			return true;
		}
		
		if(!InvitationManager.isInvited(player)) {
			//n'est pas invit�
			player.sendTranslatedMessage("buildcontest.messages.teams.youarenotinvitedtojoinateam");
			return true;
		}
		
		if(!InvitationManager.isInInvitationWith(player, target)) {
			//n'a pas �t� invit� par target
			player.sendTranslatedMessage("buildcontest.messages.teams.youarenotinvitedbythisplayer");
			return true;
		}
		
		if(target == null) {
			player.sendTranslatedMessage("buildcontest.messages.teams.playerdonotexist");
			return true;
		}
		
		TeamInvitation current = InvitationManager.getInvitation(player);
		current.validate();
		
		player.sendTranslatedMessage("buildcontest.messages.teams.youarenowinteamwith", target.getName());
		target.sendTranslatedMessage("buildcontest.messages.teams.youarenowinteamwith", player.getName());
		
		return true;
	}
	
}
