package fr.badblock.bukkit.games.buildcontest.particles;

import java.util.List;

import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

import fr.badblock.bukkit.games.buildcontest.BuildContestPlugin;
import fr.badblock.bukkit.games.buildcontest.plots.Plot;
import fr.badblock.bukkit.games.buildcontest.team.TeamManager;
import fr.badblock.gameapi.BadListener;
import fr.badblock.gameapi.players.BadblockPlayer;

public class ParticleListener extends BadListener {

	@EventHandler
	public void onPlayerClick(PlayerInteractEvent e) {
		BadblockPlayer pl = (BadblockPlayer) e.getPlayer();
		ItemStack stack = e.getItem();
		if(stack != null) {
			Particle p = Particles.getParticle(stack);
			if(p == null) return;
			
			if(e.getAction() == Action.RIGHT_CLICK_BLOCK) {
				e.setCancelled(true);
				Location on = e.getClickedBlock().getWorld().getBlockAt(e.getClickedBlock().getLocation()).getRelative(e.getBlockFace()).getLocation();
				
				Plot plot = BuildContestPlugin.getInstance().getPlot(TeamManager.getTeam(pl));
				if(plot == null) return;
				List<Block> blockInPlot = plot.getBlocks();
				
				boolean canPlace = false;
				
				for(Block b : blockInPlot) {
					if(b.getLocation().equals(on)) {
						canPlace = true;
						break;
					}
				}
				
				if(!canPlace) {
					pl.sendTranslatedActionBar("buildcontest.messages.cannotplacehere");
					return;
				}
				
				if(!Particles.isParticlePresent(pl, on)) {
					Particles.tick(pl, p, on);
				} else {
					pl.sendTranslatedActionBar("buildcontest.messages.particlepresent");
				}
			}
		}
		
		if(!Particles.is(stack)) {
			if(e.getAction() == Action.RIGHT_CLICK_AIR || e.getAction() == Action.RIGHT_CLICK_BLOCK) {
				Location clicked = e.getClickedBlock().getWorld().getBlockAt(e.getClickedBlock().getLocation()).getRelative(e.getBlockFace()).getLocation();
				if(Particles.isParticlePresent(pl, clicked)) {
					Particles.destroy(pl, clicked);
				}
			}
		}
	}
	
	
}
