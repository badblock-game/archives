package fr.badblock.bukkit.games.buildcontest.inventory.guis;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryView;
import org.bukkit.inventory.ItemStack;

import fr.badblock.bukkit.games.buildcontest.inventory.gui.LayoutGui;
import fr.badblock.bukkit.games.buildcontest.inventory.gui.SharedGUI;
import fr.badblock.bukkit.games.buildcontest.team.Team;
import fr.badblock.bukkit.games.buildcontest.team.TeamManager;
import fr.badblock.bukkit.games.buildcontest.utils.Skull;

public class DecorationInventory extends SharedGUI {
	
	private ItemStack MINI_BLOCKS, SPECIALS_BLOCKS;
	
	private HeadInventory HEAD_INV;
	
	private SpecialsBlocksInventory SPECIALS_BLOCKS_INV;

	public DecorationInventory(Team team) {
		super(team);
	}
	
	public DecorationInventory buildInv() {
		
		Inventory inv = Bukkit.createInventory(null, 27, i18n("buildcontest.inventory.decorationinv.displayname"));
		this.build(inv, LayoutGui.LAYOUT_RETURN_ONLY);
		
		createOptions();
		setupSecondaryGuis();
		
		return this;
		
	}
	
	public void createOptions() {
		
		ItemStack miniblocks = Skull.getCustomSkull("http://textures.minecraft.net/texture/349c63bc508723328a19e597f40862d27ad5c1d545663ac24466582f568d9");
		miniblocks = createItemStack(miniblocks, i18n("buildcontest.inventory.decorationinv.items.miniblocks.displayname"), i18nList("buildcontest.inventory.decorationinv.items.miniblocks.description"));
		MINI_BLOCKS = create(miniblocks, 12);
		
		ItemStack specialsblocks = createItemStack(Material.WOOD, 1, 0, i18n("buildcontest.inventory.decorationinv.items.specialblocks.displayname"), i18nList("buildcontest.inventory.decorationinv.items.specialblocks.description"));
		SPECIALS_BLOCKS = create(specialsblocks, 14);
		
	}
	
	public void setupSecondaryGuis() {
		/* T�tes */
		HEAD_INV = new HeadInventory(getPlayer()).buildInv();
		
		SPECIALS_BLOCKS_INV = new SpecialsBlocksInventory(TeamManager.getTeam(getPlayer())).createGui();
		
	}

	
	@Override
	public void onItemClick(ItemStack stack, InventoryAction action, ClickType click, ItemStack cursor, int slot, InventoryView view) {
		
		
		
	}

	@Override
	public void onItemClick(Player p, ItemStack stack, InventoryAction action, ClickType click, ItemStack cursor,
			int slot, InventoryView view) {
		if(stack.isSimilar(MINI_BLOCKS)) {
			display(p, HEAD_INV);
		}
		
		if(stack.isSimilar(SPECIALS_BLOCKS)){
			display(p, SPECIALS_BLOCKS_INV);
		}
		
	}

}
