package fr.badblock.bukkit.games.buildcontest.inventory.guis;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.WeatherType;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryView;
import org.bukkit.inventory.ItemStack;

import fr.badblock.bukkit.games.buildcontest.data.BuildContestData;
import fr.badblock.bukkit.games.buildcontest.inventory.gui.AbstractInventoryGUI;
import fr.badblock.bukkit.games.buildcontest.inventory.gui.LayoutGui;
import fr.badblock.gameapi.players.BadblockPlayer;

public class ChangeTimeInventory extends AbstractInventoryGUI{
	
	private ItemStack SUNSET, RAIN, MATIN, MIDI, SOIR, NUIT;

	public ChangeTimeInventory(Player p) {
		
		super(p);
	
	}
	
	public void buildInv() {
		
		Inventory inv = Bukkit.createInventory(null, 54, i18n("buildcontest.inventory.changetime.displayname"));
		
		build(inv, LayoutGui.LAYOUT_RETURN_BOTTOM);
		
		createOptions();
	}
	
	public void createOptions() {
		
		ItemStack weatherinfo = createItemStack(Material.SEA_LANTERN, 1, 0, i18n("buildcontest.inventory.changetime.items.wheaterinfo.displayname"), i18nList("buildcontest.inventory.changeground.items.wheaterinfo.description"));
		create(weatherinfo, 10);
		
		ItemStack timeinfo = createItemStack(Material.SEA_LANTERN, 1, 0, i18n("buildcontest.inventory.changetime.items.timeinfo.displayname"), i18nList("buildcontest.inventory.changeground.items.timeinfo.description"));
		create(timeinfo, 28);
		
		ItemStack sunset = createItemStack(Material.WOOL, 1, 4, i18n("buildcontest.inventory.changetime.items.sunset.displayname"));
		SUNSET = create(sunset, 14);
		
		ItemStack rain = createItemStack(Material.WOOL, 1, 11, i18n("buildcontest.inventory.changetime.items.rain.displayname"));
		RAIN = create(rain, 15);
		
		ItemStack matin = createItemStack(Material.STAINED_GLASS, 1, 3, i18n("buildcontest.inventory.changetime.items.morning.displayname"));
		MATIN = create(matin, 30);
		
		ItemStack midi = createItemStack(Material.STAINED_GLASS, 1, 4, i18n("buildcontest.inventory.changetime.items.noon.displayname"));
		MIDI = create(midi, 31);
		
		ItemStack soir = createItemStack(Material.STAINED_GLASS, 1, 11, i18n("buildcontest.inventory.changeground.items.evening.displayname"));
		SOIR = create(soir, 32);
		
		ItemStack nuit = createItemStack(Material.STAINED_GLASS, 1, 7, i18n("buildcontest.inventory.changeground.items.night.displayname"));
		NUIT = create(nuit, 33);
	
	}

	@Override
	public void onItemClick(ItemStack stack, InventoryAction action, ClickType type, ItemStack cursor, int slot, InventoryView view) {
		
		BadblockPlayer p = (BadblockPlayer) getPlayer();
		
		if(stack.isSimilar(SUNSET)){
			
			p.inGameData(BuildContestData.class).weather = "sun";
			p.setPlayerWeather(WeatherType.CLEAR);
			
		}
		
		if(stack.isSimilar(RAIN)){
			
			p.inGameData(BuildContestData.class).weather = "rain";
			p.setPlayerWeather(WeatherType.DOWNFALL);
			
		}
		
		if(stack.isSimilar(MATIN)){
			
			p.inGameData(BuildContestData.class).time = 700;
			p.setPlayerTime(700, true);
			
		}
		
		if(stack.isSimilar(MIDI)){
			
			p.inGameData(BuildContestData.class).time = 6200;
			p.setPlayerTime(6200, true);
			
		}
		
		if(stack.isSimilar(SOIR)){
	
			p.inGameData(BuildContestData.class).time = 13000;
			p.setPlayerTime(13000, true);
	
		}
		
		if(stack.isSimilar(NUIT)){
			
			p.inGameData(BuildContestData.class).time = 18000;
			p.setPlayerTime(18000, true);
	
		}
	
	}
	
}
