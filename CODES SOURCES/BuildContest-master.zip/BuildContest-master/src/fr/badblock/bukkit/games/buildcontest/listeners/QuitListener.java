package fr.badblock.bukkit.games.buildcontest.listeners;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerQuitEvent;

import fr.badblock.bukkit.games.buildcontest.BuildContestPlugin;
import fr.badblock.bukkit.games.buildcontest.achievements.scoreboard.BuildContestScoreboard;
import fr.badblock.bukkit.games.buildcontest.runnables.StartRunnable;
import fr.badblock.bukkit.games.buildcontest.team.InvitationManager;
import fr.badblock.bukkit.games.buildcontest.team.Team;
import fr.badblock.bukkit.games.buildcontest.team.TeamManager;
import fr.badblock.gameapi.BadListener;
import fr.badblock.gameapi.GameAPI;
import fr.badblock.gameapi.game.rankeds.RankedCalc;
import fr.badblock.gameapi.game.rankeds.RankedManager;
import fr.badblock.gameapi.players.BadblockPlayer;
import fr.badblock.gameapi.players.BadblockPlayer.BadblockMode;
import fr.badblock.gameapi.utils.i18n.messages.GameMessages;

public class QuitListener extends BadListener {

	@EventHandler
	public void onQuit(PlayerQuitEvent e) {

		BadblockPlayer player = (BadblockPlayer) e.getPlayer();
		if (!player.getGameMode().equals(GameMode.SPECTATOR) && !player.getBadblockMode().equals(BadblockMode.SPECTATOR))
		{
			GameMessages.quitMessage(GameAPI.getGameName(), player.getTabGroupPrefix().getAsLine(player) + player.getName(), Bukkit.getOnlinePlayers().size(), BuildContestPlugin.getInstance().getMaxPlayers()).broadcast();
		}
		
		if (StartRunnable.gameTask == null && BuildContestPlugin.getInstance().getOnline() < BuildContestPlugin.getInstance().getConfiguration().minPlayers) {

			StartRunnable.stopGame();

			StartRunnable.time = StartRunnable.time > 60 ? StartRunnable.time : 60;

		}

		if(inGame()) {
			BuildContestPlugin.getInstance().getPlayers().remove(e.getPlayer());
			// Work with rankeds
			String rankedGameName = RankedManager.instance.getCurrentRankedGameName();
			player.getPlayerData().incrementTempRankedData(rankedGameName, BuildContestScoreboard.LOOSES, 1);
			RankedManager.instance.calcPoints(rankedGameName, player, new RankedCalc()
			{

				@Override
				public long done() {
					double wins = RankedManager.instance.getData(rankedGameName, player, BuildContestScoreboard.WINS);
					double looses = RankedManager.instance.getData(rankedGameName, player, BuildContestScoreboard.LOOSES);
					double total = wins >= 1 ? wins * 3 : looses * -3;
					return (long) total;
				}

			});
			RankedManager.instance.fill(rankedGameName);
		}

		Team team = TeamManager.getTeam(e.getPlayer());

		System.out.println("checking");

		if(inGame() && BuildContestPlugin.getInstance().getPlot(team) != null) {
			if(!team.getPlayerWith(e.getPlayer()).getName().equals(e.getPlayer().getName())) {
				BuildContestPlugin.getInstance().getPlot(team).setOwner(team.getPlayerWith(e.getPlayer()));
			} else {
				System.out.println("removed team with player: " + e.getPlayer().getName());
				BuildContestPlugin.getInstance().TEAMS_TO_TP.remove(BuildContestPlugin.getInstance().getTeamPosition(team));
				TeamManager.removeTeam(team);
				BuildContestPlugin.getInstance().getPlots().remove(BuildContestPlugin.getInstance().getPlot(team));
			}
		}

		if(TeamManager.getTeam(e.getPlayer()) != null && !inGame()) {
			TeamManager.getTeam(e.getPlayer()).breakTeam(e.getPlayer());
			if(InvitationManager.getInvitation((BadblockPlayer) e.getPlayer()) != null) {
				InvitationManager.cancelInvitation(e.getPlayer());
			}
		} else if(inGame() && TeamManager.getTeam(e.getPlayer()) != null) {
			TeamManager.getTeam(e.getPlayer()).removePlayer(e.getPlayer());
		}

	}

}
