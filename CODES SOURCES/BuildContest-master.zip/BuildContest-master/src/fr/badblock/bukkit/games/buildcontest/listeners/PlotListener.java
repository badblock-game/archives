package fr.badblock.bukkit.games.buildcontest.listeners;

import java.util.List;

import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.BlockFromToEvent;
import org.bukkit.event.entity.ExplosionPrimeEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.world.StructureGrowEvent;

import fr.badblock.bukkit.games.buildcontest.BuildContestPlugin;
import fr.badblock.bukkit.games.buildcontest.plots.Plot;
import fr.badblock.gameapi.BadListener;
import fr.badblock.gameapi.players.BadblockPlayer;
import fr.badblock.gameapi.utils.selections.CuboidSelection;

/**
 * 
 * @author archimede67
 * Classe pour g�rer les arbres qui poussent en dehors du plot ainsi
 * que l'eau qui coule en dehors (et la lave)
 *
 */
public class PlotListener extends BadListener {

	@EventHandler
	public void onTreeGrow(StructureGrowEvent event) {
		if(!inGame()) return;
		
		Plot plot = BuildContestPlugin.getInstance().getPlotByLoc(event.getLocation());
		
		if(plot == null)
		{
			event.setCancelled(true);
			return;
		}

		CuboidSelection selection = plot.getArea();
		
		List<BlockState> states = event.getBlocks();
		
		for(BlockState block : states) {
			if(!selection.isInSelection(block.getBlock())) {
				block.setType(Material.AIR);
				block.update(true);
			}
		}
	}
	
	@EventHandler
	public void water(BlockFromToEvent e) {
		if(!inGame()) return;
		
		Plot plot = BuildContestPlugin.getInstance().getPlotByLoc(e.getBlock().getLocation());
		if(plot == null) { e.setCancelled(true); return; }
		
		CuboidSelection area = plot.getArea();
		
		Block to = e.getToBlock();
		if((e.getBlock().getType() == Material.WATER || e.getBlock().getType() == Material.STATIONARY_WATER || e.getBlock().getType() == Material.LAVA || e.getBlock().getType() == Material.STATIONARY_LAVA)) {
			if(!area.isInSelection(to))
				e.setCancelled(true);
		}
	}
	
	@EventHandler
	public void onPlayerBucketEmpty(PlayerBucketEmptyEvent event) {
		if(!inGame()) return;
		
		Plot plot = BuildContestPlugin.getInstance().getPlotByLoc(event.getBlockClicked().getLocation());
		
		if(plot == null) {
			event.setCancelled(true);
		}
	}
	
	@EventHandler
	public void tnt(ExplosionPrimeEvent e) {
		if(!inGame()) return;
		e.setCancelled(true);
	}

	
	@EventHandler
	public void move(PlayerMoveEvent e) {
		if(!inGame()) return;
		int max = BuildContestPlugin.getInstance().getMapConfiguration().getMaxY().intValue();
		
		if(e.getTo().getBlockY() >= max) {
			e.setTo(e.getFrom());
			((BadblockPlayer) e.getPlayer()).sendTranslatedActionBar("buildcontest.messages.cannotgotoohigh");
		}
	}
}
