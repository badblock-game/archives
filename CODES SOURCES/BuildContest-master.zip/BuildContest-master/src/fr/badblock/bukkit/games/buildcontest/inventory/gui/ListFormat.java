package fr.badblock.bukkit.games.buildcontest.inventory.gui;

public enum ListFormat {

	STACKABLE, NOT_STACKABLE;
	
}
