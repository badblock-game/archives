package fr.badblock.bukkit.games.buildcontest.listeners;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.Event.Result;
import org.bukkit.event.EventHandler;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.Inventory;

import fr.badblock.bukkit.games.buildcontest.data.BuildContestData;
import fr.badblock.bukkit.games.buildcontest.inventory.InventoryManager;
import fr.badblock.bukkit.games.buildcontest.inventory.gui.AbstractInventoryGUI;
import fr.badblock.bukkit.games.buildcontest.inventory.gui.AbstractPlayerInventory;
import fr.badblock.bukkit.games.buildcontest.inventory.gui.SharedGUI;
import fr.badblock.bukkit.games.buildcontest.inventory.guis.SetupGroundInventory;
import fr.badblock.bukkit.games.buildcontest.tools.Tools;
import fr.badblock.gameapi.BadListener;
import fr.badblock.gameapi.players.BadblockPlayer;

public class AGListener extends BadListener {
	
	@EventHandler
	public void onToolDrop(PlayerDropItemEvent e) {
		if(inGame() && e.getItemDrop() != null && Tools.getTool(e.getItemDrop().getItemStack(), (BadblockPlayer) e.getPlayer()) != null) {
			e.setCancelled(true);
		}
	}
	
	@EventHandler
	public void onItemClick(InventoryClickEvent e) {
		
		if(e.getCurrentItem() != null && e.getCurrentItem().getType() == Material.BARRIER) { e.setCancelled(true); e.getWhoClicked().getInventory().remove(e.getCurrentItem()); return; }
		
		if(Tools.getTool(e.getCurrentItem(), (BadblockPlayer) e.getWhoClicked()) != null) {
			e.setCancelled(true);
			e.setResult(Result.DENY);
			return;
		}
		
		Player p = (Player) e.getWhoClicked();
		BadblockPlayer badpl = (BadblockPlayer) p;
		
		if(badpl.inGameData(BuildContestData.class).current != null) {
			AbstractInventoryGUI gui = badpl.inGameData(BuildContestData.class).current;
			if(gui != null && e.isShiftClick() && !(gui instanceof SetupGroundInventory)) {
				e.setResult(Result.DENY);
				e.setCancelled(true);
				return;
			}
			if(!e.isShiftClick() && gui != null && !(gui instanceof SetupGroundInventory)) {
				if(e.getClickedInventory() != null && e.getClickedInventory().equals(gui.getCurrent())) {
					if(e.getCursor() != null && (e.getCurrentItem().getType() == Material.AIR || e.getCurrentItem() == null)) {
						e.setCancelled(true);
						gui.getCurrent().clear(e.getSlot());
					}
				}
			}
		}
		
		if(e.getClickedInventory() != null && getGui(e.getClickedInventory(), (Player) e.getWhoClicked()) != null) {
			AbstractInventoryGUI gui = getGui(e.getClickedInventory(), (Player) e.getWhoClicked());
			if(gui != null) {
				gui.onItemClick(e.getCurrentItem(), e.getAction(), e.getClick(), e.getCursor(), e.getSlot(), e.getView());
				if(gui instanceof SharedGUI) {
					((SharedGUI) gui).onItemClick(p, e.getCurrentItem(), e.getAction(), e.getClick(), e.getCursor(), e.getSlot(), e.getView());
				}
				gui.callPrev(e.getCurrentItem());
//				if(!gui.bypass()) {
				if(gui instanceof SetupGroundInventory) {
					e.setCancelled(e.getSlot() > 17);
				} else {
					e.setCancelled(true);
				}
//				} else {
//					ArrayList<ItemStack> clicks = InventoryManager.clickeables.get(gui);
//					if(clicks.contains(e.getCurrentItem())) {
//						e.setCancelled(true);
//					}
//				}
			}
		}
	}
	
	private AbstractInventoryGUI getGui(Inventory inv, Player player) {
		for(AbstractInventoryGUI gui : InventoryManager.clickeables.keySet()) {
			if(gui != null && gui.getCurrent() != null && gui.getCurrent().getTitle().equals(inv.getTitle()) && (gui instanceof SharedGUI ? ((SharedGUI) gui).getTeam().getName().contains(player.getName()) : gui.getPlayer().getName().equals(player.getName()))) {
				return gui;
			}
		}
		return null;
	}
	
	private AbstractPlayerInventory getInv(Player p) {
		for(AbstractPlayerInventory gui : InventoryManager.hotbars.keySet()) {
			if(gui != null && gui.getPlayer().getName().equals(p.getName())) {
				return gui;
			}
		}
		return null;
	}
	
	@EventHandler
	public void onInterract(PlayerInteractEvent e) {
		AbstractPlayerInventory inv = getInv(e.getPlayer());
		if(inv == null) return;
		
		if(Tools.getTool(e.getItem(), (BadblockPlayer) e.getPlayer()) != null) {
			e.setCancelled(true);
			return;
		}
		
		e.setCancelled(true);
		inv.onItemClick(e.getItem(), e.getAction());
	}
	
}
