package fr.badblock.bukkit.games.buildcontest.team.commands;

import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;

import fr.badblock.bukkit.games.buildcontest.team.InvitationManager;
import fr.badblock.bukkit.games.buildcontest.team.Team;
import fr.badblock.bukkit.games.buildcontest.team.TeamManager;
import fr.badblock.gameapi.command.AbstractCommand;
import fr.badblock.gameapi.players.BadblockPlayer;
import fr.badblock.gameapi.players.BadblockPlayer.GamePermission;
import fr.badblock.gameapi.utils.i18n.TranslatableString;

public class BrokeTeamCommand extends AbstractCommand {

	public BrokeTeamCommand() {
		super("breakmyteamwith", new TranslatableString("commands.gbuildcontest.breakmyteamwith.error"), GamePermission.PLAYER, GamePermission.PLAYER, GamePermission.PLAYER);
		allowConsole(false);
	}

	@Override
	public boolean executeCommand(CommandSender sender, String[] args) {
		if(args.length == 0)
			return true;
		
		if(!InvitationManager.can) return true;
		
		BadblockPlayer player = (BadblockPlayer) sender;
		String t = args[0];
		BadblockPlayer target = (BadblockPlayer) Bukkit.getPlayer(t);
		
		if(TeamManager.getTeam(player) == null) {
			//a d�j� une team
			//player.sendMessage("�7Vous �tes d�j� en team !");
			player.sendTranslatedMessage("buildcontest.messages.teams.youarenotinteam");
			return true;
		}
		
		Team team = TeamManager.getTeam(player);
		team.breakTeam(player);
		
		player.sendTranslatedMessage("buildcontest.messages.teams.youhavelefttheteam");
		target.sendTranslatedMessage("buildcontest.messages.teams.playerlefttheteam", player.getName());
		
		return true;
	}
	
}
