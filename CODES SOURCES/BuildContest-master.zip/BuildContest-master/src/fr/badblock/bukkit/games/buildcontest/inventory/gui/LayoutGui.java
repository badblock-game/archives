package fr.badblock.bukkit.games.buildcontest.inventory.gui;

import java.util.ArrayList;

import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public enum LayoutGui {

	LAYOUT_BASIC(true, null),
	LAYOUT_BOTTOM_OK(false, new GuiSide[] {GuiSide.BOTTOM}, new GuiItem(new ItemStack(Material.STAINED_GLASS_PANE, 1, (byte) 5), "�aValider", 4, 3), new GuiItem(new ItemStack(Material.STAINED_GLASS_PANE, 1, (byte) 14), "�cAnnuler", 6, 6)),
	LAYOUT_BACK_NEXT(true, null, new GuiItem(new ItemStack(Material.ARROW), "�7Pr�c�dent", 2, 6), new GuiItem(new ItemStack(Material.SULPHUR), "�7Suivant", 8, 6)), 
	LAYOUT_RETURN_ONLY(true, null, new GuiItem(new ItemStack(Material.MAGMA_CREAM), "�7Retour", 5, 6)), 
	LAYOUT_ALL(true, null, new GuiItem(new ItemStack(Material.ARROW), "�7Pr�c�dent", 2, 6), new GuiItem(new ItemStack(Material.SULPHUR), "�7Suivant", 8, 6), new GuiItem(new ItemStack(Material.MAGMA_CREAM), "�7Retour", 5, 6)), 
	LAYOUT_ALL_BOTTOM(false, new GuiSide[] { GuiSide.BOTTOM }, new GuiItem(new ItemStack(Material.ARROW), "�7Pr�c�dent", 2, 6), new GuiItem(new ItemStack(Material.SULPHUR), "�7Suivant", 8, 6), new GuiItem(new ItemStack(Material.MAGMA_CREAM), "�7Retour", 5, 6)),
	LAYOUT_TOP_BOTTOM(false, new GuiSide[] { GuiSide.TOP, GuiSide.BOTTOM}),
	LAYOUT_RIGHT(false, new GuiSide[] {GuiSide.RIGHT}),
	LAYOUT_LEFT(false, new GuiSide[] {GuiSide.LEFT}),
	LAYOUT_RETURN_BOTTOM(false, new GuiSide[] {GuiSide.BOTTOM}, new GuiItem(new ItemStack(Material.MAGMA_CREAM), "�7Retour", 5, 6)), 
	LAYOUT_CUSTOM(false, null);
	
	public static ArrayList<ItemStack> elements;
	
	static {
		elements = new ArrayList<>();
		setSeparator();
		setElements();
	}
	
	public GuiItem[] items;
	public boolean borders;
	private GuiSide[] side;
	
	public static ItemStack separator;
	
	LayoutGui(boolean borders, GuiSide[] side, GuiItem... items) {
		this.borders = borders;
		this.items = items;
		this.side = side;
	}
	
	public static void setElements() {
		for(LayoutGui layout : LayoutGui.values()) {
			if(layout.getClickeables() != null && layout.getClickeables().length > 0) {
				for(ItemStack st : layout.getClickeables()) {
					if(st != null && !elements.contains(st)) {
						elements.add(st);
					}
				}
			}
		}
		elements.add(separator);
	}
	
	public void resetPosForInv(Inventory in) {
		int maxY = in.getSize()/9;
		if(items != null && items.length > 0) {
			for(GuiItem item : items) {
				if(item.getY() > maxY) {
					int toRemove = item.getY() - maxY;
					int finalY = item.getY() - toRemove;
					int pos = ((finalY-1) * 9) + (item.getX()-1);
					in.setItem(pos, item.getStack());
				} else {
					int pos = ((item.getY()-1) * 9) + (item.getX()-1);
					in.setItem(pos, item.getStack());
				}
				
			}
		}
	}
	
	public void build(Inventory in) {
		if(borders) {
			makeBorders(in);
		}
		
		if(side != null) {
			makeBorder(in, side);
		}
		
		resetPosForInv(in);
		
//		if(items != null && items.length > 0) {
//			for(GuiItem item : items) {
//				int pos = ((item.getY()-1) * 9) + (item.getX()-1);
//				in.setItem(pos, item.getStack());
//			}
//		}
		
	}
	
	public ItemStack[] getClickeables() {
		ItemStack[] stacks = new ItemStack[items.length];
		for(int i = 0; i < items.length; i++) {
			stacks[i] = items[i].getStack();
		}
		return stacks;
	}
	
	private void makeBorders(Inventory in) {
		int yMax = (in.getSize() / 9);
		int xMax = 9;
		for(int y = 0; y < yMax; y++) {
			for(int x = 0; x < xMax; x++) {
				if(y == 0 || y == (yMax - 1)) {
					in.setItem((y * 9) + x, separator);
				} else {
					if(x == 0 || x == (xMax - 1)) {
						in.setItem((y * 9) + x, separator);
					}
				}
			}
		}
	}
	
	private void makeBorder(Inventory in, GuiSide[] sides) {
		int yMax = (in.getSize() / 9);
		int xMax = 9;
		
		for(GuiSide side : sides) {
			switch (side) {
			
			case TOP:
				for(int x = 0; x < xMax; x++) {
					in.setItem(x, separator);
				}
				break;
	
			case BOTTOM:
				for(int x = 0; x < xMax; x++) {
					in.setItem((((yMax-1) * 9) + x), separator);
				}
				break;
				
			case LEFT:
				for(int y = 0; y < yMax; y++) {
					in.setItem(y-1 * 9, separator);
				}
				break;
				
			case RIGHT:
				for(int y = 0; y < yMax; y++) {
					in.setItem((y-1 * 9) + 8, separator);
				}
				break;
				
			default:
				break;
				
			}
		}
	}
	
	private static void setSeparator() {
		ItemStack sep = new ItemStack(Material.STAINED_GLASS_PANE, 1, (byte) 8);
		ItemMeta meta = sep.getItemMeta();
		meta.setDisplayName(" ");
		sep.setItemMeta(meta);
		separator = sep;
	}

	public static boolean is(ItemStack stack) {
		return elements.contains(stack);
	}
	
}
