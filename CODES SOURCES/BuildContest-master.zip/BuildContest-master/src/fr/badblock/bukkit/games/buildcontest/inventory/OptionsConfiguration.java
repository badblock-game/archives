package fr.badblock.bukkit.games.buildcontest.inventory;

import org.bukkit.Material;

public class OptionsConfiguration {

	/* NICE, EXELLENT, UNBELIEVEBLE; **/
	
	/* Noms */
//	public String VERY_BAD_NAME = "�4Tr�s Mauvais";
//	public String BAD_NAME = "�cMauvais";
//	public String GOOD_NAME = "Bien";
//	public String NICE_NAME = "�bSuper";
//	public String EXELLENT_NAME = "�eExtra";
//	public String UNBELIEVEBLE_NAME = "�dIncroyable";
	public String[] names = { "verybad", "bad", "good", "super", "extra", "incredible"};
	
	public int[] points = {1, 2, 3, 4, 5, 6};
	public Material view = Material.STAINED_CLAY;
	
	public byte[] datas = {14, 6, 0, 13, 5, 11};
	
	public int[] totals = {1, 1, 1, 1, 1, 1};
	
}
