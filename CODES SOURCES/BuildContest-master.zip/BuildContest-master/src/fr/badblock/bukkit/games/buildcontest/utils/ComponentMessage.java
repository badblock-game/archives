package fr.badblock.bukkit.games.buildcontest.utils;

import lombok.Getter;
import lombok.Setter;
import net.md_5.bungee.api.chat.BaseComponent;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.ClickEvent.Action;
import net.md_5.bungee.api.chat.ComponentBuilder;
import net.md_5.bungee.api.chat.ComponentBuilder.FormatRetention;
import net.md_5.bungee.api.chat.HoverEvent;

public class ComponentMessage {
	
	@Getter@Setter
	private String message = "", command = "", onhover = "";
	
	public ComponentMessage(String message) {
		setMessage(message);
	}
	
	public ComponentMessage(String message, String command, boolean isCommand) {
		setMessage(message);
		if(isCommand)
			setCommand(command);
		else
			setOnhover(command);
	}
	
	public ComponentMessage(String message, String onhover, String command) {
		setMessage(message);
		setOnhover(onhover);
		setCommand(command);
	}
	
	public ComponentBuilder build(ComponentBuilder builder) {
		builder.append(getMessage());
		if(!getOnhover().isEmpty()) 
			builder.event(new HoverEvent(net.md_5.bungee.api.chat.HoverEvent.Action.SHOW_TEXT, new ComponentBuilder(getOnhover()).create()));
		if(!getCommand().isEmpty())
			builder.event(new ClickEvent(Action.RUN_COMMAND, getCommand()));
		//On clear le formattage pr�c�dent :d
		builder.append("", FormatRetention.NONE);
		return builder;
	}
	
	public static BaseComponent[] create(boolean oneLine, boolean space, ComponentMessage... components) {
		ComponentMessage first = components[0];
		ComponentBuilder builder = new ComponentBuilder("");
		builder = first.build(builder);
			
		ComponentMessage spaceComp = new ComponentMessage(" ");
		
		for(int i = 1; i < components.length; i++) {
			if(space) builder = spaceComp.build(builder);
			ComponentMessage current = components[i];
			builder = current.build(builder);
		}
			
		return builder.create();
//		builder.event(new ClickEvent(Action.RUN_COMMAND, getCommand()));
//		builder.event(new HoverEvent(net.md_5.bungee.api.chat.HoverEvent.Action.SHOW_TEXT, new ComponentBuilder(onhover).create()));
//		return builder.create();
	}
	
}
