package fr.badblock.bukkit.games.buildcontest.inventory.gui;

public enum GuiSide {

	TOP, LEFT, RIGHT, BOTTOM;
	
}
