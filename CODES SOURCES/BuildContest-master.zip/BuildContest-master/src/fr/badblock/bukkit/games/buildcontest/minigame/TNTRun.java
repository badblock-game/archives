package fr.badblock.bukkit.games.buildcontest.minigame;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

import fr.badblock.bukkit.games.buildcontest.BuildContestPlugin;
import fr.badblock.bukkit.games.buildcontest.config.MiniGameConfiguration;
import fr.badblock.bukkit.games.buildcontest.utils.ArchiUtils;
import fr.badblock.gameapi.GameAPI;
import fr.badblock.gameapi.players.BadblockPlayer;
import fr.badblock.gameapi.utils.threading.TaskManager;
import lombok.Data;
import net.minecraft.server.v1_8_R3.Blocks;
@Data
public class TNTRun {

	private final int TIME_BEFORE_START = 10;
	
	private List<BadblockPlayer> inGame = new ArrayList<>();
	private List<BadblockPlayer> specs = new ArrayList<>();
	private boolean setuped;
	
	private ItemStack floorMaterial;
	private Location loc1, loc2;
	
	private List<Block> area = new ArrayList<>();
	
	private HashMap<Integer, List<Blocks>> floors = new HashMap<>();
	
	private BukkitTask gameTask = null;
	private BukkitTask countDownTask = null;
	
	private final File config = BuildContestPlugin.MINIGAME;
	private boolean listening = false;
	
	public TNTRun setup() {
		if(!setGameArea()) return null;
		else return this;
	}
	
	private boolean setGameArea() {
		MiniGameConfiguration conf = BuildContestPlugin.getInstance().getMinigameConfiguration();
		if(conf.area.size() < 2) {
			System.out.println("[Error] [MiniGame] Area could not be setuped !");
			return false;
		}
		List<Location> area = conf.area;
		Location loc1 = area.get(0);
		Location loc2 = area.get(1);
		
		HashMap<String, String> material = conf.floorMaterial;
		String mat = material.get("material");
		Material bukkitMat = Material.valueOf(mat);
		String data = material.get("data");
		byte bytedata = Byte.parseByte(data);
		
		ItemStack floorMaterial = new ItemStack(bukkitMat, 1, bytedata);
		
		setFloorMaterial(floorMaterial);
		setLoc1(loc1);
		setLoc2(loc2);
		setArea();
		
		setSetuped(true);
		return true;
	}
	
	private void setArea() {
		this.area = ArchiUtils.getBlocks(loc1, loc2);
	}
	
	@SuppressWarnings("deprecation")
	public boolean isFloor(Block b) {
		return new ItemStack(b.getType(), 1, b.getData()).isSimilar(getFloorMaterial());
	}
	
	public void notifyJoined(BadblockPlayer pl) {
		if(!isSetuped()) return;
		if(!inGame.contains(pl)) inGame.add(pl);
		else return;
		inGame.forEach(player -> {
			player.sendTranslatedMessage("buildcontest.messages.tntrun.joined", pl.getName(), inGame.size());
		});
	}
	
	public void notifyLeave(BadblockPlayer pl) {
		if(!isSetuped()) return;
		if(inGame.contains(pl)) inGame.remove(pl);
		else return;
		
		if(inGame.size() < 2) {
			cancelStart();
		}
		
	}
	
	public void notifyLose(BadblockPlayer pl) {
		if(!isSetuped()) return;
		if(!isInGame(pl)) return;
		if(inGame()) return;
		inGame.forEach(player -> {
			player.sendTranslatedMessage("buildcontest.messages.tntrun.lose", pl.getName(), inGame.size()-1);
		});
		inGame.remove(pl);
		specs.add(pl);
		
		if(getInGame().size() < 2) {
			notifyWinner();
		}
		
	}
	
	public void notifyWinner() {
		if(inGame.size() == 0) { stopGame(); }
		inGame.forEach(player -> {
			if(player != null)
			if(inGame.get(0) != null)
				player.sendTranslatedMessage("buildcontest.messages.tntrun.win", inGame.get(0).getName());
		});
		specs.forEach(player -> {
			if(player != null)
			if(inGame.get(0) != null)
				player.sendTranslatedMessage("buildcontest.messages.tntrun.win", inGame.get(0).getName());
		});
		stopGame();
	}
	
	private void stopGame() {
		setStarted(false);
		if(inGame.size() > 0 && inGame.get(0) != null)
			inGame.get(0).teleport(BuildContestPlugin.getInstance().getConfiguration().getSpawn().getHandle());
		resetGame();
	}
	
	public void doGame() {
		TaskManager.scheduler.runTaskLater(GameAPI.getAPI(), new Runnable() {
			@Override
			public void run() {
				if(!isSetuped()) return;
				if(inGame()) return;
				if(!isListening())
				listenForStart();
			}
		}, 20L);
	}
	
	private String name = "TNTRun.listenForStart." + UUID.randomUUID().toString();
	private void listenForStart() {
		setListening(true);
		TaskManager.scheduleSyncRepeatingTask(name, new Runnable() {
			
			@Override
			public void run() {
				if(getInGame().size() >= 2 && !isStarting()) {
					countdown();
				}
				
			}
		}, 1, 1);
	}
	
	private boolean started = false;
	public boolean started() {
		return started;
	}
	
	private boolean starting = false;
	String countdown = "TNTRun.countdown#" + UUID.randomUUID().toString();
	private void countdown() {
		setStarting(true);
		
		GameAPI.getAPI().getOnlinePlayers().forEach(player -> {
			if(!getInGame().contains(player)) {
				player.sendTranslatedMessage("buildcontest.messages.tntrun.agameisabouttostart");
			}
		});
		
		countDownTask = TaskManager.scheduleSyncRepeatingTask(name, new Runnable() {
			
			int time = TIME_BEFORE_START;
			
			@Override
			public void run() {
				if(time >= 1 && (time <= 5 || time%5 == 0)) {
					getInGame().forEach(player -> {
						String message = GameAPI.getAPI().getI18n().get(player.getPlayerData().getLocale(), getPath("countdown"), time)[0];
						message = message.replace("secondes", time > 1 ? "secondes" : "seconde");
						player.sendMessage(message);
					});
				}
				
				if(time == 0) {
					getInGame().forEach(player -> {
						player.sendTranslatedMessage(getPath("started"));
					});
				}
				
				if(time >= 0)
					time--;
				
				if(time < 0) {
					TaskManager.cancelTaskByName(name);
					start();
				}
			}
		}, 0, 20);
	}
	
	private void start() {
		started = true;
	}
	
	private void cancelStart() {
		if(!started()) {
			TaskManager.cancelTaskByName(countdown);
			countDownTask = null;
			setStarted(false);
			setStarting(false);
		}
	}
	
	public boolean isInGame(BadblockPlayer pl) {
		return inGame.contains(pl);
	}
	
	public boolean inGame() {
		return !BuildContestPlugin.getInstance().isInLobby();
	}
	
	@SuppressWarnings("deprecation")
	public void resetGame(boolean... doGame) {
		countDownTask = null;
		inGame.clear();
		specs.clear();
		started = false;
		TaskManager.cancelTaskByName(name);
		setListening(false);
		setStarting(false);
		setStarted(false);
		for(int i = 0; i < TNTRunListener.toRestore.size(); i++) {
			Block b = TNTRunListener.toRestore.get(i);
			Location loc = b.getLocation();
			//loc.getWorld().getBlockAt(loc).setTypeIdAndData(b.getType().getId(), b.getData(), true);
			loc.getWorld().getBlockAt(loc).setType(getFloorMaterial().getType(), true);
			loc.getWorld().getBlockAt(loc).setData(getFloorMaterial().getData().getData(), true);
			loc.getWorld().getBlockAt(loc).getState().update(true);
		} 
		TNTRunListener.toRestore.clear();
		if(doGame.length == 0 || doGame[0])
			doGame();
	}
	
	public String getPath(String name) {
		return "buildcontest.messages.tntrun." + name;
	}
	
	public void disable() {
		resetGame(false);
	}
	
}
