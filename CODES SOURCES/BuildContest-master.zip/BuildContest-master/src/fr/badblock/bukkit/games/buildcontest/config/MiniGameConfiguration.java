package fr.badblock.bukkit.games.buildcontest.config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.bukkit.Location;
import org.bukkit.Material;

import fr.badblock.gameapi.configuration.BadConfiguration;
import fr.badblock.gameapi.configuration.values.MapLocation;
import fr.badblock.gameapi.configuration.values.MapString;

public class MiniGameConfiguration {

	public List<Location> area = new ArrayList<>();
	public HashMap<String, String> floorMaterial = new HashMap<>();
	
	public MiniGameConfiguration(BadConfiguration config) {
		
		if(config.getSection("floorMaterial") != null && config.getSection("floorMaterial").getValue("material", MapString.class, new MapString()) == null) {
			config.getSection("floorMaterial").setValue("material", new MapString(Material.SNOW_BLOCK.toString()));
			config.getSection("floorMaterial").setValue("data", new MapString("0"));
		}
		
		//BuildContestMapConfiguration config = new BuildContestMapConfiguration(GameAPI.getAPI().loadConfiguration(file));
		area = config.getValueList("area", MapLocation.class, new ArrayList<>()).getHandle();
		BadConfiguration section = config.getSection("floorMaterial");
		String material = section.getValue("material", MapString.class, new MapString()).getHandle();
		String data = section.getValue("data", MapString.class, new MapString()).getHandle();
		floorMaterial.put("material", material);
		floorMaterial.put("data", data);
	}
	
}
