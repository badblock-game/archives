package fr.badblock.bukkit.games.buildcontest.inventory;

import java.util.HashMap;

import org.bukkit.Material;

public class SkullConfiguration {

//	public HashMap<String, String> valuesByNames;
	public HashMap<String, HashMap<String, String>> categories;
//	public Material[] cat_blocks = new Material[] {Material.BREAD, Material.MINECART};
//	public byte[] blocks_datas = new byte[] {0};
	public HashMap<String, Material> materials = new HashMap<>();
	public HashMap<String, Byte> bytes = new HashMap<>();
	
	/*
	 * 
	 * Categories: {
	 * 
	 *    "Food": {
	 *    
	 *    
	 *    },
	 *    
	 *    "Other": {
	 *    
	 *    
	 *    
	 *    }
	 * 
	 * }
	 * 
	 */
	
}
