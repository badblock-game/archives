package fr.badblock.bukkit.games.buildcontest.team;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.entity.Player;

import fr.badblock.gameapi.players.BadblockPlayer;
import lombok.Getter;

public class Team {

	@Getter
	private List<Player> players = new ArrayList<>();
	
	public Team(Player p1, Player p2) {
		players.add(p1);
		players.add(p2);
	}
	
	public Team(Player p1) {
		players.add(p1);
	}
	
	public void breakTeam(Player quit) {
		TeamManager.removeTeam(this);
		TeamManager.updateNoTeamItem(players.get(0));
		if(quit != null)
			TeamManager.updateNoTeamItem(players.get(1));
		players.remove(quit);
	}

	public Player getPlayerWith(Player player) {
		if(players.size() == 2) {
			if(players.get(0).getName().equals(player.getName())) return players.get(1);
			else if(players.get(1).getName().equals(player.getName())) return players.get(0);
			else return null;
		} else {
			return players.get(0);
		}
	}

	public void removePlayer(Player player) {
		players.remove(player);
	}

	public String getName() {
		if(players.size() == 1) {
			return players.get(0).getName();
		} else if(players.size() == 2) {
			return players.get(0).getName() + " + " + players.get(1).getName();
		} else {
			return "N/A";
		}
	}

	public BadblockPlayer getOwner() {
		return players.size() > 0 ? (BadblockPlayer) players.get(0) : null;
	}

	public void sendTranslatedActionBar(String key, Object... args) {
		getPlayers().forEach(player -> {
			BadblockPlayer pl = (BadblockPlayer) player;
			pl.sendTranslatedActionBar(key, args);
		});
		
	}
	
}
