package fr.badblock.bukkit.games.buildcontest.blocks;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

public class SpecialsBlocks {
	
	private static List<ItemStack> allblocks = new ArrayList<>();
	
	@SuppressWarnings("deprecation")
	public static void registerBlocks() {
		
		SpecialBlock.create(Material.LOG, Material.LOG, "�bBois plein", (byte) 12, (byte) 0);
		SpecialBlock.create(Material.LOG, Material.LOG, "�bBois plein", (byte) 13, (byte) 1);
		SpecialBlock.create(Material.LOG, Material.LOG, "�bBois plein", (byte) 14, (byte) 2);
		SpecialBlock.create(Material.LOG, Material.LOG, "�bBois plein", (byte) 15, (byte) 3);
		
		SpecialBlock.create(Material.LOG_2, Material.LOG_2, "�bBois plein", (byte) 12, (byte) 0);
		SpecialBlock.create(Material.LOG_2, Material.LOG_2, "�bBois plein", (byte) 13, (byte) 1);
		
		SpecialBlock.create(Material.getMaterial(44), Material.getMaterial(43), "�bDalle pleine", (byte) 8, (byte) 0);
		SpecialBlock.create(Material.getMaterial(44), Material.getMaterial(43), "�bDalle pleine", (byte) 9, (byte) 1);
		SpecialBlock.create(Material.STONE_SLAB2, Material.DOUBLE_STONE_SLAB2, "�bDalle pleine", (byte) 8, (byte) 0);
		
	}
	
	public static List<ItemStack> getAllBlocks() {
		
		return allblocks;
		
	}
	
	public static boolean isBlock(ItemStack stack) {
		if(stack == null) return false;
		for(ItemStack item : allblocks) {
			if(item.isSimilar(stack)) {
				return true;
			}
		}
		return false;
	}
	
	

}
