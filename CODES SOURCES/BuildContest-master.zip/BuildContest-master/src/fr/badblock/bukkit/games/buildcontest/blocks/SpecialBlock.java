package fr.badblock.bukkit.games.buildcontest.blocks;

import java.util.Arrays;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class SpecialBlock {
	
	@SuppressWarnings("deprecation")
	public static void create(Material mat, Material real, String name, byte data, byte normal){
		
		ItemStack st = new ItemStack(mat, 1, normal);
		ItemMeta meta = st.getItemMeta();
		meta.setDisplayName(name);
		meta.setLore(Arrays.asList("�7" + real.getId() + ":" + data));
		st.setItemMeta(meta);
		
		SpecialsBlocks.getAllBlocks().add(st);
		
	}

}
