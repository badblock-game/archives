package fr.badblock.bukkit.games.buildcontest.tools;

import org.bukkit.entity.Player;

import lombok.Data;

@Data
public abstract class ToolAction {

	private Player player;
	
	public abstract void onClick();
	
}
