package fr.badblock.bukkit.games.buildcontest.inventory.guis;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryView;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import fr.badblock.bukkit.games.buildcontest.BuildContestPlugin;
import fr.badblock.bukkit.games.buildcontest.inventory.gui.LayoutGui;
import fr.badblock.bukkit.games.buildcontest.inventory.gui.SharedGUI;
import fr.badblock.bukkit.games.buildcontest.plots.Plot;
import fr.badblock.bukkit.games.buildcontest.team.Team;
import fr.badblock.bukkit.games.buildcontest.team.TeamManager;
import fr.badblock.bukkit.games.buildcontest.tools.ToolList;
import fr.badblock.bukkit.games.buildcontest.utils.ArchiUtils;
import fr.badblock.gameapi.GameAPI;
import fr.badblock.gameapi.players.BadblockPlayer;
import lombok.Getter;
import lombok.Setter;

public class ChangeGroundInventory extends SharedGUI {

	@Getter@Setter
	private Plot plot;
	private int theSlot = 21;
	private ItemStack resetPlot;
	public List<ItemStack> blocks = new ArrayList<ItemStack>();
	private SetupGroundInventory sgi;
	
	public ChangeGroundInventory(Team team) {
		super(team);
		plot = BuildContestPlugin.getInstance().getPlot(team);
		resetPlot = ToolList.RESET_PLOT.getStack(team.getOwner());
	}

	public void buildInv() {
		Inventory inv = Bukkit.createInventory(null, 9*5, i18n("buildcontest.inventory.changeground.displayname"));
		build(inv, LayoutGui.LAYOUT_RETURN_ONLY);
		
		updateItem(23, resetPlot);
		
		update();
	}
	
	public void update() {
		if(plot == null) {
			plot = BuildContestPlugin.getInstance().getPlot(TeamManager.getTeam(getPlayer()));
			return;
		}
		
		Bukkit.getScheduler().scheduleSyncDelayedTask(GameAPI.getAPI(), new Runnable() {
			
			@Override
			public void run() {
				ItemStack current = ArchiUtils.createItem(plot.getFloor(), 1, plot.getFloorData(), i18n("buildcontest.inventory.changeground.items.floor.displayname.1"), loadFloor());
				updateItem(theSlot, replaceBlockWithItem(current));
				
			}
		}, 1L);
		
	}
	
	@SuppressWarnings("deprecation")
	public String[] loadFloor() {
		if(blocks.size() == 0) {
			String[] tot = new String[2];
			tot[0] = i18n("buildcontest.inventory.changeground.items.floor.displayname.2");
			tot[1] = "�b-�7 " + plot.getFloor() + ":" + plot.getFloorData() + " (�b100%�7)";
			return tot;
		}
		ArrayList<ItemStack> real = countReal(blocks);
		String[] tot = new String[1 + real.size()];
		tot[0] = i18n("buildcontest.inventory.changeground.items.floor.displayname.2");
		int i = 1;
		
		for(ItemStack st : real) {
			int percentage = getPercent(st, blocks);
			Material type = st.getType();
			String block = type.name().toLowerCase();
			block = block.substring(0, 1).toUpperCase() + block.substring(1);
			block = block + ":" + st.getData().getData();
			tot[i] = "�b- �7" + block + " (�b" + percentage + "%�7)";
			i++;
		}
		return tot;
	}
	
	public int getPercent(ItemStack st, List<ItemStack> list) {
		int count = 0;
		for(int i = 0; i < list.size(); i++) {
			if(st.isSimilar(list.get(i))) {
				count++;
			}
		}
		
		int size = list.size();
		
		double value = ((double) count / (double) size) * 100.0D;
		int percent = (int) (value + 0.5d);
		
		return percent;
	}
	
	public ArrayList<ItemStack> countReal(List<ItemStack> from) {
		ArrayList<ItemStack> temp = new ArrayList<>();
		ItemStack first = from.get(0);
		temp.add(first);
		for(int i = 1; i < from.size(); i++) {
			if(!first.isSimilar(from.get(i))) {
				first = from.get(i);
				temp.add(first);
			}
		}
		return temp;
	}
	
	private boolean enabled = true;
	
	@Override
	public void onItemClick(ItemStack stack, InventoryAction action, ClickType type, ItemStack cursor, int slot, InventoryView view) {
		
	}
	
	public void onBlockSetuped() {
		System.out.println("setup blocks random?");
		if(blocks.size() == 0) return;
		if(plot != null) {
			plot.setFloorRandom(blocks);
		}
		update();
		getTeam().sendTranslatedActionBar("buildcontest.messages.groundreplaced");
		System.out.println("yeas");
	}
	
	private void openSetupGroundInv(Player p) {
		if(sgi == null)
			sgi = new SetupGroundInventory(getTeam(), this).buildInv();
		display(p, sgi);
	}

	@SuppressWarnings("deprecation")
	public void resetGround() {
		Bukkit.getScheduler().runTaskLater(GameAPI.getAPI(), new BukkitRunnable() {
			@Override
			public void run() {
//				ItemStack current = new ItemStack(plot.getFloor(), 1, (byte) plot.getFloorData());
//				updateItem(theSlot, replaceBlockWithItem(current));
				update();
				if(sgi != null) {
					sgi.clearGui();
				}
			}
		}, 5L);
	}

	@Override
	public void open() {
		super.open();
		update();
	}

	@SuppressWarnings("deprecation")
	@Override
	public void onItemClick(Player p, ItemStack stack, InventoryAction action, ClickType click, ItemStack cursor,
			int slot, InventoryView view) {
		
		if(slot == theSlot) {
			if(cursor != null && cursor != null && cursor.getType() != Material.AIR) {
				if(!enabled) {
					((BadblockPlayer) p).sendMessage("�7Cette fonctionnalit� n'est pas tout � fait au point. Merci de votre compr�hension.");
				} else {
					if(isBlock(cursor)) {
						updateItem(slot, cursor);
						if(plot != null)
							plot.setFloor(replaceItemWithBlock(cursor).getType(), replaceItemWithBlock(cursor).getData().getData());
						view.setCursor(null);
						update();
						p.closeInventory();
						getTeam().sendTranslatedActionBar("buildcontest.messages.groundreplaced");
					} else {
						((BadblockPlayer) p).sendTranslatedActionBar("buildcontest.messages.itemnotblock");
					}
				}
			} else if(cursor == null || cursor.getType() == Material.AIR) {
				if(!enabled) {
					((BadblockPlayer) p).sendMessage("�7Cette fonctionnalit� n'est pas tout � fait au point. Merci de votre compr�hension.");
				} else {
				//Open setup ground inv
					blocks.clear();
					openSetupGroundInv(p);
				}
			}
		}
		
	}
	
}
