package fr.badblock.bukkit.games.buildcontest.team;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.entity.Player;

import fr.badblock.gameapi.players.BadblockPlayer;
import lombok.Getter;

public class TeamInvitation {

	private static ArrayList<TeamInvitation> invits = new ArrayList<>();
	
	public static boolean put(Player p1, Player p2) {
		if(!doContains(p1, p2)) {
			invits.add(new TeamInvitation(p1, p2));
			return true;
		} else return false;
	}
	
	public static boolean doContains(Player p1, Player p2) {
		for(TeamInvitation teaminv : invits) {
			if(teaminv.getPlayers().contains(p1.getName()) && teaminv.getPlayers().contains(p2.getName())) {
				return true;
			}
		};
		return false;
	}
	
	public static TeamInvitation get(Player in) {
		for(TeamInvitation invit : invits) {
			if(invit.getPlayers().contains(in.getName())) {
				return invit;
			}
		}
		return null;
	}
	
	public static void cancel(TeamInvitation invit) {
		invits.remove(invit);
	}
	
	@Getter
	private Player first, second;
	@Getter
	private List<String> players = new ArrayList<>();
	
	public TeamInvitation(Player first, Player second) {
		this.first = first;
		this.second = second;
		players.add(first.getName());
		players.add(second.getName());
	}
	
	public void cancel() {
		invits.remove(this);
	}

	public void validate() {
		TeamManager.addTeam(first, second);
		disable();
	}
	
	private void disable() {
		invits.remove(this);
	}

	public void reject() {
		disable();
	}

	public BadblockPlayer getInvitedWith(BadblockPlayer player) {
		if(getFirst().getName().equals(player.getName())) return (BadblockPlayer) getSecond();
		else return (BadblockPlayer) getFirst();
	}
	
}
