package fr.badblock.bukkit.games.buildcontest.schematic;

import org.bukkit.Location;

/**
* Created by Matthias on 7/01/2017.
*/
public class Schematic {

    private byte[] blocks;
    private byte[] data;
    private short width;
    private short length;
    private short height;
    
    private Location loc1;
    @SuppressWarnings("unused")
	private Location loc2;

    public Schematic(byte[] blocks, byte[] data, short width, short length, short height)
    {
        this.blocks = blocks;
        this.data = data;
        this.width = width;
        this.length = length;
        this.height = height;
    }
    
    public Schematic(Location pos1, Location pos2) {
    	this.loc1 = pos1;
    	this.loc2 = pos2;
    	setArea(pos1, pos2);
    }
    
    @SuppressWarnings("deprecation")
	public void setArea(Location loc1, Location loc2) {
		
		int topBlockX = (loc1.getBlockX() < loc2.getBlockX() ? loc2.getBlockX() : loc1.getBlockX());
        int bottomBlockX = (loc1.getBlockX() > loc2.getBlockX() ? loc2.getBlockX() : loc1.getBlockX());
 
        int topBlockY = (loc1.getBlockY() < loc2.getBlockY() ? loc2.getBlockY() : loc1.getBlockY());
        int bottomBlockY = (loc1.getBlockY() > loc2.getBlockY() ? loc2.getBlockY() : loc1.getBlockY());
 
        int topBlockZ = (loc1.getBlockZ() < loc2.getBlockZ() ? loc2.getBlockZ() : loc1.getBlockZ());
        int bottomBlockZ = (loc1.getBlockZ() > loc2.getBlockZ() ? loc2.getBlockZ() : loc1.getBlockZ());
 
        int width = topBlockX - bottomBlockX + 1;
        int height = topBlockY - bottomBlockY + 1;
        int length = topBlockZ - bottomBlockZ + 1;
        
        int xOffset = loc1.getBlockX();
        int yOffset = loc1.getBlockY();
        int zOffset = loc1.getBlockZ();
        
        int total = 0;
        
        int[][][] blocksArray = new int[width][height][length];
        int[][][] datasArray = new int[width][height][length];
        
        for(int x = 0; x < width; x++)
        {
            for(int z = 0; z < length; z++)
            {
                for(int y = 0; y < height; y++)
                {
                	blocksArray[x][y][z] = loc1.getWorld().getBlockAt(new Location(loc1.getWorld(), x + xOffset, y + yOffset, z + zOffset)).getTypeId();
                	datasArray[x][y][z] = loc1.getWorld().getBlockAt(new Location(loc1.getWorld(), x + xOffset, y + yOffset, z + zOffset)).getData();
                    total++;
                }
            }
        }
        
        byte[] blocks = new byte[total];
        byte[] data = new byte[blocks.length];
        
                
        //y * this.width * this.length + z * this.width + x
        
        for(int x = 0; x < width; x++)
        {
            for(int z = 0; z < length; z++)
            {
                for(int y = 0; y < height; y++)
                {
                    blocks[y * width * length + z * width + x] = (byte) blocksArray[x][y][z];
                    data[y * width * length + z * width + x] = (byte) datasArray[x][y][z];
                }
            }
        }
        
        this.blocks = blocks;
        this.data = data;
        this.width = (short) width;
        this.length = (short) length;
        this.height = (short) height;
        
	}

    /**
     * @return the blocks
     */
    public byte[] getBlocks()
    {
        return blocks;
    }

    /**
     * @return the data
     */
    public byte[] getData()
    {
        return data;
    }

    /**
     * @return the width
     */
    public short getWidth()
    {
        return width;
    }

    /**
     * @return the length
     */
    public short getLength()
    {
        return length;
    }

    /**
     * @return the height
     */
    public short getHeight()
    {
        return height;
    }

	public int getOriginX() {
		return loc1.getBlockX();
	}
	
	public int getOriginY() {
		return loc1.getBlockY();
	}
	
	public int getOriginZ() {
		return loc1.getBlockZ();
	}
}