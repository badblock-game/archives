package fr.badblock.bukkit.games.buildcontest.particles;

import org.bukkit.Location;

public abstract class ParticleAction {
	
	public abstract void tick(Location loc);
	
}
