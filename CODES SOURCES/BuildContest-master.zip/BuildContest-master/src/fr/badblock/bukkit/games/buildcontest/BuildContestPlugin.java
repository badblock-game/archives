package fr.badblock.bukkit.games.buildcontest;

import java.io.File;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.DyeColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import com.google.gson.JsonArray;

import fr.badblock.bukkit.games.buildcontest.achievements.BuildContestAchievementList;
import fr.badblock.bukkit.games.buildcontest.achievements.scoreboard.BuildContestScoreboard;
import fr.badblock.bukkit.games.buildcontest.blocks.SpecialsBlocks;
import fr.badblock.bukkit.games.buildcontest.commands.GameCommand;
import fr.badblock.bukkit.games.buildcontest.config.BuildContestConfiguration;
import fr.badblock.bukkit.games.buildcontest.config.BuildContestMapConfiguration;
import fr.badblock.bukkit.games.buildcontest.config.MiniGameConfiguration;
import fr.badblock.bukkit.games.buildcontest.inventory.guis.PlayerListInventory;
import fr.badblock.bukkit.games.buildcontest.inventory.vote.VoteInventory;
import fr.badblock.bukkit.games.buildcontest.inventory.vote.VoteOption;
import fr.badblock.bukkit.games.buildcontest.listeners.AGListener;
import fr.badblock.bukkit.games.buildcontest.listeners.ChatListener;
import fr.badblock.bukkit.games.buildcontest.listeners.JoinListener;
import fr.badblock.bukkit.games.buildcontest.listeners.PartyJoinListener;
import fr.badblock.bukkit.games.buildcontest.listeners.PlotListener;
import fr.badblock.bukkit.games.buildcontest.listeners.QuitListener;
import fr.badblock.bukkit.games.buildcontest.listeners.ToolListener;
import fr.badblock.bukkit.games.buildcontest.listeners.map.BuildContestMapProtector;
import fr.badblock.bukkit.games.buildcontest.minigame.TNTRun;
import fr.badblock.bukkit.games.buildcontest.minigame.TNTRunListener;
import fr.badblock.bukkit.games.buildcontest.particles.ParticleList;
import fr.badblock.bukkit.games.buildcontest.particles.ParticleListener;
import fr.badblock.bukkit.games.buildcontest.plots.Plot;
import fr.badblock.bukkit.games.buildcontest.runnables.PreStartRunnable;
import fr.badblock.bukkit.games.buildcontest.schematic.ResultsConfiguration;
import fr.badblock.bukkit.games.buildcontest.team.Team;
import fr.badblock.bukkit.games.buildcontest.team.TeamManager;
import fr.badblock.bukkit.games.buildcontest.team.commands.AllyCommand;
import fr.badblock.bukkit.games.buildcontest.team.commands.BrokeTeamCommand;
import fr.badblock.bukkit.games.buildcontest.team.commands.CancelAllyCommand;
import fr.badblock.bukkit.games.buildcontest.team.commands.DenyAllyCommand;
import fr.badblock.bukkit.games.buildcontest.tools.ToolHandler;
import fr.badblock.bukkit.games.buildcontest.utils.Skulls;
import fr.badblock.gameapi.BadblockPlugin;
import fr.badblock.gameapi.GameAPI;
import fr.badblock.gameapi.achievements.AchievementList;
import fr.badblock.gameapi.game.GameServer.WhileRunningConnectionTypes;
import fr.badblock.gameapi.game.rankeds.RankedManager;
import fr.badblock.gameapi.players.BadblockPlayer;
import fr.badblock.gameapi.players.scoreboard.BadblockScoreboard.VoteElement;
import fr.badblock.gameapi.run.BadblockGame;
import fr.badblock.gameapi.run.BadblockGameData;
import fr.badblock.gameapi.run.RunType;
import fr.badblock.gameapi.utils.BukkitUtils;
import fr.badblock.gameapi.utils.GameRules;
import fr.badblock.gameapi.utils.general.JsonUtils;
import fr.badblock.gameapi.utils.i18n.TranslatableString;
import fr.badblock.gameapi.utils.itemstack.ItemAction;
import fr.badblock.gameapi.utils.itemstack.ItemEvent;
import lombok.Getter;
import lombok.Setter;

public class BuildContestPlugin extends BadblockPlugin { 
	
	//v1.4.9 #JustePourModifierLaClasse
	
	@Getter@Setter
	private Team winner;
	
	@Getter private static BuildContestPlugin instance;
	
	//public ArrayList<Team> playerstpvote = new ArrayList<>();
	public HashMap<Integer, Team> TEAMS_TO_TP = new HashMap<>();
	public HashMap<Team, Location> TEAM_PLOT = new HashMap<>();
	
	public ArrayList<String> allthemes = new ArrayList<>();
	
	public static File MAP;
	
	public ItemStack voteTheme;
	
	public boolean canVoteForTheme = true;
	
	public HashMap<String, VoteInventory> inventories = new HashMap<>();
	
	private static final String CONFIG = "config.json";
	private static final String RESULTS_CONFIG = "results.json";
	
	public static final String VOTES_CONFIG = "votes.json";
	private static final String MAPS_CONFIG_FOLDER = "maps";
	public static File MINIGAME;

	@Getter@Setter 
	private int maxPlayers;
	@Getter
	private BuildContestConfiguration configuration;
	@Getter@Setter
	private BuildContestMapConfiguration mapConfiguration;
	@Getter@Setter
	private ResultsConfiguration resultsConfiguration;
	@Getter@Setter
	private MiniGameConfiguration minigameConfiguration;
	
	@Getter@Setter
	private BuildStage buildStage = BuildStage.BUILD;
	@Getter@Setter
	private List<BadblockPlayer> players = new ArrayList<>();
//	@Getter@Setter
//	private ArrayList<String> themes = new ArrayList<>();
	
	@Getter@Setter
	private UUID gameId;
	
	@Getter@Setter
	private String theme;
	
	@Getter@Setter
	private boolean inLobby = true;
	
	@Getter
	private HashMap<BadblockPlayer, BuildContestScoreboard> scoreboards = new HashMap<>();
	
	public ArrayList<Plot> plots = new ArrayList<>();
	@Getter
	public ArrayList<String> maps = new ArrayList<>();
	@Getter
	public HashMap<String, String> mapNames = new HashMap<>();
	
	@Getter@Setter
	private Team current;
	
	@Getter@Setter
	private ParticleList list;

	@Getter@Setter
	private TNTRun TNTRun;
	
	/* jeu a 2 */
	
	@Getter@Setter
	private int playersInTeam = 2;
	
	/* ------- */
	
	@Getter
	private ItemStack allyWith;
	
	@SuppressWarnings("deprecation")
	@Override
	public void onEnable(RunType type) {
		instance = this;
		list = ParticleList.instance;
		
		setGameId(UUID.randomUUID());
		System.out.println("Game id is : " + getGameId());
		
		AchievementList list = BuildContestAchievementList.instance;
		
		BadblockGame.BUILDCONTEST.setGameData(new BadblockGameData() {
			
			@Override
			public AchievementList getAchievements() {
				return list;
			}
		});
		
		if(type == RunType.LOBBY) {
			return;
		}
		
		try {
			if(!getDataFolder().exists()) getDataFolder().mkdir();

			/**
			 * Chargement de la configuration du jeu
			 */
			
			// Modification des GameRules
			GameRules.doDaylightCycle.setGameRule(false);
			GameRules.spectatorsGenerateChunks.setGameRule(false);
			GameRules.doFireTick.setGameRule(false);

			// Lecture de la configuration du jeu

			BadblockGame.BUILDCONTEST.use();
			
			File configFile    = new File(getDataFolder(), CONFIG);
			this.configuration = JsonUtils.load(configFile, BuildContestConfiguration.class);
			/* D�finit les 9 themes de la partie */
			
			SecureRandom secureRandom = new SecureRandom();
			
			String theme = null;
			
			int size = (configuration.themes.size() >= 9 ? 9 : configuration.themes.size());
			
			while (allthemes.size() != size) {
				while (theme == null || allthemes.contains(theme))
					theme = configuration.themes.get(secureRandom.nextInt(configuration.themes.size()));
					allthemes.add(theme);
					//TVoteManager.register(theme);
			}
			
			JsonUtils.save(configFile, configuration, true);
			
			//Results
			
			File resultsFile = new File(getDataFolder(), RESULTS_CONFIG);
			this.resultsConfiguration = JsonUtils.load(resultsFile, ResultsConfiguration.class);
			JsonUtils.save(resultsFile, resultsConfiguration, true);
			
			File temp = new File(getDataFolder() + "/temp");
			temp.mkdir();
			
			//-------
			
			/* Heads */
			Skulls.loadFromConfig();
			
			/* Options */
			VoteOption.loadFromConfig();
			
			/*if(teamEnabled()) {
				File 			  teamsFile 	= new File(getDataFolder(), TEAMS_CONFIG);
				FileConfiguration teams 		= YamlConfiguration.loadConfiguration(teamsFile);
				getAPI().registerTeams(configuration.maxPlayersInTeam, teams);
				try { 
					teams.save(teamsFile); 
				} catch (IOException unused) {}
				
				getAPI().getJoinItems().registerTeamItem(3, new File(getDataFolder(), TEAMS_CONFIG_INVENTORY));
				
			}
			
			if(teamEnabled())
				maxPlayers = getAPI().getTeams().size() * configuration.maxPlayersInTeam;*/
			maxPlayers = configuration.maxPlayers;
			
			try {
				BukkitUtils.setMaxPlayers(maxPlayers);
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			getAPI().formatChat(true, false);
			
			getAPI().getJoinItems().registerAchievementsItem(4, BadblockGame.BUILDCONTEST);
			getAPI().getJoinItems().registerVoteItem(0);
			getAPI().getJoinItems().registerLeaveItem(8, configuration.fallbackServer);
			
			//if(teamEnabled())
				getAPI().getJoinItems().registerCustomItem(1, getAPI().createItemStackFactory().type(Material.INK_SACK)
					.durability((short) DyeColor.SILVER.getData())
					.displayName(new TranslatableString("buildcontest.inventory.joinitems.allywith.displayName"))
					.lore(new TranslatableString("buildcontest.inventory.joinitems.allywith.description", getState("buildcontest.inventory.joinitems.allywith.states", 0))).setAsSkull("MHF_Question"), new ItemEvent() {
						
						@Override
						public boolean call(ItemAction action, BadblockPlayer player) {
							
							new PlayerListInventory(player).create().open();
							
							return false;
						}
					});
			
			getAPI().setMapProtector(new BuildContestMapProtector());
			
			getAPI().getGameServer().whileRunningConnection(WhileRunningConnectionTypes.SPECTATOR);
			
			new ToolListener();
			new JoinListener();
			new QuitListener();
			new PartyJoinListener();
			new PlotListener();
			new ChatListener();
			new ToolHandler();
			new ParticleListener();
			
			SpecialsBlocks.registerBlocks();
			
			new AGListener();
			
			File votesFile = new File(getDataFolder(), VOTES_CONFIG);

			if(!votesFile.exists())
				votesFile.createNewFile();
			
			getAPI().getBadblockScoreboard().doGroupsPrefix();
			
			ArrayList<VoteElement> vote = new ArrayList<>();
			allthemes.forEach(internal -> {
				String i18n = getAPI().getI18n().get("buildcontest.inventory.themes." + internal)[0];
				VoteElement element = new VoteElement(internal, i18n);
				vote.add(element);
			});
			
			getAPI().getBadblockScoreboard().beginVote(vote);
			
			
			JsonArray array = JsonUtils.loadArray(votesFile);
			for(int i = 0; i < array.size(); i++) {
				//map_name : array.get(i).getAsJsonObject().get("internalName").getAsString()
				String internal = array.get(i).getAsJsonObject().get("internalName").getAsString();
				maps.add(internal);
				mapNames.put(internal, array.get(i).getAsJsonObject().get("displayName").getAsString());
			}
			
			new PreStartRunnable().runTaskTimer(GameAPI.getAPI(), 0, 30L);
			
			MAP = new File(getDataFolder(), MAPS_CONFIG_FOLDER);
			
			new GameCommand();
			new AllyCommand();
			new DenyAllyCommand();
			new CancelAllyCommand();
			new BrokeTeamCommand();
			
			Bukkit.getWorlds().forEach(world -> {
				world.setTime(2000L);
				world.getEntities().forEach(entity -> entity.remove());
			});
			
			//Loading minigame
			MINIGAME = new File(BuildContestPlugin.getInstance().getDataFolder(), "minigame.json");
			minigameConfiguration = new MiniGameConfiguration(GameAPI.getAPI().loadConfiguration(MINIGAME));
			setTNTRun(new TNTRun().setup());
			if(getTNTRun() != null) {
				getTNTRun().doGame();
				new TNTRunListener();
			}
			
			// Ranked
			RankedManager.instance.initialize(RankedManager.instance.getCurrentRankedGameName(), 
					BuildContestScoreboard.WINS, BuildContestScoreboard.LOOSES);
			
			
		} catch(Throwable e){
			e.printStackTrace();
		}
		
	}
	
	/*public String getState(BadblockPlayer p, String path, int pos, Object... args) {
		String[] i18n = getAPI().getI18n().get(p.getPlayerData().getLocale(), path, args);
		if(i18n.length <= pos)
		return i18n[i18n.length-1];
		else return i18n[pos];
	}*/
	
	public TranslatableString getState(String path, int pos, Object...args) {
		return new TranslatableString(path + "." + (pos+1), args);
	}
	
	public static String getString(String path, Player p, Object... args) {
		if(p != null)
			return GameAPI.getAPI().getI18n().get(((BadblockPlayer) p).getPlayerData().getLocale(), path, args)[0];
		else {
			return GameAPI.getAPI().getI18n().get(path, args)[0];
		}
	}
	
	public boolean teamEnabled() {
		return configuration.teamEnabled;
	}

	public void addPlot(Plot plot) {
		plots.add(plot);
	}

	private HashMap<Team, Plot> PLOT_BY_TEAMS = new HashMap<>();
	private HashMap<Location, Plot> PLOT_BY_LOCS = new HashMap<>();
	
	public Plot getPlot(Team team) {
		if(PLOT_BY_TEAMS.containsKey(team)) return PLOT_BY_TEAMS.get(team);
		else {
			for(Plot plot : plots) {
				for(Player p : team.getPlayers()) {
					if(p.getName().equals(plot.getOwner().getName())) {
						PLOT_BY_TEAMS.put(team, plot);
					}
				}
			}
			return PLOT_BY_TEAMS.get(team);
		}
	}

	
	public Plot getPlotByLoc(Location location) {
		if(PLOT_BY_LOCS.containsKey(location)) return PLOT_BY_LOCS.get(location);
		else {
			for(Plot plot : plots) {
				if(plot.getArea().isInSelection(location))
					PLOT_BY_LOCS.put(location, plot);
			}
			
			return PLOT_BY_LOCS.get(location);
		}
	}

	public ArrayList<Plot> getPlots() {
		return plots;
	}
	
	public List<Player> getSoloPlayers() {
		List<Player> temp = new ArrayList<>();
		for(Player p : Bukkit.getOnlinePlayers()) {
			if(TeamManager.getTeam(p) == null) {
				temp.add(p);
			}
		}
		return temp;
	}

	public int getRealPlayersCount() {
		return TeamManager.countSoloTeams() + TeamManager.countDuoTeams();
	}
	
	public int getOnline() {
		int two = TeamManager.countDuoTeams();
		int solo = Bukkit.getOnlinePlayers().size() - (two * 2);
		return solo + two;
	}

	public static int getDispoPlayers() {
		int two = TeamManager.countDuoTeams();
		int solo = Bukkit.getOnlinePlayers().size() - (two * 2);
		return solo;
	}

	private HashMap<Team, Integer> TEAM_POSITION = new HashMap<>();
	
	public int getTeamPosition(Team team) {
		if(TEAM_POSITION.get(team) != null) return TEAM_POSITION.get(team);
		
		for(int pos : TEAMS_TO_TP.keySet()) {
			if(TEAMS_TO_TP.get(pos).equals(team)) {
				TEAM_POSITION.put(team, pos);
			}
		}
		return TEAM_POSITION.get(team);
	}
	
	
}
