package fr.badblock.bukkit.games.buildcontest.tools;

import java.util.ArrayList;

import org.bukkit.inventory.ItemStack;

import fr.badblock.gameapi.players.BadblockPlayer;

public class Tools {

	public static ArrayList<Tool> tools = new ArrayList<>();
	
	public static Tool registerTool(Tool tool) {
		tools.add(tool);
		return tool;
	}
	
	public static Tool getTool(ItemStack from, BadblockPlayer p) {
		for(Tool tool : tools) {
			if(tool.getStack(p).isSimilar(from)) {
				return tool;
			}
		}
		return null;
	}
	
}
