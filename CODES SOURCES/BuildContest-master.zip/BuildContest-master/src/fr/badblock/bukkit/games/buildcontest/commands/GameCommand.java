package fr.badblock.bukkit.games.buildcontest.commands;

import java.io.File;
import java.util.ArrayList;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import fr.badblock.bukkit.games.buildcontest.BuildContestPlugin;
import fr.badblock.bukkit.games.buildcontest.inventory.InventoryManager;
import fr.badblock.bukkit.games.buildcontest.inventory.guis.BuildToolsInventory;
import fr.badblock.bukkit.games.buildcontest.runnables.StartRunnable;
import fr.badblock.bukkit.games.buildcontest.utils.ArchiJsonUtils;
import fr.badblock.bukkit.games.buildcontest.utils.ArchiUtils;
import fr.badblock.gameapi.GameAPI;
import fr.badblock.gameapi.command.AbstractCommand;
import fr.badblock.gameapi.players.BadblockPlayer;
import fr.badblock.gameapi.players.BadblockPlayer.GamePermission;
import fr.badblock.gameapi.utils.general.JsonUtils;
import fr.badblock.gameapi.utils.i18n.TranslatableString;
import fr.badblock.gameapi.utils.selections.CuboidSelection;
import fr.badblock.gameapi.utils.threading.TaskManager;

public class GameCommand extends AbstractCommand {
	public GameCommand() {
		super("game", new TranslatableString("commands.gbuildcontest.usage"), GamePermission.ADMIN, GamePermission.ADMIN, GamePermission.ADMIN);
		allowConsole(false);
	}

	@Override
	public boolean executeCommand(CommandSender sender, String[] args) {
		if(args.length == 0) {
			return false;
		}
		
		BadblockPlayer player = (BadblockPlayer) sender;
		BuildContestPlugin plug = BuildContestPlugin.getInstance();

		int len = args.length;
		
		switch(args[0].toLowerCase()){
			case "start":
				String msg = "commands.gbuildcontest.start";
				
				if(!StartRunnable.started()){
					StartRunnable.startGame();
				} else msg += "-fail";
				
				player.sendTranslatedMessage(msg);
			break;
			case "reload":
				for(Player pl : Bukkit.getOnlinePlayers()){
					BadblockPlayer bplayer = (BadblockPlayer) pl;
					bplayer.sendPlayer(BuildContestPlugin.getInstance().getConfiguration().fallbackServer);
				}
				TaskManager.runTaskLater(new Runnable() {
					
					@Override
					public void run() {
						Bukkit.shutdown();
						
					}
				}, 10);
				break;
			case "force":
				StartRunnable.time = 15;
				break;
			case "cancel":
				if(StartRunnable.started()) {
					StartRunnable.cancelStart();
				}
				break;
			case "stop":
				msg = "commands.gbuildcontest.stop";
				
				if(StartRunnable.started()){
					StartRunnable.stopGame();
				} else msg += "-fail";
				
				player.sendTranslatedMessage(msg);
			break;
			case "minigame":
				
				String what = args[1];
				if(what == null) return false;
				
				if(what.equalsIgnoreCase("setarea")) {
					CuboidSelection sel = player.getSelection();

					if(sel == null || sel.getFirstBound() == null || sel.getSecondBound() == null) return false;
					Location loc1 = sel.getFirstBound().bukkit(player.getWorld());
					Location loc2 = sel.getSecondBound().bukkit(player.getWorld());
					
					JsonObject toSave = ArchiJsonUtils.addMinigameLoc(loc1);
					JsonUtils.save(BuildContestPlugin.MINIGAME, toSave, true);
					toSave = ArchiJsonUtils.addMinigameLoc(loc2);
					JsonUtils.save(BuildContestPlugin.MINIGAME, toSave, true);
					
					player.sendMessage("�7L'�bar�ne�7 a �t� sauvegard�e !");
				
					
				}
				
				break;
			case "maxPlayers":
				if(args.length != 2)
					return false;
				
				plug.getConfiguration().maxPlayers = Integer.parseInt(args[1]);
				
				player.sendTranslatedMessage("commands.gbuildcontest.modifycount");
			break;

//			case "reload":
//				BuildContestPlugin.getInstance().reload();
//				break;
				
			case "inv":
				BuildToolsInventory gui = new BuildToolsInventory(player).buildToolGui();
				InventoryManager.add(gui);
				gui.open();
				break;
				
			case "plots":
				if(len == 3) {
					// plots add XXXXX || plots remove XXXXX || plots list <nom_de_la_map>
					
					if(args[1].equalsIgnoreCase("list")) {
						String map_name = args[2];
						
						if(!plug.maps.contains(map_name)) {
							player.sendTranslatedMessage("commands.gbuildcontest.errors.mapnotexist", map_name);
							return true;
						} else {
							
							ArrayList<Location> plots = ArchiJsonUtils.loadPlotsFromMap(map_name);
							int i = 1;
							
							if(plots == null || plots.size() == 0) {
								player.sendMessage("�cAucun plot pour la map " + map_name);
								return true;
							}
							
							player.sendMessage("�7Liste des plots pour la map �b" + map_name + "�7[centres] :");
							for(Location plot : plots) {
								int x = plot.getBlockX();
								int y = plot.getBlockY();
								int z = plot.getBlockZ();
								float yaw = plot.getYaw();
								float pitch = plot.getPitch();
								ArchiUtils.sendClickableMessage(player, "�b> �7Loc �b#" + i + "�7 (" + x + ", " + y + ", " + z + ")", "/tp " + x + " " + y + " " + z + " " + yaw + " " + pitch, "Cliquez pour vous tp");
								i++;
							}
						}
					} else if(args[1].equalsIgnoreCase("add")) {
						String map_name = args[2];
						
						File mapsFile = BuildContestPlugin.MAP;
						File mapFile = new File(mapsFile, map_name + ".json");
						
						if(!plug.maps.contains(map_name)) {
							player.sendTranslatedMessage("commands.gbuildcontest.errors.mapnotexist", map_name);
							return true;
						}
						
						CuboidSelection selection = player.getSelection();
						if(selection == null) {
							player.sendTranslatedMessage("commands.gbuildcontest.errors.makeselectionfirst");
							return true;
						}
						if(selection.getFirstBound() != null && selection.getSecondBound() != null) {
							
							Location first = selection.getFirstBound().bukkit(Bukkit.getWorld(selection.getWorldName()));
							Location second = selection.getSecondBound().bukkit(Bukkit.getWorld(selection.getWorldName()));
							
							int x1 = first.getBlockX();
							int x2 = second.getBlockX();
							
							int z1 = first.getBlockZ();
							int z2 = second.getBlockZ();
							
							//Calcul du centre du plot
							
							double centerX = (x1 + x2) / 2;
							double centerZ = (z1 + z2) / 2;
							
							int y = first.getBlockY();
							
							Location centerPlot = new Location(Bukkit.getWorld(selection.getWorldName()), centerX, y, centerZ, 90.0f, -90.0f);
							JsonObject array = ArchiJsonUtils.addPlotForMap(map_name, centerPlot);
							
							JsonUtils.save(mapFile, array, true);
							
							player.sendMessage("�7Le plot �b#" + ArchiJsonUtils.loadPlotsFromMap(map_name).size() + "�7 (" + centerX + ", " + y + ", " + centerZ + ") a �t� cr�e pour la map �b" + map_name + "�7 !");
							
						} else {
							player.sendTranslatedMessage("commands.gbuildcontest.errors.makeselectionfirst");
							return true;
						}
						
					}
					
				} else {
					return false;
				}
				
				break;
			
			case "map":
				
				// map add <nom_de_la_map>
				if(args[1].equalsIgnoreCase("add")) {
					String name = args[2];
					
					File toSave = new File(plug.getDataFolder(), BuildContestPlugin.VOTES_CONFIG);
					File mapsFile = BuildContestPlugin.MAP;
					
					File toCreate = new File(mapsFile, name + ".json");
					
					if(toCreate.exists()) {
						player.sendTranslatedMessage("commands.gbuildcontest.errors.mapexist", name);
						return true;
					} else {
						try {
							toCreate.createNewFile();
						} catch(Exception e) {
							e.printStackTrace();
						}
						
						JsonObject obj = new JsonObject();
						obj.addProperty("internalName", name);
						obj.addProperty("displayName", name + "_displayName");
						
						JsonArray array = JsonUtils.loadArray(toSave);
						array.add(obj);
						
						JsonUtils.save(toSave, array, true);
						
						JsonObject obj2 = new JsonObject();
						// spectatorLocation, areaLocation, yMinLimit, sideLength, floorY
						
						JsonObject specLoc = new JsonObject();
						specLoc.addProperty("world", "world");
						specLoc.addProperty("x", 0.0);
						specLoc.addProperty("y", 172.0);
						specLoc.addProperty("z", 0.0);
						specLoc.addProperty("yaw", -90.0);
						specLoc.addProperty("pitch", 90.0);
						
						
						
						obj2.add("spectatorLocation", GameAPI.getPrettyGson().toJsonTree(specLoc));
						obj2.add("areaLocations", new JsonArray());
						obj2.addProperty("yMinLimit", 0);
						obj2.addProperty("sideLength", 35);
						obj2.addProperty("floorY", 99);
						
						JsonUtils.save(toCreate, obj2, true);
						
						
						player.sendMessage("Fichiers cr�es !");
						
					}
				} else if(args[1].equalsIgnoreCase("list")) {
					player.sendMessage("�7Liste des maps :");
					for(String map : plug.maps) {
						player.sendMessage("�b> �7" + map);
					}
				}
				
				break;
			
			default: return false;
		}
		
		return true;
	}
}