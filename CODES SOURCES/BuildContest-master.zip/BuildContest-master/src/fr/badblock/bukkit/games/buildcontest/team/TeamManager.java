package fr.badblock.bukkit.games.buildcontest.team;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.DyeColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;

import fr.badblock.bukkit.games.buildcontest.BuildContestPlugin;
import fr.badblock.gameapi.GameAPI;
import fr.badblock.gameapi.players.BadblockPlayer;
import fr.badblock.gameapi.utils.i18n.TranslatableString;

public class TeamManager {

	private static List<Team> teams = new ArrayList<>();
	
	public static void addTeam(Player p1, Player p2) {
		if(!InvitationManager.can) return;
		Team newTeam = new Team(p1, p2);
		teams.add(newTeam);
		updateTeamItem(newTeam);
	}
	
	public static Team getTeam(Player in) {
		for(Team team : teams) {
			if(team.getPlayers().contains(in)) 
				return team;
		}
		return null;
	}
	
	public static void updateTeamItem(Team t) {
		
		BadblockPlayer first = (BadblockPlayer) t.getPlayers().get(0);
		BadblockPlayer second = (BadblockPlayer) t.getPlayers().get(1);
		
		GameAPI.getAPI().createItemStackFactory().type(Material.INK_SACK)
				.durability((short) 10)
				.displayName(BuildContestPlugin.getInstance().getState("buildcontest.inventory.joinitems.allywith.displayName", 2, second.getName()))
				.lore(new TranslatableString("buildcontest.inventory.joinitems.allywith.description", BuildContestPlugin.getInstance().getState("buildcontest.inventory.joinitems.allywith.states", 2, second.getName())))
				.doWithI18n(second.getPlayerData().getLocale())
				.updateItemStack(1, first.getInventory().getItem(1));
		
		//ItemStackUtils.changeDisplay(first.getInventory().getItem(1), "&7En team avec &b" + second.getName() + " &7!", GameAPI.getAPI().getI18n().get("buildcontest.inventory.joinitems.allywith.description", BuildContestPlugin.getInstance().getState("buildcontest.inventory.joinitems.allywith.states", 1, second.getName())));
		
		GameAPI.getAPI().createItemStackFactory().type(Material.INK_SACK)
				.durability((short) 10)
				.displayName(BuildContestPlugin.getInstance().getState("buildcontest.inventory.joinitems.allywith.displayName", 2, first.getName()))
				.lore(new TranslatableString("buildcontest.inventory.joinitems.allywith.description", BuildContestPlugin.getInstance().getState("buildcontest.inventory.joinitems.allywith.states", 2, first.getName())))
				.doWithI18n(second.getPlayerData().getLocale())
				.updateItemStack(1, second.getInventory().getItem(1));
		
		
		//ItemStackUtils.changeDisplay(second.getInventory().getItem(1), "&7En team avec &b" + first.getName() + " &7!", GameAPI.getAPI().getI18n().get("buildcontest.inventory.joinitems.allywith.description", BuildContestPlugin.getInstance().getState("buildcontest.inventory.joinitems.allywith.states", 1, first.getName())));
		
	}
	
	@SuppressWarnings("deprecation")
	public static void updateNoTeamItem(Player player) {
		BadblockPlayer p = (BadblockPlayer) player;
		GameAPI.getAPI().createItemStackFactory().type(Material.INK_SACK)
				.durability((short) DyeColor.SILVER.getData())
				.displayName(BuildContestPlugin.getInstance().getState("buildcontest.inventory.joinitems.allywith.displayName", 0))
				.lore(new TranslatableString("buildcontest.inventory.joinitems.allywith.description", BuildContestPlugin.getInstance().getState("buildcontest.inventory.joinitems.allywith.states", 0)))
				.doWithI18n(p.getPlayerData().getLocale())
				.updateItemStack(1, p.getInventory().getItem(1));
		//p.getInventory().setItem(1, noteam);
	}

	public static void removeTeam(Team team) {
		teams.remove(team);
	}

	public static void addSoloTeam(Player player) {
		teams.add(new Team(player));
	}

	public static List<Team> getTeams() {
		return teams;
	}

	public static int countSoloTeams() {
		int count = 0;
		for(Team team : teams) {
			if(team.getPlayers().size() == 1) {
				count++;
			}
		}
		return count;
	}
	
	public static int countDuoTeams() {
		int count = 0;
		for(Team team : teams) {
			if(team.getPlayers().size() == 2) {
				count++;
			}
		}
		return count;
	}
	
}
