package fr.badblock.bukkit.games.buildcontest.tools;

import org.bukkit.Material;

import fr.badblock.bukkit.games.buildcontest.BuildContestPlugin;
import fr.badblock.bukkit.games.buildcontest.inventory.InventoryManager;
import fr.badblock.bukkit.games.buildcontest.plots.Plot;
import fr.badblock.bukkit.games.buildcontest.team.TeamManager;
import fr.badblock.bukkit.games.buildcontest.utils.ArchiUtils;
import fr.badblock.gameapi.players.BadblockPlayer;

public class ToolList {

	public static Tool RESET_PLOT = Tools.registerTool(new Tool(ArchiUtils.createItem(Material.BARRIER, 1, 0, "buildcontest.tools.resetplot.displayname", "buildcontest.tools.resetplot.description"), new ToolAction() {
		
		@Override
		public void onClick() {
			Plot plot = BuildContestPlugin.getInstance().getPlot(TeamManager.getTeam(getPlayer()));
			plot.reset();
			((BadblockPlayer) getPlayer()).sendTranslatedActionBar("buildcontest.messages.plotclear");
			getPlayer().closeInventory();
		}
		
	}));
	
	public static Tool OPEN_TOOLS = Tools.registerTool(new Tool(ArchiUtils.createItem(Material.REDSTONE_TORCH_ON, 1, 0, "buildcontest.tools.buildtools.displayname", "buildcontest.tools.buildtools.description"), new ToolAction() {
		
		@Override
		public void onClick() {
			InventoryManager.openBuildToolsGui(getPlayer());		
		}
		
	}));
	
}
