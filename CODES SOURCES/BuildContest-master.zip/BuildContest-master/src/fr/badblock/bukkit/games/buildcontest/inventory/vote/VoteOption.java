package fr.badblock.bukkit.games.buildcontest.inventory.vote;

import java.io.File;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

import fr.badblock.bukkit.games.buildcontest.BuildContestPlugin;
import fr.badblock.bukkit.games.buildcontest.inventory.OptionsConfiguration;
import fr.badblock.gameapi.GameAPI;
import fr.badblock.gameapi.utils.general.JsonUtils;
import lombok.Getter;
import lombok.Setter;

public class VoteOption {
	
	public static List<VoteOption> options = new ArrayList<>();
	
	private static String OPTIONS = "vote_options.json";
	private static OptionsConfiguration configuration;
	
	@Getter@Setter
	private ItemStack stack;
	@Getter@Setter
	private String name, desc;
	@Getter@Setter
	private int points;
	
	public VoteOption(String name, String desc, ItemStack stack, int points) {
		this.name = name;
		this.desc = desc;
		this.stack = stack;
		this.points = points;
	}
	
	public static OptionsConfiguration get() {
		return configuration;
	}
	
	public static void loadFromConfig() {
		File configFile    = new File(BuildContestPlugin.getInstance().getDataFolder(), OPTIONS);
		configuration = JsonUtils.load(configFile, OptionsConfiguration.class);
		
		String path = "buildcontest.voteoptions";
		String[] indexs = configuration.names;
		
		String[] names = new String[indexs.length];
		String[] descs = new String[indexs.length];
		
		int[] totals = configuration.totals;
		
		int i = 0;
		int firstRandom = -1;
		ArrayList<String> total = new ArrayList<>();
		for(String index : indexs) {
			total.clear();
			String votePath = path + "." + index; //buildcontest.voteoptions.bad.1.name.json
			for(int t = 0; t < totals[i]; t++) {
				String name = GameAPI.getAPI().getI18n().get(votePath + "." + (t+1) + ".name")[0];
				total.add(name);
			}
			if(firstRandom < 0) {
				firstRandom = new SecureRandom().nextInt(total.size());
			}
			
			names[i] = total.get(firstRandom);
			descs[i] = votePath + ".description";
			i++;
		}
		
		Material mat = configuration.view;
		byte[] datas = configuration.datas;
		
		int[] points = configuration.points;
		
		options.clear();
		
		for(int index = 0; index < configuration.names.length; index++) {
			ItemStack newStack = new ItemStack(mat, 1, datas[index]);
			options.add(new VoteOption(names[index], descs[index], newStack, points[index]));
		}
		
		JsonUtils.save(configFile, configuration, true);
	}
	
//	public void loadFromConfig() {
//		File configFile    = new File(BuildContestPlugin.getInstance().getDataFolder(), OPTIONS);
//		this.configuration = JsonUtils.load(configFile, OptionsConfiguration.class);
//		
//		String[] names = configuration.names;
//		Material mat = configuration.view;
//		byte[] datas = configuration.datas;
//		
//		int[] points = configuration.points;
//		
//		for(int index = 0; index < values().length; index++) {
//			values()[index].name = names[index];
//			ItemStack newStack = new ItemStack(mat, points[index], datas[index]);
//			values()[index].stack = newStack;
//			values()[index].points = points[index];
//		}
//		
//		JsonUtils.save(configFile, configuration, true);
//	}
	
}
