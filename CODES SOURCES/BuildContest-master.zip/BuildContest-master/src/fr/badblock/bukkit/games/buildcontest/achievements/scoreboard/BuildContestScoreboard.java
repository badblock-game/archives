package fr.badblock.bukkit.games.buildcontest.achievements.scoreboard;

import fr.badblock.bukkit.games.buildcontest.BuildContestPlugin;
import fr.badblock.bukkit.games.buildcontest.BuildStage;
import fr.badblock.bukkit.games.buildcontest.runnables.GameRunnable;
import fr.badblock.bukkit.games.buildcontest.runnables.StartRunnable;
import fr.badblock.gameapi.GameAPI;
import fr.badblock.gameapi.players.BadblockPlayer;
import fr.badblock.gameapi.players.scoreboard.BadblockScoreboardGenerator;
import fr.badblock.gameapi.players.scoreboard.CustomObjective;

public class BuildContestScoreboard extends BadblockScoreboardGenerator {
	
	private CustomObjective objective;
	private BadblockPlayer  player;
	
	public static final String WINS 	  = "wins",
			LOOSES = "looses";

	public BuildContestScoreboard(BadblockPlayer player){
		this.objective = GameAPI.getAPI().buildCustomObjective("buildcontest");
		this.player    = player;

		objective.showObjective(player);
		objective.setDisplayName("&b" + GameAPI.getGameName());
		objective.setGenerator(this);

		objective.generate();
	}
	
	@Override
	public void generate(){
		objective.changeLine(7,  "&8&m----------------------");
		objective.changeLine(6, "");
		objective.changeLine(5, i18n("buildcontest.inventory.themeKey"));
		objective.changeLine(4, i18n("buildcontest.inventory.themes." + BuildContestPlugin.getInstance().getTheme()));
		objective.changeLine(3, "");
		objective.changeLine(2,  "&8&m----------------------");
		doBadblockFooter(objective);
	}
	
	public void update() {	
		if(BuildContestPlugin.getInstance().getBuildStage() == BuildStage.BUILD) {
			int timeInSeconds = StartRunnable.gameTask.getTime();
			int minutes = timeInSeconds / 60;
			int seconds = timeInSeconds % 60;
			String finalTime = (minutes > 9 ? minutes : "0" + minutes) + "m" + (seconds > 9 ? seconds : "0" + seconds);
			objective.setDisplayName("&b" + GameAPI.getGameName() + " - " + finalTime);
		} else if(BuildContestPlugin.getInstance().getBuildStage() == BuildStage.VOTE) {
			
			int time = GameRunnable.voteRunnable.time;
			
			objective.setDisplayName("&b" + GameAPI.getGameName() + " - " + time + "s");
			
			objective.changeLine(10,  "&8&m----------------------");
			objective.changeLine(9, "");
			objective.changeLine(8, i18n("buildcontest.inventory.themeKey"));
			objective.changeLine(7, i18n("buildcontest.inventory.themes." + BuildContestPlugin.getInstance().getTheme()));
			objective.changeLine(6, "");
			objective.changeLine(5, i18n("buildcontest.inventory.plotOfKey"));
			objective.changeLine(4, "�b" + (BuildContestPlugin.getInstance().getCurrent() != null ? BuildContestPlugin.getInstance().getCurrent().getName() : "..."));
			objective.changeLine(3, "");
			objective.changeLine(2,  "&8&m----------------------");
			
		} else {
			objective.setDisplayName("&b" + GameAPI.getGameName() + " - " + i18n("buildcontest.inventory.finishedKey"));
			
			objective.changeLine(10,  "&8&m----------------------");
			objective.changeLine(9, "");
			objective.changeLine(8, i18n("buildcontest.inventory.themeKey"));
			objective.changeLine(7, i18n("buildcontest.inventory.themes." + BuildContestPlugin.getInstance().getTheme()));
			objective.changeLine(6, "");
			objective.changeLine(5, i18n("buildcontest.inventory.winnerKey"));
			objective.changeLine(4, "�b" + (BuildContestPlugin.getInstance().getWinner() != null ? BuildContestPlugin.getInstance().getWinner().getName() : "..."));
			objective.changeLine(3, "");
			objective.changeLine(2,  "&8&m----------------------");
		}
	}

	private String i18n(String key, Object... args){
		return GameAPI.i18n().get(player.getPlayerData().getLocale(), key, args)[0];
	}
}
