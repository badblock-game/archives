package fr.badblock.bukkit.games.buildcontest.utils;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.util.BlockIterator;

import fr.badblock.bukkit.games.buildcontest.inventory.gui.AbstractInventoryGUI;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.ComponentBuilder;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.ClickEvent.Action;

public class ArchiUtils {

	public static <T extends AbstractInventoryGUI> ArrayList<T> toArrayList(List<T> list) {
		ArrayList<T> newList = new ArrayList<>();
		for(T elem : list) {
			newList.add(elem);
		}
		return newList;
	}

	public static ItemStack createItem(Material mat, int amount, int data, String title, String... lore) {
		ItemStack newStack = new ItemStack(mat, amount, (byte) data);
		ItemMeta meta = newStack.getItemMeta();
		meta.setDisplayName(title);
		meta.setLore(Arrays.asList(lore));
		newStack.setItemMeta(meta);
		return newStack;
	}

	public static Location getRandomLoc(int blockY, List<Block> blocks) {
		ArrayList<Location> allLocs = new ArrayList<>();
		for(Block b : blocks) {
			if(b.getLocation().getBlockY() == blockY) {
				allLocs.add(b.getLocation());
			}
		}
		return allLocs.get(new SecureRandom().nextInt(allLocs.size()));
	}

	public static List<String> getList(Set<String> set) {
		List<String> temp = new ArrayList<>();
		set.forEach(string -> {
			temp.add(string);
		});
		return temp;
	}
	
	public static void sendClickableMessage(Player p, String message, String command, String onhover) {
		ComponentBuilder builder = new ComponentBuilder(message);
		builder.event(new ClickEvent(Action.RUN_COMMAND, command));
		builder.event(new HoverEvent(net.md_5.bungee.api.chat.HoverEvent.Action.SHOW_TEXT, new ComponentBuilder(onhover).create()));
		p.spigot().sendMessage(builder.create());
	}
	
	public static void sendComponentMessage(Player p, ComponentMessage... message) {
		
	}

	public static List<Location> getLocInPlayerLine(Player p) {
		
		HashSet<Material> transparent = new HashSet<>();
		transparent.add(Material.BARRIER);
		
		List<Location> temp = new ArrayList<>();
		
		BlockIterator it = new BlockIterator(p.getWorld(), p.getLocation().toVector(), p.getEyeLocation().getDirection(), 5, 5);
		while(it.hasNext()) {
			Block b = it.next();
			//System.out.println("adding block " + b.getType());
			temp.add(b.getLocation());
		}
		
//		List<Block> blocks = p.getLineOfSight(transparent, 5);
//		List<Location> locs = new ArrayList<>();
//		System.out.println("There is " + blocks.size()  + " locs !");
//		blocks.forEach(block -> {
//			locs.add(block.getLocation());
//			System.out.println(block.getType());
//		});
		
		return temp;
	}
	
	public static List<Block> getBlocks(Location loc1, Location loc2) {
		
		List<Block> blocks = new ArrayList<>();
		
		int topBlockX = (loc1.getBlockX() < loc2.getBlockX() ? loc2.getBlockX() : loc1.getBlockX());
        int bottomBlockX = (loc1.getBlockX() > loc2.getBlockX() ? loc2.getBlockX() : loc1.getBlockX());
 
        int topBlockY = (loc1.getBlockY() < loc2.getBlockY() ? loc2.getBlockY() : loc1.getBlockY());
        int bottomBlockY = (loc1.getBlockY() > loc2.getBlockY() ? loc2.getBlockY() : loc1.getBlockY());
 
        int topBlockZ = (loc1.getBlockZ() < loc2.getBlockZ() ? loc2.getBlockZ() : loc1.getBlockZ());
        int bottomBlockZ = (loc1.getBlockZ() > loc2.getBlockZ() ? loc2.getBlockZ() : loc1.getBlockZ());
 
        for(int x = bottomBlockX; x <= topBlockX; x++)
        {
            for(int z = bottomBlockZ; z <= topBlockZ; z++)
            {
                for(int y = bottomBlockY; y <= topBlockY; y++)
                {
                    blocks.add(loc1.getWorld().getBlockAt(new Location(loc1.getWorld(), x, y, z)));
                }
            }
        }
        
        return blocks;
	}
	
	public static List<Block> getRealBlocks(Location loc0, Location loc2) {
		
		Location loc1 = loc0.clone().add(0, 1, 0);
		
		List<Block> blocks = new ArrayList<>();
		
		int topBlockX = (loc1.getBlockX() < loc2.getBlockX() ? loc2.getBlockX() : loc1.getBlockX());
        int bottomBlockX = (loc1.getBlockX() > loc2.getBlockX() ? loc2.getBlockX() : loc1.getBlockX());
 
        int topBlockY = (loc1.getBlockY() < loc2.getBlockY() ? loc2.getBlockY() : loc1.getBlockY());
        int bottomBlockY = (loc1.getBlockY() > loc2.getBlockY() ? loc2.getBlockY() : loc1.getBlockY());
 
        int topBlockZ = (loc1.getBlockZ() < loc2.getBlockZ() ? loc2.getBlockZ() : loc1.getBlockZ());
        int bottomBlockZ = (loc1.getBlockZ() > loc2.getBlockZ() ? loc2.getBlockZ() : loc1.getBlockZ());
 
        for(int x = bottomBlockX; x <= topBlockX; x++)
        {
            for(int z = bottomBlockZ; z <= topBlockZ; z++)
            {
                for(int y = bottomBlockY; y <= topBlockY; y++)
                {
                    blocks.add(loc1.getWorld().getBlockAt(new Location(loc1.getWorld(), x, y, z)));
                }
            }
        }
        
        return blocks;
	}
	
	public static List<Block> getBlocks(Location loc1, Location loc2, int y) {
		
		List<Block> blocks = new ArrayList<>();
		
		int topBlockX = (loc1.getBlockX() < loc2.getBlockX() ? loc2.getBlockX() : loc1.getBlockX());
        int bottomBlockX = (loc1.getBlockX() > loc2.getBlockX() ? loc2.getBlockX() : loc1.getBlockX());
 
        int topBlockZ = (loc1.getBlockZ() < loc2.getBlockZ() ? loc2.getBlockZ() : loc1.getBlockZ());
        int bottomBlockZ = (loc1.getBlockZ() > loc2.getBlockZ() ? loc2.getBlockZ() : loc1.getBlockZ());
 
        for(int x = bottomBlockX; x <= topBlockX; x++)
        {
            for(int z = bottomBlockZ; z <= topBlockZ; z++)
            {
                blocks.add(loc1.getWorld().getBlockAt(new Location(loc1.getWorld(), x, y, z)));
            }
        }
        
        return blocks;
	}
}
