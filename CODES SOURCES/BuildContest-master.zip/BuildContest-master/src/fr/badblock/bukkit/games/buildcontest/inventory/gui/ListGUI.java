package fr.badblock.bukkit.games.buildcontest.inventory.gui;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryView;
import org.bukkit.inventory.ItemStack;

import fr.badblock.bukkit.games.buildcontest.team.Team;

public class ListGUI extends SharedGUI {

	public int pages = 1;
	public int currentPage = 1;
	public int itemPerPage = 45;
	
	public ListFormat format;
	
	public ItemStack[][] itemsPerPage;
	public List<ItemStack> total = new ArrayList<>();
	
	public ListGUI(Team team) {
		super(team);
	}
	
	public ListGUI buildInv(String name, List<ItemStack> list) {
		Inventory current = Bukkit.createInventory(null, 54, name);
		this.build(current, LayoutGui.LAYOUT_ALL_BOTTOM);
		
		setList(list);
		
		return this;
	}
	
	public void setList(List<ItemStack> list) {
		total = list;
		balanceItems();
		updateInv();
	}
	
	public void removeFromList(ItemStack stack) {
		total.remove(stack);
		balanceItems();
		updateInv();
	}
	
	public void setListFormat(ListFormat format) {
		this.format = format;		
	}
	
	private void updateInv() {
		GuiItem prev = LayoutGui.LAYOUT_ALL_BOTTOM.items[0];
		GuiItem next = LayoutGui.LAYOUT_ALL_BOTTOM.items[1];
		
		int pPos = ((prev.getY()-1) * 9) + (prev.getX()-1);
		int nPos = ((next.getY()-1) * 9) + (next.getX()-1);
		
		if(pages == 1) {
			getCurrent().setItem(nPos, LayoutGui.separator);
			getCurrent().setItem(pPos, LayoutGui.separator);
		} else if(pages > 1) {
			if(currentPage == 1) {
				getCurrent().setItem(pPos, LayoutGui.separator);
				getCurrent().setItem(nPos, next.getStack());
			} else if(currentPage > 1 && currentPage < pages) {
				getCurrent().setItem(pPos, prev.getStack());
				getCurrent().setItem(nPos, next.getStack());
			} else if(currentPage == pages) {
				getCurrent().setItem(pPos, prev.getStack());
				getCurrent().setItem(nPos, LayoutGui.separator);
			}
		}
		
	}
	
	protected void balanceItems() {
		pages = (int) Math.ceil(total.size() / (double) itemPerPage);
		if(total.size() == 0) pages = 1;
		itemsPerPage = new ItemStack[pages][];
		
		if(pages > 1) {
			for(int now = 0; now < pages; now++) {
				int size = (total.size() > itemPerPage ? (total.size() - (now * itemPerPage)) : total.size());
				itemsPerPage[now] = new ItemStack[size+1];
				for(int index = 0; index < size; index++) {
					itemsPerPage[now][index] = total.get((now * itemPerPage) + index);
				}
			}
		} else {
			int size = total.size();
			itemsPerPage[0] = new ItemStack[size];
			for(int index = 0; index < size; index++) {
				itemsPerPage[0][index] = total.get(index);
			}
		}
	}
	
	@Override
	public void open() {
		super.open();
		updateCurrentPage();
	}
	
	public void updateCurrentPage() {
		clearGui();
		ItemStack[] items = itemsPerPage[currentPage-1];
		if(items != null && items.length > 0) {
			int index = 0;
			for(ItemStack item : items) {
				if(item == null) break;
				else { //TODO:
					if(format == ListFormat.NOT_STACKABLE)
						getCurrent().setItem(index, item);
					else getCurrent().addItem(item);
				}
				index++;
			}
		}
		updateInv();
	}
	
	@Override
	public void onItemClick(ItemStack stack, InventoryAction action, ClickType type, ItemStack cursor, int slot, InventoryView view) {
		
	}
	
	
	
	public boolean hasNext() {
		return currentPage < pages-1;
	}
	
	public boolean hasPrev() {
		return currentPage > 1;
	}

	@Override
	public void onItemClick(Player p, ItemStack stack, InventoryAction action, ClickType click, ItemStack cursor,
			int slot, InventoryView view) {
		if(isNext(stack)) {
			if(!hasNext())
				return;
			
			currentPage++;
			updateCurrentPage();
		} else if(isPrev(stack)) {
			if(!hasPrev())
				return;

			currentPage--;
			updateCurrentPage();
		} else if(isReturn(stack)) {
			displayBack(p);
		}
		
	}

}
