package fr.badblock.bukkit.games.buildcontest.achievements;

import fr.badblock.gameapi.achievements.AchievementList;
import fr.badblock.gameapi.achievements.PlayerAchievement;
import fr.badblock.gameapi.run.BadblockGame;

public class BuildContestAchievementList {

	public static AchievementList instance = new AchievementList(BadblockGame.BUILDCONTEST);
	
	/* GAGNER AUTANT DE PARTIES */
	
	public static final PlayerAchievement BC_WIN_1  = instance.addAchievement(new PlayerAchievement("buildcontest_win_1", 10, 2, 1));
	public static final PlayerAchievement BC_WIN_2  = instance.addAchievement(new PlayerAchievement("buildcontest_win_2", 50, 25, 10));
	public static final PlayerAchievement BC_WIN_3  = instance.addAchievement(new PlayerAchievement("buildcontest_win_3", 250, 100, 100));
	public static final PlayerAchievement BC_WIN_4  = instance.addAchievement(new PlayerAchievement("buildcontest_win_4", 500, 250, 1000));
	
	/* JOUER AUTANT DE PARTIES */
	
	public static final PlayerAchievement BC_PARTICIPATE_1  = instance.addAchievement(new PlayerAchievement("buildcontest_participate_1", 10, 2, 10));
	public static final PlayerAchievement BC_PARTICIPATE_2  = instance.addAchievement(new PlayerAchievement("buildcontest_participate_2", 50, 25, 100));
	public static final PlayerAchievement BC_PARTICIPATE_3  = instance.addAchievement(new PlayerAchievement("buildcontest_participate_3", 250, 100, 1000));
	public static final PlayerAchievement BC_PARTICIPATE_4  = instance.addAchievement(new PlayerAchievement("buildcontest_participate_4", 500, 250, 10000));
	
	/* FINIR X EME */
	
	public static final PlayerAchievement FINISH_FIRST = instance.addAchievement(new PlayerAchievement("buildcontest_finish-1", 200, 400, 1, true));
	public static final PlayerAchievement FINISH_SECOND = instance.addAchievement(new PlayerAchievement("buildcontest_finish-2", 150, 300, 1, true));
	public static final PlayerAchievement FINISH_THIRD = instance.addAchievement(new PlayerAchievement("buildcontest_finish-3", 100, 250, 1, true));
	public static final PlayerAchievement FINISH_FOURTH = instance.addAchievement(new PlayerAchievement("buildcontest_finish-4", 75, 200, 1, true));
	public static final PlayerAchievement FINISH_FIFTH = instance.addAchievement(new PlayerAchievement("buildcontest_finish-5", 50, 150, 1, true));	
	
}
