package fr.badblock.bukkit.games.pvpbox.listeners;

import org.bukkit.Chunk;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerTeleportEvent;

public class PlayerTeleportListener implements Listener {
	
	@EventHandler
	public void onPlayerTeleport(PlayerTeleportEvent event) {
		Player player = event.getPlayer();
		Chunk chunk = event.getTo().getChunk();
		if (chunk == null) return;
		if (chunk.isLoaded()) return;
		chunk.load(true);
	}
	
}
