package fr.badblock.bukkit.games.pvpbox;

import java.io.File;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.craftbukkit.v1_8_R3.inventory.CraftItemStack;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffectType;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import fr.badblock.bukkit.games.pvpbox.commands.BBoxCommand;
import fr.badblock.bukkit.games.pvpbox.commands.CReportCommand;
import fr.badblock.bukkit.games.pvpbox.commands.CreateKitCommand;
import fr.badblock.bukkit.games.pvpbox.commands.DuelCommand;
import fr.badblock.bukkit.games.pvpbox.commands.FeedCommand;
import fr.badblock.bukkit.games.pvpbox.commands.FlyCommand;
import fr.badblock.bukkit.games.pvpbox.commands.GmCommand;
import fr.badblock.bukkit.games.pvpbox.commands.GodmodeCommand;
import fr.badblock.bukkit.games.pvpbox.commands.HealCommand;
import fr.badblock.bukkit.games.pvpbox.commands.KickAllCommand;
import fr.badblock.bukkit.games.pvpbox.commands.SlotsCommand;
import fr.badblock.bukkit.games.pvpbox.commands.SpawnCommand;
import fr.badblock.bukkit.games.pvpbox.commands.TeamCommand;
import fr.badblock.bukkit.games.pvpbox.commands.VanishCommand;
import fr.badblock.bukkit.games.pvpbox.kits.Kit;
import fr.badblock.bukkit.games.pvpbox.kits.KitItem;
import fr.badblock.bukkit.games.pvpbox.listeners.AsyncChatListener;
import fr.badblock.bukkit.games.pvpbox.listeners.BlocksListener;
import fr.badblock.bukkit.games.pvpbox.listeners.ChunkUnloadListener;
import fr.badblock.bukkit.games.pvpbox.listeners.CreatureSpawnListener;
import fr.badblock.bukkit.games.pvpbox.listeners.EntityDamageListener;
import fr.badblock.bukkit.games.pvpbox.listeners.FoodLevelChangeListener;
import fr.badblock.bukkit.games.pvpbox.listeners.InventoryClickListener;
import fr.badblock.bukkit.games.pvpbox.listeners.PaintingBreakListener;
import fr.badblock.bukkit.games.pvpbox.listeners.PermissionEntityListener;
import fr.badblock.bukkit.games.pvpbox.listeners.PlayerArmorStandManipulateListener;
import fr.badblock.bukkit.games.pvpbox.listeners.PlayerCloseInventoryListener;
import fr.badblock.bukkit.games.pvpbox.listeners.PlayerConsumeListener;
import fr.badblock.bukkit.games.pvpbox.listeners.PlayerDeathListener;
import fr.badblock.bukkit.games.pvpbox.listeners.PlayerDropItemListener;
import fr.badblock.bukkit.games.pvpbox.listeners.PlayerInteractListener;
import fr.badblock.bukkit.games.pvpbox.listeners.PlayerJoinListener;
import fr.badblock.bukkit.games.pvpbox.listeners.PlayerMoveListener;
import fr.badblock.bukkit.games.pvpbox.listeners.PlayerPickupItemListener;
import fr.badblock.bukkit.games.pvpbox.listeners.PlayerQuitListener;
import fr.badblock.bukkit.games.pvpbox.listeners.PlayerRespawnListener;
import fr.badblock.bukkit.games.pvpbox.listeners.PlayerTeleportListener;
import fr.badblock.bukkit.games.pvpbox.listeners.ProjectileLaunchListener;
import fr.badblock.bukkit.games.pvpbox.listeners.WeatherChangeListener;
import fr.badblock.bukkit.games.pvpbox.objects.BadPlayer;
import fr.badblock.bukkit.games.pvpbox.objects.BadTeam;
import fr.badblock.bukkit.games.pvpbox.objects.Statue;
import fr.badblock.bukkit.games.pvpbox.permissions.PermissionsExManager;
import fr.badblock.bukkit.games.pvpbox.utils.BoxLevel;
import fr.badblock.bukkit.games.pvpbox.utils.BoxThread;
import fr.badblock.bukkit.games.pvpbox.utils.ConfigUtils;
import fr.badblock.bukkit.games.pvpbox.utils.TempScheduler;
import fr.badblock.bukkit.games.pvpbox.utils.database.DataRequest;
import fr.badblock.bukkit.games.pvpbox.utils.database.DataType;
import fr.badblock.bukkit.games.pvpbox.utils.database.Database2Manager;
import fr.badblock.bukkit.games.pvpbox.utils.database.DatabaseManager;
//import fr.badblock.common.commons.technologies.rabbitmq.RabbitConnector;
//import fr.badblock.common.commons.technologies.rabbitmq.RabbitService;
import io.netty.util.internal.ConcurrentSet;
import net.md_5.bungee.api.ChatColor;
import net.minecraft.server.v1_8_R3.IChatBaseComponent;
import net.minecraft.server.v1_8_R3.IChatBaseComponent.ChatSerializer;
import net.minecraft.server.v1_8_R3.NBTTagCompound;
import net.minecraft.server.v1_8_R3.PacketPlayOutChat;

public class BadBlockPvPBox extends JavaPlugin {
	
	public static BadBlockPvPBox instance;
	public Location				 location;
	public ItemStack 			 kitItem;
	public ItemStack 			 hubBackItem;
	public World				 world;
	public Inventory			 boxKitSelectorInventory;
	public Inventory			 teamKitSelectorInventory;
	public List<Location>		 teamArenaTeleportLocations;
	public List<Location>		 pvpArenaTeleportLocations;
	public PermissionsExManager  permissionsExManager;
	public ItemStack			 shopItem;
	public ItemStack			 closeInventoryItem;
	public ItemStack			 ironChestplate;
	public ItemStack			 goldChestplate;
	public ItemStack			 diamondChestplate;
	public Gson					 gson;
	public Map<String,  String>  teamsGroup     = new HashMap<>();
	public Map<String,  String>  teamsPrefix    = new HashMap<>();
	public Map<String , String>  players        = new HashMap<>();
	public List<String>			 dropsMaterials = new ArrayList<>();
	public int 					 slots;
	public long					 nb;
	
//	public RabbitService		 rabbitService;
	
	/* Config */
	public File 				config;
	public FileConfiguration 	configfile;
	public File 				kits;
	public FileConfiguration	kitsfile;
	public File 				database;
	public FileConfiguration	databasefile;
	public File 				locations;
	public FileConfiguration	locationsfile;
	public File 				gameplay;
	public FileConfiguration	gameplayfile;
	
	@Override
	public void onEnable() {
		instance = this;
		new BoxThread();
		permissionsExManager = new PermissionsExManager();
		getCommand("slots").setExecutor(new SlotsCommand());
		getCommand("bbox").setExecutor(new BBoxCommand());
		getCommand("createkit").setExecutor(new CreateKitCommand());
		getCommand("spawn").setExecutor(new SpawnCommand());
		getCommand("team").setExecutor(new TeamCommand());
		getCommand("duel").setExecutor(new DuelCommand());
		getCommand("godmode").setExecutor(new GodmodeCommand());
		getCommand("gm").setExecutor(new GmCommand());
		getCommand("fly").setExecutor(new FlyCommand());
		getCommand("creport").setExecutor(new CReportCommand());
		getCommand("feed").setExecutor(new FeedCommand());
		getCommand("heal").setExecutor(new HealCommand());
		getCommand("kickall").setExecutor(new KickAllCommand());
		VanishCommand vc = new VanishCommand();
		getCommand("vanish").setExecutor(vc);
		// Initialisation des kits
		this.getServer().getMessenger().registerOutgoingPluginChannel(this, "BungeeCord");
		// Enregistrement des listeners
		PluginManager pluginManager = this.getServer().getPluginManager();
		pluginManager.registerEvents(new AsyncChatListener(), this);
		pluginManager.registerEvents(new PlayerJoinListener(), this);
		pluginManager.registerEvents(new BlocksListener(), this);
		pluginManager.registerEvents(new PlayerInteractListener(), this);
		pluginManager.registerEvents(new InventoryClickListener(), this);
		pluginManager.registerEvents(new CreatureSpawnListener(), this);
		pluginManager.registerEvents(new ChunkUnloadListener(), this);
		pluginManager.registerEvents(new EntityDamageListener(), this);
		pluginManager.registerEvents(new PlayerRespawnListener(), this);
		pluginManager.registerEvents(new FoodLevelChangeListener(), this);
		pluginManager.registerEvents(new WeatherChangeListener(), this);
		pluginManager.registerEvents(new PaintingBreakListener(), this);
		pluginManager.registerEvents(new ProjectileLaunchListener(), this);
		pluginManager.registerEvents(new PlayerDeathListener(), this);
		pluginManager.registerEvents(new PlayerDropItemListener(), this);
		pluginManager.registerEvents(new PlayerPickupItemListener(), this);
		pluginManager.registerEvents(new PlayerCloseInventoryListener(), this);
		pluginManager.registerEvents(new PlayerTeleportListener(), this);
		pluginManager.registerEvents(new PlayerQuitListener(), this);
		pluginManager.registerEvents(new PlayerMoveListener(), this);
		pluginManager.registerEvents(new PermissionEntityListener(), this);
		pluginManager.registerEvents(new PlayerConsumeListener(), this);
		pluginManager.registerEvents(new PlayerArmorStandManipulateListener(), this);
		pluginManager.registerEvents(vc, this);
//		new WorldWeatherTask(this);
		Bukkit.getWorld("world").setTime(6000);
//		Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "gamerule doFireTick false");
//		Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "gamerule doDaylightCycle false");
		Bukkit.getWorld("world").setGameRuleValue("doFireTick", "false");
		Bukkit.getWorld("world").setGameRuleValue("doDaylightCycle", "false");
		/* Chargement des fichiers */
		config = new File(getDataFolder(), "config.yml");
		configfile = YamlConfiguration.loadConfiguration(config);
		kits = new File(getDataFolder(), "kits.yml");
		kitsfile = YamlConfiguration.loadConfiguration(kits);
		database = new File(getDataFolder(), "database.yml");
		databasefile = YamlConfiguration.loadConfiguration(database);
		locations = new File(getDataFolder(), "locations.yml");
		locationsfile = YamlConfiguration.loadConfiguration(locations);
		gameplay = new File(getDataFolder(), "gameplay.yml");
		gameplayfile = YamlConfiguration.loadConfiguration(gameplay);
		
		this.reloadConfig();
		
		location = ConfigUtils.getLocation(instance, "spawn", config, configfile);
		
		DatabaseManager.load(databasefile.getString("db.hostname"), databasefile.getInt("db.port"), databasefile.getString("db.username"), databasefile.getString("db.password"), databasefile.getString("db.database"));
		Database2Manager.load(databasefile.getString("dbothers.hostname"), databasefile.getInt("dbothers.port"), databasefile.getString("dbothers.username"), databasefile.getString("dbothers.password"), databasefile.getString("dbothers.database"));
//		rabbitService = RabbitConnector.getInstance().newService("rabbit2", config.getString("rabbit.hostname"), config.getInt("rabbit.port"), config.getString("rabbit.username"), config.getString("rabbit.password"), config.getString("rabbit.virtualHost"));
		Bukkit.getScheduler().runTaskTimerAsynchronously(this, new Runnable() {
			@Override
			public void run() {
				// Points
				nb++;
				ConcurrentSet<String> commands = new ConcurrentSet<>();
				DatabaseManager.sendQuery(new DataRequest("SELECT points, pseudo FROM pvpbox_players ORDER BY points DESC LIMIT 10;", DataType.QUERY) {
					@Override
					public void callback(ResultSet resultSet) {
						try {
							int line = 1;
							int id = 0;
							Map<Integer, String> list = new HashMap<>();
							while(resultSet.next()) {
								int points = resultSet.getInt("points");
								String pseudo = resultSet.getString("pseudo");
								id++;
								line++;
								BoxLevel currentLevel = BoxLevel.getLevel((double) points);
								BoxLevel nextLevel = BoxLevel.getLevel(currentLevel.id + 1);
								double percent;
								if (nextLevel != null) {
									double max = nextLevel.xp();
									percent = (points - currentLevel.xp()) / (max - currentLevel.xp()) * 100.0D;
								}else percent = 100D;
								commands.add("hologram setline rankpoints " + line + " §b" + id+ ". §a" + pseudo + " §7(§bniveau " + currentLevel.name + " ["+ BadPlayer.round(percent, 2) + "%]§7)");
							}					
						}catch(Exception error) {
							error.printStackTrace();
						}
					}
				});
				DatabaseManager.sendQuery(new DataRequest("SELECT * FROM pvpbox_players ORDER BY kills DESC LIMIT 10;", DataType.QUERY) {
					@Override
					public void callback(ResultSet resultSet) {
						try {
							int line = 1;
							int id = 0;
							Map<Integer, String> list = new HashMap<>();
							while(resultSet.next()) {
								int points = resultSet.getInt("kills");
								String pseudo = resultSet.getString("pseudo");
								id++;
								line++;
								commands.add("hologram setline rankkills " + line + " §b" + id+ ". §a" + pseudo + " §7(§b" + points + " tués§7)");
							}
						}catch(Exception error) {
							error.printStackTrace();
						}
					}
				});
				DatabaseManager.sendQuery(new DataRequest("SELECT * FROM pvpbox_players ORDER BY teamVictories DESC LIMIT 10;", DataType.QUERY) {
					@Override
					public void callback(ResultSet resultSet) {
						try {
							int line = 1;
							int id = 0;
							Map<Integer, String> list = new HashMap<>();
							while(resultSet.next()) {
								int points = resultSet.getInt("teamVictories");
								String pseudo = resultSet.getString("pseudo");
								id++;
								line++;
								commands.add("hologram setline rankteamvictoires " + line + " §b" + id+ ". §a" + pseudo + " §7(§b" + points + " victoires§7)");
							}		
						}catch(Exception error) {
							error.printStackTrace();
						}
					}
				});
				long o = nb == 1 ? 1 : 28 * 20;
				TempScheduler tempScheduler = new TempScheduler();
				tempScheduler.task = Bukkit.getScheduler().runTaskTimer(instance, new Runnable() {
					@Override
					public void run() {
						if (commands.size() == 0) {
							tempScheduler.task.cancel();
							return;
						}
						Iterator<String> iterator = commands.iterator();
						if (iterator.hasNext()) {
							String command = iterator.next();
							iterator.remove();
							getServer().dispatchCommand(getServer().getConsoleSender(), command);
						}
					}
				}, o, o);
			}
		}, 0, 20 * 900);
		this.getServer().getOnlinePlayers().forEach(player -> {
			BadPlayer badPlayer = BadPlayer.get(player);	
			badPlayer.setSpawn(player);
		});
		for (World world : this.getServer().getWorlds()) {
			for (Entity entity : world.getEntitiesByClasses(Item.class, Projectile.class)) {
				entity.remove();
			}
		}
	}
	
	@Override
	public void reloadConfig() {
		FileConfiguration config = this.gameplayfile;
		world = this.getServer().getWorld(config.getString("world", "world"));
		if (Statue.statues.size() >= 0)
			for (Statue statue : Statue.statues)
				statue.unregister();
		if (config.contains("statues")) {
			for (String key : config.getConfigurationSection("statues").getKeys(false)) {
				ConfigurationSection cs = config.getConfigurationSection("statues." + key);
				// (UUID uuid, PotionEffectType effect, Location center, int booster) 
				new Statue(cs.getString("name"), UUID.fromString(key),
						PotionEffectType.getByName(cs.getString("effect")),
						ConfigUtils.getBlockLocationFromFile(this, "statues." + key + ".center", gameplay, gameplayfile),
						cs.getInt("booster"),
						cs.getInt("radius"));
			}
		}
		config = this.configfile;
		if(!config.contains("slots")) config.set("slots", -1);
		if(!config.contains("minY")) config.set("minY", 80);
		if(!config.contains("header")){
			config.createSection("header");
		}
		if(!config.contains("footer")){
			config.createSection("footer");
		}
		if(!config.contains("spawn")){
			config.createSection("spawn");
			ConfigUtils.setLocation(instance, new Location(Bukkit.getWorld("world"), 0, 200, 0), "spawn", this.configfile, this.config);
		}
		config = this.kitsfile;
		if (!config.contains("kits")) {
			config.createSection("kits");
			config.set("chestplate.free.lore", Arrays.asList("bonjour"));
			config.set("chestplate.murderer.lore", Arrays.asList("bonjour"));
			config.set("chestplate.mastodon.lore", Arrays.asList("bonjour"));
			config.set("kits.archer", "");
			config.set("kits.archer.slot", 0);
			config.set("kits.archer.amount", 1);
			config.set("kits.archer.name", "&eArcher");
			config.set("kits.archer.material", "BOW");
			config.set("kits.archer.data", (short) 0);
			config.set("kits.archer.fakeEnchantment", false);
			config.set("kits.archer.lore", Arrays.asList("&b&lNouveau kit", "", "&eContient: ", "&e- une frite"));
			ItemStack itemStack = new ItemStack(Material.APPLE, 5, (short) 1);
			ItemMeta itemMeta = itemStack.getItemMeta();
			itemMeta.setDisplayName("&ePomme cheat");
			itemStack.setItemMeta(itemMeta);
			itemStack.addUnsafeEnchantment(Enchantment.DAMAGE_ALL, 1);
			KitItem kitItem = new KitItem(0, itemStack);
			config.createSection("kits.archer.items.1");
			kitItem.set(config.getConfigurationSection("kits.archer.items.1"));
		}
		for (String key : config.getConfigurationSection("kits").getKeys(false)) {
			ConfigurationSection cs = config.getConfigurationSection("kits." + key);
			new Kit(cs);
		}
		config = this.configfile;
		// Items
		set();
		Bukkit.getScheduler().runTaskTimer(this, new Runnable() {
			@Override
			public void run() {
				set();
			}
		}, 1200, 1200);
		for (String string : config.getStringList("groupsOrder")) {
			String[] splitter = string.split(":");
			teamsGroup.put(splitter[0], splitter[1]);
			teamsPrefix.put(splitter[0], splitter[2]);
		}
		config = this.gameplayfile;
		for (String m : config.getStringList("dropsMaterials")) {
			try {
				dropsMaterials.add(Material.getMaterial(m).name());
			}catch(Exception o) {
				System.out.println("[PvPBox] ERROR: UNKNOWN " + m + " TYPE!");
			}
		}
		gson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().setPrettyPrinting().create();
		BadTeam.teams.clear();// Load de toutes les teams
	}
	
	public void set() {
		kitItem = setUnbreakable(new ItemStack(Material.DIAMOND_SWORD));
		ItemMeta itemMeta = kitItem.getItemMeta();
		itemMeta.setDisplayName("§bChoisir un kit !");
		itemMeta.setLore(Arrays.asList("", "§eEn cliquant sur cet item, vous devrez choisir un kit.", "§eIl vous sera automatiquement", "§edonné lorsque vous rejoindrez", "§el'arène."));
		kitItem.setItemMeta(itemMeta);
		hubBackItem = new ItemStack(Material.WOOD_DOOR);
		itemMeta = hubBackItem.getItemMeta();
		itemMeta.setDisplayName("§bRetourner au hub");
		itemMeta.setLore(Arrays.asList("", "§eEn cliquant sur cet item, vous serez téléporté au hub de BadBlock."));
		hubBackItem.setItemMeta(itemMeta);
		boxKitSelectorInventory = Bukkit.createInventory(null, 9 * 5, "§bSélectionnez un kit");
		ItemStack itemStack = new ItemStack(Material.STAINED_GLASS_PANE, 1, (short) 7);
		boxKitSelectorInventory.setItem(0, itemStack);
		boxKitSelectorInventory.setItem(1, itemStack);
		boxKitSelectorInventory.setItem(2, itemStack);
		boxKitSelectorInventory.setItem(3, itemStack);
		boxKitSelectorInventory.setItem(4, itemStack);
		boxKitSelectorInventory.setItem(5, itemStack);
		boxKitSelectorInventory.setItem(6, itemStack);
		boxKitSelectorInventory.setItem(7, itemStack);
		boxKitSelectorInventory.setItem(8, itemStack);
		boxKitSelectorInventory.setItem(9, itemStack);
		boxKitSelectorInventory.setItem(17, itemStack);
		boxKitSelectorInventory.setItem(18, itemStack);
		boxKitSelectorInventory.setItem(26, itemStack);
		boxKitSelectorInventory.setItem(27, itemStack);
		boxKitSelectorInventory.setItem(28, itemStack);
		boxKitSelectorInventory.setItem(34, itemStack);
		boxKitSelectorInventory.setItem(35, itemStack);
		shopItem = new ItemStack(Material.GOLD_INGOT, 1);
		itemMeta = shopItem.getItemMeta();
		itemMeta.setDisplayName("§eGrades");
		itemMeta.setLore(Arrays.asList("", "§bAcheter un grade"));
		shopItem.setItemMeta(itemMeta);
		boxKitSelectorInventory.setItem(36, shopItem);
		boxKitSelectorInventory.setItem(37, itemStack);
		boxKitSelectorInventory.setItem(38, itemStack);
		boxKitSelectorInventory.setItem(39, itemStack);
		boxKitSelectorInventory.setItem(40, itemStack);
		boxKitSelectorInventory.setItem(41, itemStack);
		boxKitSelectorInventory.setItem(42, itemStack);
		boxKitSelectorInventory.setItem(43, itemStack);
		closeInventoryItem = new ItemStack(Material.BARRIER, 1);
		itemMeta = closeInventoryItem.getItemMeta();
		itemMeta.setDisplayName("§cQuitter");
		itemMeta.setLore(Arrays.asList("", "§bQuitter l'inventaire"));
		closeInventoryItem.setItemMeta(itemMeta);
		ironChestplate = new ItemStack(Material.IRON_CHESTPLATE, 1);
		itemMeta = ironChestplate.getItemMeta();
		itemMeta.setDisplayName("§aGratuit");
		itemMeta.setLore(toColorList(kitsfile.getStringList("chestplate.free.lore")));
		ironChestplate.setItemMeta(itemMeta);
		goldChestplate = new ItemStack(Material.GOLD_CHESTPLATE, 1);
		itemMeta = goldChestplate.getItemMeta();
		itemMeta.setDisplayName("§6Assassin");
		itemMeta.setLore(toColorList(kitsfile.getStringList("chestplate.murderer.lore")));
		goldChestplate.setItemMeta(itemMeta);
		diamondChestplate = new ItemStack(Material.DIAMOND_CHESTPLATE, 1);
		itemMeta = diamondChestplate.getItemMeta();
		itemMeta.setDisplayName("§5Mastodonte");
		itemMeta.setLore(toColorList(kitsfile.getStringList("chestplate.mastodon.lore")));
		diamondChestplate.setItemMeta(itemMeta);
		boxKitSelectorInventory.setItem(13, ironChestplate);
		boxKitSelectorInventory.setItem(22, goldChestplate);
		boxKitSelectorInventory.setItem(31, diamondChestplate);
		boxKitSelectorInventory.setItem(44, closeInventoryItem);
		Kit.kits.values().forEach(kit -> boxKitSelectorInventory.setItem(kit.slot, kit.kitItem));
		pvpArenaTeleportLocations = ConfigUtils.getLocationList(instance, "pvpArenaTeleportLocations", locations, locationsfile);
		teamArenaTeleportLocations = ConfigUtils.getLocationList(instance, "teamArenaTeleportLocations", locations, locationsfile);
		teamKitSelectorInventory = Bukkit.createInventory(null, 9 * 3, "§bSélectionnez un kit");
		itemStack = new ItemStack(Material.STAINED_GLASS_PANE, 1, (short) 7);
		teamKitSelectorInventory.setItem(0, itemStack);
		teamKitSelectorInventory.setItem(1, itemStack);
		teamKitSelectorInventory.setItem(2, itemStack);
		teamKitSelectorInventory.setItem(3, itemStack);
		teamKitSelectorInventory.setItem(4, itemStack);
		teamKitSelectorInventory.setItem(5, itemStack);
		teamKitSelectorInventory.setItem(6, itemStack);
		teamKitSelectorInventory.setItem(7, itemStack);
		teamKitSelectorInventory.setItem(8, itemStack);
		teamKitSelectorInventory.setItem(9, itemStack);
		teamKitSelectorInventory.setItem(17, itemStack);
		teamKitSelectorInventory.setItem(18, itemStack);
		teamKitSelectorInventory.setItem(19, itemStack);
		teamKitSelectorInventory.setItem(20, itemStack);
		teamKitSelectorInventory.setItem(21, itemStack);
		teamKitSelectorInventory.setItem(22, itemStack);
		teamKitSelectorInventory.setItem(23, itemStack);
		teamKitSelectorInventory.setItem(24, itemStack);
		teamKitSelectorInventory.setItem(25, itemStack);
		teamKitSelectorInventory.setItem(26, closeInventoryItem);
		teamKitSelectorInventory.setItem(13, ironChestplate);
		Kit.kits.values().parallelStream().filter(kit -> kit.permission == null || "".equals(kit.permission)).forEach(kit -> teamKitSelectorInventory.setItem(kit.slot, kit.kitItem));
		
	}
	
	public ItemStack setUnbreakable(ItemStack itemStack) {
		net.minecraft.server.v1_8_R3.ItemStack stack = CraftItemStack.asNMSCopy(itemStack);
		NBTTagCompound tag = new NBTTagCompound(); 
		tag.setBoolean("Unbreakable", true);
		stack.setTag(tag);
		ItemStack is = CraftItemStack.asBukkitCopy(stack);
		return is;
	}
	
	@Override
	public void onDisable() {
		BadPlayer.players.values().forEach(player -> player.getInfos().save());
	}
	
	public List<String> toColorList(List<String> noColoredList) {
		List<String> coloredList = new ArrayList<>();
		noColoredList.forEach(string -> coloredList.add(ChatColor.translateAlternateColorCodes('&', string)));
		return coloredList;
	}
	
	public static void sendActionBar(Player player, String message){
		IChatBaseComponent cbc = ChatSerializer.a("{\"text\": \"" + message + "\"}");
		PacketPlayOutChat ppoc = new PacketPlayOutChat(cbc, (byte) 2);
		((CraftPlayer)player).getHandle().playerConnection.sendPacket(ppoc);
	}
	
	
}
