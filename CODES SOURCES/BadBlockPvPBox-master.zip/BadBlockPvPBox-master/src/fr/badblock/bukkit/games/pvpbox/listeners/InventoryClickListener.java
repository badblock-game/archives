package fr.badblock.bukkit.games.pvpbox.listeners;

import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import fr.badblock.bukkit.games.pvpbox.BadBlockPvPBox;
import fr.badblock.bukkit.games.pvpbox.arenas.Duel;
import fr.badblock.bukkit.games.pvpbox.kits.Kit;
import fr.badblock.bukkit.games.pvpbox.objects.BadPlayer;
import fr.badblock.bukkit.games.pvpbox.objects.BadTeam;
import it.mri.mycommand.execute.DispatchCommands;
import it.mri.mycommand.utilities.enums.CommandsType;


public class InventoryClickListener implements Listener {
	
	@EventHandler
	public void onInventoryClick(InventoryClickEvent event) {
		if (!(event.getWhoClicked().getType().equals(EntityType.PLAYER))) return;
		Player player = (Player) event.getWhoClicked();
		if (event.getCurrentItem() == null) return;
		ItemStack itemStack = event.getCurrentItem();
		if (itemStack.getType().equals(Material.AIR)) return;
		BadBlockPvPBox instance = BadBlockPvPBox.instance;
		Inventory inventory = event.getInventory();
		if (inventory.equals(instance.boxKitSelectorInventory)) {
			event.setCancelled(true);
			if (itemStack.getType().equals(Material.IRON_CHESTPLATE)) return;
			if (itemStack.getType().equals(Material.GOLD_CHESTPLATE)) return;
			if (itemStack.getType().equals(Material.DIAMOND_CHESTPLATE)) return;
			if (itemStack.getType().equals(Material.STAINED_GLASS_PANE)) return;
			if (itemStack.getType().equals(Material.GOLD_INGOT)) {
				DispatchCommands.ExecuteCommands(player, "/grade", CommandsType.RUN_COMMAND);
				return;
			}
			if (itemStack.getType().equals(Material.BARRIER)) {
				player.closeInventory();
				return;
			}
			player.closeInventory();
			player.setGameMode(GameMode.ADVENTURE);
			Kit.kits.values().forEach(kit -> {
				if (!kit.kitItem.equals(itemStack)) return;
				if (kit.permission != null && !"".equals(kit.permission) && !player.hasPermission(kit.permission)) {
					player.sendMessage("§cVous n'avez pas le grade nécessaire pour utiliser ce kit.");
					return;
				}
				BadPlayer badPlayer = BadPlayer.get(player);
				player.sendMessage("§bKit sélectionné : §a"+kit.name);
				player.sendMessage("§7Sautez dans l'arène pour détruire vos adversaires !");
				badPlayer.getInfos().setCurrentkit(kit.name);
				badPlayer.updateScores(player);
				
//				BoxThread.instance.addRequest(new Runnable() {
//					@Override
//					public void run() {
//						if (!player.isOnline()) return;
//						player.sendMessage("§bKit sélectionné: " + kit.name);
//						player.sendMessage("§aTéléportation dans l'arène...");
//						if (instance.pvpArenaTeleportLocations.size() == 0) {
//							player.sendMessage("§cAucun point de spawn dans l'arène défini.");
//							return;
//						}
//						List<Location> playerLocations = new ArrayList<>();
//						instance.getServer().getOnlinePlayers().forEach(pl -> playerLocations.add(pl.getLocation()));
//						Location betterLocation = null;
//						long distance = Long.MIN_VALUE;
//						for (Location location : instance.pvpArenaTeleportLocations) {
//							long dist = Long.MAX_VALUE;
//							for (Location loc : playerLocations)
//								if (loc.distance(location) < dist)
//									dist = (long) loc.distance(location);
//							if (distance < dist) {
//								betterLocation = location;
//								distance = dist;
//							}
//						}
//						if (betterLocation == null) {
//							betterLocation = instance.pvpArenaTeleportLocations.get(0);
//						}
//						final Location finalLocation = betterLocation;
//						instance.getServer().getScheduler().runTask(instance, new Runnable() {
//							@Override
//							public void run() {
//								if (!player.isOnline()) return;
//								BadPlayer badPlayer = BadPlayer.get(player);
//								badPlayer.setToBoxArena(player);
//								for (Player plo : Bukkit.getOnlinePlayers())
//									if (plo.canSee(player))
//										plo.hidePlayer(player);
//								for (Player plo : Bukkit.getOnlinePlayers()) {
//									if (!BadPlayer.players.containsKey(plo.getUniqueId())) continue;
//									BadPlayer plb = BadPlayer.get(plo);
//									if (plb == null) continue;
//									if (VanishCommand.isVanished(plo)) continue;
//									if (plb.boxArenaBypass < System.currentTimeMillis())
//										player.showPlayer(plo);
//								}
//								player.sendMessage("§aVous êtes invisible pendant quelques secondes...");
//								instance.getServer().getScheduler().runTaskLater(instance, new Runnable() {
//									@Override
//									public void run() {
//										if (player == null || !player.isOnline()) return;
//										if (VanishCommand.isVanished(player)) return;
//										for (Player plo : Bukkit.getOnlinePlayers()) {
//											if (!BadPlayer.players.containsKey(plo.getUniqueId())) continue;
//											BadPlayer bplo = BadPlayer.get(plo);
//											if (bplo.gameState.equals(GameState.WAIT)) continue;
//											plo.showPlayer(player);
//										}
//										player.sendMessage("§aVous êtes désormais visible.");
//									}
//								}, 5 * 20);
//								player.teleport(finalLocation);
//								PlayerInventory playerInventory = player.getInventory();
//								playerInventory.clear();
//								playerInventory.setHeldItemSlot(0);
//								player.setMaxHealth(20);
//								player.setHealth(20);
//								player.getActivePotionEffects().clear();
//								player.setFoodLevel(20);
//								player.setExp(badPlayer.playerExp);
//								player.setLevel(badPlayer.playerLevel);
//								playerInventory.setArmorContents(null);
//								kit.items.forEach(kitItem -> {
//									int slot = kitItem.slot;
//									if (slot == 103) playerInventory.setHelmet(kitItem.itemStack);
//									else if (slot == 102) playerInventory.setChestplate(kitItem.itemStack);
//									else if (slot == 101) playerInventory.setLeggings(kitItem.itemStack);
//									else if (slot == 100) playerInventory.setBoots(kitItem.itemStack);
//									else playerInventory.setItem(slot, kitItem.itemStack);
//								});
//								player.updateInventory();
//							}
//						});
//					}
//				});
			});
		}
		if (event.getInventory() != null && event.getInventory().getName() != null && event.getInventory().getName().equalsIgnoreCase("§9Sélectionnez vos adversaires")) {
			event.setCancelled(true);
			ItemMeta meta = itemStack.getItemMeta();
			if (meta.getDisplayName() != null) {
				BadTeam team = BadTeam.teams.get(meta.getDisplayName().replace("§6", ""));
				if (team == null) {
					player.sendMessage("§cCette team est inexistante.");
					return;
				}
				player.closeInventory();
				player.getServer().dispatchCommand(player, "duel " + team.name);
			}
			return;
		}
		if (event.getInventory().equals(instance.teamKitSelectorInventory)) {
			event.setCancelled(true);
			if (itemStack.getType().equals(Material.STAINED_GLASS_PANE)) return;
			if (itemStack.getType().equals(Material.BARRIER)) {
				player.closeInventory();
				return;
			}
			Kit.kits.values().forEach(kit -> {
				if (!kit.kitItem.equals(itemStack)) return;
				Duel duel = Duel.get(player);
				if (duel == null) {
					player.closeInventory();
					return;
				}
				duel.kits.put(player, kit);
				duel.sendMessage("§b§l[Duel] §e" + player.getName() + "§b a choisi son kit.");
				player.sendMessage("§cVeuillez patienter pendant que les autres joueurs choisissent son kit.");
			});
			
			player.closeInventory();
			return;
		}
	}
	
}
