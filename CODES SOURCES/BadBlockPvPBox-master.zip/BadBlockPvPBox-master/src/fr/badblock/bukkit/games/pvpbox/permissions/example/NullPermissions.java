package fr.badblock.bukkit.games.pvpbox.permissions.example;

import org.bukkit.entity.Player;

import fr.badblock.bukkit.games.pvpbox.permissions.abstracts.AbstractPermissions;

public class NullPermissions extends AbstractPermissions {
	@Override
	public String getGroup(Player base){
		return "";
	}

	@Override
	public String getPrefix(Player base) {
		return "";
	}

	@Override
	public String getSuffix(Player base) {
		return "";
	}
	
	@Override
	public boolean hasPermission(Player base, String node){
		return base.hasPermission(node);
	}
}
