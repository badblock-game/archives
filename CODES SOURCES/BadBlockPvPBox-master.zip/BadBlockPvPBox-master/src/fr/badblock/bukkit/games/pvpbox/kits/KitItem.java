package fr.badblock.bukkit.games.pvpbox.kits;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import fr.badblock.bukkit.games.pvpbox.BadBlockPvPBox;

public class KitItem {
	
	public int				 		 slot;
	public int						 amount;
	public boolean					 splash;
	public Material			 		 material;
	public short 			 		 data;
	public String			 		 name;
	public List<String>		 		 lore;
	public Map<Enchantment, Integer> enchantments;
	public ItemStack		 		 itemStack;
	
	public KitItem(ConfigurationSection item) {
		slot = item.getInt("slot");
		splash = item.getBoolean("splash", false);
		amount = item.getInt("amount", 1);
		material = Material.getMaterial(item.getString("material"));
		data = (short) item.getInt("data");
		if (name != null && !"".equalsIgnoreCase(name)) {
			name = (String) item.getString("name");
			name = ChatColor.translateAlternateColorCodes('&', name);
		}
		lore = (List<String>) item.getStringList("lore");
		lore = BadBlockPvPBox.instance.toColorList(lore);
		enchantments = new HashMap<>();
		item.getStringList("enchantments").forEach(string -> {
			String[] splitter = string.split(":");
			Enchantment enchantment = Enchantment.getByName(splitter[0]);
			int booster = Integer.parseInt(splitter[1]);
			enchantments.put(enchantment, booster);
		}); 
		itemStack = new ItemStack(material, amount, data);
		ItemMeta itemMeta = itemStack.getItemMeta();
		itemMeta.setDisplayName(name);
		itemMeta.setLore(lore);
		enchantments.entrySet().forEach(enchantment -> itemStack.addUnsafeEnchantment(enchantment.getKey(), enchantment.getValue()));
	}
	
	public KitItem(int slot, ItemStack itemStack) {
		this.slot = slot;
		this.amount = itemStack.getAmount();
		this.material = itemStack.getType();
		this.data = itemStack.getData().getData();
		this.name = itemStack.getItemMeta().getDisplayName();
		this.lore = itemStack.getItemMeta().getLore();
		this.enchantments = itemStack.getEnchantments();
	}
	
	public void set(ConfigurationSection item) {
		item.set("slot", slot);
		item.set("amount", amount);
		item.set("splash", splash);
		item.set("material", material.name());
		item.set("data", data);
		item.set("name", name);
		item.set("lore", lore);
		List<String> enchantmentsString = new ArrayList<>();
		enchantments.entrySet().forEach(enchantment -> enchantmentsString.add(enchantment.getKey().getName() + ":" + enchantment.getValue()));
		item.set("enchantments", enchantmentsString);
	}
	
}
