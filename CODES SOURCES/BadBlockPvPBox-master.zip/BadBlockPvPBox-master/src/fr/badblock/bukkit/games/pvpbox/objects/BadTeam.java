package fr.badblock.bukkit.games.pvpbox.objects;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.stream.Collectors;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import com.google.gson.annotations.Expose;

import fr.badblock.bukkit.games.pvpbox.BadBlockPvPBox;

public class BadTeam {
	
	public static Map<String, BadTeam> teams = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
	
	@Expose public  String		 			  name;
	@Expose public  String					  owner;
	@Expose public  Map<String, List<String>> players;
	@Expose public  List<String> 			  pendingPlayers;
	private TreeSet<String>					  waitingTeamsDuel;
	
	public BadTeam(Player owner, String name) {
		this.name = name;
		this.owner = owner.getName();
		this.players = new HashMap<>();
		this.pendingPlayers = new ArrayList<>();
		waitingTeamsDuel = new TreeSet<String>(String.CASE_INSENSITIVE_ORDER);
		players.put(owner.getName(), new ArrayList<>());
	}
	
	public TreeSet<String> getWaitingTeamsDuel() {
		if (waitingTeamsDuel == null) waitingTeamsDuel = new TreeSet<String>(String.CASE_INSENSITIVE_ORDER);
		return waitingTeamsDuel;
	}
	
	public void addPendingPlayer(String player) {
		this.pendingPlayers.remove(player);
		this.players.put(player, new ArrayList<>());
	}
	
	public void addPlayer(String player) {
		this.pendingPlayers.remove(player);
		this.players.put(player, new ArrayList<>());
	}
	
	public void register() {
		if (players == null) players = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
		if (waitingTeamsDuel == null) waitingTeamsDuel = new TreeSet<String>(String.CASE_INSENSITIVE_ORDER);
		teams.put(this.name, this);
		Player player = Bukkit.getPlayer(this.owner);
		if (player != null && player.isOnline()) BadPlayer.get(player).updateScores(player);
	}
	
	public void update() {
		for (Player player : this.getOnlinePlayers())
			BadPlayer.get(player).updateScores(player);
	}
	
	public void unregister() {
		teams.remove(this.name);
	}
	
	public Set<String> getPlayers() {
		return this.players.keySet();
	}
	
	public List<String> getPlayersWithoutLeader() {
		return this.players.keySet().parallelStream().filter(player -> !owner.equalsIgnoreCase(player)).collect(Collectors.toList());
	}
	
	public Set<Player> getOnlinePlayers() {
		Set<Player> players = new HashSet<>();
		for (String pl : getPlayers()) {
			Player player = BadBlockPvPBox.instance.getServer().getPlayer(pl);
			if (player != null && player.isOnline()) {
				players.add(player);
			}
		}
		return players;
	}
	
	public Set<Player> getOnlinePlayersInDuel() {
		Set<Player> players = new HashSet<>();
		for (String pl : getPlayers()) {
			Player player = BadBlockPvPBox.instance.getServer().getPlayer(pl);
			if (player != null && player.isOnline()) {
				BadPlayer badPlayer = BadPlayer.get(player);
				if (badPlayer.gameState.equals(GameState.IN_TEAM_ARENA))
					players.add(player);
			}
		}
		return players;
	}
	
	public Set<String> getOfflinePlayers() {
		Set<String> players = new HashSet<>();
		for (String pl : getPlayers()) {
			Player player = BadBlockPvPBox.instance.getServer().getPlayer(pl);
			if (player == null || !player.isOnline()) {
				players.add(pl);
			}
		}
		return players;
	}
	
	public Set<Player> getOnlinePlayersWithoutLeader() {
		Set<Player> players = new HashSet<>();
		for (String pl : getPlayersWithoutLeader()) {
			Player player = BadBlockPvPBox.instance.getServer().getPlayer(pl);
			if (player != null && player.isOnline()) {
				players.add(player);
			}
		}
		return players;
	}
	
	public boolean hasPermission(Player player, String permission) {
		return player.getName().equalsIgnoreCase(this.owner) || (players.get(player.getName()) != null && players.get(player.getName()).contains(permission));
	}
	
	public Set<Player> getOnlinePlayers(String permission) {
		Set<Player> players = new HashSet<>();
		for (String pl : getPlayers()) {
			List<String> permissions = this.players.get(pl);
			Player player = BadBlockPvPBox.instance.getServer().getPlayer(pl);
			if (player != null && player.isOnline()) {
				if (pl.equalsIgnoreCase(owner) || (permissions != null && permissions.contains(permission)))
					players.add(player);
			}
		}
		return players;
	}
	
	public static int getOnlineBadTeams() {
		return teams.values().parallelStream().filter(team -> team.getOnlinePlayers().size() > 0).collect(Collectors.toList()).size();
	}
	
	public static List<BadTeam> getOnlineBadTeams(BadTeam withoutTeam) {
		List<BadTeam> t = teams.values().parallelStream().filter(team -> team.getOnlinePlayers().size() > 0).collect(Collectors.toList());
		t.remove(withoutTeam);
		return t;
	}
	
	public static BadTeam getTeam(Player player) {
		if (teams == null) teams = new TreeMap<>(String.CASE_INSENSITIVE_ORDER); 
		for (BadTeam to : teams.values()) {
			if (to.players == null) to.players = new HashMap<>(); 
			if (to.players.containsKey(player.getName())) return to;
		}
		return null;
	}
	
}
