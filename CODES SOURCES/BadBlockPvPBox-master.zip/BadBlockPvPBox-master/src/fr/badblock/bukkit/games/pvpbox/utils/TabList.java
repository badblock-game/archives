package fr.badblock.bukkit.games.pvpbox.utils;

import java.lang.reflect.Field;
import java.util.List;

import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.entity.Player;

import net.md_5.bungee.api.ChatColor;
import net.minecraft.server.v1_8_R3.IChatBaseComponent;
import net.minecraft.server.v1_8_R3.IChatBaseComponent.ChatSerializer;
import net.minecraft.server.v1_8_R3.PacketPlayOutPlayerListHeaderFooter;
import net.minecraft.server.v1_8_R3.PlayerConnection;

public class TabList {
	
	public static void sendTabList(List<String> header, List<String> footer, Player p){
		
		PlayerConnection connection = ((CraftPlayer)p).getHandle().playerConnection;
		try {
			
			Object packet = PacketPlayOutPlayerListHeaderFooter.class.newInstance();
			Object headerobj = StringToChatBase(header);
			Object footerobj = StringToChatBase(footer);
			
			Field headerfield = PacketPlayOutPlayerListHeaderFooter.class.getDeclaredField("a");
			headerfield.setAccessible(true);
			headerfield.set(packet, headerobj);
			headerfield.setAccessible(false);
			
			Field footerfield = PacketPlayOutPlayerListHeaderFooter.class.getDeclaredField("b");
			footerfield.setAccessible(true);
			footerfield.set(packet, footerobj);
			footerfield.setAccessible(false);
			
			connection.sendPacket((PacketPlayOutPlayerListHeaderFooter) packet);
		
		} catch (InstantiationException | IllegalAccessException | NoSuchFieldException e) {
			e.printStackTrace();
		}
	}
	
	private static IChatBaseComponent StringToChatBase(List<String> string){
		if(string == null) return null;
		String lastline = "";
		
		for(int i = 0; i < string.size(); i++){
			
			if((i+1) >= string.size()){
				lastline = lastline + string.get(i);
			} else {
				lastline = lastline + string.get(i)+"\n";
			}
			
		}
		
		return ChatSerializer.a("{\"text\": \"" + ChatColor.translateAlternateColorCodes('&', lastline) + "\"}");
		
	}

}
