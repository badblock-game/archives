package fr.badblock.bukkit.games.pvpbox.listeners;

import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.FoodLevelChangeEvent;

import fr.badblock.bukkit.games.pvpbox.objects.BadPlayer;
import fr.badblock.bukkit.games.pvpbox.objects.GameState;

public class FoodLevelChangeListener implements Listener {
	
	@EventHandler
	public void onFoodLevelChange(FoodLevelChangeEvent event) {
		if (!(event.getEntity().getType().equals(EntityType.PLAYER))) return;
		Player player = (Player) event.getEntity();
		BadPlayer badPlayer = BadPlayer.get(player);
		if (badPlayer.godmode) event.setFoodLevel(20);
		if (badPlayer.gameState.equals(GameState.WAIT)) {
			event.setFoodLevel(20);
		}
	}
	
}
