package fr.badblock.bukkit.games.pvpbox.listeners;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import net.minecraft.server.v1_8_R3.PacketPlayInClientCommand;
import net.minecraft.server.v1_8_R3.PacketPlayInClientCommand.EnumClientCommand;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import fr.badblock.bukkit.games.pvpbox.BadBlockPvPBox;
import fr.badblock.bukkit.games.pvpbox.arenas.Duel;
import fr.badblock.bukkit.games.pvpbox.objects.BadPlayer;

public class PlayerDeathListener implements Listener {
	
	@EventHandler (ignoreCancelled = false)
	public void onPlayerDeath(PlayerDeathEvent event) {
		Player player = event.getEntity();
		
		event.setDeathMessage(null);
		event.setDroppedExp(0);
		Iterator<ItemStack> iterator = event.getDrops().iterator();
		while (iterator.hasNext()) {
			ItemStack itemStack = iterator.next();
			if (itemStack == null) continue;
			if (itemStack.getType() == null) continue;
			if (!BadBlockPvPBox.instance.dropsMaterials.contains(itemStack.getType().name()))
				iterator.remove();
		}
		new BukkitRunnable() {
			public void run() {
				try {
					PacketPlayInClientCommand packet = new PacketPlayInClientCommand(EnumClientCommand.PERFORM_RESPAWN);
					((CraftPlayer)player).getHandle().playerConnection.a(packet);
				} catch (Throwable t) {
					t.printStackTrace();
				}
			}
		}.runTaskLater(BadBlockPvPBox.instance, 1L);
		String prefix = BadBlockPvPBox.instance.permissionsExManager.getPrefix(player);
		BadPlayer badPlayer = BadPlayer.get(player);
		for(Entity entity : Bukkit.getWorld("world").getEntities()){
			if(entity.getUniqueId().equals(badPlayer.enderpearluuid)) entity.remove();
		}
		if (player.getKiller() == null) {
			BadBlockPvPBox.instance.getServer().getOnlinePlayers().forEach(pl -> BadBlockPvPBox.sendActionBar(pl, prefix + player.getName() + " §8est mort."));
			if (badPlayer.getInfos() != null) {
				badPlayer.getInfos().setDeaths(badPlayer.getInfos().getDeaths() + 1);
				if (badPlayer.getInfos().getPoints() > 0) {
					badPlayer.getInfos().setPoints(badPlayer.getInfos().getPoints() - 4);
				}
				badPlayer.updateScores(player);
			}
			player.sendMessage("§cVous êtes mort.");
		}else{
			if (!player.getKiller().getAddress().getHostString().equals(player.getAddress().getHostString())) {
				if (badPlayer.getInfos() != null) {
					badPlayer.getInfos().setDeaths(badPlayer.getInfos().getDeaths() + 1);
					if (badPlayer.getInfos().getPoints() > 0) {
						badPlayer.getInfos().setPoints(badPlayer.getInfos().getPoints() - 4);
					}
					badPlayer.updateScores(player);
				}
				BadPlayer bpKiller = BadPlayer.get(player.getKiller());
				if (bpKiller.getInfos() != null) {
					bpKiller.getInfos().setKills(bpKiller.getInfos().getKills() + 1);
					bpKiller.getInfos().setPoints(bpKiller.getInfos().getPoints() + 2);
					bpKiller.updateScores(player.getKiller());
				}
			}
			String prefix2 = BadBlockPvPBox.instance.permissionsExManager.getPrefix(player.getKiller());
			player.sendMessage("§cVous avez été tué par " + prefix2 + player.getKiller().getName() + "§c.");
			player.getKiller().sendMessage("§aVous avez tué " + prefix + player.getName() + "§a.");
			double o = player.getKiller().getHealth() + 10;
			if (o > player.getKiller().getMaxHealth()) o = player.getKiller().getMaxHealth();
			player.getKiller().setHealth(o);
			BadBlockPvPBox.instance.getServer().getOnlinePlayers().forEach(pl -> BadBlockPvPBox.sendActionBar(pl, prefix + player.getName() + " §8a été tué par " + prefix2 + player.getKiller().getName() + "§8."));
		}
		Duel duel = Duel.get(player);
		if (duel != null) {
			event.getDrops().clear();
			duel.demanderPlayers.remove(player);
			duel.demandedPlayers.remove(player);
			if (badPlayer.getInfos() != null) {
				badPlayer.getInfos().setTeamDeaths(badPlayer.getInfos().getTeamDeaths() + 1);
				badPlayer.updateScores(player);
			}
			badPlayer.updateScores(player);
			if (player.getKiller() != null) {
				duel.sendMessage("§b§l[Duel] §e" + prefix + player.getName() + "§c a été tué par §e" + BadBlockPvPBox.instance.permissionsExManager.getPrefix(player.getKiller()) + player.getKiller().getName());
				BadPlayer bpKiller = BadPlayer.get(player.getKiller());
				if (bpKiller.getInfos() != null) {
					bpKiller.getInfos().setTeamKills(bpKiller.getInfos().getTeamKills() + 1);
					bpKiller.updateScores(player.getKiller());
				}
			}else
				duel.sendMessage("§b§l[Duel] §e" + prefix + player.getName() + "§c est mort.");
			if (duel.launched) {
				if (duel.getDemandedPlayers().size() == 0) {
					List<String> demanderIps = new ArrayList<>();
					List<String> demandedIps = new ArrayList<>();
					duel.demanderPlayersBase.parallelStream().filter(az -> az != null && az.isOnline()).forEach(az -> demanderIps.add(az.getAddress().getHostString()));
					duel.demandedPlayersBase.parallelStream().filter(az -> az != null && az.isOnline()).forEach(az -> demandedIps.add(az.getAddress().getHostString()));
					boolean sameIp = false;
					for (String ip : demanderIps) 
						if (demandedIps.contains(ip)) sameIp = true;
					duel.sendMessage("§b§l[Duel] §aLa team §e" + duel.demanderTeam.name + "§a a gagnée !");
					if (!sameIp) {
						duel.demanderPlayersBase.forEach(plo -> {
							if (plo == null || !plo.isOnline()) return;
							BadPlayer bpl = BadPlayer.get(plo);
							if (bpl.getInfos() != null) {
								bpl.getInfos().setTeamVictories(bpl.getInfos().getTeamVictories() + 1);
								bpl.getInfos().setPoints(bpl.getInfos().getPoints() + duel.demandedPlayersBase.size());
							}	
							bpl.updateScores(plo);
						});
						duel.demandedPlayersBase.forEach(plo -> {
							if (plo == null || !plo.isOnline()) return;
							BadPlayer bpl = BadPlayer.get(plo);
							if (bpl.getInfos() != null) bpl.getInfos().setTeamLooses(bpl.getInfos().getTeamLooses() + 1);
							bpl.updateScores(plo);
						});
					}
					Bukkit.broadcastMessage("§b§l[Duel] §8La team §b" + duel.demanderTeam.name + " §8a vaincue la team §b" + duel.demandedTeam.name + "§8.");
					duel.finish(player);
					return;
				}
				if (duel.getDemanderPlayers().size() == 0) {
					List<String> demanderIps = new ArrayList<>();
					List<String> demandedIps = new ArrayList<>();
					duel.demanderPlayersBase.parallelStream().filter(az -> az != null && az.isOnline()).forEach(az -> demanderIps.add(az.getAddress().getHostString()));
					duel.demandedPlayersBase.parallelStream().filter(az -> az != null && az.isOnline()).forEach(az -> demandedIps.add(az.getAddress().getHostString()));
					boolean sameIp = false;
					for (String ip : demanderIps) 
						if (demandedIps.contains(ip)) sameIp = true;
					if (!sameIp) {
						duel.demandedPlayersBase.forEach(plo -> {
							if (plo == null || !plo.isOnline()) return;
							BadPlayer bpl = BadPlayer.get(plo);
							if (bpl.getInfos() != null) {
								bpl.getInfos().setTeamVictories(bpl.getInfos().getTeamVictories() + 1);
								bpl.getInfos().setPoints(bpl.getInfos().getPoints() + duel.demandedPlayersBase.size());
							}
							bpl.updateScores(plo);
						});
						duel.demanderPlayersBase.forEach(plo -> {
							if (plo == null || !plo.isOnline()) return;
							BadPlayer bpl = BadPlayer.get(plo);
							if (bpl.getInfos() != null) bpl.getInfos().setTeamLooses(bpl.getInfos().getTeamLooses() + 1);
							bpl.updateScores(plo);
						});
					}
					duel.sendMessage("§b§l[Duel] §aLa team §e" + duel.demandedTeam.name + "§a a gagnée !");
					Bukkit.broadcastMessage("§b§l[Duel] §8La team §b" + duel.demandedTeam.name + " §8a vaincue la team §b" + duel.demanderTeam.name + "§8.");
					duel.finish(player);
					return;
				}
			}else{
				if (duel.getDemandedPlayers().size() == 0) {
					duel.sendMessage("§b§l[Duel] §ePlus de joueurs dans une des teams, duel annulé.");
					duel.finish(player);
					return;
				}
				if (duel.getDemanderPlayers().size() == 0) {
					duel.sendMessage("§b§l[Duel] §ePlus de joueurs dans une des teams, duel annulé.");
					duel.finish(player);
					return;
				}
			}
			Bukkit.getScheduler().runTaskLater(BadBlockPvPBox.instance, new Runnable() {
				@Override
				public void run() {
					if (!player.isOnline()) return;
					if (!duel.finish && duel.launched) {
						duel.spectators.add(player);
						player.setGameMode(GameMode.SPECTATOR);
						player.teleport(duel.arenaLocation);
					}
				}
			}, 5);
			return;
		}
	}
	
}
