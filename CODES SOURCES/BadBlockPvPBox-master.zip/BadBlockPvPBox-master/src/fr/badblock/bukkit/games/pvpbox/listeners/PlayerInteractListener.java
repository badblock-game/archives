package fr.badblock.bukkit.games.pvpbox.listeners;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityInteractEvent;
import org.bukkit.event.hanging.HangingBreakEvent;
import org.bukkit.event.player.PlayerArmorStandManipulateEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import fr.badblock.bukkit.games.pvpbox.BadBlockPvPBox;
import fr.badblock.bukkit.games.pvpbox.arenas.Duel;
import fr.badblock.bukkit.games.pvpbox.objects.BadPlayer;
import fr.badblock.bukkit.games.pvpbox.objects.BadTeam;
import fr.badblock.bukkit.games.pvpbox.objects.GameState;

public class PlayerInteractListener implements Listener {
	
	@EventHandler (ignoreCancelled = false, priority = EventPriority.HIGHEST)
	public void onPlayerInteract(PlayerInteractEvent event) {
		Player player = event.getPlayer();
		if (!event.getAction().equals(Action.RIGHT_CLICK_AIR) && !event.getAction().equals(Action.RIGHT_CLICK_BLOCK)) return;
		if (player.getItemInHand() == null) return;
		ItemStack itemStack = player.getItemInHand();
		BadPlayer badPlayer = BadPlayer.get(player);
		if (badPlayer != null) {
			if (badPlayer.gameState.equals(GameState.IN_TEAM_ARENA)) {
				Duel duel = Duel.get(player);
				if (duel == null) return;
				if (!duel.launched && !duel.finish) {
					if (itemStack.getTypeId() == 373 && itemStack.getDurability() >= (short) 16000) {
						event.setCancelled(true);
						player.getInventory().setItem(player.getInventory().getHeldItemSlot(), itemStack);
					}
				}
			}
		}
		BadBlockPvPBox instance = BadBlockPvPBox.instance;
		if (event.getAction().equals(Action.RIGHT_CLICK_BLOCK)) {
			if (player.hasPermission("pvpbox.admin")) {
				if (event.getClickedBlock().getType().equals(Material.STAINED_CLAY)) {
					BadPlayer.get(player).block = event.getClickedBlock();
					player.sendMessage("§aBloc sélectionné.");
				}
			}else if (event.getClickedBlock().getType().equals(Material.TRAP_DOOR)) {
				event.setCancelled(true);
				return;
			}
		}
		if(itemStack.getType().equals(Material.ENDER_PEARL)){
			if (badPlayer.enderpearlExpire > System.currentTimeMillis()) {
				player.sendMessage("§cVous devez patienter 5 secondes entre chaque enderpearl !");
			} else {
				badPlayer.enderpearlExpire = System.currentTimeMillis() + 5000;
				int amount = player.getItemInHand().getAmount();
				event.setCancelled(true);
				Bukkit.getScheduler().runTaskLaterAsynchronously(BadBlockPvPBox.instance, new Runnable() {
					@Override
					public void run() {
						player.getInventory().setItemInHand(new ItemStack(Material.ENDER_PEARL, amount));
					}
				}, 1L);
			}
		}
		if (instance.hubBackItem.equals(itemStack)) {
			event.setCancelled(true);
			instance.getServer().dispatchCommand(player, "hub");
			return;
		}
		if (instance.kitItem.equals(itemStack)) {
			event.setCancelled(true);
			player.openInventory(instance.boxKitSelectorInventory);
			return;
		}
		if (itemStack.getType().equals(Material.SKULL_ITEM)) {
			event.setCancelled(true);
			BadTeam team = BadTeam.getTeam(player);
			if (team == null) {
				player.sendMessage("§cVous devez être dans une team pour pouvoir faire un match de team.");
				player.sendMessage("§eUtilisez /team pour plus d'informations.");
				return;
			}
			if (BadTeam.getOnlineBadTeams() == 1) {
				player.sendMessage("§cSeule votre team est connectée, vous ne pouvez pas faire un match de team.");
				return;
			}
			int size = BadTeam.getOnlineBadTeams() < 9 ? 1 : BadTeam.getOnlineBadTeams() / 9 + 1;
			Inventory inventory = Bukkit.createInventory(null, size * 9, "§9Sélectionnez vos adversaires");
			BadTeam.getOnlineBadTeams(team).forEach(t -> {
				if (t.equals(team)) return;
				if (inventory.getContents().length >= 54) return;
				ItemStack item = new ItemStack(Material.SKULL_ITEM, t.getOnlinePlayers().size() == 1 ? -1 : t.getOnlinePlayers().size(), (byte) 3);
				SkullMeta smeta = (SkullMeta) item.getItemMeta();
				smeta.setOwner(t.owner);
				item.setItemMeta(smeta);
				smeta.setDisplayName("§6" + t.name);
				List<String> lore = new ArrayList<>();
				lore.add("");
				lore.add("§cTeam administrée par " + t.owner);
				lore.add("");
				lore.add("§e--------------------------");
				if (t.getOnlinePlayers().size() == team.getOnlinePlayers().size()) 
					lore.add("§aVous pouvez combattre avec cette team.");
				else lore.add("§cTeam non équilibrée en joueurs par rapport à vous.");
				lore.add("§e--------------------------");
				lore.add("");
				String plurial = t.getOnlinePlayers().size() >= 2 ? "s" :"";
				lore.add("§aJoueur" + plurial + " connecté" + plurial + " :");
				for (Player plo : t.getOnlinePlayers())
					lore.add("§a- " + plo.getName());
				lore.add("");
				plurial = t.getOfflinePlayers().size() >= 2 ? "s" :"";
				lore.add("§cJoueur" + plurial + " déconnecté" + plurial + " :");
				for (String plo : t.getOfflinePlayers())
					lore.add("§a- " + plo);
				smeta.setLore(lore);
				item.setItemMeta(smeta);
				inventory.addItem(item);
			});
			player.openInventory(inventory);
			return;
		}
	}
	
	@EventHandler (priority = EventPriority.MONITOR, ignoreCancelled = true)
	public void soilChangePlayer(PlayerInteractEvent event) {
		if (event.getAction().equals(Action.PHYSICAL) && event.getClickedBlock().getType().equals(Material.SOIL)) {
			event.setCancelled(true);
		}
	}
	
	@EventHandler
	public void onArmorStandManipulate(PlayerArmorStandManipulateEvent event) {
		if (event.getPlayer().hasPermission("pvpbox.admin")) return;
		event.setCancelled(true);
	}
	
	@EventHandler (priority = EventPriority.MONITOR, ignoreCancelled = true)
	public void soilChangeEntity(EntityInteractEvent event) {
		if (!event.getEntityType().equals(EntityType.PLAYER) && event.getBlock().getType().equals(Material.SOIL)) {
			event.setCancelled(true);
		}
	}
	
	@EventHandler
	public void onPlayerInteractEntity(PlayerInteractEntityEvent event) {
		if (event.getPlayer().hasPermission("pvpbox.admin")) return;
		EntityType type = event.getRightClicked().getType();
		if (type.equals(EntityType.ARMOR_STAND) || type.equals(EntityType.PAINTING) || type.equals(EntityType.ITEM_FRAME))
			event.setCancelled(true);
	}
	
	@EventHandler
	public void onHangingBreak(HangingBreakEvent event) {
		EntityType type = event.getEntity().getType();
		if (type.equals(EntityType.ARMOR_STAND) || type.equals(EntityType.PAINTING) || type.equals(EntityType.ITEM_FRAME))
			event.setCancelled(true);
	}
	
}
