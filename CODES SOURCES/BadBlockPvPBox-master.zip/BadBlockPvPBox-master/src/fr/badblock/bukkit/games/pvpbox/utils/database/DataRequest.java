package fr.badblock.bukkit.games.pvpbox.utils.database;

import java.sql.ResultSet;

import lombok.Getter;

public class DataRequest {
	
	@Getter String 	 query;
	@Getter DataType type;
	
	public DataRequest(String query, DataType type) {
		this.query = query;
		this.type = type;
	}
	
	public void callback(ResultSet resultSet) {
		
	}
	
}
