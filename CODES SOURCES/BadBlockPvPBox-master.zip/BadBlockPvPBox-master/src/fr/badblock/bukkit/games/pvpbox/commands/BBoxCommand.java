package fr.badblock.bukkit.games.pvpbox.commands;

import java.io.IOException;
import java.util.UUID;

import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffectType;

import fr.badblock.bukkit.games.pvpbox.BadBlockPvPBox;
import fr.badblock.bukkit.games.pvpbox.objects.BadPlayer;
import fr.badblock.bukkit.games.pvpbox.objects.Statue;
import fr.badblock.bukkit.games.pvpbox.utils.ConfigUtils;

public class BBoxCommand implements CommandExecutor {
	
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String arg, String[] args) {
		if (!(sender instanceof Player)) return false;
		Player player = (Player) sender;
		if (!player.hasPermission("pvpbox.admin")) return false;
		if (args.length == 0) return true;
		if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
			BadBlockPvPBox.instance.reloadConfig();
			sender.sendMessage("§aConfiguration rechargée avec succès.");
			return true;
		}
		if (args.length == 1 && args[0].equalsIgnoreCase("save")) {
			BadBlockPvPBox.instance.saveConfig();
			sender.sendMessage("§aConfiguration sauvegardée avec succès.");
			return true;
		}
		if (args.length == 1 && args[0].equalsIgnoreCase("addspawn")) {
			BadBlockPvPBox.instance.reloadConfig();
			BadBlockPvPBox.instance.pvpArenaTeleportLocations.add(player.getLocation());
			player.sendMessage("§aPoint de téléportation ajouté.");
			ConfigUtils.saveLocationList(BadBlockPvPBox.instance, BadBlockPvPBox.instance.pvpArenaTeleportLocations, "pvpArenaTeleportLocations", BadBlockPvPBox.instance.locations, BadBlockPvPBox.instance.locationsfile);
			try {
				BadBlockPvPBox.instance.locationsfile.save(BadBlockPvPBox.instance.locations);
			} catch (IOException e) {
				e.printStackTrace();
			}
			return true;
		}
		if (args.length == 1 && args[0].equalsIgnoreCase("addarena")) {
			BadBlockPvPBox.instance.reloadConfig();
			BadBlockPvPBox.instance.teamArenaTeleportLocations.add(player.getLocation());
			player.sendMessage("§aPoint de téléportation à cette arène ajouté.");
			ConfigUtils.saveLocationList(BadBlockPvPBox.instance, BadBlockPvPBox.instance.teamArenaTeleportLocations, "teamArenaTeleportLocations", BadBlockPvPBox.instance.locations, BadBlockPvPBox.instance.locationsfile);
			try {
				BadBlockPvPBox.instance.locationsfile.save(BadBlockPvPBox.instance.locations);
			} catch (IOException e) {
				e.printStackTrace();
			}
			return true;
		}
		if (args.length == 1 && args[0].equalsIgnoreCase("addmaterial")) {
			if (player.getItemInHand() == null || player.getItemInHand().getType() == null || player.getItemInHand().getType().equals(Material.AIR)) {
				player.sendMessage("§cAucun item.");
				return true;
			}
			Material material = player.getItemInHand().getType();
			if (BadBlockPvPBox.instance.dropsMaterials.contains(material.name())) {
				player.sendMessage("§cVous avez déjà cet item dans la liste");
				return true;
			}
			BadBlockPvPBox.instance.dropsMaterials.add(material.name());
			BadBlockPvPBox.instance.gameplayfile.set("dropsMaterials", BadBlockPvPBox.instance.dropsMaterials);
			player.sendMessage("§aItem ajouté (" + material.name() + ").");
			try {
				BadBlockPvPBox.instance.gameplayfile.save(BadBlockPvPBox.instance.gameplay);
			} catch (IOException e) {
				e.printStackTrace();
			}
			return true;
		}
		if (args.length >= 1 && args[0].equalsIgnoreCase("createstatue")) {
			// ARGS: /bbox createstatue <EFFECT> <BOOSTER> <BLOCKS>
			if (args.length != 4) {
				player.sendMessage("§cUtilisation: /bbox createstatue <EFFECT> <BOOSTER> <RADIUS>");
				return true;
			}
			UUID uuid = UUID.randomUUID();
			PotionEffectType effectType;
			try {
				effectType = PotionEffectType.getByName(args[1]);
				if (effectType == null) {
					player.sendMessage("§cEffet inconnu.");
					return true;
				}
			}catch(Exception error) {
				player.sendMessage("§cEffet inconnu.");
				return true;
			}
			BadPlayer badPlayer = BadPlayer.get(player);
			if (badPlayer.block == null) {
				player.sendMessage("§cAucun bloc cliqué.");
				return true;
			}
			int booster = -1;
			try {
				booster = Integer.parseInt(args[2]);
			}catch(Exception error) {
				player.sendMessage("§cLe booster doit être un nombre.");
				return true;
			}
			int radius = -1;
			try {
				radius = Integer.parseInt(args[3]);
			}catch(Exception error) {
				player.sendMessage("§cLe radius doit être un nombre.");
				return true;
			}
			new Statue("§f" + effectType.getName().toLowerCase(), uuid, effectType, badPlayer.block.getLocation(), booster, radius);
			FileConfiguration config = BadBlockPvPBox.instance.gameplayfile;
			config.set("statues." + uuid, "");
			config.set("statues." + uuid + ".name", effectType.getName().toLowerCase());
			config.set("statues." + uuid + ".effect", effectType.getName());
			config.set("statues." + uuid + ".center", ConfigUtils.convertLocationBlockToString(badPlayer.block.getLocation()));
			config.set("statues." + uuid + ".booster", booster);
			config.set("statues." + uuid + ".radius", radius);
			try {
				config.save(BadBlockPvPBox.instance.gameplay);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			player.sendMessage("§aStatue " + uuid.toString() + " créée.");
			return true;
		}
		return false;
	}
	
}
