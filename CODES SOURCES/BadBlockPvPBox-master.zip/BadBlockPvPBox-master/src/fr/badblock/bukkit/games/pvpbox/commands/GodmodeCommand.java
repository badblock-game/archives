package fr.badblock.bukkit.games.pvpbox.commands;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import fr.badblock.bukkit.games.pvpbox.BadBlockPvPBox;
import fr.badblock.bukkit.games.pvpbox.arenas.Duel;
import fr.badblock.bukkit.games.pvpbox.objects.BadPlayer;
import fr.badblock.bukkit.games.pvpbox.objects.GameState;

public class GodmodeCommand implements CommandExecutor {
	
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String arg, String[] args) {
		if (!(sender instanceof Player)) return false;
		Player player = (Player) sender;
		BadPlayer badPlayer = BadPlayer.get(player);
		if (!player.hasPermission("pvpbox.godmode")) {
			player.sendMessage("§cVous n'avez pas la permission.");
			return true;
		}
		if (badPlayer.godmode) {
			badPlayer.godmode = false;
			player.sendMessage("§cGodemode désactivé.");
		}else{
			badPlayer.godmode = true;
			player.setHealth(player.getMaxHealth());
			player.setFoodLevel(20);
			player.sendMessage("§aGodemode activé.");
		}
		return true;
	}
	
}
