package fr.badblock.bukkit.games.pvpbox.listeners;

import org.bukkit.entity.EnderPearl;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.projectiles.ProjectileSource;

import fr.badblock.bukkit.games.pvpbox.arenas.Duel;
import fr.badblock.bukkit.games.pvpbox.objects.BadPlayer;
import fr.badblock.bukkit.games.pvpbox.objects.GameState;

public class ProjectileLaunchListener implements Listener {
	
	@EventHandler
	public void onProjectileLaunch(ProjectileLaunchEvent event) {
		ProjectileSource source = event.getEntity().getShooter();
		if (source == null) return;
		if (!(source instanceof Player)) return;
		Player player = (Player) source;
		BadPlayer badPlayer = BadPlayer.get(player);
		if (badPlayer == null) return;
		if (!badPlayer.gameState.equals(GameState.IN_TEAM_ARENA)) return;
		Duel duel = Duel.get(player);
		if (duel == null) return;
		if (!duel.launched && !duel.finish) {
			event.setCancelled(true);
		}
	}
	
	@EventHandler
	public void onProjectile(ProjectileLaunchEvent e){
				
		if(!(e.getEntity() instanceof EnderPearl)) return;
		if(!(e.getEntity().getShooter() instanceof Player)) return;
		
		Player p = (Player) e.getEntity().getShooter();
		BadPlayer badPlayer = BadPlayer.get(p);
		
		badPlayer.enderpearluuid = e.getEntity().getUniqueId();

	}
	
//	private boolean isValidBlock(int y) {
//		return y != -1;
//	}
	
}
