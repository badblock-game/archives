package fr.badblock.bukkit.games.pvpbox.listeners;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

import fr.badblock.bukkit.games.pvpbox.BadBlockPvPBox;
import fr.badblock.bukkit.games.pvpbox.arenas.Duel;
import fr.badblock.bukkit.games.pvpbox.objects.BadPlayer;
import fr.badblock.bukkit.games.pvpbox.objects.BadTeam;

public class PlayerQuitListener implements Listener {
	
	@EventHandler
	public void onPlayerQuit(PlayerQuitEvent event) {
		Player player = event.getPlayer();
		event.setQuitMessage(null);
		BadPlayer badPlayer = BadPlayer.get(player);
		
		if(badPlayer.timedeco != 0){
			if(badPlayer.timedeco > System.currentTimeMillis()){
				badPlayer.getInfos().setDeaths(badPlayer.getInfos().getDeaths() + 1);
			}
		}
		BadTeam team = BadTeam.getTeam(player);
		if (team != null)
			team.getOnlinePlayers().forEach(plo -> {
				plo.sendMessage("§b§l[Team] §e" + player.getName() + " s'est déconnecté(e).");
				BadPlayer.get(plo).updateScores(plo);
			});
		badPlayer.remove();
		Duel duel = Duel.get(player);
		if (duel != null) {
			duel.demanderPlayers.remove(player);
			duel.demandedPlayers.remove(player);
			String prefix = BadBlockPvPBox.instance.permissionsExManager.getPrefix(player);
			duel.sendMessage("§b§l[Duel] §e" + prefix + player.getName() + "§c a déconnecté(e).");
			if (duel.launched) {
				if (duel.getDemandedPlayers().size() == 0) {List<String> demanderIps = new ArrayList<>();
				List<String> demandedIps = new ArrayList<>();
				duel.demanderPlayersBase.parallelStream().filter(az -> az != null && az.isOnline()).forEach(az -> demanderIps.add(az.getAddress().getHostString()));
				duel.demandedPlayersBase.parallelStream().filter(az -> az != null && az.isOnline()).forEach(az -> demandedIps.add(az.getAddress().getHostString()));
				boolean sameIp = false;
				for (String ip : demanderIps) 
					if (demandedIps.contains(ip)) sameIp = true;
				duel.sendMessage("§b§l[Duel] §aLa team §e" + duel.demanderTeam.name + "§a a gagnée !");
				if (!sameIp) {
					duel.demanderPlayersBase.forEach(plo -> {
						if (plo == null || !plo.isOnline()) return;
						BadPlayer bpl = BadPlayer.get(plo);
						if (bpl.getInfos() != null) {
							bpl.getInfos().setTeamVictories(bpl.getInfos().getTeamVictories() + 1);
							badPlayer.getInfos().setPoints(badPlayer.getInfos().getPoints() + duel.demandedPlayersBase.size());
						}
						bpl.updateScores(plo);
					});
					duel.demandedPlayersBase.forEach(plo -> {
						if (plo == null || !plo.isOnline()) return;
						BadPlayer bpl = BadPlayer.get(plo);
						if (bpl.getInfos() != null) bpl.getInfos().setTeamLooses(bpl.getInfos().getTeamLooses() + 1);
						bpl.updateScores(plo);
					});
				}
				Bukkit.broadcastMessage("§b§l[Duel] §8La team §b" + duel.demanderTeam.name + " §8a vaincue la team §b" + duel.demandedTeam.name + "§8.");
				duel.finish(player);
				}
				if (duel.getDemanderPlayers().size() == 0) {
					List<String> demanderIps = new ArrayList<>();
					List<String> demandedIps = new ArrayList<>();
					duel.demanderPlayersBase.parallelStream().filter(az -> az != null && az.isOnline()).forEach(az -> demanderIps.add(az.getAddress().getHostString()));
					duel.demandedPlayersBase.parallelStream().filter(az -> az != null && az.isOnline()).forEach(az -> demandedIps.add(az.getAddress().getHostString()));
					boolean sameIp = false;
					for (String ip : demanderIps) 
						if (demandedIps.contains(ip)) sameIp = true;
					if (!sameIp) {
						duel.demandedPlayersBase.forEach(plo -> {
							if (plo == null || !plo.isOnline()) return;
							BadPlayer bpl = BadPlayer.get(plo);
							if (bpl.getInfos() != null) {
								bpl.getInfos().setTeamVictories(bpl.getInfos().getTeamVictories() + 1);
								badPlayer.getInfos().setPoints(badPlayer.getInfos().getPoints() + duel.demandedPlayersBase.size());
							}
							bpl.updateScores(plo);
						});
						duel.demanderPlayersBase.forEach(plo -> {
							if (plo == null || !plo.isOnline()) return;
							BadPlayer bpl = BadPlayer.get(plo);
							if (bpl.getInfos() != null) bpl.getInfos().setTeamLooses(bpl.getInfos().getTeamLooses() + 1);
							bpl.updateScores(plo);
						});
					}
					duel.sendMessage("§b§l[Duel] §aLa team §e" + duel.demandedTeam.name + "§a a gagnée !");
					Bukkit.broadcastMessage("§b§l[Duel] §8La team §b" + duel.demandedTeam.name + " §8a vaincue la team §b" + duel.demanderTeam.name + "§8.");
					duel.finish(player);
				}
			}else{
				if (duel.getDemandedPlayers().size() == 0) {
					duel.sendMessage("§b§l[Duel] §ePlus de joueurs dans une des teams, duel annulé.");
					duel.finish(player);
				}
				if (duel.getDemanderPlayers().size() == 0) {
					duel.sendMessage("§b§l[Duel] §ePlus de joueurs dans une des teams, duel annulé.");
					duel.finish(player);
				}
			}
			duel.demanderPlayers.remove(player);
			duel.demandedPlayers.remove(player);
		}
		return;
	}
}

