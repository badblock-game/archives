package fr.badblock.bukkit.games.pvpbox.listeners;

import net.minecraft.server.v1_8_R3.PacketPlayInClientCommand;
import net.minecraft.server.v1_8_R3.PacketPlayInClientCommand.EnumClientCommand;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.painting.PaintingBreakEvent;
import org.bukkit.scheduler.BukkitRunnable;

import fr.badblock.bukkit.games.pvpbox.BadBlockPvPBox;
import fr.badblock.bukkit.games.pvpbox.arenas.Duel;

public class PaintingBreakListener implements Listener {
	
	@EventHandler (ignoreCancelled = false)
	public void onPaintingBreak(PaintingBreakEvent event) {
		event.setCancelled(true);
	}
	
}
