package fr.badblock.bukkit.games.pvpbox.utils;

import org.bukkit.scheduler.BukkitTask;

public class TempScheduler {
	
	public BukkitTask task;
	
}
