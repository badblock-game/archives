package fr.badblock.bukkit.games.pvpbox.objects;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class ChatData {
	
	public String playerName;
	public String message;

}
