package fr.badblock.bukkit.games.pvpbox.commands;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import net.minecraft.server.v1_8_R3.ChatClickable;
import net.minecraft.server.v1_8_R3.ChatClickable.EnumClickAction;
import net.minecraft.server.v1_8_R3.ChatMessage;
import net.minecraft.server.v1_8_R3.ChatModifier;
import net.minecraft.server.v1_8_R3.IChatBaseComponent;
import net.minecraft.server.v1_8_R3.MinecraftServer;
import net.minecraft.server.v1_8_R3.PlayerList;

import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import fr.badblock.bukkit.games.pvpbox.BadBlockPvPBox;
import fr.badblock.bukkit.games.pvpbox.arenas.Duel;
import fr.badblock.bukkit.games.pvpbox.objects.BadPlayer;
import fr.badblock.bukkit.games.pvpbox.objects.BadTeam;
import fr.badblock.bukkit.games.pvpbox.objects.GameState;

public class DuelCommand implements CommandExecutor {
	
	public static String prefix = "§b§l[Duel] §f";
	
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String arg, String[] args) {
		if (!(sender instanceof Player)) return false;
		Player player = (Player) sender;
		BadPlayer badPlayer = BadPlayer.get(player);
		if (args.length == 0 || (args.length == 1 && args[0].equalsIgnoreCase("help"))) {
			player.sendMessage("§8§l«§b§l-§8§l»§m------§f§8§l«§b§l-§8§l»§b §b§lDuels §8§l«§b§l-§8§l»§m------§f§8§l«§b§l-§8§l»");
			player.sendMessage("§c> §6/duel §bhelp §6: liste des commandes");
			player.sendMessage("§c> §6/duel §b<nom> §6: envoyer une requête de duel à une team");
			player.sendMessage("§c> §6/duel §baccept <nom> §6: accepter à rejoindre une team");
			player.sendMessage("§8§l«§b§l-§8§l»§m--------------------------§f§8§l«§b§l-§8§l»§b");
		}else{
			if (args.length >= 1 && args[0].equalsIgnoreCase("accept")) {
				if (args.length != 2) {
					player.sendMessage(prefix + "§cUtilisation: /team accept <nom>");
					return true;
				}
				accept(player, args[1]);
			}else if (args.length >= 1) {
				invite(player, args[0]);
			}
		}
		return true;
	}
	
	
	public void invite(Player player, String name) {
		BadTeam team = BadTeam.getTeam(player);
		if (team == null) {
			player.sendMessage(prefix + "§cVous n'êtes pas dans une team.");
			return;
		}
		BadTeam otherTeam = BadTeam.teams.get(name);
		if (otherTeam == null) {
			player.sendMessage(prefix + "§cCette team n'existe pas.");
			return;
		}
		if (team.name.equalsIgnoreCase(name)) {
			player.sendMessage(prefix + "§cLa schizophrénie est prohibée sur ce serveur.");
			return;
		}
		if (!team.hasPermission(player, "duel")) {
			player.sendMessage(prefix + "§cVous n'avez pas la permission de provoquer un duel.");
			return;
		}
		if (team.getWaitingTeamsDuel().contains(name)) {
			player.sendMessage(prefix + "§cCette team a déjà reçue une invitation de votre part qui est en attente de validation par celle-ci.");
			return;
		}
		if (team.getOnlinePlayersInDuel().size() > 0) {
			player.sendMessage(prefix + "§cVotre team est déjà dans un duel.");
			return;
		}
		if (otherTeam.getOnlinePlayersInDuel().size() > 0) {
			player.sendMessage(prefix + "§cCette team est déjà dans un duel.");
			return;
		}
		if (team.getOnlinePlayers().size() != otherTeam.getOnlinePlayers().size()) {
			player.sendMessage(prefix + "§cVotre team n'est pas équilibrée en joueurs par rapport à celle que vous essayer de combattre.");
			return;
		}
		Set<Player> players = otherTeam.getOnlinePlayers("duelaccept");
		if (players.size() == 0) {
			player.sendMessage(prefix + "§cAucune personne connectée pouvant accepter votre requête dans cette team.");
			return;
		}
		if (otherTeam.getWaitingTeamsDuel().contains(team.name)) {
			player.getServer().dispatchCommand(player, "duel accept " + name);
			return;
		}
		List<Player> okPlayers = new ArrayList<>(team.getOnlinePlayers());
		okPlayers.addAll(otherTeam.getOnlinePlayers());
		for (Player pl : okPlayers) {
			if (!BadPlayer.players.containsKey(pl.getUniqueId())) continue;
			if (!pl.isOnline()) continue;
			if (!BadPlayer.get(pl).gameState.equals(GameState.WAIT)) {
				player.sendMessage("§cUn des joueurs est actuellement en zone de jeu, vous ne pouvez pas provoquer le duel.");
				return;
			}
		}
		for (Player pl : players) {
			pl.sendMessage(prefix + "§eLa team §b" + team.name + " §evous invite à combattre.");
			IChatBaseComponent base = new ChatMessage(prefix + "§8§l[§b§lAccepter§8§l]");
			base.setChatModifier(new ChatModifier());
			base.getChatModifier().setChatClickable(new ChatClickable(EnumClickAction.RUN_COMMAND, "/duel accept " + team.name));
			PlayerList list = MinecraftServer.getServer().getPlayerList();
			list.getPlayer(pl.getName()).sendMessage(base);
		}
		team.getWaitingTeamsDuel().add(otherTeam.name);
		team.getOnlinePlayers().forEach(plo -> plo.sendMessage(prefix + "§e" + player.getName() + " a envoyé une invitation de duel à la team " + otherTeam.name + "."));
	}
	
	public void accept(Player player, String name) {
		BadTeam team = BadTeam.getTeam(player);
		if (team == null) {
			player.sendMessage(prefix + "§cVous n'êtes pas dans une team.");
			return;
		}
		if (!team.hasPermission(player, "duelaccept")) {
			player.sendMessage(prefix + "§cVous n'avez pas la permission d'accepter un duel.");
			return;
		}
		BadTeam otherTeam = BadTeam.teams.get(name);
		if (otherTeam == null) {
			player.sendMessage(prefix + "§cCette team n'existe pas.");
			return;
		}
		if (!otherTeam.getWaitingTeamsDuel().contains(team.name)) {
			player.sendMessage(prefix + "§cRequête expirée ou inexistante.");
			return;
		}
		if (team.getOnlinePlayersInDuel().size() > 0) {
			player.sendMessage(prefix + "§cVotre team est déjà dans un duel.");
			return;
		}
		if (otherTeam.getOnlinePlayersInDuel().size() > 0) {
			player.sendMessage(prefix + "§cCette team est déjà dans un duel.");
			return;
		}
		if (otherTeam.getOnlinePlayers().size() != team.getOnlinePlayers().size()) {
			player.sendMessage(prefix + "§cCette team n'est plus équilibrée par rapport à la votre.");
			return;
		}
		otherTeam.getWaitingTeamsDuel().remove(team.name);
		team.getOnlinePlayers().forEach(plo -> plo.sendMessage(prefix + "§e" + player.getName() + " a accepté l'invitation de duel contre la team " + otherTeam.name + "."));
		Location freeArena = Duel.getFreeArena();
		if (freeArena == null) {
			player.sendMessage("§cAucune arène libre, veuillez réessayer ultérieurement.");
			return;
		}
		new Duel(otherTeam, team, freeArena);
		List<Player> players = new ArrayList<>(team.getOnlinePlayers());
		players.addAll(otherTeam.getOnlinePlayers());
		for (Player pl : players) {
			if (!BadPlayer.players.containsKey(pl.getUniqueId())) continue;
			if (!pl.isOnline()) continue;
			if (!BadPlayer.get(pl).gameState.equals(GameState.WAIT)) {
				player.sendMessage("§cUn des joueurs est actuellement en zone de jeu, vous ne pouvez pas accepter le duel.");
				return;
			}
		}
		for (Player pl : players) 
			pl.openInventory(BadBlockPvPBox.instance.teamKitSelectorInventory);
	}
	
}
