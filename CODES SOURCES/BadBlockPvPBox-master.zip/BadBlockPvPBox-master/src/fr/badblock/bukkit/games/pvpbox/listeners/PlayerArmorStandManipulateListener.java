package fr.badblock.bukkit.games.pvpbox.listeners;

import org.bukkit.GameMode;
import org.bukkit.entity.EntityType;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerArmorStandManipulateEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;

public class PlayerArmorStandManipulateListener implements Listener{
	
	@EventHandler
	public void onInteract(PlayerArmorStandManipulateEvent e){
		
		if(!(e.getPlayer().getGameMode() == GameMode.CREATIVE)){
			e.setCancelled(true);
		}
		
	}
	
	@EventHandler
	public void onInteractItemFrame(PlayerInteractEntityEvent e){
		if(e.getRightClicked().getType().equals(EntityType.ITEM_FRAME)) e.setCancelled(true);
	}

}
