package fr.badblock.bukkit.games.pvpbox.commands;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import fr.badblock.bukkit.games.pvpbox.objects.BadPlayer;

public class VanishCommand extends AbstractCommand implements Listener {
	
	private static List<String> vanishedPlayers = new ArrayList<String>();
	
	public static boolean isVanished(Entity e){
		if(e instanceof Player)
			return vanishedPlayers.contains(e.getName());
		else return false;
	}
	
	public static void setVanished(Player p, boolean vanished){
		if(vanished){
			vanishedPlayers.add(p.getName());
			for(Player pls : Bukkit.getOnlinePlayers()){
				pls.hidePlayer(p);
			}
			BadPlayer.get(p).vanish = true;
			p.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, Integer.MAX_VALUE, 0));
		} else {
			
			for(Player pls : Bukkit.getOnlinePlayers()){
				pls.showPlayer(p);
			}
			BadPlayer.get(p).vanish = false;
			vanishedPlayers.remove(p.getName());
			for(PotionEffect effect : p.getActivePotionEffects()){
				if(effect.getType().equals(PotionEffectType.INVISIBILITY)){
					p.removePotionEffect(effect.getType());
				}
			}
			
		}
	}

	@EventHandler
	public void onConnect(PlayerJoinEvent e){
		Player p = e.getPlayer();
		BadPlayer.get(p).vanish = false;
		for(Player pl : Bukkit.getOnlinePlayers()){
			p.showPlayer(pl);
		}
		for(String name : vanishedPlayers){
			Player pl = Bukkit.getPlayer(name);
			p.hidePlayer(pl);
		}
	}
	@EventHandler
	public void onDisconnect(PlayerQuitEvent e){
		BadPlayer.get(e.getPlayer()).vanish = false;
		if(isVanished(e.getPlayer())){
			vanishedPlayers.remove(e.getPlayer().getName());
		}
	}

	public VanishCommand() {
		super("pvpbox.vanish", "%gold%Utilisation : /vanish (<player>)", true);
	}

	@Override
	public void run(CommandSender sender, String[] args) {
		Player concerned = null;
		if(args.length == 0 && !(sender instanceof Player)){
			sendHelp(sender);
		} else if(args.length > 0){
			concerned = Bukkit.getPlayer(args[0]);
		} else {
			concerned = (Player) sender;
		}
		if(concerned == null){
			sendMessage(sender, "%red%Le joueur " + args[0] + " est introuvable.");
		} else {
			if(!isVanished(concerned)){
				setVanished(concerned, true);
				
				sendMessage(concerned, "%gold%Vous êtes maintenant invisible.");
				if(args.length > 0){
					sendMessage(sender, "%gold%" + concerned.getName() + " est maintenant invisible%gold%.");
				}
			} else {
				setVanished(concerned, false);

				sendMessage(concerned, "%gold%Vous êtes maintenant visible.");
				if(args.length > 0){
					sendMessage(sender, "%gold%" + concerned.getName() + " est maintenant visible%gold%.");
				}
			}
		}
	}
}