package fr.badblock.bukkit.games.pvpbox.utils.database;

import java.lang.Thread.State;
import java.sql.ResultSet;
import java.sql.Statement;

import com.google.gson.reflect.TypeToken;

import fr.badblock.bukkit.games.pvpbox.BadBlockPvPBox;
import fr.badblock.bukkit.games.pvpbox.objects.BadTeam;
import fr.badblock.bukkit.games.pvpbox.utils.LoggerUtils;

public class Database2Manager {
	
	public static void sendQuery(DataRequest dataRequest) {
		Badblock2Database.getInstance().request.add(dataRequest);
		if (Badblock2Database.getInstance().thread != null && Badblock2Database.getInstance().thread.getState() != null && Badblock2Database.getInstance().thread.getState().equals(State.WAITING))
			synchronized (Badblock2Database.getInstance().thread) {
				Badblock2Database.getInstance().thread.notify();
			}
	}
	
	public static String secure(java.sql.Connection link, String str) throws Exception {
		if (str == null) {
			return null;
		}
		
		if (str.replaceAll("[a-zA-Z0-9_!@#$%^&*()-=+~.;:,\\Q[\\E\\Q]\\E<>{}\\/? ]","").length() < 1) {
			return str;
		}
		
		String clean_string = str;
		clean_string = clean_string.replaceAll("\\\\", "\\\\\\\\");
		clean_string = clean_string.replaceAll("\\n","\\\\n");
		clean_string = clean_string.replaceAll("\\r", "\\\\r");
		clean_string = clean_string.replaceAll("\\t", "\\\\t");
		clean_string = clean_string.replaceAll("\\00", "\\\\0");
		clean_string = clean_string.replaceAll("'", "\\\\'");
		clean_string = clean_string.replaceAll("\\\"", "\\\\\"");
		
		if (clean_string.replaceAll("[a-zA-Z0-9_!@#$%^&*()-=+~.;:,\\Q[\\E\\Q]\\E<>{}\\/?\\\\\"' ]"
				,"").length() < 1) 
		{
			return clean_string;
		}
		
		java.sql.Statement stmt = link.createStatement();
		String qry = "SELECT QUOTE('"+clean_string+"')";
		
		stmt.executeQuery(qry);
		java.sql.ResultSet resultSet = stmt.getResultSet();
		resultSet.first();
		String r = resultSet.getString(1);
		return r.substring(1,r.length() - 1);       
	}
	
	public static void load(String hostname, int port, String username, String password, String database) {
		LoggerUtils.logWithColor("§e[PvPBox] §dLoading others database...");
		Badblock2Database dbInstance = Badblock2Database.getInstance();
		dbInstance.connect(hostname, port, username, password, database);
		// Create threads
		/*threads = new ArrayList<>();
		threads.addAll(createThreads(16));*/
	}
	
}
