package fr.badblock.bukkit.games.pvpbox.commands;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

import fr.badblock.bukkit.games.pvpbox.BadBlockPvPBox;
import fr.badblock.bukkit.games.pvpbox.kits.Kit;
import fr.badblock.bukkit.games.pvpbox.kits.KitItem;

public class CreateKitCommand implements CommandExecutor {

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String arg, String[] args) {
		if (!(sender instanceof Player)) return false;
		Player player = (Player) sender;
		if (!player.hasPermission("pvpbox.admin")) return false;
		BadBlockPvPBox instance = BadBlockPvPBox.instance;
		FileConfiguration config = instance.kitsfile;
		List<KitItem> items = new ArrayList<>();
		int i = -1;
		for (ItemStack itemStack : player.getInventory().getContents()) {
			i++;
			if (itemStack == null) continue;
			if (itemStack.getType().equals(Material.AIR)) continue;
			items.add(new KitItem(i, itemStack));
		}
		PlayerInventory inventory = player.getInventory();
		if (inventory.getHelmet() != null) items.add(new KitItem(103, inventory.getHelmet()));
		if (inventory.getChestplate() != null) items.add(new KitItem(102, inventory.getChestplate()));
		if (inventory.getLeggings() != null) items.add(new KitItem(101, inventory.getLeggings()));
		if (inventory.getBoots() != null) items.add(new KitItem(100, inventory.getBoots()));
		Kit kit = new Kit(0, true, Material.DIAMOND_SWORD, 1, (short) 0, "default", false, items, "pvpbox.admin");
		config.createSection("kits." + kit.name);
		config.set("kits." + kit.name, "");
		config.set("kits." + kit.name + ".permission", "");
		config.set("kits." + kit.name + ".splash", 1);
		config.set("kits." + kit.name + ".amount", 1);
		config.set("kits." + kit.name + ".slot", 0);
		config.set("kits." + kit.name + ".name", "default");
		config.set("kits." + kit.name + ".material", "DIAMOND_SWORD");
		config.set("kits." + kit.name + ".data", (short) 0);
		config.set("kits." + kit.name + ".fakeEnchantment", false);
		config.set("kits." + kit.name + ".lore", Arrays.asList("&b&lNouveau kit", "", "&eContient: ", "&e- une frite"));
		kit.items.forEach(item -> {
			config.createSection("kits." + kit.name + ".items." + item.slot);
			item.set(config.getConfigurationSection("kits." + kit.name + ".items." + item.slot));
		});
		try {
			instance.kitsfile.save(instance.kits);
		} catch (IOException e) {
			e.printStackTrace();
		}
		player.sendMessage("§aKit créé. §4§lGO CONFIG LE KIT MAINTENANT !");
		return false;
	}
	
}
