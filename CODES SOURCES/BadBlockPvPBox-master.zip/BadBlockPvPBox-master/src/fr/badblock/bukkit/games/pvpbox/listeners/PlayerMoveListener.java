package fr.badblock.bukkit.games.pvpbox.listeners;

import java.util.Iterator;
import java.util.Map.Entry;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.PlayerInventory;

import fr.badblock.bukkit.games.pvpbox.BadBlockPvPBox;
import fr.badblock.bukkit.games.pvpbox.kits.Kit;
import fr.badblock.bukkit.games.pvpbox.objects.BadPlayer;
import fr.badblock.bukkit.games.pvpbox.objects.GameState;

public class PlayerMoveListener implements Listener {
	
	@EventHandler
	public void onPlayerMove(PlayerMoveEvent event) {
		Player player = event.getPlayer();
		BadPlayer badPlayer = BadPlayer.get(player);
		Location from = event.getFrom();
		Location to = event.getTo();
		boolean move = from.getBlockX() != to.getBlockX() || from.getBlockY() != to.getBlockY() || from.getBlockZ() != to.getBlockZ();
		if (move) {
			if (badPlayer.lastTeleport != 0) {
				badPlayer.lastTeleport = 0;
				player.sendMessage("§cTéléportation annulée.");
			}
		}
		
		if(event.getTo().getY() <= BadBlockPvPBox.instance.configfile.getDouble("minY") && (event.getTo().getY() >= BadBlockPvPBox.instance.configfile.getDouble("minY") - 10D) && badPlayer.gameState == GameState.WAIT){
			
			badPlayer.setToBoxArena(player);
			PlayerInventory playerInventory = player.getInventory();
			playerInventory.clear();
			playerInventory.setHeldItemSlot(0);
			player.setMaxHealth(20);
			player.setHealth(20);
			player.getActivePotionEffects().clear();
			player.setFoodLevel(20);
			player.setExp(badPlayer.playerExp);
			player.setLevel(badPlayer.playerLevel);
			playerInventory.setArmorContents(null);
			System.out.println(Kit.kits.toString());
			
			String kitname = badPlayer.getInfos().getCurrentkit().equalsIgnoreCase("null") ? "§b§lTank" : badPlayer.getInfos().getCurrentkit();
			Kit kit = Kit.kits.get(kitname);
			kit.items.forEach(kitItem -> {
				int slot = kitItem.slot;
				if (slot == 103) playerInventory.setHelmet(kitItem.itemStack);
				else if (slot == 102) playerInventory.setChestplate(kitItem.itemStack);
				else if (slot == 101) playerInventory.setLeggings(kitItem.itemStack);
				else if (slot == 100) playerInventory.setBoots(kitItem.itemStack);
				else playerInventory.setItem(slot, kitItem.itemStack);
			});
			player.updateInventory();
			
			
		}
		
	}
	
}
