package fr.badblock.bukkit.games.pvpbox.commands;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import fr.badblock.bukkit.games.pvpbox.BadBlockPvPBox;
import fr.badblock.bukkit.games.pvpbox.arenas.Duel;
import fr.badblock.bukkit.games.pvpbox.objects.BadPlayer;
import fr.badblock.bukkit.games.pvpbox.objects.GameState;

public class SpawnCommand implements CommandExecutor {
	
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String arg, String[] args) {
		if (!(sender instanceof Player)) return false;
		Player player = (Player) sender;
		BadPlayer badPlayer = BadPlayer.get(player);
		if (!player.hasPermission("pvpbox.admin") && badPlayer.gameState.equals(GameState.IN_BOX_ARENA)) {
			long time = System.currentTimeMillis() + 10000L;
			badPlayer.lastTeleport = time;
			BadBlockPvPBox instance = BadBlockPvPBox.instance;
			player.sendMessage("§bVous allez être téléporté au spawn dans 10 secondes, veuillez ne pas bouger...");
			instance.getServer().getScheduler().runTaskLater(instance, new Runnable() {
				@Override
				public void run() {
					if (!player.isOnline()) return;
					if (time != badPlayer.lastTeleport) return;
					if (badPlayer.lastTeleport < System.currentTimeMillis()) return;
					badPlayer.lastTeleport = 0;
					BadPlayer.get(player).setSpawn(player);
					player.sendMessage("§eVous avez été téléporté au spawn.");
				}
			}, 195);
		}else{
			Duel duel = Duel.get(player);
			if (duel != null) {
				duel.demanderPlayers.remove(player);
				duel.demandedPlayers.remove(player);
				String prefix = BadBlockPvPBox.instance.permissionsExManager.getPrefix(player);
				duel.sendMessage("§b§l[Duel] §e" + prefix + player.getName() + "§c est revenu au spawn.");
				if (duel.launched) {
					if (duel.getDemandedPlayers().size() == 0) {
						List<String> demanderIps = new ArrayList<>();
						List<String> demandedIps = new ArrayList<>();
						duel.demanderPlayersBase.parallelStream().filter(az -> az != null && az.isOnline()).forEach(az -> demanderIps.add(az.getAddress().getHostString()));
						duel.demandedPlayersBase.parallelStream().filter(az -> az != null && az.isOnline()).forEach(az -> demandedIps.add(az.getAddress().getHostString()));
						boolean sameIp = false;
						for (String ip : demanderIps) 
							if (demandedIps.contains(ip)) sameIp = true;
						if (!sameIp) {
							duel.sendMessage("§b§l[Duel] §aLa team §e" + duel.demanderTeam.name + "§a a gagnée !");
							duel.demanderPlayersBase.forEach(plo -> {
								if (plo == null || !plo.isOnline()) return;
								BadPlayer bpl = BadPlayer.get(plo);
								if (bpl.getInfos() != null) {
									bpl.getInfos().setTeamVictories(bpl.getInfos().getTeamVictories() + 1);
									badPlayer.getInfos().setPoints(badPlayer.getInfos().getPoints() + duel.demandedPlayersBase.size());
								}
								bpl.updateScores(plo);
							});
							duel.demandedPlayersBase.forEach(plo -> {
								if (plo == null || !plo.isOnline()) return;
								BadPlayer bpl = BadPlayer.get(plo);
								if (bpl.getInfos() != null) bpl.getInfos().setTeamLooses(bpl.getInfos().getTeamLooses() + 1);
								bpl.updateScores(plo);
							});
						}
						Bukkit.broadcastMessage("§b§l[Duel] §8La team §b" + duel.demanderTeam.name + " §8a vaincue la team §b" + duel.demandedTeam.name + "§8.");
						duel.finish(player);
					}
					if (duel.getDemanderPlayers().size() == 0) {
						List<String> demanderIps = new ArrayList<>();
						List<String> demandedIps = new ArrayList<>();
						duel.demanderPlayersBase.parallelStream().filter(az -> az != null && az.isOnline()).forEach(az -> demanderIps.add(az.getAddress().getHostString()));
						duel.demandedPlayersBase.parallelStream().filter(az -> az != null && az.isOnline()).forEach(az -> demandedIps.add(az.getAddress().getHostString()));
						boolean sameIp = false;
						for (String ip : demanderIps) 
							if (demandedIps.contains(ip)) sameIp = true;
						if (!sameIp) {
							duel.demandedPlayersBase.forEach(plo -> {
								if (plo == null || !plo.isOnline()) return;
								BadPlayer bpl = BadPlayer.get(plo);
								if (bpl.getInfos() != null) {
									bpl.getInfos().setTeamVictories(bpl.getInfos().getTeamVictories() + 1);
									badPlayer.getInfos().setPoints(badPlayer.getInfos().getPoints() + duel.demandedPlayersBase.size());
								}
								bpl.updateScores(plo);
							});
							duel.demanderPlayersBase.forEach(plo -> {
								if (plo == null || !plo.isOnline()) return;
								BadPlayer bpl = BadPlayer.get(plo);
								if (bpl.getInfos() != null) bpl.getInfos().setTeamLooses(bpl.getInfos().getTeamLooses() + 1);
								bpl.updateScores(plo);
							});
						}
						duel.sendMessage("§b§l[Duel] §aLa team §e" + duel.demandedTeam.name + "§a a gagnée !");
						Bukkit.broadcastMessage("§b§l[Duel] §8La team §b" + duel.demandedTeam.name + " §8a vaincue la team §b" + duel.demanderTeam.name + "§8.");
						duel.finish(player);
					}
				}else{
					if (duel.getDemandedPlayers().size() == 0) {
						duel.sendMessage("§b§l[Duel] §ePlus de joueurs dans une des teams, duel annulé.");
						duel.finish(player);
					}
					if (duel.getDemanderPlayers().size() == 0) {
						duel.sendMessage("§b§l[Duel] §ePlus de joueurs dans une des teams, duel annulé.");
						duel.finish(player);
					}
				}
			}
			badPlayer.setSpawn(player);
			player.sendMessage("§eVous avez été téléporté au spawn.");
		}
		return true;
	}
	
}
