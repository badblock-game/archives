package fr.badblock.bukkit.games.pvpbox.utils.database;

import java.lang.Thread.State;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import fr.badblock.bukkit.games.pvpbox.BadBlockPvPBox;
import fr.badblock.bukkit.games.pvpbox.objects.BadPlayerInfos;
import fr.badblock.bukkit.games.pvpbox.objects.BadTeam;
import fr.badblock.bukkit.games.pvpbox.utils.LoggerUtils;

public class DatabaseManager {
	
	public static List<DatabaseThread> threads;
	
	private static List<DatabaseThread> createThreads(int number) {
		List<DatabaseThread> result = new ArrayList<>();
		for (int i = 0; i < number; i++) {
			result.add(new DatabaseThread(i));
		}
		return result;
	}
	
	public static void sendQuery(DataRequest dataRequest) {
		BadblockDatabase.getInstance().request.add(dataRequest);
		if (BadblockDatabase.getInstance().thread != null && BadblockDatabase.getInstance().thread.getState() != null && BadblockDatabase.getInstance().thread.getState().equals(State.WAITING))
			synchronized (BadblockDatabase.getInstance().thread) {
				BadblockDatabase.getInstance().thread.notify();
			}
	}
	
	public static String secure(java.sql.Connection link, String str) throws Exception {
		if (str == null) {
			return null;
		}
		
		if (str.replaceAll("[a-zA-Z0-9_!@#$%^&*()-=+~.;:,\\Q[\\E\\Q]\\E<>{}\\/? ]","").length() < 1) {
			return str;
		}
		
		String clean_string = str;
		clean_string = clean_string.replaceAll("\\\\", "\\\\\\\\");
		clean_string = clean_string.replaceAll("\\n","\\\\n");
		clean_string = clean_string.replaceAll("\\r", "\\\\r");
		clean_string = clean_string.replaceAll("\\t", "\\\\t");
		clean_string = clean_string.replaceAll("\\00", "\\\\0");
		clean_string = clean_string.replaceAll("'", "\\\\'");
		clean_string = clean_string.replaceAll("\\\"", "\\\\\"");
		
		if (clean_string.replaceAll("[a-zA-Z0-9_!@#$%^&*()-=+~.;:,\\Q[\\E\\Q]\\E<>{}\\/?\\\\\"' ]"
				,"").length() < 1) 
		{
			return clean_string;
		}
		
		java.sql.Statement stmt = link.createStatement();
		String qry = "SELECT QUOTE('"+clean_string+"')";
		
		stmt.executeQuery(qry);
		java.sql.ResultSet resultSet = stmt.getResultSet();
		resultSet.first();
		String r = resultSet.getString(1);
		return r.substring(1,r.length() - 1);       
	}
	
	public static void load(String hostname, int port, String username, String password, String database) {
		LoggerUtils.logWithColor("§e[PvPBox] §dLoading database...");
		BadblockDatabase dbInstance = BadblockDatabase.getInstance();
		dbInstance.connect(hostname, port, username, password, database);
		// Create threads
		/*threads = new ArrayList<>();
		threads.addAll(createThreads(16));*/
		final Gson gson = new GsonBuilder().create();
		try {
			Statement statement = BadblockDatabase.getInstance().createStatement();
			ResultSet resultSet = statement.executeQuery("SELECT COUNT(*) AS nb FROM pvpbox_teams ORDER BY id ASC;");
			resultSet.next();
			int nb = resultSet.getInt("nb");
			resultSet.close();
			resultSet = statement.executeQuery("SELECT * FROM pvpbox_teams ORDER BY id ASC;");
			int i = 0;
			while (resultSet.next()) {
				String name = resultSet.getString("name");
				String content = resultSet.getString("content");
				BadTeam badTeam = BadBlockPvPBox.instance.gson.fromJson(content, new TypeToken<BadTeam>(){}.getType());
				badTeam.register();
				i++;
				System.out.println("[TEAMS] Loaded team " + name + " (" + i + " of " + nb + ")");
			}
			resultSet.close();
			statement.close();
		}catch(Exception error) {
			error.printStackTrace();
		}
	}
	
}
