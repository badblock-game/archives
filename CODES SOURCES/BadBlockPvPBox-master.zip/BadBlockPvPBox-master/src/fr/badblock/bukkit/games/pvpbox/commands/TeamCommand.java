package fr.badblock.bukkit.games.pvpbox.commands;

import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import fr.badblock.bukkit.games.pvpbox.BadBlockPvPBox;
import fr.badblock.bukkit.games.pvpbox.objects.BadPlayer;
import fr.badblock.bukkit.games.pvpbox.objects.BadPlayerInfos;
import fr.badblock.bukkit.games.pvpbox.objects.BadTeam;
import fr.badblock.bukkit.games.pvpbox.utils.database.DataRequest;
import fr.badblock.bukkit.games.pvpbox.utils.database.DataType;
import fr.badblock.bukkit.games.pvpbox.utils.database.DatabaseManager;
import net.minecraft.server.v1_8_R3.ChatClickable;
import net.minecraft.server.v1_8_R3.ChatClickable.EnumClickAction;
import net.minecraft.server.v1_8_R3.ChatMessage;
import net.minecraft.server.v1_8_R3.ChatModifier;
import net.minecraft.server.v1_8_R3.IChatBaseComponent;
import net.minecraft.server.v1_8_R3.MinecraftServer;
import net.minecraft.server.v1_8_R3.PlayerList;

public class TeamCommand implements CommandExecutor {

	public static String prefix = "§b§l[Team] §f";

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String arg, String[] args) {
		if (!(sender instanceof Player)) return false;
		Player player = (Player) sender;
		BadPlayer badPlayer = BadPlayer.get(player);
		if (args.length == 0 || (args.length == 1 && args[0].equalsIgnoreCase("help"))) {
			player.sendMessage("§8§l«§b§l-§8§l»§m------§f§8§l«§b§l-§8§l»§b §b§lTeam §8§l«§b§l-§8§l»§m------§f§8§l«§b§l-§8§l»");
			player.sendMessage("§c> §6/team §bhelp §6: liste des commandes");
			player.sendMessage("§c> §6/team §bcreate <nom> §6: créer une team");
			player.sendMessage("§c> §6/team §baccept <nom> §6: accepter à rejoindre une team");
			player.sendMessage("§c> §6/team §binvite <pseudo> §6: inviter un joueur dans sa team");
			player.sendMessage("§c> §6/team §bleave §6: quitter sa team");
			player.sendMessage("§c> §6/team §bkick <pseudo> §6: éjecter un joueur de sa team");
			player.sendMessage("§c> §6/team §brename <nom> §6: renommer sa team");
			player.sendMessage("§c> §6/team §bperm <pseudo> add/remove <invite/kick/rename/perm/duelaccept/duel> §6: ajouter une permission à un joueur de sa team");
			player.sendMessage("§c> §6/team §blist §6: voir la liste des membres de la team");
			if (player.hasPermission("box.breakteam"))
				player.sendMessage("§c> §6/team §bbreak <nom> §6: casser une équipe");
			player.sendMessage("§8§l«§b§l-§8§l»§m--------------------------§f§8§l«§b§l-§8§l»§b");
		}else{
			if (args.length >= 1 && args[0].equalsIgnoreCase("create")) {
				if (args.length != 2) {
					player.sendMessage(prefix + "§cUtilisation: /team create <nom>");
					return true;
				}
				create(player, args[1]);
			}else if (args.length >= 1 && args[0].equalsIgnoreCase("accept")) {
				if (args.length != 2) {
					player.sendMessage(prefix + "§cUtilisation: /team accept <nom>");
					return true;
				}
				accept(player, args[1]);
			}else if (args.length >= 1 && args[0].equalsIgnoreCase("invite")) {
				if (args.length != 2) {
					player.sendMessage(prefix + "§cUtilisation: /team invite <nom>");
					return true;
				}
				invite(player, args[1]);
			}else if (args.length >= 1 && args[0].equalsIgnoreCase("leave")) {
				leave(player);
			}else if (args.length >= 1 && args[0].equalsIgnoreCase("kick")) {
				if (args.length != 2) {
					player.sendMessage(prefix + "§cUtilisation: /team kick <nom>");
					return true;
				}
				kick(player, args[1]);
			}else if (args.length >= 1 && args[0].equalsIgnoreCase("rename")) {
				if (args.length != 2) {
					player.sendMessage(prefix + "§cUtilisation: /team rename <nom>");
					return true;
				}
				rename(player, args[1]);
			}else if (args.length >= 1 && args[0].equalsIgnoreCase("perm")) {
				if (args.length != 4) {
					player.sendMessage(prefix + "§cUtilisation: /team perm <pseudo> <add/remove> <invite/kick/rename/perm>");
					return true;
				}
				perm(player, args[1], args[2], args[3]);
			}else if (args.length >= 1 && args[0].equalsIgnoreCase("accept")) {
				if (args.length != 2) {
					player.sendMessage(prefix + "§cUtilisation: /team accept <nom>");
					return true;
				}
				accept(player, args[1]);
			}else if (args.length >= 1 && args[0].equalsIgnoreCase("break")) {
				if (args.length != 2) {
					player.sendMessage(prefix + "§cUtilisation: /team break <nom>");
					return true;
				}
				if (!player.hasPermission("box.breakteam")) {
					player.sendMessage(prefix + "§cVous n'avez pas la permission de casser une équipe.");
					return true;
				}
				BadTeam badTeam = BadTeam.teams.get(args[1]);
				if (badTeam == null) {
					player.sendMessage(prefix + "§cCette équipe n'existe pas.");
					return true;	
				}
				Player pl = Bukkit.getPlayer(badTeam.owner);
				if (pl == null) {
					player.sendMessage(prefix + "§cLe chef d'équipe est déconnecté.");
					return true;	
				}
				if (!player.hasPermission("box.breakteam.bypass") && pl.hasPermission("box.breakteam")) {
					player.sendMessage(prefix + "§cVous n'avez pas la permission de casser cette équipe.");
					return true;
				}
				Set<Player> pla = badTeam.getOnlinePlayers();
				for(String namepl : badTeam.getPlayers()){
					if(Bukkit.getPlayer(namepl) != null) BadPlayer.get(Bukkit.getPlayer(namepl)).getInfos().setTeamName("null");
				}
				badTeam.getOnlinePlayersWithoutLeader().forEach(plo -> plo.sendMessage(prefix + "§c" + player.getName() + " a dissous la team. (0/3)"));
				pl.sendMessage(prefix + "§c" + player.getName() + " a dissous votre team.");
				badTeam.unregister();
				DatabaseManager.sendQuery(new DataRequest("DELETE FROM pvpbox_teams WHERE name = '" + badTeam.name + "'", DataType.UPDATE));
				for (Player plo : pla)
					BadPlayer.get(plo).updateScores(plo);
				player.sendMessage("§aVous avez dissous la team §b" + badTeam.name + "§a.");
			}else if (args.length >= 1 && args[0].equalsIgnoreCase("list")) {
				list(player);
			}else{
				player.sendMessage(prefix + "§cCommande inconnue. §8Tapez §b/team help§8 pour plus d'informations.");
			}
		}
		return true;
	}

	public void list(Player player) {
		BadTeam team = BadTeam.getTeam(player);
		if (team == null) {
			player.sendMessage(prefix + "§cVous devez être dans une team pour pouvoir exécuter cette commande.");
			return;
		}
		player.sendMessage("§8§l«§b§l-§8§l»§m------§f§8§l«§b§l-§8§l»§b §b§l" + team.name + "§8§l «§b§l-§8§l»§m------§f§8§l«§b§l-§8§l»");
		player.sendMessage("§c[LEADER] " + team.owner + " > " + (isOnline(team.owner) ? "§aConnecté" : "§cDéconnecté"));
		team.getPlayersWithoutLeader().forEach(name -> player.sendMessage("§9Membre " + name + " > " + (isOnline(name) ? "§aConnecté" : "§cDéconnecté")));
	}

	public boolean isOnline(String name) {
		return BadBlockPvPBox.instance.getServer().getPlayer(name) != null;
	}

	public void create(Player player, String name) {
		if (BadTeam.getTeam(player) != null) {
			player.sendMessage(prefix + "§cVous êtes déjà dans une team.");
			return;
		}
		if (player.getName().equalsIgnoreCase(name)) {
			player.sendMessage(prefix + "§cLa schizophrénie est prohibée sur ce serveur.");
			return;
		}
		if (BadTeam.teams.containsKey(name)) {
			player.sendMessage(prefix + "§cCe nom de team existe déjà.");
			return;
		}
		if (name.length() < 3) {
			player.sendMessage(prefix + "§cLe nom de la team doit faire au minimum 3 caractères.");
			return;
		}
		if (name.length() > 8) {
			player.sendMessage(prefix + "§cLe nom de la team doit faire au maximum 8 caractères.");
			return;
		}
		if (name.equalsIgnoreCase("help") || name.equalsIgnoreCase("accept")) {
			player.sendMessage(prefix + "§cVous ne pouvez pas nommer cette team avec ce nom.");
			return;
		}
		Pattern pattern = Pattern.compile("^[0-9a-zA-Z]+$");
		Matcher matcher = pattern.matcher(name);
		if (!matcher.matches()) {
			player.sendMessage(prefix + "§cLa team doit contenir que des lettres ou/et des nombres.");
			return;
		}
		BadTeam badTeam = new BadTeam(player, name);
		badTeam.register();
		BadPlayerInfos infos = BadPlayer.get(player).getInfos();
		infos.setTeamName(name);
		DatabaseManager.sendQuery(new DataRequest("INSERT INTO pvpbox_teams(name, content) VALUES('" + name + "', '" + BadBlockPvPBox.instance.gson.toJson(badTeam) + "')", DataType.UPDATE));
		player.sendMessage(prefix + "§aLa team " + name + " a bien été créée.");
		player.sendMessage(prefix + "§eTapez §b/team invite <pseudo> §epour inviter votre premier membre.");
	}

	public void perm(Player player, String pseudo, String type, String permission) {
		BadTeam team = BadTeam.getTeam(player);
		if (team == null) {
			player.sendMessage(prefix + "§cVous n'êtes pas dans une team.");
			return;
		}
		if (player.getName().equalsIgnoreCase(pseudo)) {
			player.sendMessage(prefix + "§cLa schizophrénie est prohibée sur ce serveur.");
			return;
		}
		if (team.owner.equalsIgnoreCase(pseudo)) {
			player.sendMessage(prefix + "§cLe leader dispose déjà de toutes les permissions.");
			return;
		}
		if (!team.owner.equalsIgnoreCase(player.getName())) {
			player.sendMessage(prefix + "§cSeul le leader peut changer les permissions de quelqu'un.");
			return;
		}
		if (player.getName().equalsIgnoreCase(pseudo)) {
			player.sendMessage(prefix + "§cVous n'avez pas le droit de vous ajouter vous-même des permissions.");
			return;
		}
		if (!team.hasPermission(player, "perm")) {
			player.sendMessage(prefix + "§cVous n'avez pas la permission de gérer les permissions de la team.");
			return;
		}
		if (team.pendingPlayers.contains(pseudo)) {
			player.sendMessage(prefix + "§cCe joueur n'a pas accepté encore la demande de team.");
			return;
		}
		if (!team.getPlayers().contains(pseudo)) {
			player.sendMessage(prefix + "§cCe joueur n'est pas dans cette team.");
			return;
		}
		if (!type.equalsIgnoreCase("add") && !type.equalsIgnoreCase("remove")) {
			player.sendMessage(prefix + "§cMode inconnu. Liste: remove & add");
			return;
		}
		String perm = permission.equalsIgnoreCase("invite") ? "invite" : permission.equalsIgnoreCase("kick") ? "kick" : permission.equalsIgnoreCase("rename") ? "rename" : permission.equalsIgnoreCase("perm") ? "perm" : permission.equalsIgnoreCase("duel") ? "duel" : permission.equalsIgnoreCase("duelaccept") ? "duelaccept" : "";
		if (perm.equals("")) {
			player.sendMessage(prefix + "§cPermission inconnue.");
			return;
		}
		if (type.equalsIgnoreCase("add")) {
			if (team.players.get(pseudo).contains(perm)) {
				player.sendMessage(prefix + "§cCe joueur a déjà cette permission.");
				return;
			}
			team.players.get(pseudo).add(perm);
			DatabaseManager.sendQuery(new DataRequest("UPDATE pvpbox_teams SET name = '" + team.name + "', content = '" + BadBlockPvPBox.instance.gson.toJson(team) + "' WHERE name = '" + team.name + "'", DataType.UPDATE));
			player.sendMessage("§aPermission " + perm + " ajoutée à " + pseudo + ".");
			return;
		}
		if (type.equalsIgnoreCase("remove")) {
			if (!team.players.get(pseudo).contains(perm)) {
				player.sendMessage(prefix + "§cCe joueur n'a déjà pas cette permission.");
				return;
			}
			team.players.get(pseudo).remove(perm);
			DatabaseManager.sendQuery(new DataRequest("UPDATE pvpbox_teams SET name = '" + team.name + "', content = '" + BadBlockPvPBox.instance.gson.toJson(team) + "' WHERE name = '" + team.name + "'", DataType.UPDATE));
			player.sendMessage("§aPermission " + perm + " enlevée à " + pseudo + ".");
			return;
		}
	}

	public void rename(Player player, String name) {
		BadTeam team = BadTeam.getTeam(player);
		if (team == null) {
			player.sendMessage(prefix + "§cVous n'êtes pas dans une team.");
			return;
		}
		if (!team.hasPermission(player, "rename")) {
			player.sendMessage(prefix + "§cVous n'avez pas la permission de renommer la team.");
			return;
		}
		if (BadTeam.teams.containsKey(name)) {
			player.sendMessage(prefix + "§cCe nom de team existe déjà.");
			return;
		}
		if (name.length() < 3) {
			player.sendMessage(prefix + "§cLe nom de la team doit faire au minimum 3 caractères.");
			return;
		}
		if (name.length() > 8) {
			player.sendMessage(prefix + "§cLe nom de la team doit faire au maximum 8 caractères.");
			return;
		}
		if (name.equalsIgnoreCase("help") || name.equalsIgnoreCase("accept")) {
			player.sendMessage(prefix + "§cVous ne pouvez pas nommer cette team avec ce nom.");
			return;
		}
		Pattern pattern = Pattern.compile("^[0-9a-zA-Z]+$");
		Matcher matcher = pattern.matcher(name);
		if (!matcher.matches()) {
			player.sendMessage(prefix + "§cLa team doit contenir que des lettres ou/et des nombres.");
			return;
		}
		for(String plname : team.getPlayers()){
			if(BadPlayer.players.containsKey(Bukkit.getPlayer(plname).getUniqueId())){
				BadPlayer.get(Bukkit.getPlayer(plname)).getInfos().setTeamName(name);
			}
		}
		String lastName = team.name;
		team.unregister();
		team.name = name;
		team.register();
		DatabaseManager.sendQuery(new DataRequest("UPDATE pvpbox_teams SET name = '" + team.name + "', content = '" + BadBlockPvPBox.instance.gson.toJson(team) + "' WHERE name = '" + lastName + "'", DataType.UPDATE));
		team.getOnlinePlayers().forEach(plo -> plo.sendMessage(prefix + "§a" + player.getName() + " a renommé la team en " + name + "."));
		team.update();
	}

	public void leave(Player player) {
		BadTeam team = BadTeam.getTeam(player);
		if (team == null) {
			player.sendMessage(prefix + "§cVous n'êtes pas dans une team.");
			return;
		}
		if (team.owner.equalsIgnoreCase(player.getName())) {
			Set<Player> pla = team.getOnlinePlayers();
			team.getOnlinePlayersWithoutLeader().forEach(plo -> plo.sendMessage(prefix + "§c" + player.getName() + " a dissous la team. (0/3)"));
			player.sendMessage(prefix + "§cVous avez dissous votre team.");
			team.unregister();
			DatabaseManager.sendQuery(new DataRequest("DELETE FROM pvpbox_teams WHERE name = '" + team.name + "'", DataType.UPDATE));
			for (Player plo : pla)
				BadPlayer.get(plo).updateScores(plo);
			return;
		}
		Set<Player> pla = team.getOnlinePlayers();
		team.getPlayers().remove(player.getName());
		DatabaseManager.sendQuery(new DataRequest("UPDATE pvpbox_teams SET name = '" + team.name + "', content = '" + BadBlockPvPBox.instance.gson.toJson(team) + "' WHERE name = '" + team.name + "'", DataType.UPDATE));
		team.getOnlinePlayers().forEach(plo -> plo.sendMessage(prefix + "§c" + player.getName() + " a quitté la team."));
		player.sendMessage(prefix + "§cVous avez quitté la team. (" + team.getPlayers().size() + "/3)");
		for (Player plo : pla)
			BadPlayer.get(plo).updateScores(plo);
	}

	public void invite(Player player, String name) {
		BadTeam team = BadTeam.getTeam(player);
		if (team == null) {
			player.sendMessage(prefix + "§cVous n'êtes pas dans une team.");
			return;
		}
		if (player.getName().equalsIgnoreCase(name)) {
			player.sendMessage(prefix + "§cLa schizophrénie est prohibée sur ce serveur.");
			return;
		}
		if (!team.hasPermission(player, "invite")) {
			player.sendMessage(prefix + "§cVous n'avez pas la permission d'inviter un joueur dans la team.");
			return;
		}
		if (team.pendingPlayers.contains(name)) {
			player.sendMessage(prefix + "§cCette personne a déjà une invitation à cette team en cours.");
			return;
		}
		if (team.getPlayers().contains(name)) {
			player.sendMessage(prefix + "§cCette personne est déjà dans la team.");
			return;
		}
		Player to = BadBlockPvPBox.instance.getServer().getPlayer(name);
		if (to != null && to.isOnline()) {
			to.sendMessage(prefix + "§eLa team §b" + team.name + " §evous invite à la rejoindre.");
			IChatBaseComponent base = new ChatMessage(prefix + "§8§l[§b§lAccepter§8§l]");
			base.setChatModifier(new ChatModifier());
			base.getChatModifier().setChatClickable(new ChatClickable(EnumClickAction.RUN_COMMAND, "/team accept " + team.name));
			PlayerList list = MinecraftServer.getServer().getPlayerList();
			list.getPlayer(to.getName()).sendMessage(base);
		}
		BadTeam toTeam = BadTeam.getTeam(to);
		if (toTeam != null) {
			player.sendMessage(prefix + "§cCe joueur est déjà dans une team.");
			return;
		}
		team.pendingPlayers.add(to.getName());
		DatabaseManager.sendQuery(new DataRequest("UPDATE pvpbox_teams SET name = '" + team.name + "', content = '" + BadBlockPvPBox.instance.gson.toJson(team) + "' WHERE name = '" + team.name + "'", DataType.UPDATE));
		team.getOnlinePlayers().forEach(plo -> plo.sendMessage(prefix + "§e" + to.getName() + " a été invité dans la team par " + player.getName() + "."));
	}

	public void accept(Player player, String name) {
		BadTeam team = BadTeam.teams.get(name);
		if (team == null) {
			player.sendMessage(prefix + "§cCette team n'existe pas.");
			return;
		}
		if (!team.pendingPlayers.contains(player.getName())) {
			player.sendMessage(prefix + "§cRequête expirée ou inexistante.");
			return;
		}
		if (team.getPlayers().contains(player.getName())) {
			player.sendMessage(prefix + "§cVous êtes déjà dans cette team.");
			return;
		}
		if (team.getPlayers().size() >= 3) {
			player.sendMessage(prefix + "§cUne team est limitée à 3 joueurs au maximum.");
			return;
		}
		team.addPlayer(player.getName());
		BadPlayer.get(player).getInfos().setTeamName(name);
		DatabaseManager.sendQuery(new DataRequest("UPDATE pvpbox_teams SET name = '" + team.name + "', content = '" + BadBlockPvPBox.instance.gson.toJson(team) + "' WHERE name = '" + team.name + "'", DataType.UPDATE));
		team.getOnlinePlayers().forEach(plo -> plo.sendMessage(prefix + "§e" + player.getName() + " a rejoint la team (" + team.getPlayers().size() + "/3)."));
		team.update();
	}

	public void kick(Player player, String name) {
		BadTeam team = BadTeam.getTeam(player);
		if (team == null) {
			player.sendMessage(prefix + "§cVous n'êtes pas dans une team.");
			return;
		}
		if (player.getName().equalsIgnoreCase(name)) {
			player.sendMessage(prefix + "§cLa schizophrénie est prohibée sur ce serveur.");
			return;
		}
		if (!team.hasPermission(player, "kick")) {
			player.sendMessage(prefix + "§cVous n'avez pas la permission d'éjecter un joueur dans la team.");
			return;
		}
		if (team.pendingPlayers.contains(name)) {
			team.pendingPlayers.remove(name);
			player.sendMessage(prefix + "§cInvitation annulée.");
			Player to = BadBlockPvPBox.instance.getServer().getPlayer(name);
			if (to != null && to.isOnline()) {
				to.sendMessage(prefix + "§cInvitation de " + name + " annulée.");
			}
			DatabaseManager.sendQuery(new DataRequest("UPDATE pvpbox_teams SET name = '" + team.name + "', content = '" + BadBlockPvPBox.instance.gson.toJson(team) + "' WHERE name = '" + team.name + "'", DataType.UPDATE));
			return;
		}
		if (!team.getPlayers().contains(name)) {
			player.sendMessage(prefix + "§cCette personne n'est pas dans la team.");
			return;
		}
		Set<Player> pla = team.getOnlinePlayers();
		team.getPlayers().remove(name);
		Player to = BadBlockPvPBox.instance.getServer().getPlayer(name);
		if (to != null && to.isOnline()) {
			to.sendMessage(prefix + "§cVous avez été éjecté de la team par " + player.getName() + ". (" + team.getPlayers().size() + "/3)");
		}
		BadPlayer.get(to).getInfos().setTeamName("null");
		DatabaseManager.sendQuery(new DataRequest("UPDATE pvpbox_teams SET name = '" + team.name + "', content = '" + BadBlockPvPBox.instance.gson.toJson(team) + "' WHERE name = '" + team.name + "'", DataType.UPDATE));
		team.getOnlinePlayers().forEach(plo -> plo.sendMessage(prefix + "§c" + name + " a été éjecté de la team par " + player.getName() + ". (" + team.getPlayers().size() + "/3)"));
		for (Player plo : pla)
			BadPlayer.get(plo).updateScores(plo);
	}

}
