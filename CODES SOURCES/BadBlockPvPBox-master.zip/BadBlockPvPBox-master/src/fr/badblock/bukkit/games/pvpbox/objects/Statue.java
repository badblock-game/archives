package fr.badblock.bukkit.games.pvpbox.objects;

import io.netty.util.internal.ConcurrentSet;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;

import fr.badblock.bukkit.games.pvpbox.BadBlockPvPBox;

public class Statue implements Runnable {
	
	public static Set<Statue> statues		= new ConcurrentSet<>();
	
	public UUID 			  uuid;
	public PotionEffectType   effect;
	public Location 		  center;
	public int				  booster;
	public int 				  blocks;
	public BukkitTask		  task;
	public List<UUID>		  uuids;
	public String		      name;
	
	public Statue(String name, UUID uuid, PotionEffectType effect, Location center, int booster, int blocks) {
		this.name = ChatColor.translateAlternateColorCodes('&', name);
		this.uuid = uuid;
		this.effect = effect;
		this.center = center;
		this.booster = booster;
		this.blocks = blocks;
		this.uuids = new ArrayList<>();
		BadBlockPvPBox instance = BadBlockPvPBox.instance;
		this.task = instance.getServer().getScheduler().runTaskTimer(instance, this, 10, 10);
		this.register();
	}
	
	@Override
	public void run() {
		List<UUID> o = new ArrayList<>();
		for (Player player : Bukkit.getOnlinePlayers()) {
			Location playerLocation = player.getLocation();
			double distanceX = Math.abs(playerLocation.getX() - center.getX());
			double distanceZ = Math.abs(playerLocation.getZ() - center.getZ());
			double greatDistance = Math.sqrt(distanceX * distanceX + distanceZ * distanceZ);
			if (greatDistance <= blocks) {
				if (!player.hasPotionEffect(effect))
					player.addPotionEffect(new PotionEffect(effect, 20 * 5, booster - 1));
				o.add(player.getUniqueId());
				if (!uuids.contains(player.getUniqueId())) {
					uuids.add(player.getUniqueId());
					BadPlayer.get(player).updateScores(player);
				}
			}else if (uuids.contains(player.getUniqueId())) {
				uuids.remove(player.getUniqueId());
				BadPlayer.get(player).updateScores(player);
			}
		}
		uuids = o;
	}
	
	public void unregister() {
		statues.remove(this);
		task.cancel();
	}
	
	public void register() {
		statues.add(this);
	}
	
}
