package fr.badblock.bukkit.games.pvpbox.commands;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import fr.badblock.bukkit.games.pvpbox.BadBlockPvPBox;
import fr.badblock.bukkit.games.pvpbox.utils.TempScheduler;

public class KickAllCommand extends AbstractCommand {
	
	public KickAllCommand() {
		super("pvpbox.kickall", "%gold%Utilisation : /kickall (<player>)", true);
	}
	
	public void run(CommandSender sender, String[] args) {
		for (Player po : Bukkit.getOnlinePlayers())
			if (!po.hasPermission("pvpbox.bypass.kickall"))
				po.kickPlayer("§cLes joueurs ont été renvoyés au hub.");
		sender.sendMessage("§aLes joueurs ont été renvoyés au hub.");
	}
	
}