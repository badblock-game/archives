package fr.badblock.bukkit.games.pvpbox.tasks;

import org.bukkit.scheduler.BukkitRunnable;

import fr.badblock.bukkit.games.pvpbox.BadBlockPvPBox;

public class WorldWeatherTask extends BukkitRunnable {
	
	public WorldWeatherTask(BadBlockPvPBox plugin) {
		this.runTaskTimerAsynchronously(plugin, 0, 1);	
	}

	@Override
	public void run() {
		BadBlockPvPBox.instance.getServer().getWorlds().forEach(world -> {
			world.setFullTime(0);
			world.setStorm(false);
			world.setThunderDuration(0);
			world.setThundering(false);
			world.setWeatherDuration(0);
			world.setTime(6000);
		});
	}
	
}
