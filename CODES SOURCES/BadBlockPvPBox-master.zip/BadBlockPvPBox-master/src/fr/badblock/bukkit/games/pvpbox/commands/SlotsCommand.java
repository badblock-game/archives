package fr.badblock.bukkit.games.pvpbox.commands;

import java.io.IOException;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import fr.badblock.bukkit.games.pvpbox.BadBlockPvPBox;
import fr.badblock.bukkit.games.pvpbox.arenas.Duel;
import fr.badblock.bukkit.games.pvpbox.objects.BadPlayer;
import fr.badblock.bukkit.games.pvpbox.objects.GameState;

public class SlotsCommand implements CommandExecutor {
	
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String arg, String[] args) {
		if (!(sender instanceof Player)) return false;
		Player player = (Player) sender;
		BadPlayer badPlayer = BadPlayer.get(player);
		if (!player.hasPermission("pvpbox.slots")) {
			player.sendMessage("§cVous n'avez pas la permission.");
			return true;
		}
		if (args.length != 1) {
			player.sendMessage("§cUsage: /slots <nb/-1>");
			return true;
		}
		int i = Integer.MIN_VALUE;
		try {
			i = Integer.parseInt(args[0]);
		}catch(Exception error) {
			player.sendMessage("§cLe nombre de slots doit être un nombre.");
			return true;
		}
		if (i <= 0) {
			player.sendMessage("§cLimite de slots enlevée.");
			BadBlockPvPBox.instance.configfile.set("slots", -1);
			try {
				BadBlockPvPBox.instance.configfile.save(BadBlockPvPBox.instance.config);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}else{
			player.sendMessage("§aLimite de slots mise à " + i);
			BadBlockPvPBox.instance.configfile.set("slots", i);
			try {
				BadBlockPvPBox.instance.configfile.save(BadBlockPvPBox.instance.config);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return true;
	}
	
}
