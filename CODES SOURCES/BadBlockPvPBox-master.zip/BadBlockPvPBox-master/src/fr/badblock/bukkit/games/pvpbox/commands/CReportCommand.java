package fr.badblock.bukkit.games.pvpbox.commands;

import java.util.HashMap;
import java.util.Map;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import fr.badblock.bukkit.games.pvpbox.listeners.AsyncChatListener;
import fr.badblock.bukkit.games.pvpbox.objects.ChatData;
import fr.badblock.bukkit.games.pvpbox.utils.database.Badblock2Database;
import fr.badblock.bukkit.games.pvpbox.utils.database.DataRequest;
import fr.badblock.bukkit.games.pvpbox.utils.database.DataType;
import fr.badblock.bukkit.games.pvpbox.utils.database.Database2Manager;

public class CReportCommand implements CommandExecutor {

	public static Map<String, Long> lastReport = new HashMap<>();
	public static Map<Integer, String> lastReportId = new HashMap<>();

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String arg, String[] args) {
		if (!(sender instanceof Player)) {
			sender.sendMessage("§cVous devez être un joueur pour pouvois executer cette commande.");
			return true;
		}
		Player player = (Player) sender;
		if (args.length != 1) return false;
		String idString = args[0];
		int id = -1;
		try {
			id = Integer.parseInt(idString);
		}catch(Exception error) {
			return false;
		}
		if (!AsyncChatListener.messages.containsKey(id)) {
			player.sendMessage("§cCe message n'existe pas.");
			return true;
		}
		if (lastReportId.containsKey(id)) {
			if (lastReportId.get(id).equalsIgnoreCase(player.getName())) {
				player.sendMessage("§cVous avez déjà signalé ce message.");
				return true;
			}else {
				player.sendMessage("§cCe message a déjà été signalé. Un signalement suffit.");
				return true;
			}
		}
		if (lastReport.containsKey(player.getName())) {
			long l = lastReport.get(player.getName());
			if (l > System.currentTimeMillis()) {
				player.sendMessage("§cVous avez déjà signalé un message il y a peu.");
				return true;
			}
		}
		ChatData chatData = AsyncChatListener.messages.get(id);
		if (player.getName().equalsIgnoreCase(chatData.playerName)) {
			player.sendMessage("§cLe trouble de la personnalité masochiste est référencée dans le DSM-IV. Il est important de consulter avant de vouloir signaler soi-même ses messages à des autorités compétentes.");
			return true;
		}
//		BadBlockPvPBox.instance.rabbitService.sendPacket("badreport", "§7(By " + player.getName() + ") | §7" + chatData.playerName + " §8» §7" + chatData.message, Encodage.UTF8, RabbitPacketType.PUBLISHER, 5000, false);
		Database2Manager.sendQuery(new DataRequest("INSERT INTO reportMsg(player, byPlayer, message, timestamp) VALUES('" + secure(chatData.playerName) + "', '" + secure(player.getName()) + "', '" + secure(chatData.message) + "', '" + System.currentTimeMillis() + "')", DataType.UPDATE));
		player.sendMessage("§7[§bReport§7] §7Votre signalement à l''encontre de §b" + chatData.playerName + "§7 a été envoyé.");
		player.sendMessage("§bContenu du message: §7" + chatData.message);
		lastReport.put(player.getName(), System.currentTimeMillis() + 30_000L);
		lastReportId.put(id, player.getName());
		return true;
	}

	public String secure(String str) {
		try {
			return Database2Manager.secure(Badblock2Database.getInstance().getConnection(), str);
		} catch (Exception e) {
			e.printStackTrace();
			return "--l-^pofdslfds^pl";
		}
	}

}
