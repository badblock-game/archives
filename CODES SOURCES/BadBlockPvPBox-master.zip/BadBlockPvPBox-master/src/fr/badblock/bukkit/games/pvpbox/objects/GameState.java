package fr.badblock.bukkit.games.pvpbox.objects;

public enum GameState {
	
	WAIT,
	IN_BOX_ARENA,
	IN_TEAM_ARENA;
	
}
