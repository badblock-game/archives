package fr.badblock.bukkit.games.pvpbox.utils.database;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Queue;

import lombok.Getter;

import com.google.common.collect.Queues;

public class DatabaseThread extends Thread {
	
	private Queue<DataRequest>	requests;
	@Getter private long 		lastExecute;
	
	public DatabaseThread(int id) {
		this.setName("database_" + id);
		this.requests = Queues.newConcurrentLinkedQueue();
		this.start();
	}
	
	@Override
	public void run() {
		while (true) {
			lastExecute = System.currentTimeMillis();
			if (!requests.isEmpty()) {
				DataRequest request = requests.poll();
				//System.out.println("[PvPBox] Do request : " + request.getQuery());
				try {
					Statement statement = BadblockDatabase.getInstance().createStatement();
					if (request.getType().equals(DataType.QUERY)) {
						ResultSet resultSet = statement.executeQuery(request.getQuery());
						request.callback(resultSet);
						resultSet.close();
					}else{
						statement.executeUpdate(request.getQuery());
					}
					statement.close();
				}catch(Exception error) {
					error.printStackTrace();
				}
			}
			if (!requests.isEmpty()) continue;
			try {
				synchronized (this) {
					this.wait();
				}
			}catch(Exception error) {
				error.printStackTrace();
			}
		}
	}
	
	public boolean isCallable() {
		return this.getState() != null && this.getStackTrace().equals(State.WAITING);	
	}
	
	public void addRequest(DataRequest dataRequest) {
		requests.add(dataRequest);
		if (this.getState() != null && this.getState().equals(State.WAITING))
			synchronized (this) {
				this.notify();
			}
	}
	
}
