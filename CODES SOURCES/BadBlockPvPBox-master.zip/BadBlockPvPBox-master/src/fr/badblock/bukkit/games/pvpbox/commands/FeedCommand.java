package fr.badblock.bukkit.games.pvpbox.commands;

import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class FeedCommand
  extends AbstractCommand
{
  public FeedCommand()
  {
    super("pvpbox.feed", "%gold%Utilisation : /feed (<player>)", true);
  }
 
  public void run(CommandSender sender, String[] args)
  {
    Player concerned = null;
    if ((args.length == 0) && (!(sender instanceof Player))) {
      sendHelp(sender);
    } else if (args.length > 0) {
      concerned = Bukkit.getPlayer(args[0]);
    } else {
      concerned = (Player)sender;
    }
    if (concerned == null)
    {
      sendMessage(sender, new String[] { "%red%Le joueur " + args[0] + " est introuvable." });
    }
    else
    {
      feed(concerned);
     
      sendMessage(concerned, new String[] { "%gold%Vous avez été nourri !" });
      if (args.length > 0) {
        sendMessage(sender, new String[] { "%gold%" + concerned.getName() + " a été nourri." });
      }
    }
  }
 
  public static void feed(Player concerned)
  {
    concerned.setFoodLevel(20);
  }
}