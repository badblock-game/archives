package fr.badblock.bukkit.games.pvpbox.listeners;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

import fr.badblock.bukkit.games.pvpbox.objects.BadPlayer;
import fr.badblock.bukkit.games.pvpbox.objects.BadTeam;
import fr.badblock.bukkit.games.pvpbox.objects.ChatData;
import net.md_5.bungee.api.ChatColor;
import net.md_5.bungee.api.chat.BaseComponent;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.ComponentBuilder;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;
import net.minecraft.server.v1_8_R3.PacketPlayOutChat;

public class AsyncChatListener implements Listener {

	public static Map<Integer, ChatData> messages = new HashMap<>();

	@EventHandler
	public void onAsyncChat(AsyncPlayerChatEvent event) {
		Player player = event.getPlayer();
		boolean whitemessage = player.hasPermission("whitemessage");
		BadTeam team = BadTeam.getTeam(player);
		String teamPrefix = team != null ? "§b§o*" + team.name + "* " : ""; 
		BadPlayer badPlayer = BadPlayer.get(player);
		int i = new Random().nextInt(Integer.MAX_VALUE);
		while (messages.containsKey(i)) {
			i = new Random().nextInt(Integer.MAX_VALUE);
		}
		messages.put(i, new ChatData(player.getName(), event.getMessage()));
		TextComponent message = new TextComponent("§c§l⚠§r");
		message.setClickEvent( new ClickEvent( ClickEvent.Action.RUN_COMMAND, "/creport " + i) );
		message.setHoverEvent( new HoverEvent( HoverEvent.Action.SHOW_TEXT, new ComponentBuilder("§cSignaler le joueur " + player.getName()).create() ) );

		TextComponent textComponent = new TextComponent();
		String tobechanged = event.getMessage();
		String color = whitemessage ? "§c" : "§f";
		String finalmessage = setColor(tobechanged, color);
		textComponent.setText(" §f§l[§b" + badPlayer.level + "§f§l] " + teamPrefix + ChatColor.translateAlternateColorCodes('&', badPlayer.rank + event.getPlayer().getName()) + " §7: " + finalmessage);
		message.addExtra(textComponent);
		event.setCancelled(true);
		for(Player p : event.getRecipients()){
			sendMessage(p, message);
		}
	}

	private void sendMessage(Player player, BaseComponent... components)
	{
		CraftPlayer craftPlayer = (CraftPlayer) player;
		if (craftPlayer.getHandle().playerConnection == null) {
			return;
		}
		PacketPlayOutChat packet = new PacketPlayOutChat();
		packet.components = components;
		craftPlayer.getHandle().playerConnection.sendPacket(packet);
	}
	
	private String setColor(String message, String color){
		String[] args = message.split("");
		ArrayList<String> finalargs = new ArrayList<String>();
		for(String word : args){
			finalargs.add(color+word);
		}
		String finalstring = "";
		for(int i = 0; i < args.length; i++){
			finalstring = finalstring + finalargs.get(i);
		}
		
		return finalstring;
	}

}
