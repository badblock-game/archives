package fr.badblock.bukkit.games.pvpbox.objects;

import lombok.Getter;
import lombok.Setter;

import java.util.UUID;

import com.google.gson.annotations.Expose;

import fr.badblock.bukkit.games.pvpbox.utils.database.DataRequest;
import fr.badblock.bukkit.games.pvpbox.utils.database.DataType;
import fr.badblock.bukkit.games.pvpbox.utils.database.DatabaseManager;

@Getter @Setter public class BadPlayerInfos {
	
			private BadPlayer badPlayer;
	@Expose private int 	  kills;
	@Expose private int 	  deaths;
	@Expose private int 	  teamKills;
	@Expose private int 	  teamDeaths;
	@Expose private int 	  teamVictories;
	@Expose private int 	  teamLooses;
	@Expose private int		  points;
	@Expose private UUID 	  uuid;
	@Expose private String	  currentkit;
	@Expose private String 	  teamName;

	public BadPlayerInfos(BadPlayer badPlayer, BadPlayerInfos clone) {
		this.setBadPlayer(badPlayer);
		this.setPoints(clone.points);
		this.setKills(clone.getKills());
		this.setDeaths(clone.getDeaths());
		this.setTeamKills(clone.getTeamKills());
		this.setTeamDeaths(clone.getTeamDeaths());
		this.setTeamVictories(clone.getTeamVictories());
		this.setTeamLooses(clone.getTeamLooses());
		this.setUuid(clone.getUuid());
		this.setCurrentkit(clone.getCurrentkit());
		this.setTeamName(clone.getTeamName());
	}
	
	public BadPlayerInfos(BadPlayer badPlayer, int kills, int deaths, int teamKills, int teamDeaths, int teamVictories, int teamLooses, int points, UUID uuid, String currentkit, String teamname) {
		this.setBadPlayer(badPlayer);
		this.setKills(kills);
		this.setDeaths(deaths);
		this.setTeamKills(teamKills);
		this.setTeamDeaths(teamDeaths);
		this.setTeamVictories(teamVictories);
		this.setTeamLooses(teamLooses);
		this.setPoints(points);
		this.setUuid(uuid);
		this.setCurrentkit(currentkit);
		this.setTeamName(teamname);
	}
	
	public BadPlayerInfos save() {
		DatabaseManager.sendQuery(new DataRequest("UPDATE pvpbox_players SET points = '" + points + "', kills = '" + kills + "', deaths = '" + deaths + "', teamKills = '" + teamKills + "', teamDeaths = '" + teamDeaths + "', teamVictories = '" + teamVictories + "', teamLooses = '" + teamLooses + "', points = '" + points + "', uuid = '" + uuid.toString()+"', currentkit = '"+currentkit+"', teamName = '"+teamName+"' WHERE pseudo = '" + this.getBadPlayer().name + "'", DataType.UPDATE));
		return this;
	}
	
	
}
