package fr.badblock.bukkit.games.pvpbox.utils;

import java.util.Queue;

import com.google.common.collect.Queues;

public class BoxThread extends Thread {
	
	public static BoxThread instance;
	public Queue<Runnable>	queue;
	
	public BoxThread() {
		instance = this;
		queue = Queues.newConcurrentLinkedQueue();
		this.setName("boxThread");
		this.start();
	}
	
	@Override
	public void run() {
		while (true) {
			if (!queue.isEmpty()) {
				try {
					Runnable runnable = queue.poll();
					runnable.run();
				}catch(Exception error) {
					error.printStackTrace();
				}
				if (!queue.isEmpty()) continue;
			}
			try {
				synchronized (instance) {
					instance.wait();
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void addRequest(Runnable runnable) {
		queue.add(runnable);
		if (this.isAlive() && this.getState() != null && this.getState().equals(State.WAITING))
			synchronized (instance) {
				instance.notify();
			}
	}
	
}
