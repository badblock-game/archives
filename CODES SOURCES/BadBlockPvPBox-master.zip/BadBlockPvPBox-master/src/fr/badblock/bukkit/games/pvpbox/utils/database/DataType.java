package fr.badblock.bukkit.games.pvpbox.utils.database;

public enum DataType {
	
	QUERY,
	UPDATE;
	
}
