package fr.badblock.bukkit.games.pvpbox.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.permissions.Permission;

import fr.badblock.bukkit.games.pvpbox.utils.ChatUtils;

public abstract class AbstractCommand implements CommandExecutor {
	
	protected String permission, help;
	protected boolean allowConsole;
	
	public AbstractCommand(String permission, String help, boolean allowConsole) {
		this.permission = permission;
		this.allowConsole = allowConsole;
		this.help = help;
	}
	
	public boolean can(CommandSender sender) {
		return sender.hasPermission(new Permission(permission)) && (allowConsole || (sender instanceof Player));
	}
	
	public void sendHelp(CommandSender sender) {
		sendMessage(sender, help);
	}
	
	public void sendMessage(CommandSender sender, String... messages) {
		for (String message : messages)
			sender.sendMessage(ChatUtils.colorReplace(message));
	}
	
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String arg, String[] args) {
		if (!can(sender)) {
			sender.sendMessage("§cVous n'avez pas la permission d'utiliser cette commande.");
			return true;
		}
		run(sender, args);
		return true;
	}
	
	public abstract void run(CommandSender sender, String[] args);
	
}
