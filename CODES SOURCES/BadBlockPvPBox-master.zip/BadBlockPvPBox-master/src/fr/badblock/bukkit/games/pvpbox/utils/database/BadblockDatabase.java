package fr.badblock.bukkit.games.pvpbox.utils.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Queue;

import com.google.common.collect.Queues;

import fr.badblock.bukkit.games.pvpbox.utils.LoggerUtils;

public class BadblockDatabase {

	private static BadblockDatabase instance;
	
	// Instance
	private Connection connection;
	private boolean    isConnected;
	private Statement  statement;
	public Thread	   thread;
	public  Queue<DataRequest> request	=	 Queues.newLinkedBlockingDeque();
	
	public static BadblockDatabase getInstance() {
		if (instance == null) instance = new BadblockDatabase();
		return instance;
	}
	
	/**
	 * Connexion � la base de donn�es
	 * @param hostName
	 * @param port
	 * @param username
	 * @param password
	 * @param database
	 */
	public void connect(String hostName, int port, String username, String password, String database) {
		if (port == 0) return; // retourne si le port est vide.
		thread = new Thread("pvpbox_database") {
			@Override
			public void run() {
				synchronized (thread) {
					while (true) {
						while (!request.isEmpty()) {
							DataRequest query = request.poll();
							try {
								Statement statement = BadblockDatabase.getInstance().createStatement();
								if (query.getType().equals(DataType.QUERY)) {
									ResultSet resultSet = statement.executeQuery(query.getQuery());
									query.callback(resultSet);
									resultSet.close();
								}else{
									statement.executeUpdate(query.getQuery());
								}
								statement.close();
							}catch(Exception error) {
								error.printStackTrace();
							}
						}
						try {
							thread.wait();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
				}
			}
		};
		thread.start();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			DriverManager.setLoginTimeout(5);
			connection = DriverManager.getConnection("jdbc:mysql://" + hostName + ":" + port + "/" +database+"?autoReconnect=true&connectTimeout=5000", username, password);
			this.isConnected = true;
			System.out.println("-------------------");
			System.out.println("SQL CONNECTE");
			System.out.println("-------------------");
			LoggerUtils.logWithColor("§a[PvPBox] Base de donnée ok!");
		} catch (Exception e) {
			LoggerUtils.logWithColor("§c> "+e.getMessage());
			e.printStackTrace();
		}
	}
	
	/**
	 * V�rifier si la personne est connect�e � la base de donn�e.
	 * Attention: m�thode d�capr�c�e car elle ne permet pas de savoir si la personne est r�ellement connect�e encore.
	 * @deprecated
	 * @return
	 */
	public boolean isConnected() {
		return this.isConnected;
	}
	
	/**
	 * V�rifier si la connexion est active.
	 * @return
	 * @throws SQLException
	 */
	public boolean isConnectionEtablished() throws SQLException {
		return this.connection != null && !this.connection.isClosed();
	}
	
	/**
	 * Cr�er un statement reli�e � la connexion de la base de donn�e
	 * @return
	 * @throws SQLException
	 */
	public Statement createStatement() throws SQLException {
		if (!isConnected || (connection != null && connection.isClosed())) {
			throw new DatabaseIsNotConnectedException();
		}
		return connection.createStatement();
	}
	
	/**
	 * Terminer la connexion, cela terminera la liaison avec la base de donn�es ainsi que les statements et requ�tes en cours sur la session.
	 * @throws SQLException
	 */
	public void closeConnection() throws SQLException {
		connection.close();
	}
	
	/**
	 * R�cup�rer la connexion active
	 * @return
	 */
	public Connection getConnection() {
		return this.connection;
	}
	
	/**
	 * 
	 * @author Aurelian User
	 *
	 */
	@SuppressWarnings("serial")
	private class DatabaseIsNotConnectedException extends RuntimeException {
		public DatabaseIsNotConnectedException() {
			super("Operation cannot be executed because the database was not connected.");
		}
	}
	
}
