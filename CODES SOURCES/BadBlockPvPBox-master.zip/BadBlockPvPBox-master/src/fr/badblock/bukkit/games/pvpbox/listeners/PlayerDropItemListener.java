package fr.badblock.bukkit.games.pvpbox.listeners;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerDropItemEvent;

import fr.badblock.bukkit.games.pvpbox.objects.BadPlayer;
import fr.badblock.bukkit.games.pvpbox.objects.GameState;

public class PlayerDropItemListener implements Listener {
	
	@EventHandler
	public void onPlayerDropItem(PlayerDropItemEvent event) {
		Player player = event.getPlayer();
		if (player.hasPermission("pvpbox.admin")) return;
		BadPlayer badPlayer = BadPlayer.get(player);
		if (badPlayer.gameState.equals(GameState.WAIT))
			event.setCancelled(true);
	}
	
}
