package fr.badblock.bukkit.games.pvpbox.utils;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.Plugin;

import fr.badblock.bukkit.games.pvpbox.BadBlockPvPBox;

public class ConfigUtils {

	/*
	 * Configuration "classiques" à tous les jeux
	 */

	/**
	 * Recupérer le nom de la map
	 * @param plugin
	 * @return le nom ou "NoName" si la configuration n'en a pas
	 */
	public static String getMapName(Plugin plugin) {
		return (plugin.getConfig().getString("mapName") != null ? plugin.getConfig().getString("mapName") : "NoName");
	}

	/*
	 * WaitingRoom et assimilés
	 */

	/**
	 * Recupère le point nommé
	 * @param plugin
	 * @return le point nommé ou le spawn de base du world
	 */
	public static Location getLocation(BadBlockPvPBox plugin, String name, File file, FileConfiguration config) {
		return getLocationFromFile(plugin, name, file, config) != null ? getLocationFromFile(plugin, name, file, config) : Bukkit.getWorlds().get(0).getSpawnLocation();
	}

	/**
	 * Définit la location nommée
	 * @param plugin
	 * @param location
	 */
	public static void setLocation(BadBlockPvPBox plugin, Location location, String name, FileConfiguration config, File file) {
		saveLocation(plugin, name, location, file, config);
		try {
			config.save(file);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Recupère une liste de locations
	 */
	public static List<Location> getLocationList(BadBlockPvPBox plugin, String name, File file, FileConfiguration config) {
		List<Location> spawns = new ArrayList<Location>();
		List<String> configSpawns = config.getStringList(name);
		for (String loc : configSpawns) {
			String[] wxyz = loc.split(",");
			World w = Bukkit.getWorld(wxyz[0]);
			double x = Double.parseDouble(wxyz[1]);
			double y = Double.parseDouble(wxyz[2]);
			double z = Double.parseDouble(wxyz[3]);
			int pitch = Integer.parseInt(wxyz[4]);
			int yaw = Integer.parseInt(wxyz[5]);
			Location location = new Location(w, x, y, z);
			location.setPitch(pitch);
			location.setYaw(yaw);
			spawns.add(location);
		}
		return spawns;
	}

	/**
	 * Sauvegarde une liste de locations
	 * @param plugin
	 * @param locations
	 * @param name
	 */
	public static void saveLocationList(BadBlockPvPBox plugin, List<Location> locations, String name, File file, FileConfiguration config) {
		List<String> locsToString = new ArrayList<String>();
		for (Location location : locations) {
			locsToString.add(ConfigUtils.convertLocationToString(location));
		}
		config.set(name, locsToString);
		try {
			config.save(file);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/*
	 * Location file convertion
	 */

	/**
	 * Sauvegarde la location
	 * @param plugin
	 * @param node
	 * @param location
	 */
	public static void saveLocation(Plugin plugin, String node, Location location, File file, FileConfiguration config) {
		config.set(node, convertLocationToString(location));
		try {
			config.save(file);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Sauvegarde la location en type Block
	 * @param plugin
	 * @param node
	 * @param location
	 */
	public static void saveBlockLocation(Plugin plugin, String node, Location location, File file, FileConfiguration config) {
		config.set(node, convertLocationBlockToString(location));
		try {
			config.save(file);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Recupère une location dans la config
	 * @param plugin
	 * @param node
	 * @return
	 */
	public static Location getLocationFromFile(Plugin plugin, String node, File file, FileConfiguration config) {
		return convertStringToLocation(config.getString(node));
	}

	/**
	 * Recupère une location de type Block dans la config
	 * @param plugin
	 * @param node
	 * @return
	 */
	public static Location getBlockLocationFromFile(Plugin plugin, String node, File file, FileConfiguration config) {
		return convertStringToBlockLocation(config.getString(node));
	}

	/*
	 * Convertions
	 */

	/**
	 * Location Block à partir d'une chaine
	 * @param string
	 * @return
	 */
	public static Location convertStringToBlockLocation(String string) {
		if (string != null) {
			String[] wxyz = string.split(",");
			World w = Bukkit.getWorld(wxyz[0]);
			int x = Integer.parseInt(wxyz[1]);
			int y = Integer.parseInt(wxyz[2]);
			int z = Integer.parseInt(wxyz[3]);
			return new Location(w, x, y, z);
		}
		return null;
	}

	/**
	 * Location à partir d'une chaine
	 * @param string
	 * @return
	 */
	public static Location convertStringToLocation(String string) {
		if (string == null) return null;
		String[] wxyzPitchYaw = string.split(",");
		World w = Bukkit.getWorld(wxyzPitchYaw[0]);
		double x = Double.parseDouble(wxyzPitchYaw[1]);
		double y = Double.parseDouble(wxyzPitchYaw[2]);
		double z = Double.parseDouble(wxyzPitchYaw[3]);
		int pitch = Integer.parseInt(wxyzPitchYaw[4]);
		int yaw = Integer.parseInt(wxyzPitchYaw[5]);
		Location location = new Location(w, x, y, z);
		location.setPitch(pitch);
		location.setYaw(yaw);
		return location;
	}

	/**
	 * Converti une location block en chaine
	 * @param location
	 * @return
	 */
	public static String convertLocationBlockToString(Location location) {
		String world = location.getWorld().getName();
		int x = location.getBlockX();
		int y = location.getBlockY();
		int z = location.getBlockZ();
		return world + "," + x + "," + y + "," + z;
	}

	/**
	 * Converti une location en chaine
	 * @param location
	 * @return
	 */
	public static String convertLocationToString(Location location) {
		String world = location.getWorld().getName();
		double x = location.getX();
		double y = location.getY();
		double z = location.getZ();
		int pitch = (int) location.getPitch();
		int yaw = (int) location.getYaw();
		return world + "," + x + "," + y + "," + z + "," + pitch + "," + yaw;
	}
	
}
