package fr.badblock.bukkit.games.pvpbox.utils;

public enum BoxLevel {
	
	LEVEL_001("1", 1),
	LEVEL_002("2", 2),
	LEVEL_003("3", 3),
	LEVEL_004("4", 4),
	LEVEL_005("5", 5),
	LEVEL_006("6", 6),
	LEVEL_007("7", 7),
	LEVEL_008("8", 8),
	LEVEL_009("9", 9),
	LEVEL_010("10", 10),
	LEVEL_011("11", 11),
	LEVEL_012("12", 12),
	LEVEL_013("13", 13),
	LEVEL_014("14", 14),
	LEVEL_015("15", 15),
	LEVEL_016("16", 16),
	LEVEL_017("17", 17),
	LEVEL_018("18", 18),
	LEVEL_019("19", 19),
	LEVEL_020("20", 20),
	LEVEL_021("21", 21),
	LEVEL_022("22", 22),
	LEVEL_023("23", 23),
	LEVEL_024("24", 24),
	LEVEL_025("25", 25),
	LEVEL_026("26", 26),
	LEVEL_027("27", 27),
	LEVEL_028("28", 28),
	LEVEL_029("29", 29),
	LEVEL_030("30", 30),
	LEVEL_031("31", 31),
	LEVEL_032("32", 32),
	LEVEL_033("33", 33),
	LEVEL_034("34", 34),
	LEVEL_035("35", 35),
	LEVEL_036("36", 36),
	LEVEL_037("37", 37),
	LEVEL_038("38", 38),
	LEVEL_039("39", 39),
	LEVEL_040("40", 40),
	LEVEL_041("41", 41),
	LEVEL_042("42", 42),
	LEVEL_043("43", 43),
	LEVEL_044("44", 44),
	LEVEL_045("45", 45),
	LEVEL_046("46", 46),
	LEVEL_047("47", 47),
	LEVEL_048("48", 48),
	LEVEL_049("49", 49),
	LEVEL_050("50", 50),
	LEVEL_051("51", 51),
	LEVEL_052("52", 52),
	LEVEL_053("53", 53),
	LEVEL_054("54", 54),
	LEVEL_055("55", 55),
	LEVEL_056("56", 56),
	LEVEL_057("57", 57),
	LEVEL_058("58", 58),
	LEVEL_059("59", 59),
	LEVEL_060("60", 60),
	LEVEL_061("61", 61),
	LEVEL_062("62", 62),
	LEVEL_063("63", 63),
	LEVEL_064("64", 64),
	LEVEL_065("65", 65),
	LEVEL_066("66", 66),
	LEVEL_067("67", 67),
	LEVEL_068("68", 68),
	LEVEL_069("69", 69),
	LEVEL_070("70", 70),
	LEVEL_071("71", 71),
	LEVEL_072("72", 72),
	LEVEL_073("73", 73),
	LEVEL_074("74", 74),
	LEVEL_075("75", 75),
	LEVEL_076("76", 76),
	LEVEL_077("77", 77),
	LEVEL_078("78", 78),
	LEVEL_079("79", 79),
	LEVEL_080("80", 80),
	LEVEL_081("81", 81),
	LEVEL_082("82", 82),
	LEVEL_083("83", 83),
	LEVEL_084("84", 84),
	LEVEL_085("85", 85),
	LEVEL_086("86", 86),
	LEVEL_087("87", 87),
	LEVEL_088("88", 88),
	LEVEL_089("89", 89),
	LEVEL_090("90", 90),
	LEVEL_091("91", 91),
	LEVEL_092("92", 92),
	LEVEL_093("93", 93),
	LEVEL_094("94", 94),
	LEVEL_095("95", 95),
	LEVEL_096("96", 96),
	LEVEL_097("97", 97),
	LEVEL_098("98", 98),
	LEVEL_099("99", 99),
	LEVEL_100("100", 100);
	/*
	
	/*LEVEL_001(0, "1", 1),
	LEVEL_002(6, "2", 2),
	LEVEL_003(128, "3", 3),
	LEVEL_004(256, "4", 4),
	LEVEL_005(512, "5", 5),
	LEVEL_006(768, "6", 6),
	LEVEL_007(1024, "7", 7),
	LEVEL_008(1280, "8", 8),
	LEVEL_009(1536, "9", 9),
	LEVEL_010(1792, "10", 10),
	LEVEL_011(2536, "11", 11),
	LEVEL_012(3072, "12", 12),
	LEVEL_013(4096, "13", 13),
	LEVEL_014(5108, "14", 14),
	LEVEL_015(6144, "15", 15),
	LEVEL_016(7164, "16", 16),
	LEVEL_017(8192, "17", 17),
	LEVEL_018(9812, "18", 18),
	LEVEL_019(11533, "19", 19),
	LEVEL_020(13477, "20", 20),
	LEVEL_021(17589, "21", 21),
	LEVEL_022(20001, "22", 22),
	LEVEL_023(22514, "23", 23),
	LEVEL_024(25619, "24", 24),
	LEVEL_025(29404, "25", 25),
	LEVEL_026(32047, "26", 26),
	LEVEL_027(36777, "27", 27),
	LEVEL_028(39999, "28", 28),
	LEVEL_029(44801, "29", 29),
	LEVEL_030(50000, "30", 30),
	LEVEL_031(54672, "31", 31),
	LEVEL_032(58541, "32", 32),
	LEVEL_033(61011, "33", 33),
	LEVEL_034(65222, "34", 34),
	LEVEL_035(69999, "35", 35),
	LEVEL_036(74582, "36", 36),
	LEVEL_037(78521, "37", 37),
	LEVEL_038(81010, "38", 38),
	LEVEL_039(84555, "39", 39),
	LEVEL_040(89761, "40", 40),
	LEVEL_041(92041, "41", 41),
	LEVEL_042(98882, "42", 42),
	LEVEL_043(100000, "43", 43),
	LEVEL_044(13477, "44", 44),
	LEVEL_045(13477, "45", 45),
	LEVEL_046(13477, "46", 46),
	LEVEL_047(13477, "47", 47),
	LEVEL_048(13477, "48", 48),
	LEVEL_049(13477, "49", 49),
	LEVEL_050(13477, "50", 50),
	LEVEL_051(13477, "51", 51),
	LEVEL_052(13477, "52", 52),
	LEVEL_053(13477, "53", 53),
	LEVEL_054(13477, "54", 54),
	LEVEL_055(13477, "55", 55),
	LEVEL_056(13477, "56", 56),
	LEVEL_057(13477, "57", 57),
	LEVEL_058(13477, "58", 58),
	LEVEL_059(13477, "59", 59),
	LEVEL_060(13477, "60", 60),
	LEVEL_061(13477, "61", 61),
	LEVEL_062(13477, "62", 62),
	LEVEL_063(13477, "63", 63),
	LEVEL_064(13477, "64", 64),
	LEVEL_065(13477, "65", 65),
	LEVEL_066(13477, "66", 66),
	LEVEL_067(13477, "67", 67),
	LEVEL_068(13477, "68", 68),
	LEVEL_069(13477, "69", 69),
	LEVEL_070(13477, "70", 70),
	LEVEL_071(13477, "71", 71),
	LEVEL_072(13477, "72", 72),
	LEVEL_073(13477, "73", 73),
	LEVEL_074(13477, "74", 74),
	LEVEL_075(13477, "75", 75),
	LEVEL_076(13477, "76", 76),
	LEVEL_077(13477, "77", 77),
	LEVEL_078(13477, "78", 78),
	LEVEL_079(13477, "79", 79),
	LEVEL_080(13477, "80", 80),
	LEVEL_081(13477, "81", 81),
	LEVEL_082(13477, "82", 82),
	LEVEL_083(13477, "83", 83),
	LEVEL_084(13477, "84", 84),
	LEVEL_085(13477, "85", 85),
	LEVEL_086(13477, "86", 86),
	LEVEL_087(13477, "87", 87),
	LEVEL_088(13477, "88", 88),
	LEVEL_089(13477, "89", 89),
	LEVEL_090(13477, "90", 90),
	LEVEL_091(13477, "91", 91),
	LEVEL_092(13477, "92", 92),
	LEVEL_093(13477, "93", 93),
	LEVEL_094(13477, "94", 94),
	LEVEL_095(13477, "95", 95),
	LEVEL_096(13477, "96", 96),
	LEVEL_097(13477, "97", 97),
	LEVEL_098(13477, "98", 98),
	LEVEL_099(13477, "99", 99),
	LEVEL_100(13477, "100", 100);*/
	
	public static BoxLevel	maxLevel;
	
	//public int 	  level;
	public int	  id;
	public String name;
	
	static {
		BoxLevel level = BoxLevel.LEVEL_001;
		for (BoxLevel levels : values())
			if (level.xp() < levels.xp()) {
				level = levels;
				continue;
			}
		maxLevel = level;
	}
	
	BoxLevel(/*int level, */String name, int id) {
		//this.level = level;
		this.id = id;
		this.name = name;
	}
	
	public int xp() {
		if (this.id == 1) return 0;
		return id^id^id;
	}
	
	public static BoxLevel getLevel(double exp) {
		BoxLevel level = BoxLevel.LEVEL_001;
		if (exp < level.xp()) return level;
		for (BoxLevel levels : values())
			if (exp >= levels.xp()) {
				level = levels;
				continue;
			}
		return level;
 	}	
	
	public static BoxLevel getLevel(int level) {
		for (BoxLevel levels : values())
			if (levels.id == level) return levels;
		return null;
 	}
	
	public static BoxLevel getNextLevel(double exp) {
		BoxLevel level = BoxLevel.LEVEL_001;
		for (BoxLevel levels : values())
			if (exp >= levels.xp()) {
				level = levels;
			}else{
				level = levels;
				break;
			}
		return level;
 	}
	
}
