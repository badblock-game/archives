package fr.badblock.bukkit.games.pvpbox.listeners;

import org.bukkit.Location;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;

import fr.badblock.bukkit.games.pvpbox.arenas.Duel;
import fr.badblock.bukkit.games.pvpbox.objects.BadPlayer;
import fr.badblock.bukkit.games.pvpbox.objects.BadTeam;
import fr.badblock.bukkit.games.pvpbox.objects.GameState;

public class EntityDamageListener implements Listener {

	@EventHandler
	public void onEntityDamage(EntityDamageEvent event) {
		Entity entity = event.getEntity();
		EntityType type = event.getEntityType();
		if (type.equals(EntityType.ARMOR_STAND) || type.equals(EntityType.PAINTING) || type.equals(EntityType.ITEM_FRAME))
			event.setCancelled(true);
		if (event.getCause().equals(DamageCause.FALL)) event.setCancelled(true);
		if (entity.getType().equals(EntityType.PLAYER)) {
			Player player = (Player) entity;
			BadPlayer badPlayer = BadPlayer.get(player);
			if (badPlayer.godmode) {
				event.setCancelled(true);
				return;
			}else if (badPlayer.vanish) {
				event.setCancelled(true);
				return;
			}
		}
	}

	@EventHandler (priority = EventPriority.MONITOR)
	public void onEntityDamage(EntityDamageByEntityEvent event) {
		Entity entity = event.getEntity();
		Entity damager = event.getDamager();
		if (damager.getType().equals(EntityType.ARROW)) {
			Arrow arrow = (Arrow) damager;
			if (arrow.getShooter() instanceof Player) {
				damager = (Player) arrow.getShooter();
			}
		}
		Location location = entity.getLocation();
		if (entity.getType().equals(EntityType.PLAYER)) {
			Player player = (Player) entity;
			BadPlayer badPlayer = BadPlayer.get(player);
			if (badPlayer.gameState.equals(GameState.WAIT)) {
				event.setCancelled(true);
				return;
			}	
			if (badPlayer.godmode) {
				event.setCancelled(true);
				return;
			}
			if (badPlayer.vanish) {
				event.setCancelled(true);
				return;
			}
			if (badPlayer.gameState.equals(GameState.IN_TEAM_ARENA)) {
				Duel duel = Duel.get(player);
				if (duel != null) {
					if (damager instanceof Player) {
						Player dp = (Player) damager;
						BadTeam badTeam = BadTeam.getTeam(dp);
						if (badTeam != null) {
							if ((badTeam.players.containsKey(dp.getName()) && badTeam.players.containsKey(player.getName()))) {
								event.setCancelled(true);
								return;
							}
						}
					}
					if (duel.launched) return;
				}
				event.setCancelled(true);
			}
			if (badPlayer.boxArenaBypass >= System.currentTimeMillis()) {
				event.setCancelled(true);
				player.sendMessage("§cPatientez avant de pouvoir attaquer ce joueur, il vient d'atterir dans l'arène.");
				return;
			}
			badPlayer.timedeco = System.currentTimeMillis() + 60_000L;
			//if (!event.isCancelled())
				//location.getWorld().playEffect(location.add(0, 1, 0), Effect.STEP_SOUND, 152);
		}
		if (damager.getType().equals(EntityType.PLAYER)) {
			Player player = (Player) damager;
			BadPlayer badPlayer = BadPlayer.get(player);
			if (badPlayer.gameState.equals(GameState.WAIT)) {
				event.setCancelled(true);
				return;
			}
			if (badPlayer.godmode || badPlayer.vanish) {
				event.setCancelled(true);
				player.sendMessage("§cVous ne pouvez pas jouer en godmode !");
				return;
			}
			if (badPlayer.gameState.equals(GameState.IN_TEAM_ARENA)) {
				Duel duel = Duel.get(player);
				if (duel != null) {
					if (entity instanceof Player) {
						Player ep = (Player) entity;
						BadTeam badTeam = BadTeam.getTeam(player);
						if (badTeam != null) {
							if ((badTeam.players.containsKey(player.getName()) && badTeam.players.containsKey(ep.getName()))) {
								event.setCancelled(true);
								return;
							}
						}
					}
					if (duel.launched) return;
				}
				event.setCancelled(true);
			}
			if (badPlayer.boxArenaBypass >= System.currentTimeMillis()) {
				event.setCancelled(true);
				player.sendMessage("§cPatientez avant de pouvoir attaquer ce joueur, vous venez d'atterir dans l'arène.");
				return;
			}
			badPlayer.timedeco = System.currentTimeMillis() + 60_000L;
		}
	}

}
