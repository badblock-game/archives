package fr.badblock.bukkit.games.pvpbox.listeners;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityInteractEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import fr.badblock.bukkit.games.pvpbox.BadBlockPvPBox;
import fr.badblock.bukkit.games.pvpbox.arenas.Duel;
import fr.badblock.bukkit.games.pvpbox.objects.BadTeam;

public class PlayerCloseInventoryListener implements Listener {
	
	@EventHandler (ignoreCancelled = false)
	public void onPlayerCloseInventory(InventoryCloseEvent event) {
		if (!(event.getPlayer().getType().equals(EntityType.PLAYER))) return;
		Player player = (Player) event.getPlayer();
		if (event.getInventory() != null && event.getInventory().getName() != null && event.getInventory().getName().equals(BadBlockPvPBox.instance.teamKitSelectorInventory.getName())) {
			Duel duel = Duel.get(player);
			if (duel != null) {
				if (duel.finish == true) return;
				if (duel.kits.get(player) != null) return;
				duel.sendMessage("§b§l[Duel] §c" + player.getName() + " a quitté l'inventaire des kits, duel annulé.");
				duel.finish(player);
			}
		}
	}
	
}
