package fr.badblock.bukkit.games.pvpbox.commands;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import fr.badblock.bukkit.games.pvpbox.BadBlockPvPBox;
import fr.badblock.bukkit.games.pvpbox.arenas.Duel;
import fr.badblock.bukkit.games.pvpbox.objects.BadPlayer;
import fr.badblock.bukkit.games.pvpbox.objects.GameState;

public class GmCommand implements CommandExecutor {
	
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String be, String[] args) {
		if (!(sender instanceof Player)) return false;
		Player player = (Player) sender;
		String result = "";
		int i = 0;
		for (String arg : args) {
			i++;
			if (i == args.length) {
				result += arg;
			}else result += arg + " ";
		}
		BadPlayer badPlayer = BadPlayer.get(player);
		player.getServer().dispatchCommand(player, "gamemode " + result);
		return true;
	}
	
}
