package fr.badblock.bukkit.games.pvpbox.arenas;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Collectors;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.scheduler.BukkitRunnable;

import fr.badblock.bukkit.games.pvpbox.BadBlockPvPBox;
import fr.badblock.bukkit.games.pvpbox.kits.Kit;
import fr.badblock.bukkit.games.pvpbox.objects.BadPlayer;
import fr.badblock.bukkit.games.pvpbox.objects.BadTeam;
import fr.badblock.bukkit.games.pvpbox.objects.GameState;
import fr.badblock.bukkit.games.pvpbox.utils.TempScheduler;
import fr.badblock.bukkit.games.pvpbox.utils.Title;

public class Duel extends BukkitRunnable {
	
	public static List<Duel> duels = new ArrayList<>();
	
	public BadTeam  			demanderTeam;
	public BadTeam  			demandedTeam;
	public Location 			arenaLocation;
	public Map<Player, Kit>		kits;
	public Set<Player>			demanderPlayers;
	public Set<Player>			demandedPlayers;
	public Set<Player>			demanderPlayersBase;
	public Set<Player>			demandedPlayersBase;
	public boolean 				launched;
	public int					time = 10;
	public int		 			xpTask = 20;
	public boolean				finish;
	public List<Player>			spectators;
	public TempScheduler 		temp = new TempScheduler();
	
	public Duel(BadTeam demanderTeam, BadTeam demandedTeam, Location arenaLocation) {
		this.demanderTeam = demanderTeam;
		this.demandedTeam = demandedTeam;
		this.demanderPlayers = demanderTeam.getOnlinePlayers();
		this.demandedPlayers = demandedTeam.getOnlinePlayers();
		this.demanderPlayersBase = demanderTeam.getOnlinePlayers();
		this.demandedPlayersBase = demandedTeam.getOnlinePlayers();
		this.arenaLocation = arenaLocation;
		this.spectators = new ArrayList<>();
		this.kits = new HashMap<>();
		duels.add(this);
		this.runTaskTimer(BadBlockPvPBox.instance, 0, 20);
		List<Player> players = new ArrayList<>(getDemanderPlayers());
		players.addAll(getDemandedPlayers());
		for (Player player : players) {
			BadPlayer.get(player).setSpawn(player);
			for (Player plo : players)
				player.showPlayer(plo);
			this.kits.put(player, null);
			sendMessage("§b§l[Duel] §bEn attente de " + player.getName() + "...");
		}
		temp.task = Bukkit.getScheduler().runTaskTimer(BadBlockPvPBox.instance, new Runnable() {
			@Override
			public void run() {
				if (xpTask < 0) return;
				xpTask--;
				for (Player player : players) {
					if (!player.isOnline()) break;
					player.setExp(xpTask * 0.05F);
				}
			}
		}, 1, 1);
	}
	
	@Override
	public void run() {
		for (Player player : spectators) {
			if (player.isOnline() && player.getGameMode().equals(GameMode.SPECTATOR)) {
				if (player.getLocation().distance(arenaLocation) > 30) {
					player.teleport(arenaLocation);
					player.sendMessage("§cNe vous éloignez pas en spectateur !");
				}
			}
		}
		if (launched) return;
		if (!canStart()) {
			time = 10;
			return;
		}
		if (time < 0) return;
		List<Player> players = new ArrayList<>(getDemanderPlayers());
		players.addAll(getDemandedPlayers());
		if (time == 10) {
			for (Player player : players) {
				for (Player plo : players)
					player.showPlayer(plo);
				player.teleport(arenaLocation);
				PlayerInventory playerInventory = player.getInventory();
				if (kits.get(player) != null) {
					kits.get(player).items.forEach(kitItem -> {
						int slot = kitItem.slot;
						if (slot == 103) playerInventory.setHelmet(kitItem.itemStack);
						else if (slot == 102) playerInventory.setChestplate(kitItem.itemStack);
						else if (slot == 101) playerInventory.setLeggings(kitItem.itemStack);
						else if (slot == 100) playerInventory.setBoots(kitItem.itemStack);
						else playerInventory.setItem(slot, kitItem.itemStack);
					});
				}
				player.updateInventory();
				BadPlayer.get(player).gameState = GameState.IN_TEAM_ARENA;
			}
		}
		time--;
		if (time > 0) {
			xpTask = 20;
			Title title = new Title("§6Début du duel", "§6dans " + time + " seconde" + (time > 1 ? "s" : ""));
			title.setStayTime(15);
			for (Player player : players) {
				player.playSound(player.getLocation(), Sound.NOTE_STICKS, 100, 1);
				title.send(player);
				player.setLevel(time);
			}
		}
		if (time == 0) {
			temp.task.cancel();
			for (Player player : players) {
				player.playSound(player.getLocation(), Sound.ENDERDRAGON_GROWL, 100, 1);
				BadPlayer badPlayer = BadPlayer.get(player);
				player.setExp(badPlayer.playerExp);
				player.setLevel(badPlayer.playerLevel);
			}
			launched = true;
			sendMessage("§b§l[Duel] §aQue le duel commence !");
		}
	}
	
	public boolean canStart() {
		if (this.getDemandedPlayers().size() != this.getDemanderPlayers().size()) return false;
		for (Entry<Player, Kit> entry : kits.entrySet())
			if (entry.getValue() == null) {
				return false;
			}
		return true;
	}
	
	public List<Player> getDemanderPlayers() {
		return demanderPlayers.parallelStream().filter(player -> player != null && player.isOnline()).collect(Collectors.toList());
	}
	
	public List<Player> getDemandedPlayers() {
		return demandedPlayers.parallelStream().filter(player -> player != null && player.isOnline()).collect(Collectors.toList());
	}
	
	public void finish(Player po) {
		finish = true;
		if (temp != null && temp.task != null)
			temp.task.cancel();
		this.cancel();
		List<Player> players = new ArrayList<>(getDemanderPlayers());
		players.addAll(getDemandedPlayers());
		for (Player player : players)
			if (!player.isDead() && player.isOnline()) {
				BadPlayer.get(player).setSpawn(player, launched);
				if (po != null && !po.equals(player)) player.closeInventory();
			}
		for (Player player : spectators) {
			if (!player.isDead() && player.isOnline() && player.getGameMode().equals(GameMode.SPECTATOR)) {
				BadPlayer.get(player).setSpawn(player, launched);
				if (po != null && !po.equals(player)) player.closeInventory();
			}
		}
		duels.remove(this);
	}
	
	public void sendMessage(Player player, String string) {
		List<Player> players = new ArrayList<>(getDemanderPlayers());
		players.addAll(getDemandedPlayers());
		players.remove(player);
		for (Player plo : players)
			plo.sendMessage(string);
	}
	
	public void sendMessage(String string) {
		List<Player> players = new ArrayList<>(getDemanderPlayers());
		players.addAll(getDemandedPlayers());
		for (Player plo : players)
			plo.sendMessage(string);
	}
	
	public static Duel get(Player player) {
		for (Duel duel : duels)
			if (duel.getDemanderPlayers().contains(player) || duel.getDemandedPlayers().contains(player)) return duel;
		return null;
	}
	
	public static Duel getSpectator(Player player) {
		for (Duel duel : duels)
			if (duel.spectators.contains(player)) return duel;
		return null;
	}
	
	public static Location getFreeArena() {
		List<Location> frees = new ArrayList<>(BadBlockPvPBox.instance.teamArenaTeleportLocations);
		for (Duel duel : duels)
			frees.remove(duel.arenaLocation);
		if (frees.size() == 0) return null;
		return frees.get(0);
	}
	
}
