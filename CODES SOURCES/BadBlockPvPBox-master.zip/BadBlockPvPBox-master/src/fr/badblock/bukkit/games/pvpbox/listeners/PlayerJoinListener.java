package fr.badblock.bukkit.games.pvpbox.listeners;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.event.player.PlayerLoginEvent.Result;

import fr.badblock.bukkit.games.pvpbox.BadBlockPvPBox;
import fr.badblock.bukkit.games.pvpbox.objects.BadPlayer;
import fr.badblock.bukkit.games.pvpbox.objects.BadTeam;
import fr.badblock.bukkit.games.pvpbox.utils.TabList;

public class PlayerJoinListener implements Listener {
	
	@EventHandler
	public void onLogin(PlayerLoginEvent event) {
		Player player = event.getPlayer();
		if (player.hasPermission("slots.bypass")) return;
		int slots = BadBlockPvPBox.instance.configfile.getInt("slots");
		if (slots <= 0) return;
		else if (Bukkit.getOnlinePlayers().size() >= slots) event.disallow(Result.KICK_FULL, "§cCe serveur est surchargé, veuillez patienter quelques instants...");
	}
	
	@EventHandler
	public void onJoin(PlayerJoinEvent event) {
		TabList.sendTabList(BadBlockPvPBox.instance.configfile.getStringList("header"), BadBlockPvPBox.instance.configfile.getStringList("footer"), event.getPlayer());
		Player player = event.getPlayer();
		event.setJoinMessage("[§a+§r] " + player.getName());
		BadPlayer badPlayer = BadPlayer.get(player);
		badPlayer.setSpawn(player);
		BadTeam team = BadTeam.getTeam(player);
		if (team == null) return;
		team.getOnlinePlayers().forEach(plo -> {
			if (plo == null || !plo.isOnline()) return;
			plo.sendMessage("§b§l[Team] §e" + player.getName() + " s'est connecté(e).");
		});
		//player.sendMessage("§a§lBoostedWeek ➤ §6§lXP en PvPBox doublé + pas de perte d'XP à la mort ce week-end");
	}
	
}
