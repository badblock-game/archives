package fr.badblock.bukkit.games.pvpbox.listeners;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

import fr.badblock.bukkit.games.pvpbox.objects.BadPlayer;
import fr.badblock.bukkit.games.pvpbox.utils.BoxThread;
import ru.tehkode.permissions.events.PermissionEntityEvent;

public class PermissionEntityListener implements Listener {
	
	@EventHandler
	public void onPermissionEntity(PermissionEntityEvent event) {
		BoxThread.instance.addRequest(new Runnable() {
			@Override
			public void run() {
				for (Player plo : Bukkit.getOnlinePlayers())
					BadPlayer.get(plo).updateRanks();
			}
		});
	}
	
}
