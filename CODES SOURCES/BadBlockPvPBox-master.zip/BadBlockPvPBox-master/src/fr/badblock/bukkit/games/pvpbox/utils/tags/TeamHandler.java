﻿package fr.badblock.bukkit.games.pvpbox.utils.tags;


public class TeamHandler {

    String name;
    String prefix;
    String suffix;

    public TeamHandler(String name) {
        this.name = name;
    }
}