package fr.badblock.bukkit.games.pvpbox.objects;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Score;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import fr.badblock.bukkit.games.pvpbox.BadBlockPvPBox;
import fr.badblock.bukkit.games.pvpbox.utils.BoxLevel;
import fr.badblock.bukkit.games.pvpbox.utils.Title;
import fr.badblock.bukkit.games.pvpbox.utils.database.DataRequest;
import fr.badblock.bukkit.games.pvpbox.utils.database.DataType;
import fr.badblock.bukkit.games.pvpbox.utils.database.DatabaseManager;
import jdk.nashorn.internal.objects.annotations.Getter;
import jdk.nashorn.internal.objects.annotations.Setter;
import net.md_5.bungee.api.ChatColor;

public class BadPlayer {
	
	public static Map<UUID, BadPlayer> players = new HashMap<>();
	
	public String	  name;
	public GameState  gameState;
	public UUID		  uuid;
	public long		  boxArenaBypass;
	public long		  lastTeleport;
	public long		  bypassAlert;
	public boolean	  godmode;
	public boolean	  vanish;
	public Block	  block;
	public Objective  lastObjective;
	public Objective  scoreObjective;
	public Objective  levelsObjective;
	public Scoreboard scoreboard;
	public String	  rank;
	public int		  level = 1;
	public int 		  rang = 0;
	public int		  playerLevel;
	public float	  playerExp;
	public UUID		  enderpearluuid;
	
	public long       timedeco = 0;
	public long 	  enderpearlExpire;
	
	public boolean 	  haveuuid = false;
	
	public Map<String, Team>	 teams    = new HashMap<>();
	private BadPlayerInfos infos;
	
	public BadPlayer(Player player) {
		name = player.getName();
		uuid = player.getUniqueId();
		gameState = GameState.WAIT;
		player.setGameMode(GameMode.ADVENTURE);
		this.scoreboard = Bukkit.getScoreboardManager().getNewScoreboard();
		for (Entry<String, String> entry : BadBlockPvPBox.instance.teamsGroup.entrySet()) {
			Team team = scoreboard.registerNewTeam(entry.getKey() + "");
			team.setPrefix(ChatColor.translateAlternateColorCodes('&', BadBlockPvPBox.instance.teamsPrefix.get(entry.getKey())) + " ");
			teams.put(entry.getKey(), team);
		}
		this.updateRanks();
		Objective objective = scoreboard.registerNewObjective("showhealth", "health");
		objective.setDisplaySlot(DisplaySlot.BELOW_NAME);
		objective.setDisplayName("§c§l♥");
		levelsObjective = scoreboard.registerNewObjective("leveltab", "dummy");
		levelsObjective.setDisplaySlot(DisplaySlot.PLAYER_LIST);
		levelsObjective.setDisplayName(" niveaux");
		BadPlayer badPlayer = this;
		DatabaseManager.sendQuery(new DataRequest("SELECT uuid FROM pvpbox_players WHERE pseudo = '"+player.getName()+"'", DataType.QUERY){
			@Override
			public void callback(ResultSet resultSet){
				try {
					if(resultSet.next()){
						String uuid = resultSet.getString("uuid");
						if(uuid.equals("null") || uuid == null){
							haveuuid = false;
						} else {
							haveuuid = true;
						}
					} else {
						BadPlayerInfos badPlayerInfos = new BadPlayerInfos(badPlayer, 0, 0, 0, 0, 0, 0, 0, player.getUniqueId(), "null", "null");
						setInfos(badPlayerInfos);
						level = BoxLevel.getLevel((double) getInfos().getPoints()).id;
						Bukkit.getScheduler().runTask(BadBlockPvPBox.instance, new Runnable() {
							@Override
							public void run() {
								if (player == null || !player.isOnline()) return;
								badPlayer.updateScores(player);
							}
						});
						DatabaseManager.sendQuery(new DataRequest("INSERT INTO pvpbox_players(pseudo, points, kills, deaths, teamDeaths, teamKills, teamLooses, teamVictories, uuid, currentkit, teamName) VALUES('" + name + "', '" + badPlayerInfos.getPoints() + "', '" + badPlayerInfos.getKills() + "', '" + badPlayerInfos.getDeaths() + "', '" + badPlayerInfos.getTeamDeaths() + "', '" + badPlayerInfos.getTeamKills() + "', '" + badPlayerInfos.getTeamLooses() + "', '" + badPlayerInfos.getTeamVictories() + "', '"+badPlayerInfos.getUuid() +"', '"+badPlayerInfos.getCurrentkit()+"', '"+badPlayerInfos.getTeamName()+"')", DataType.UPDATE));
						haveuuid = true;
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		});
		
		String where = haveuuid == true ? "uuid" : "pseudo";
		String choosed = haveuuid == true ? player.getUniqueId().toString() : player.getName();
		DatabaseManager.sendQuery(new DataRequest("SELECT points, kills, deaths, teamDeaths, teamKills, teamLooses, teamVictories, uuid, currentkit, teamName FROM pvpbox_players WHERE " + where + " = '" + choosed + "'", DataType.QUERY) {
			@Override
			public void callback(ResultSet resultSet) {
				if (player == null || !player.isOnline()) return;
				try {
					if (resultSet.next()) {
						// int kills, int deaths, int teamKills, int teamDeaths, int teamVictories, int teamLooses, int points, uuid uuid) {
						BadPlayerInfos data = new BadPlayerInfos(badPlayer, resultSet.getInt("kills"), resultSet.getInt("deaths"), resultSet.getInt("teamKills"), resultSet.getInt("teamDeaths"), resultSet.getInt("teamVictories"), resultSet.getInt("teamLooses"), resultSet.getInt("points"), UUID.fromString(resultSet.getString("uuid")), resultSet.getString("currentkit"), resultSet.getString("teamName"));
						setInfos(data);
						data.save();
						level = BoxLevel.getLevel((double) data.getPoints()).id;
						Bukkit.getScheduler().runTask(BadBlockPvPBox.instance, new Runnable() {
							@Override
							public void run() {
								if (player == null || !player.isOnline()) return;
								badPlayer.updateScores(player);
							}
						});
					}else{
						
					}
				}catch(Exception error) {
					error.printStackTrace();
				}
			}
		});
		players.put(this.uuid, this);
		for (Player po : Bukkit.getOnlinePlayers()) {
			if (!BadPlayer.players.containsKey(po.getUniqueId())) continue;
			BadPlayer.get(po).updateScores(po);
		}
		this.updateScores(player);
		player.setScoreboard(scoreboard);
		/*Bukkit.getScheduler().runTaskTimer(BadBlockPvPBox.instance, new Runnable() {
			@Override
			public void run() {
				if (player == null || !player.isOnline()) return;
				updateScores(player);
			}
		}, 20 * 30, 20 * 30);*/
	}

	public BadPlayerInfos getInfos() {
		return infos;
	}
	
	public void setInfos(BadPlayerInfos infos) {
		this.infos = infos;
	}
	
	public void updateScores(Player player) {
		if (infos == null) return;
		this.updateRanks();
		this.getInfos().save();
		Objective last = scoreboard.getObjective(player.getName());
		if (last != null) last.unregister();
		scoreObjective = scoreboard.registerNewObjective(player.getName(), "dummy");
		scoreObjective.setDisplayName("§b§lPvP-Box");
		scoreObjective.setDisplaySlot(DisplaySlot.SIDEBAR);
		if (scoreObjective == null) return;
		double points = getInfos() == null ? 0 : getInfos().getPoints();
		if (points >= BoxLevel.maxLevel.xp()) {
			points = BoxLevel.maxLevel.xp();
			getInfos().setPoints((int) points);
		}
		int newLevel = BoxLevel.getLevel(points).id;
		if (newLevel > level) {
			level = newLevel;
			Title title = new Title("§aVous êtes désormais", "§aau niveau §b" + level);
			title.send(player);
			player.playSound(player.getLocation(), Sound.LEVEL_UP, 100, 1);
			Bukkit.broadcastMessage(rank + player.getName() + " §best désormais niveau §a" + level + "§b.");
		}else if (newLevel < level) {
			if (level == BoxLevel.maxLevel.id) {
				getInfos().setPoints(BoxLevel.maxLevel.xp());
				points = BoxLevel.maxLevel.xp();
			}else{
				level = newLevel;
				Title title = new Title("§cVous avez été rétrogradé", "§cau niveau §b" + level);
				title.send(player);
				player.playSound(player.getLocation(), Sound.ENDERMAN_DEATH, 100, 1);
			}
		}
		for (Player plo : Bukkit.getOnlinePlayers()) {
			if (!BadPlayer.players.containsKey(plo.getUniqueId())) continue;
			BadPlayer bplo = BadPlayer.get(plo);
			if (!plo.getPlayerListName().equals(plo.getName())) levelsObjective.getScore(plo.getPlayerListName()).setScore(bplo.level);
			else levelsObjective.getScore(plo.getName()).setScore(bplo.level);
		}
		Score score = scoreObjective.getScore("§8§m---------------------- ");
		score.setScore(14);
		score = scoreObjective.getScore("§7Experience : §b" + ((int)points));
		score.setScore(13);
		BoxLevel currentLevel = BoxLevel.getLevel(points);
		BoxLevel nextLevel = BoxLevel.getLevel(currentLevel.id + 1);
		double percent;
		if (nextLevel != null) {
			double max = nextLevel.xp();
			percent = (points - currentLevel.xp()) / (max - currentLevel.xp()) * 100.0D;
		}else percent = 100D;
		this.playerLevel = level;
		this.playerExp = (float) (percent / 100.0);
		score = scoreObjective.getScore("§7Niveau : §b" + level + " §a(" + round(percent, 2) + "%)");
		score.setScore(12);
		score = scoreObjective.getScore(" ");
		score.setScore(11);
		BadTeam badTeam = BadTeam.getTeam(player);
		if(badTeam != null){
			if(this.getInfos().getTeamName() != badTeam.name) this.getInfos().setTeamName(badTeam.name);
		} else {
			if(this.getInfos().getTeamName() != "null") this.getInfos().setTeamName("null");
		}
		String teamName = badTeam == null ? "§cAucune" : "§b" + badTeam.name;
		String teamNumber = badTeam == null ? "§b0" : "§b" + badTeam.getOnlinePlayers().size();
		double duelWins = getInfos() == null ? 0.0D : getInfos().getTeamVictories();
		double duelLooses = getInfos() == null ? 0.0D : getInfos().getTeamLooses();
//		double duelRatios = duelLooses == 0.0D ? duelWins : round(duelWins / duelLooses, 2) * 1.0D;
		double kills = getInfos() == null ? 0 : getInfos().getKills();
		double deaths = getInfos() == null ? 0 : getInfos().getDeaths();
		double ratios = deaths == 0.0D ? kills : round(kills / deaths, 2) * 1.0D;
		String currentkit = infos.getCurrentkit() == null || infos.getCurrentkit().equalsIgnoreCase("null") ? "§bPar défaut" : "§b"+infos.getCurrentkit();
		Statue statue = null;
		for (Statue s : Statue.statues)
			if (s.uuids.contains(player.getUniqueId())) statue = s;
		String statueName = statue == null ? "§cAucune" : statue.name;
		score = scoreObjective.getScore("§7Team : " + teamName + " §7(§b" + teamNumber + "§7)");
		score.setScore(10);
		score = scoreObjective.getScore("§7Duels : §b"+(int)duelWins+" §a✔ §7/§b "+(int)duelLooses + " §c✖ ");
		score.setScore(9);
//		score = scoreObjective.getScore("§7Duels perdus : §b" + (int)duelLooses);
//		score.setScore(10);
		score = scoreObjective.getScore("  ");
		score.setScore(8);
		score = scoreObjective.getScore("§7Tués : §b" + (int)kills);
		score.setScore(7);
		score = scoreObjective.getScore("§7Morts : §b" + (int)deaths);
		score.setScore(6);
		score = scoreObjective.getScore("§7Ratio : §b" + ratios);
		score.setScore(5);
		score = scoreObjective.getScore("   ");
		score.setScore(4);
		score = scoreObjective.getScore("§7Kit choisi : "+currentkit);
		score.setScore(3);
		score = scoreObjective.getScore("§7Statue : " + statueName);
		score.setScore(2);
		score = scoreObjective.getScore("§8§m----------------------");
		score.setScore(1);
		score = scoreObjective.getScore("§7Site : §b§lBadBlock.fr");
		score.setScore(0);
	}
	
	public static double round(double value, int places) {
		if (places < 0) throw new IllegalArgumentException();
		
		BigDecimal bd = new BigDecimal(value);
		bd = bd.setScale(places, RoundingMode.HALF_UP);
		return bd.doubleValue();
	}
	
	public void updateRanks() {
		Player player = Bukkit.getPlayer(this.name);
		if (player == null || !player.isOnline()) return;
		rank = BadBlockPvPBox.instance.permissionsExManager.getPrefix(player);
		Bukkit.getOnlinePlayers().forEach(plo -> {
			String o = "A";
			String pl = BadBlockPvPBox.instance.permissionsExManager.getGroup(plo);
			for (Entry<String, String> entry : BadBlockPvPBox.instance.teamsGroup.entrySet())
				if (entry.getValue().equals(pl))
					o = entry.getKey();
			if(o.equalsIgnoreCase("A")) return;
			Team team = teams.get(o);
			if (!team.hasPlayer(plo))
				team.addPlayer(plo);
			for (Team to : teams.values()) {
				if (!to.equals(team) && to.hasPlayer(plo)) to.removePlayer(plo);
			}
		});
	}
	
	public void setToBoxArena(Player player) {
		gameState = GameState.IN_BOX_ARENA;
		boxArenaBypass = System.currentTimeMillis() + 5000L;
		BadBlockPvPBox instance = BadBlockPvPBox.instance;
	}
	
	public void setSpawn(Player player, boolean withTp) {
		timedeco = 0;
		gameState = GameState.WAIT;
		player.setGameMode(GameMode.ADVENTURE);
		BadBlockPvPBox instance = BadBlockPvPBox.instance;
		if (withTp)
			player.teleport(instance.location);
		PlayerInventory inventory = player.getInventory();
		player.setMaxHealth(20);
		player.setHealth(20);
		for (PotionEffect potionEffect : player.getActivePotionEffects())
			player.removePotionEffect(potionEffect.getType());
		player.getActivePotionEffects().clear();
		player.setFoodLevel(20);
		inventory.clear();
		inventory.setArmorContents(null);
		inventory.setHeldItemSlot(4);
		inventory.setItem(4, instance.kitItem);
		inventory.setItem(8, instance.hubBackItem);
		ItemStack itemStack = new ItemStack(Material.SKULL_ITEM, 1, (short) 3);
		SkullMeta skull = (SkullMeta) itemStack.getItemMeta();
		skull.setOwner(player.getName());
		itemStack.setItemMeta(skull);
		ItemMeta itemMeta = itemStack.getItemMeta();
		itemMeta.setDisplayName("§bFaire un match de team");
		itemMeta.setLore(Arrays.asList("", "§eCet item vous permet de créer un match", "§ede team (votre team contre une autre)", "§eLes teams doivent être équilibrées", "§epour pouvoir lancer une session PvP"));
		itemStack.setItemMeta(itemMeta);
		inventory.setItem(0, itemStack);
		player.setFlying(false);
		player.setAllowFlight(false);
		player.setExp(this.playerExp);
		player.setLevel(this.playerLevel);
	}
	
	public void setSpawn(Player player) {
		setSpawn(player, true);
	}
	
	public void remove() {
		if(this.getInfos()!= null) 
			this.getInfos().save();
		players.remove(this.uuid);
	}
	
	public static BadPlayer get(Player player) {
		if (!players.containsKey(player.getUniqueId())) {
			BadPlayer badPlayer = new BadPlayer(player);
			players.put(player.getUniqueId(), badPlayer);
			return badPlayer;
		}
		return players.get(player.getUniqueId());
	}
	
}
