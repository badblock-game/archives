package fr.badblock.bukkit.games.pvpbox.kits;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.craftbukkit.v1_8_R3.inventory.CraftItemStack;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import net.md_5.bungee.api.ChatColor;
import net.minecraft.server.v1_8_R3.NBTTagCompound;
import net.minecraft.server.v1_8_R3.NBTTagList;

public class Kit {
	
	public static Map<String, Kit> kits = new HashMap<>();
	
	public Material		 material;
	public boolean		 splash;
	public int			 amount;
	public short		 data;
	public int			 slot;
	public String		 name;
	public boolean		 fakeEnchantment;
	public ItemStack	 kitItem;
	public List<KitItem> items;
	public String		 permission;
	
	public Kit(int slot, boolean splash, Material material, int amount, short data, String name, boolean fakeEnchantment, List<KitItem> items, String permission) {
		this.name = name;
		this.splash = splash;
		this.material = material;
		this.data = data;
		this.amount = amount;
		kitItem = new ItemStack(material, amount, data);
		if (fakeEnchantment) {
			net.minecraft.server.v1_8_R3.ItemStack nmsStack = CraftItemStack.asNMSCopy(kitItem);
			NBTTagCompound tag = null;
			if (!nmsStack.hasTag()){
				tag = new NBTTagCompound();
				nmsStack.setTag(tag);
			}
			if (tag == null)
				tag = nmsStack.getTag();
			NBTTagList ench = new NBTTagList();
			tag.set("ench", ench);
			nmsStack.setTag(tag);
			kitItem = CraftItemStack.asBukkitCopy(nmsStack);
		}
		ItemMeta itemMeta = kitItem.getItemMeta();
		itemMeta.setDisplayName(name);
		this.items = items;
		this.permission = permission;
		kits.put(this.name, this);
	}
	
	public Kit(ConfigurationSection cs) {
		slot = cs.getInt("slot");
		amount = cs.getInt("amount", 1);
		splash = cs.getBoolean("splash", false);
		name = cs.getString("name");
		name = ChatColor.translateAlternateColorCodes('&', name);
		fakeEnchantment = cs.getBoolean("fakeEnchantment");
		Material material = Material.getMaterial(cs.getString("material"));
		short data = (short) cs.getInt("data");
		kitItem = new ItemStack(material, amount, data);
		if (fakeEnchantment) {
			net.minecraft.server.v1_8_R3.ItemStack nmsStack = CraftItemStack.asNMSCopy(kitItem);
			NBTTagCompound tag = null;
			if (!nmsStack.hasTag()){
				tag = new NBTTagCompound();
				nmsStack.setTag(tag);
			}
			if (tag == null)
				tag = nmsStack.getTag();
			NBTTagList ench = new NBTTagList();
			tag.set("ench", ench);
			nmsStack.setTag(tag);
			kitItem = CraftItemStack.asBukkitCopy(nmsStack);
		}
		ItemMeta itemMeta = kitItem.getItemMeta();
		itemMeta.setDisplayName(name);
		List<String> lore = cs.getStringList("lore");
		List<String> realLore = new ArrayList<>();
		for (String string : lore)
			realLore.add(ChatColor.translateAlternateColorCodes('&', string));
		itemMeta.setLore(realLore);
		kitItem.setItemMeta(itemMeta);
		items = new ArrayList<>();
		cs.getConfigurationSection("items").getKeys(false).forEach(key -> items.add(new KitItem(cs.getConfigurationSection("items." + key))));
		permission = cs.getString("permission");
		System.out.println("NOM DU KIT : " + this.name);
		kits.put(this.name, this);
	}
	
}
