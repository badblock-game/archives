package fr.badblock.badybots.service;

public class BadyBots {
	
	public static void main(String[] args) {
		new Main();
	}
	
}
