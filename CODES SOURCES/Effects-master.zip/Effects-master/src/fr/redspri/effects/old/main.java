package fr.redspri.effects.old;

import fr.badblock.gameapi.BadblockPlugin;
import fr.badblock.gameapi.run.RunType;

public class main extends BadblockPlugin {

    @Override
    public void onEnable(RunType runType) {
        new BeamCommand();
        new CadaverCommand();
    }
}
