package effetcs.beams;

import net.minecraft.server.v1_8_R3.*;
import org.bukkit.Location;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftEntity;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.entity.Player;

/**
 * Packets d'un faisceau
 * @author RedSpri
 **/
public class BeamFactory extends BeamCore {
    //TODO Javadoc

    public BeamFactory(Location from, Location to) {
        super(from, to);
    }

    @Override
    public Object getDataWatcher(int type) {
        DataWatcher dw = new DataWatcher(null);
        byte data = (byte) calcData(0, 0, false);
        data = (byte) calcData(data, 1, false);
        data = (byte) calcData(data, 3, false);
        data = (byte) calcData(data, 4, false);
        data = (byte) calcData(data, 5, true);
        dw.a(0, data);
        dw .a(6, 20F);
        dw.a(16, type);
        return dw;
    }

    @Override
    public void sendPlayerPacket(Object packet, Player p) {
        ((CraftPlayer) p).getHandle().playerConnection.sendPacket((Packet) packet);
    }

    @Override
    public Object getGuardianPacket() throws Exception {
        PacketPlayOutSpawnEntityLiving packet = new PacketPlayOutSpawnEntityLiving();
        set(packet, "a", entityId);
        set(packet, "b", 68);
        set(packet, "c", toFixedPointNumber(from.getX()));
        set(packet, "d", toFixedPointNumber(from.getY()));
        set(packet, "e", toFixedPointNumber(from.getZ()));
        set(packet, "f", (int)toPackedByte(from.getYaw()));
        set(packet, "g", (int)toPackedByte(from.getPitch()));
        set(packet, "h", (int)toPackedByte(from.getPitch()));
        set(packet, "i", (byte) 0);
        set(packet, "j", (byte) 0);
        set(packet, "k", (byte) 0);
        set(packet, "l", dataWatcher);
        return packet;
    }

    @Override
    public Object getArmorStandPacket() throws Exception {
        PacketPlayOutEntityMetadata packet = new PacketPlayOutEntityMetadata();
        set(packet, "a", entityId);
        ((DataWatcher) dataWatcher).a(17, ((CraftEntity) as).getHandle().getId());
        set(packet, "b", ((DataWatcher) dataWatcher).b());
        return packet;
    }

    @Override
    public Object getRemovePacket() {
        return new PacketPlayOutEntityDestroy(entityId);
    }
}
