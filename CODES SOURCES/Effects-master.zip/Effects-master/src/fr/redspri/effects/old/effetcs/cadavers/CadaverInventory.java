package fr.redspri.effects.old.effetcs.cadavers;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

/**
 * Inventaire d'un cadavre
 * @author RedSpri
 **/
public class CadaverInventory {
     //Initialisation avec des armures et un inventaire vide
    /** Représente le casque du cadavre **/
    private ItemStack helmet = new ItemStack(Material.AIR);
    /** Représente le plastron du cadavre **/
    private ItemStack chestplate =  new ItemStack(Material.AIR);
    /** Représente les jambières du cadavre **/
    private ItemStack leggings = new ItemStack(Material.AIR);
    /** Représente les bottes du cadavre **/
    private ItemStack boots = new ItemStack(Material.AIR);
    /** Représente l'item dans la main du cadavre **/
    private ItemStack handitem = new ItemStack(Material.AIR);

    /**
     * Instancie une nouvel inventaire de cadavre
     *
     * @param helmet casque du cadavre (@null pour de l'air)
     * @param chestplate plastron du cadavre (@null pour de l'air)
     * @param leggings jambières du cadavre (@null pour de l'air)
     * @param boots bottes du cadavre (@null pour de l'air)
     * @param handitem item dans la main du cadavre (@null pour de l'air)
     **/
    public CadaverInventory(ItemStack helmet, ItemStack chestplate, ItemStack leggings, ItemStack boots, ItemStack handitem) {
        if (helmet != null) this.helmet = helmet;
        if (chestplate != null) this.chestplate = chestplate;
        if (leggings != null) this.leggings = leggings;
        if (boots != null) this.boots = boots;
        if (handitem != null) this.handitem = handitem;
    }

    /**
     * Récupère le casque du cadavre
     **/
    public ItemStack getHelmet() {
        return helmet;
    }

    /**
     * Récupère le plastron du cadavre
     **/
    public ItemStack getChestplate() {
        return chestplate;
    }

    /**
     * Récupère les jambières du cadavre
     **/
    public ItemStack getLeggings() {
        return leggings;
    }

    /**
     * Récupère les bottes du cadavre
     */
    public ItemStack getBoots() {
        return boots;
    }

    /**
     * Récupère l'item dans la main du joueur
     **/
    public ItemStack getHanditem() {
        return handitem;
    }
}
