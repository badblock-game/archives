package fr.redspri.effects.old.effetcs.cadavers;

import com.mojang.authlib.GameProfile;
import net.minecraft.server.v1_8_R3.*;
import net.minecraft.server.v1_8_R3.PacketPlayOutEntity.PacketPlayOutRelEntityMove;
import net.minecraft.server.v1_8_R3.PacketPlayOutPlayerInfo.EnumPlayerInfoAction;
import net.minecraft.server.v1_8_R3.PacketPlayOutPlayerInfo.PlayerInfoData;
import net.minecraft.server.v1_8_R3.WorldSettings.EnumGamemode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.entity.Player;

import java.lang.reflect.Field;
import java.util.*;

/**
 * Données et packets d'un cadavre
 * @author RedSpri
 **/
public class CadaverFactory {

    /** Représente la location du cadavre **/
    public Location loc;
    /** Représente le profil Mojang du cadavre **/
    public GameProfile profil;
    /** Représente le DataWatcher du cadavre **/
    public DataWatcher watcher;
    /** Représente l'id du cadavre en tant qu'entitée **/
    public int entityid;
    /** Représente le CadaverInventory du cadavre **/
    public CadaverInventory inv;
    /** Représente la valeur du CadaverRotation du cadavre **/
    public int rotation;
    /** Représente le nom dans la tablist **/
    public String text;

    /**
     * Instancie un nouveau CadaverFactory
     *
     * @param loc Location du cadavre
     * @param profil Profil mojang du cadavre
     * @param watcher DataWatcher du cadavre
     * @param entityid Id de l'entité du cadavre
     * @param inv CadaverInventory du cadavre
     * @param rotation Valeur du CadaverRotation du cadavre
     **/
    CadaverFactory(Location loc, GameProfile profil, DataWatcher watcher, int entityid, CadaverInventory inv, int rotation, String text) {
        this.loc = loc;
        this.profil = profil;
        this.watcher = watcher;
        this.entityid = entityid;
        this.inv = inv;
        this.rotation = rotation;
        this.text = text;
        //Si la valeur du CadaverRotation du cadavre est trop grande ou trop petite, on la set à une rotation ailatoire
        if(rotation > 4 || rotation < 0) this.rotation = CadaverRotation.randomRotation().get();
    }

    /***
     *  Récupère la location du lit
     **/
    public Location getBedLocation(Location loc){
        Location l = loc.clone();
        l.setY(1);
        return l;
    }

    /**
     * Convertit un ItemStack bukkit (org.bukkit.inventory.ItemStack) en ItemStack Minecraft (net.minecraft.server.v1_8_R3.ItemStack) *
     **/
    @SuppressWarnings("deprecation")
    public ItemStack getMcItemStack(org.bukkit.inventory.ItemStack stack){
        if(stack == null){
            return new ItemStack(Item.getById(0));
        }
        ItemStack temp = new ItemStack(Item.getById(stack.getTypeId()), stack.getAmount());
        temp.setData((int)stack.getData().getData());
        return temp;
    }

    /**
     * Récupère le packet d'apparition du cadavre
     * @return PacketPlayOutNamedEntitySpawn
     **/
    public PacketPlayOutNamedEntitySpawn getSpawnPacket() {
        //Création de l'instance du packet
        PacketPlayOutNamedEntitySpawn packet = new PacketPlayOutNamedEntitySpawn();
        try {
            //field correspondant à l'id de l'entité
            Field a = packet.getClass().getDeclaredField("a");
            a.setAccessible(true); //on rend le field accessible
            a.set(packet, entityid); //on le défini

            //field correspondant à l'id du profil mojang
            Field b = packet.getClass().getDeclaredField("b");
            b.setAccessible(true);
            b.set(packet, profil.getId());

            //field correspondant à la coordonnée x du cadavre
            Field c = packet.getClass().getDeclaredField("c");
            c.setAccessible(true);
            c.setInt(packet, MathHelper.floor(loc.getX() * 32.0D));

            //field correspondant à la coordonnée y du cadavre
            Field d = packet.getClass().getDeclaredField("d");
            d.setAccessible(true);
            d.setInt(packet, MathHelper.floor((loc.getY() + 2 /* on le met à la surface */) * 32.0D));

            //field correspondant à la coordonnée x du cadavre
            Field e = packet.getClass().getDeclaredField("e");
            e.setAccessible(true);
            e.setInt(packet, MathHelper.floor(loc.getZ() * 32.0D));

            //field correspondant à la coordonnée yaw du cadavrz
            Field f = packet.getClass().getDeclaredField("f");
            f.setAccessible(true);
            f.setByte(packet, (byte) (int) (loc.getYaw() * 256.0F / 360.0F));

            //field correspondant à la coordonnée pitch du cadavre
            Field g = packet.getClass().getDeclaredField("g");
            g.setAccessible(true);
            g.setByte(packet, (byte) (int) (loc.getPitch() * 256.0F / 360.0F));

            //field correspondant au DataWatcher du cadavre
            Field i = packet.getClass().getDeclaredField("i");
            i.setAccessible(true);
            i.set(packet, watcher);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return packet;
    }

    /**
     * Récupère le packet du joueur cadavre couché (dans un lit)
     * @return PacketPlayOutBed
     **/
    public PacketPlayOutBed getBedPacket() {
        //Création de l'instance du packet
        PacketPlayOutBed packet = new PacketPlayOutBed();
        try {
            //field correspondant à l'id de l'entité
            Field a = packet.getClass().getDeclaredField("a");
            a.setAccessible(true);
            a.setInt(packet, entityid);

            //field correspondant à la location du lit
            Field b = packet.getClass().getDeclaredField("b");
            b.setAccessible(true);
            b.set(packet, new BlockPosition(loc.getBlockX(), 1, loc.getBlockZ()));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return packet;
    }

    /**
     * Récupère le packet des coordonnées du joueur
     * @return PacketPlayOutRelEntityMove
     **/
    private PacketPlayOutRelEntityMove getMovePacket() {
        //Création de l'instance du packet avec directement les arguments
        return new PacketPlayOutRelEntityMove(entityid, (byte) 0, (byte) (-60.8), (byte) 0, false);
    }

    /**
     * Récupère le packet des informations du joueur cadavre
     * @return PacketPlayOutPlayerInfo
     **/
    public PacketPlayOutPlayerInfo getInfoPacket() {
        //Création de l'instance du packet comme connexion de joueur
        PacketPlayOutPlayerInfo packet = new PacketPlayOutPlayerInfo(EnumPlayerInfoAction.ADD_PLAYER);
        try {
            //field correspondant aux données du joueur
            Field b = packet.getClass().getDeclaredField("b");
            b.setAccessible(true);
            @SuppressWarnings("unchecked")
            List<PlayerInfoData> data = (List<PlayerInfoData>) b.get(packet);
            data.add(packet.new PlayerInfoData(profil /* profil mojang */, 0 /* ping */, EnumGamemode.CREATIVE /* mode survie */, new ChatMessage(text /* nom dans la tablist */)));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return packet;
    }

    /**
     * Récupère le packet de disparition du cadavre
     * @return PacketPlayOutPlayerInfo
     **/
    public PacketPlayOutPlayerInfo getRemoveInfoPacket() {
        //Création de l'instance du packet comme déconnexion de joueur
        PacketPlayOutPlayerInfo packet = new PacketPlayOutPlayerInfo(EnumPlayerInfoAction.REMOVE_PLAYER);
        try {
            //field correspondant aux données du joueur
            Field b = packet.getClass().getDeclaredField("b");
            b.setAccessible(true);
            @SuppressWarnings("unchecked")
            List<PlayerInfoData> data = (List<PlayerInfoData>) b.get(packet);
            data.add(packet.new PlayerInfoData(profil, 0, EnumGamemode.CREATIVE, new ChatMessage("")));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return packet;
    }

    /**
     * Récupère le packet de disparition du cadavre
     * @return PacketPlayOutPlayerInfo
     **/
    public PacketPlayOutEntityEquipment getEquipmentPacket(int slot, ItemStack stack){
        //Création de l'instance du packet avec directement les arguments
        return new PacketPlayOutEntityEquipment(entityid, slot, stack);
    }

    /**
     * Actualiser le cadavre pour tout le monde
     **/
    @SuppressWarnings("deprecation")
    public void createForAllPlayers() {
        //On récupèrs les différents packets
        PacketPlayOutNamedEntitySpawn spawnPacket = getSpawnPacket();
        PacketPlayOutBed bedPacket = getBedPacket();
        PacketPlayOutRelEntityMove movePacket = getMovePacket();
        PacketPlayOutPlayerInfo infoPacket = getInfoPacket();
        final PacketPlayOutPlayerInfo removeInfo = getRemoveInfoPacket();
        //Création des packets pour le CadaverInventory
        final PacketPlayOutEntityEquipment helmetInfo = getEquipmentPacket(4, getMcItemStack(inv.getHelmet()));
        final PacketPlayOutEntityEquipment chestplateInfo = getEquipmentPacket(3, getMcItemStack(inv.getChestplate()));
        final PacketPlayOutEntityEquipment leggingsInfo = getEquipmentPacket(2, getMcItemStack(inv.getLeggings()));
        final PacketPlayOutEntityEquipment bootsInfo = getEquipmentPacket(1, getMcItemStack(inv.getBoots()));
        final PacketPlayOutEntityEquipment mainhandInfo = getEquipmentPacket(0, getMcItemStack(inv.getHanditem()));
        //On loop tout les joueurs présent dans le monde du cadavre
        for (Player p : loc.getWorld().getPlayers()) {
            //On récupère la connexion du joueur pour lui envoyer les packets
            PlayerConnection conn = ((CraftPlayer) p).getHandle().playerConnection;
            //On envoie les changements de block au joueur
            p.sendBlockChange(getBedLocation(loc), Material.BED_BLOCK, (byte) rotation);
            //on envoie les packets au joueur
            conn.sendPacket(removeInfo);
            conn.sendPacket(infoPacket);
            conn.sendPacket(spawnPacket);
            conn.sendPacket(bedPacket);
            conn.sendPacket(movePacket);
            conn.sendPacket(helmetInfo);
            conn.sendPacket(chestplateInfo);
            conn.sendPacket(leggingsInfo);
            conn.sendPacket(bootsInfo);
            conn.sendPacket(mainhandInfo);
        }
}

    /**
     * Actualiser le cadavre pour un jooueur
     * @param p Joueur cible
     **/
    @SuppressWarnings("deprecation")
    public void createForOnePlayer(final Player p) {
        //On récupère les différents packets
        PacketPlayOutNamedEntitySpawn spawnPacket = getSpawnPacket();
        PacketPlayOutBed bedPacket = getBedPacket();
        PacketPlayOutRelEntityMove movePacket = getMovePacket();
        PacketPlayOutPlayerInfo infoPacket = getInfoPacket();
        final PacketPlayOutPlayerInfo removeInfo = getRemoveInfoPacket();
        //Création des packets pour le CadaverInventory
        final PacketPlayOutEntityEquipment helmetInfo = getEquipmentPacket(4, getMcItemStack(inv.getHelmet()));
        final PacketPlayOutEntityEquipment chestplateInfo = getEquipmentPacket(3, getMcItemStack(inv.getChestplate()));
        final PacketPlayOutEntityEquipment leggingsInfo = getEquipmentPacket(2, getMcItemStack(inv.getLeggings()));
        final PacketPlayOutEntityEquipment bootsInfo = getEquipmentPacket(1, getMcItemStack(inv.getBoots()));
        final PacketPlayOutEntityEquipment mainhandInfo = getEquipmentPacket(0, getMcItemStack(inv.getHanditem()));
        //On récupère la connexion du joueur pour lui envoyer les packets
        PlayerConnection conn = ((CraftPlayer) p).getHandle().playerConnection;
        //On envoie les changements de block au joueur
        p.sendBlockChange(getBedLocation(loc), Material.BED_BLOCK, (byte) rotation);
        //on envoie les packets au joueur
        conn.sendPacket(removeInfo);
        conn.sendPacket(infoPacket);
        conn.sendPacket(spawnPacket);
        conn.sendPacket(bedPacket);
        conn.sendPacket(movePacket);
        conn.sendPacket(helmetInfo);
        conn.sendPacket(chestplateInfo);
        conn.sendPacket(leggingsInfo);
        conn.sendPacket(bootsInfo);
        conn.sendPacket(mainhandInfo);
    }

    /**
     * Supprimer le cadavre pour un jooueur
     * @param p Joueur cible
     **/
    @SuppressWarnings("deprecation")
    public void removeForOnePlayer(Player p) {
        //Création de l'instance du packet avec directement les arguments
        PacketPlayOutEntityDestroy packet = new PacketPlayOutEntityDestroy(entityid);
        //Envoi du packet
        ((CraftPlayer) p).getHandle().playerConnection.sendPacket(packet);
        //On récupère le vrai block a place du lit
        Block b = getBedLocation(loc).getBlock();
        //On envoie les changements de block au joueur
        p.sendBlockChange(b.getLocation(), b.getType(), b.getData());
    }

    /**
     * Supprimer le cadavre pour tout le monde
     **/
    @SuppressWarnings("deprecation")
    public void removeForAllPlayers() {
        //Création de l'instance du packet avec directement les arguments
        PacketPlayOutEntityDestroy packet = new PacketPlayOutEntityDestroy(entityid);
        //On récupère le vrai block a place du lit
        Block b = getBedLocation(loc).getBlock();
        //On loop tout les joueurs présent dans le monde du cadavre
        for (Player p : loc.getWorld().getPlayers()) {
            ((CraftPlayer) p).getHandle().playerConnection.sendPacket(packet);
            //On envoie les changements de block au joueur
            p.sendBlockChange(b.getLocation(), b.getType(), b.getData());
        }
    }
}