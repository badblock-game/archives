package fr.redspri.effects.old;

import fr.badblock.gameapi.command.AbstractCommand;
import fr.badblock.gameapi.players.BadblockPlayer;
import fr.badblock.gameapi.utils.i18n.TranslatableString;
import fr.redspri.effects.old.effetcs.death.FakeDeath;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;

public class BeamCommand extends AbstractCommand {
    public BeamCommand() {
        super("beam", new TranslatableString("commands.beam.usage"), "dev.beam");
        allowConsole(false);
    }

    @Override
    public boolean executeCommand(CommandSender sender, String[] args) {
        //BadblockPlayer p = (BadblockPlayer) sender;
        //Beam b = new Beam(p.getLocation(), p.getTargetBlock((HashSet<Byte>) null, 50).getLocation(), true);
        new FakeDeath((BadblockPlayer) Bukkit.getPlayer(args[0]), (BadblockPlayer) sender);
        return true;
    }
}
