package fr.redspri.effects.old.effetcs.cadavers;

import com.mojang.authlib.GameProfile;
import fr.badblock.gameapi.GameAPI;
import fr.badblock.gameapi.players.BadblockPlayer;
import net.minecraft.server.v1_8_R3.*;
import org.bukkit.Location;
import org.bukkit.craftbukkit.v1_8_R3.CraftWorld;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.entity.Player;

import java.lang.reflect.Field;
import java.util.UUID;

/**
 * Cadavre
 * @author RedSpri
 **/
public class Cadaver {
    /** Représente LeCadaverFactory du cadavre **/
    private CadaverFactory factory;

    /**
     * Instancie un nouveau cadavre
     *
     * @param p Joueur d'origine
     * @param loc Location du cadavre
     * @param inv CadaverInventory du cadavre
     * @param rotation CadaverRotation du cadave
     * @param spawnImmediately le faire apparaitre <b>pour tout le monde</b> imédiéatement après l'avoir créé, sans besoin d'appeller la méthode create()
     **/
    public Cadaver(BadblockPlayer p, Location loc, CadaverInventory inv, CadaverRotation rotation, boolean spawnImmediately) {
        int entityId = getFreeEntityId();
        GameProfile prof = cloneProfileWithRandomUUID(((CraftPlayer) p).getProfile(), buildname(p));
        DataWatcher dw = clonePlayerDatawatcher(p, entityId);
        this.factory = new CadaverFactory(loc, prof, dw, entityId, inv, rotation.get(), buildname(p));
        if (spawnImmediately) create();
    }

    public String buildname(BadblockPlayer p) {
        String s;
        if (GameAPI.getAPI().getTeamsKey().size() < 1) s = p.getTabGroupPrefix() + p.getName();
        else {
            if (p.getTeam() != null) s = (p.getTeam().getChatName()) + p.getName();
            else s = p.getMainGroup() + p.getName();
        }
        return s;
    }

    /**
     * Récupère un nouveau DataWatcher à partir d'un joueur et d'un id d'entité
     *
     * @param player le joueur en question
     * @param currentEntId l'id de l'entit& en question
     * @return DataWatcher
     **/
    private DataWatcher clonePlayerDatawatcher(Player player, int currentEntId) {
        //Création un nouveau EnntityHuman à partir du joueur afin d'en récupérer le DataWatcher plus tard
        EntityHuman h = new EntityHuman(((CraftWorld) player.getWorld()).getHandle(), ((CraftPlayer) player).getProfile()) {
            public void sendMessage(IChatBaseComponent arg0) {}
            public boolean a(int arg0, String arg1) {
                return false;
            }
            public BlockPosition getChunkCoordinates() {
                return null;
            }
            public boolean isSpectator() {
                return false;
            }
        };
        h.d(currentEntId); //on set l'entity id
        System.out.println("test");
        return h.getDataWatcher();
    }

    /**
     * Récupère un profil Mojang de joueur avec un nom défini et un profil
     *
     * @param prof L'autre profil en question
     * @param name Le nom en question
     * @return GameProfile
     **/
    private GameProfile cloneProfileWithRandomUUID(GameProfile prof, String name) {
        //Création d'un nouveau profil avec les paramètres défini
        GameProfile newProf = new GameProfile(UUID.randomUUID(), name);
        newProf.getProperties().putAll(prof.getProperties());
        return newProf;
    }

    /**
     * Récupère un id d'entité disponible
     *
     * @return int
     **/
    private int getFreeEntityId() {
        try {
            //field correspondant au nombre total d'entité
            Field entityCount = Entity.class.getDeclaredField("entityCount");
            entityCount.setAccessible(true);
            int id = entityCount.getInt(null); //on le récupère
            entityCount.setInt(null, id + 1); //on agrandit le nombre d'entité de 1
            return id;
        } catch (Exception e) { //Si les actions précédentes ont échouées
            e.printStackTrace(); //on log l'erreur
            return (int) Math.round(Math.random() * Integer.MAX_VALUE * 0.25); //on return un nombre aliatoire
        }
    }

    /**
     * Récupère le CadaverFacotry du cadavre
     *
     * @return CadaverFactory
     **/
    public CadaverFactory getFactory() {
        return factory;
    }

    /**
     * Fait apparaitre le cadavre pour tout le monde
     */
    public void create() {
        factory.createForAllPlayers();
    }

    /**
     * Fait apparaitre le cadavre pour un joueur seulement
     * @param p le joueur en question
     */
    public void create(BadblockPlayer p) {
        factory.createForOnePlayer(p);
    }

    /**
     * Fait disparaitre le cadavre pour tout le monde
     */
    public void remove() {
        factory.removeForAllPlayers();
    }

    /**
     * Fait disparaitre le cadavre pour un joueur seulement
     * @param p le joueur en question
     */
    public void remove(BadblockPlayer p) {
        factory.removeForOnePlayer(p);
    }


}
