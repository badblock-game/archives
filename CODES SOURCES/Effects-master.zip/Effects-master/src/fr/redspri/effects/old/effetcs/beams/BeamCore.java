package effetcs.beams;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Player;

import java.lang.reflect.Field;
import java.util.Random;

/**
 * Fonctionnement d'un faisceau
 * @author RedSpri
 **/
public abstract class BeamCore {
    //TODO Javadoc

    final Integer entityId;
    final Object dataWatcher;
    ArmorStand as = null;
    final Location from;
    final Location to;

    public BeamCore(Location from, Location to) {
        entityId = new Random().nextInt(Integer.MAX_VALUE);
        int type = calcType(0, 2);
        type = calcType(type, 4);
        dataWatcher = getDataWatcher(type);
        this.from = from;
        this.to = to;
    }

    public void start() {
        if (as == null) {
            as = to.getWorld().spawn(to ,ArmorStand.class);
            as.setGravity(false);
            as.setVisible(false);
        }
        try {
            sendPacket(getGuardianPacket());
            sendPacket(getArmorStandPacket());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void start(Player p) {
        if (as == null) {
            as = to.getWorld().spawn(to ,ArmorStand.class);
            as.setGravity(false);
            as.setVisible(false);
        }
        try {
            sendPlayerPacket(getGuardianPacket(), p);
            sendPlayerPacket(getArmorStandPacket(), p);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void sendPacket(Object packet) {
        for(Player player : Bukkit.getOnlinePlayers()){
            sendPlayerPacket(packet, player);
        }
    }

    public void remove() {
        if (as != null) {
            as.remove();
            as = null;
        }
        try {
            sendPacket(getRemovePacket());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void remove(Player p) {
        if (as != null) {
            as.remove();
            as = null;
        }
        try {
            sendPlayerPacket(getRemovePacket(), p);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public abstract Object getDataWatcher(int type);
    public abstract void sendPlayerPacket(Object packet, Player p);
    public abstract Object getGuardianPacket() throws Exception;
    public abstract Object getArmorStandPacket() throws Exception;
    public abstract Object getRemovePacket();

    public int calcData(int data, int id, boolean flag) {
        if (flag) { return data | (1 << id);
        } else return data & ~(1 << id);
    }

    public int calcType(int type, int id) {
        return type & ~id;
    }

    public byte toPackedByte(float f) {
        return (byte)((int)(f * 256.0F / 360.0F));
    }

    public int toFixedPointNumber(Double d) {
        return (int)(d * 32D);
    }

    public void set(Object instance, String name, Object value) throws Exception {
        Field field = instance.getClass().getDeclaredField(name);
        field.setAccessible(true);
        field.set(instance, value);
    }

}
