package fr.redspri.effects.old;

import fr.redspri.effects.old.effetcs.cadavers.Cadaver;
import fr.redspri.effects.old.effetcs.cadavers.CadaverInventory;
import fr.redspri.effects.old.effetcs.cadavers.CadaverRotation;
import fr.badblock.gameapi.command.AbstractCommand;
import fr.badblock.gameapi.players.BadblockPlayer;
import fr.badblock.gameapi.utils.i18n.TranslatableString;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.inventory.ItemStack;

public class CadaverCommand extends AbstractCommand {
    public CadaverCommand() {
        super("cadaver", new TranslatableString("commands.cadaver.usage"), "dev.cadaver");
        allowConsole(false);
    }

    @Override
    public boolean executeCommand(CommandSender sender, String[] args) {
        if (args.length < 1) return false;
        else {
            Cadaver c = new Cadaver((BadblockPlayer) Bukkit.getPlayer(args[0]), ((BadblockPlayer) sender).getLocation(), new CadaverInventory(new ItemStack(Material.DIAMOND_HELMET), null, null, null, null), CadaverRotation.EAST, true);
        }
        return true;
    }
}
