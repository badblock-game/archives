package fr.redspri.effects.old.effetcs.death;

import fr.badblock.gameapi.players.BadblockPlayer;
import net.minecraft.server.v1_8_R3.*;
import org.bukkit.Bukkit;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.entity.Player;

import java.lang.reflect.Field;

public class FakeDeath {

    public FakeDeath(BadblockPlayer victim, BadblockPlayer attacker) {
        Integer vid = ((CraftPlayer) victim).getEntityId();
        Integer aid = ((CraftPlayer) attacker).getEntityId();
        PacketPlayOutCombatEvent packet = new PacketPlayOutCombatEvent();
        try {
            Field a = packet.getClass().getDeclaredField("a");
            a.setAccessible(true);
            a.set(packet, PacketPlayOutCombatEvent.EnumCombatEventType.END_COMBAT);

            Field b = packet.getClass().getDeclaredField("b");
            b.setAccessible(true);
            b.set(packet, aid);

            Field c = packet.getClass().getDeclaredField("c");
            c.setAccessible(true);
            c.set(packet, vid);

            Field e = packet.getClass().getDeclaredField("e");
            e.setAccessible(true);
            e.set(packet, "");
        } catch (NoSuchFieldException | IllegalAccessException e) {
            e.printStackTrace();
        }
        for (Player pp : Bukkit.getOnlinePlayers()) {
            CraftPlayer c = (CraftPlayer) pp;
            c.getHandle().playerConnection.sendPacket(packet);
        }
    }
}

