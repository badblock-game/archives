package effetcs.beams;

import fr.badblock.gameapi.players.BadblockPlayer;
import org.bukkit.Location;

/**
 * Faisceau
 * @author RedSpri
 **/
public class Beam {
    private BeamFactory factory;

    public Beam(Location start, Location end, boolean spawnImmediately) {
        factory = new BeamFactory(start, end);
        if (spawnImmediately) factory.start();
    }

    /**
     * Récupère le BeamFacotry du faisceau
     *
     * @return BeamFactory
     **/
    public BeamFactory getFactory() {
        return factory;
    }

    /**
     * Fait apparaitre le faisceau pour tout le monde
     */
    public void create() {
        factory.start();
    }

    /**
     * Fait apparaitre le faisceau pour un joueur seulement
     * @param p le joueur en question
     */
    public void create(BadblockPlayer p) {
        factory.start(p);
    }

    /**
     * Fait disparaitre le faisceau pour tout le monde
     */
    public void remove() {
        factory.remove();
    }

    /**
     * Fait disparaitre le faisceau pour un joueur seulement
     * @param p le joueur en question
     */
    public void remove(BadblockPlayer p) {
        factory.remove(p);
    }
}
