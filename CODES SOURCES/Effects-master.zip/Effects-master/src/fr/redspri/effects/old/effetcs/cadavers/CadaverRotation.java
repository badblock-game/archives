package fr.redspri.effects.old.effetcs.cadavers;

import java.util.Arrays;
import java.util.Collections;
import java.util.Random;

/**
 * Rotation d'un cadavre
 * @author RedSpri
 **/
public enum CadaverRotation {
    /** Sud **/
    SOUTH(0),
    /** Oueest **/
    WEST(1),
    /** Nord **/
    NORTH(2),
    /** Est **/
    EAST(4);

    /**
     * Valeur entière lorse que le cadavre est instancié
     **/
    private int value;
    CadaverRotation(int value) {
        this.value = value;
    }


    /**
     * Eécupère la valeur entière
     **/
    public int get() {
        return value;
    }

    /**
     * Récupère une valeur aliatoire de l'énumération
     **/
    public static CadaverRotation randomRotation() {
        return Collections.unmodifiableList(Arrays.asList(values())).get(new Random().nextInt(Collections.unmodifiableList(Arrays.asList(values())).size()));
    }

}
