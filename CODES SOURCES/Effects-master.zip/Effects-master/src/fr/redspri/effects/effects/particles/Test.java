package fr.redspri.effects.effects.particles;

import fr.badblock.gameapi.GameAPI;
import fr.badblock.gameapi.command.AbstractCommand;
import fr.badblock.gameapi.particles.ParticleEffect;
import fr.badblock.gameapi.particles.ParticleEffectType;
import fr.badblock.gameapi.players.BadblockPlayer;
import fr.badblock.gameapi.utils.i18n.TranslatableString;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

public class Test extends AbstractCommand{
    Double radius = 2.5d;

    Player p = null;
    public Test() {
        super("testdev", new TranslatableString("command.testeffect"), BadblockPlayer.GamePermission.ADMIN);
    }

    @Override
    public boolean executeCommand(CommandSender commandSender, String[] strings) {
        this.p = (Player) commandSender;
        int height = 25;
        Location loc = p.getLocation();
        Long time = 0L;
        for (double r = 0; r < Math.PI * 2; r += Math.PI / 15) {
            double x = Math.cos(r);
            double z = Math.sin(r);
            for (double i = 0; i < height; i++) {
                double h = i * (Math.PI / height);
                double y = Math.cos(h);
                double radiusEdit = Math.sin(h);
                double inwardsRadius = radius - radiusEdit;
                double outwardsRadius = radius + radiusEdit;
                Bukkit.getScheduler().runTaskLater(GameAPI.getAPI(), () -> {
                    loc.add(x * inwardsRadius, y, z * inwardsRadius);
                    playEffect(loc);
                    loc.subtract(x * inwardsRadius, y, z * inwardsRadius);

                    loc.add(x * outwardsRadius, y, z * outwardsRadius);
                    playEffect(loc);
                    loc.subtract(x * outwardsRadius, y, z * outwardsRadius);
                }, time);
            }
            time += 5L;
        }
        return true;
    }

    private Vector rotateAroundAxisX(Vector v, Integer i) {
        double angle = Math.toRadians(i);
        double cos = Math.cos(angle);
        double sin = Math.sin(angle);
        double y = v.getY() * cos - v.getZ() * sin;
        double z = v.getY() * sin + v.getZ() * cos;
        return v.setY(y).setZ(z);
    }

    private Vector rotateAroundAxisY(Vector v, Integer i) {
        double angle = Math.toRadians(i);
        double cos = Math.cos(angle);
        double sin = Math.sin(angle);
        double x = v.getX() * cos + v.getZ() * sin;
        double z = v.getX() * -sin + v.getZ() * cos;
        return v.setX(x).setZ(z);
    }

    private Vector rotateAroundAxisZ(Vector v, Integer i) {
        double angle = Math.toRadians(i);
        double cos = Math.cos(angle);
        double sin = Math.sin(angle);
        double x = v.getX() * cos - v.getY() * sin;
        double y = v.getX() * sin + v.getY() * cos;
        return v.setX(x).setY(y);
    }

    private void playEffect(Location l) {
        ParticleEffect effect = GameAPI.getAPI().createParticleEffect(ParticleEffectType.FLAME);
        effect.setSpeed(0);
        effect.setLongDistance(true);
        effect.setAmount(1);
        for (Player player : Bukkit.getOnlinePlayers()) {
            BadblockPlayer bplayer = (BadblockPlayer) player;
            bplayer.sendParticle(l, effect);
        }
    }
}
