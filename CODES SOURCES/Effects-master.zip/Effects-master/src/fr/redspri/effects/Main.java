package fr.redspri.effects;

import fr.badblock.gameapi.BadblockPlugin;
import fr.badblock.gameapi.run.RunType;
import fr.redspri.effects.effects.particles.Test;

public class Main extends BadblockPlugin{

    @Override
    public void onEnable(RunType runType) {
        new Test();
    }
}
