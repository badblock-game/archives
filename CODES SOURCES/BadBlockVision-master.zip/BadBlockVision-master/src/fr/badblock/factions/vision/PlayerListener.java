package fr.badblock.factions.vision;

import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryInteractEvent;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

import fr.badblock.factions.vision.utils.ChatUtils;

public class PlayerListener implements Listener {
	
	@EventHandler
	public void onInteract(PlayerInteractEvent e){
		if(Main.getInstance().getInUse().contains(e.getPlayer().getUniqueId())){
			ChatUtils.sendMessage(e.getPlayer(), "%red%Vous n'�tes pas autoris� � int�ragir, juste regarder !");
			e.setCancelled(true);
			e.getPlayer().setSpectatorTarget(e.getPlayer());
		}
	}
	
	@EventHandler (priority = EventPriority.MONITOR)
	public void onPlayerCommandPreprocess(PlayerCommandPreprocessEvent e){
		if(Main.getInstance().getInUse().contains(e.getPlayer().getUniqueId())){
			if (!e.getMessage().startsWith("/")) return;
			ChatUtils.sendMessage(e.getPlayer(), "%red%Vous n'�tes pas autoris� � ex�cuter une commande en vision.");
			e.setCancelled(true);
		}
	}
	
	@EventHandler
	public void onInteractEntity(PlayerInteractEntityEvent e){
		if(Main.getInstance().getInUse().contains(e.getPlayer().getUniqueId())){
			ChatUtils.sendMessage(e.getPlayer(), "%red%Vous n'�tes pas autoris� � int�ragir ici, juste regarder !");
			e.setCancelled(true);
			e.getPlayer().setSpectatorTarget(e.getPlayer());
		}
	}

	@EventHandler
	public void onInventoryInteract(InventoryInteractEvent e){
		if (!(e.getWhoClicked() instanceof Player)) return;
		Player player = (Player) e.getWhoClicked();
		if(Main.getInstance().getInUse().contains(player.getUniqueId())){
			ChatUtils.sendMessage(player, "%red%Vous n'�tes pas autoris� � int�ragir ici, juste regarder !");
			e.setCancelled(true);
			player.setSpectatorTarget(player);
		}
	}
	
	@EventHandler
	public void onInventoryClick(InventoryClickEvent e){
		if (!(e.getWhoClicked() instanceof Player)) return;
		Player player = (Player) e.getWhoClicked();
		if(Main.getInstance().getInUse().contains(player.getUniqueId())){
			ChatUtils.sendMessage(player, "%red%Vous n'�tes pas autoris� � int�ragir ici, juste regarder !");
			e.setCancelled(true);
			player.setSpectatorTarget(player);
		}
	}
	
	@EventHandler
	public void onInventoryDrag(InventoryDragEvent e){
		if (!(e.getWhoClicked() instanceof Player)) return;
		Player player = (Player) e.getWhoClicked();
		if(Main.getInstance().getInUse().contains(player.getUniqueId())){
			ChatUtils.sendMessage(player, "%red%Vous n'�tes pas autoris� � int�ragir ici, juste regarder !");
			e.setCancelled(true);
			player.setSpectatorTarget(player);
		}
	}
	
	@EventHandler
	public void onTeleport(PlayerTeleportEvent e){
		if(Main.getInstance().getInUse().contains(e.getPlayer().getUniqueId())){
			ChatUtils.sendMessage(e.getPlayer(), "%red%[Vision] Vous n'�tes pas autoris� � vous t�l�porter, juste regarder !");
 			e.setCancelled(true);
		}
	}
	
	@EventHandler
	public void onQuit(PlayerQuitEvent e){
		if(Main.getInstance().getInUse().contains(e.getPlayer().getUniqueId())){
			Main.getInstance().getInUse().remove(e.getPlayer().getUniqueId());
			e.getPlayer().setGameMode(GameMode.SURVIVAL);
			e.getPlayer().teleport(Main.getInstance().getPrevious().get(e.getPlayer().getUniqueId()));
			Main.getInstance().getPrevious().remove(e.getPlayer().getUniqueId());
		}
	}
	
	@EventHandler
	public void onUseCommand(PlayerCommandPreprocessEvent e){
		if(Main.getInstance().getInUse().contains(e.getPlayer().getUniqueId())){
			e.setCancelled(true);
		}
	}
}
