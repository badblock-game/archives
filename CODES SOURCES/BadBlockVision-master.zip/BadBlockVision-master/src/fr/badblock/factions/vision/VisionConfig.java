package fr.badblock.factions.vision;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

public class VisionConfig {
	@Getter@Setter private static VisionConfig instance;
	
	private ConfigurationSection config;
	private List<String> time;
	
	@Getter private int minuteBeforeUse = 30;
	
	public int getTime(Player player){
		int maximum = 0;
		for(final String max : time){
			try {
				String permission = max.split(":")[0];
				int maxValue = Integer.parseInt(max.split(":")[1]);
			
				if(maxValue > maximum && player.hasPermission(permission)){
					maximum = maxValue;
				}
			} catch(Exception e){}
		}
		
		return maximum;
	}
	
	@SuppressWarnings("serial")
	public VisionConfig(ConfigurationSection section){
		config = section;
		time = get("time", new ArrayList<String>(){{add("permission:15"); add("permission2:30");}});
		minuteBeforeUse = get("minuteBeforeUse", minuteBeforeUse);
	}
	
	@SuppressWarnings("unchecked")
	public <T> T get(String key, T defaultValue){
		if(!config.contains(key))
			config.set(key, defaultValue);
		if(!(config.get(key).getClass().isInstance(defaultValue)))
			config.set(key, defaultValue);
		return (T) config.get(key);
	}
}
