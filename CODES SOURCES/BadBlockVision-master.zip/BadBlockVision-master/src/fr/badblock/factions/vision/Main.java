package fr.badblock.factions.vision;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.ProtocolManager;
import com.comphenix.protocol.events.ListenerPriority;
import com.comphenix.protocol.events.PacketAdapter;
import com.comphenix.protocol.events.PacketEvent;

import fr.badblock.factions.vision.utils.ChatUtils;
import fr.badblock.factions.vision.utils.Title;
import lombok.Getter;
import net.md_5.bungee.api.ChatColor;

public class Main extends JavaPlugin {
	@Getter private static Main instance;
	
	public static final long MINUTE = 20L * 60;
	
	private List<UUID> players = new ArrayList<UUID>();
	@Getter private List<UUID> inUse = new ArrayList<UUID>();
	@Getter private Map<UUID, Location> previous = new HashMap<UUID, Location>();
	
	@Override
	public void onEnable(){
		instance = this;
		VisionConfig.setInstance(new VisionConfig(getConfig()));

		saveConfig();

		getServer().getPluginManager().registerEvents(new PlayerListener(), this);

		List<PacketType> packets = new ArrayList<>();
		// Adding the packets
		packets.add(PacketType.Play.Server.CAMERA);
		ProtocolManager protocolManager = ProtocolLibrary.getProtocolManager();
		packets.forEach(packet -> {
			protocolManager.addPacketListener(new PacketAdapter(this, ListenerPriority.NORMAL, packet) {
				@Override
				public void onPacketSending(PacketEvent event) {
					Player player = event.getPlayer();
					// Not online
					if (player == null || !player.isOnline()) return;
					if(Main.getInstance().getInUse().contains(player.getUniqueId())) {
						event.setCancelled(true);
						player.setSpectatorTarget(player);
					}
				}
			});
		});
	}

	@Override
	public void onDisable(){}

	private void use(final UUID player){
		players.add(player);
		new BukkitRunnable(){
			@Override
			public void run(){
				Player p = getServer().getPlayer(player);
				if(p != null)
					ChatUtils.sendMessage(p, "&aVous pouvez de nouveau utiliser /vision !");
				players.remove(player);
			}
		}.runTaskLater(this, MINUTE * VisionConfig.getInstance().getMinuteBeforeUse());
	}
	
	@Override
	public boolean onCommand(CommandSender sender, Command command, String label, String[] args){
		if(args.length == 0 && sender instanceof Player){
			Player player = (Player) sender;
			if(players.contains(player.getUniqueId())){
				ChatUtils.sendMessage(player, "&cVous devez attendre " + VisionConfig.getInstance().getMinuteBeforeUse() + " minutes entre deux utilisations. &aPasse au grade sup�rieur pour augmenter la dur�e de vision !");
			} else {
				final int time = VisionConfig.getInstance().getTime(player);
				if(time == 0){
					ChatUtils.sendMessage(player, "&cVous n'avez pas la permission d'utiliser cette commande !");
				} else {
					final UUID uniqueId = player.getUniqueId();
					previous.put(uniqueId, player.getLocation().clone());
					
					inUse.add(uniqueId);
					
					player.sendMessage(ChatColor.GREEN + "Mode spectateur dans 10 secondes ...");
					
					new BukkitRunnable(){
						@Override
						public void run(){
							player.setGameMode(GameMode.SPECTATOR);
							
							new BukkitRunnable(){
								private int t = time;
								@Override
								public void run(){
									Player p = getServer().getPlayer(uniqueId);
									if(p == null || !p.isOnline()){
										cancel(); return;
									}
									
									if(t == time){
										new Title("&bBadBlock Vision", "&aLa vision se termine dans &b" + t + "&a secondes !", 10, 40, 10).send(p);
									}
									
									if(t == 0){
										new Title("&bBadBlock Vision", "&cLa vision est termin�e, t�l�portation !").send(p);
										
										p.setGameMode(GameMode.SURVIVAL);
										
										cancel(); inUse.remove(uniqueId); 
										p.teleport(previous.get(uniqueId)); 
										Main.getInstance().getPrevious().remove(uniqueId);
										return;
									}
									if(t <= 5 && t > 1){
										new Title("&bBadBlock Vision", "&aLa vision se termine dans &b" + t + "&a secondes !").send(p);
									} else if(t == 1){
										new Title("&bBadBlock Vision", "&aLa vision se termine dans &b1 &aseconde !").send(p);
									}
									t--;
								}
								
							}.runTaskTimer(Main.getInstance(), 0, 20L);
						}
						
					}.runTaskLater(this, 20 * 10L);
				}
			}
			
			use(player.getUniqueId());
		} else if(args.length > 0 && args[0].equalsIgnoreCase("reload")){
			if(!sender.hasPermission("vision.admin")){
				ChatUtils.sendMessage(sender, "%red%Vous n'avez pas la permission d'utiliser cette commande !");
			} else {
				reloadConfig();
				VisionConfig.setInstance(new VisionConfig(getConfig()));
				ChatUtils.sendMessage(sender, "&aConfiguration recharg�e !");
			}
		} else {
			ChatUtils.sendMessage(sender, "&8&l&m-------------------------------------");
			ChatUtils.sendMessage(sender, "&b/vision &7: lance la vision");
			if(sender.hasPermission("vision.admin")){
				ChatUtils.sendMessage(sender, "&b/vision reload &7: recharge la configuration");
			}
			ChatUtils.sendMessage(sender, "&8&l&m-------------------------------------");
		}
		
		return true;
	}
}
