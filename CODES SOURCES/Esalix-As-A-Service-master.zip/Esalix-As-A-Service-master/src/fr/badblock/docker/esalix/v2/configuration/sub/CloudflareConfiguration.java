package fr.badblock.docker.esalix.v2.configuration.sub;

import lombok.Data;

@Data
public class CloudflareConfiguration
{

	private String						email		= "default@example.com";
	private String						apikey		= "XXXXXXXXXXXXXXXXXXXX";
	private String						website		= "my-website.com";
	private String						dns			= "node-{0}";
	
}
