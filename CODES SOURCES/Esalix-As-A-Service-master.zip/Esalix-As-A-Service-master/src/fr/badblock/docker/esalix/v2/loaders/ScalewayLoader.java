package fr.badblock.docker.esalix.v2.loaders;

import fr.badblock.docker.esalix.scaleway.Region;
import fr.badblock.docker.esalix.scaleway.ScalewayApiClient;
import fr.badblock.docker.esalix.v2.Esalix;
import fr.badblock.docker.esalix.v2.manager.ScalewayManager;

public class ScalewayLoader extends _EsalixLoader
{

	public ScalewayLoader()
	{
		super(_EsalixLoaderType.SCALEWAY);
	}

	@Override
	public void load(Esalix esalix)
	{
		esalix.setScaleway(new ScalewayApiClient(esalix.getConfiguration().getScaleway().getScalewayToken(), Region.PARIS1));;
		ScalewayManager.thread = Thread.currentThread();
	}
	
}
