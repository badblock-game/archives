package fr.badblock.docker.esalix.v2.workers;

import java.sql.ResultSet;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import fr.badblock.docker.esalix.scaleway.exception.ScalewayApiException;
import fr.badblock.docker.esalix.scaleway.model.Server;
import fr.badblock.docker.esalix.scaleway.model.ServerAction;
import fr.badblock.docker.esalix.scaleway.model.State;
import fr.badblock.docker.esalix.v2.database.BadblockDatabase;
import fr.badblock.docker.esalix.v2.database.Request;
import fr.badblock.docker.esalix.v2.database.Request.RequestType;
import fr.badblock.docker.esalix.v2.dockerpart.entities.DedicatedServerEntity;
import fr.badblock.docker.esalix.v2.dockerpart.entities.DedicatedServerType;
import fr.badblock.docker.esalix.v2.logging.Log;
import fr.badblock.docker.esalix.v2.logging.Log.LogType;
import fr.badblock.docker.esalix.v2.manager.OpenServerManager;
import fr.badblock.docker.esalix.v2.manager.ScalewayManager;

public class RemoveUselessResources extends TimerTask
{

	public RemoveUselessResources()
	{
		new Timer().schedule(this, 60000, 10000);
	}

	@Override
	public void run()
	{
		// Freeze deleters
		if (OpenServerManager.freezeDeleters > System.currentTimeMillis())
		{
			return;
		}

		/** UNATTACHED RESOURCES **/

		// Remove unattached storage
		removeUnattachedStorage();
		// Removed unattached IP
		removeUnattachedIPs();

		/** REMOVE USELESS SERVERS **/

		// Remove stopped servers
		removeStoppedServers();
		// Remove not dockerized
		removeNotDockerizedServers();
		// Remove useless database servers
		removeUselessDatabaseServers();
	}

	private void removeUnattachedStorage()
	{
		try
		{
			ScalewayManager.scaleway.getAllVolumes(1, 100).getVolumes().stream().filter(volume -> volume.getServer() == null).forEach(
					volume -> 
					{
						try {
							ScalewayManager.scaleway.deleteVolume(volume.getId());
						} catch (ScalewayApiException e) {
							e.printStackTrace();
						}
						Log.log("Removed unattached volume " + volume.getId() + ".", LogType.SUCCESS);
					});
		}
		catch (Exception error)
		{
			error.printStackTrace();
		}
	}

	private void removeUnattachedIPs()
	{
		try
		{
			ScalewayManager.scaleway.getAllIPs(1, 100).getIPs().stream().filter(ip -> ip.getServer() == null).forEach(ip ->
			{
				try
				{
					ScalewayManager.scaleway.deleteIP(ip.getId());
				}
				catch (ScalewayApiException exception)
				{
					exception.printStackTrace();
				}
				Log.log("Removed unattached IP " + ip.getIpAddress() + ".", LogType.SUCCESS);
			});
		}
		catch (Exception error)
		{
			error.printStackTrace();
		}
	}

	private void removeStoppedServers()
	{
		try
		{
			ScalewayManager.scaleway.getAllServers(1, 100).getServers().stream().filter(server -> server.getState().equals(State.stopped)).forEach(server ->
			{
				try
				{
					ScalewayManager.scaleway.deleteServer(server.getId());
				}
				catch (ScalewayApiException e)
				{
					e.printStackTrace();
				}
				Log.log("Removed stopped server " + server.getId() + ".", LogType.SUCCESS);
			});
		}
		catch (Exception error)
		{
			error.printStackTrace();
		}
	}

	private void removeUselessDatabaseServers()
	{
		BadblockDatabase.getInstance().addSyncRequest(new Request("SELECT * FROM esalix", RequestType.GETTER)
		{
			@Override
			public void done(ResultSet resultSet)
			{
				try
				{
					List<Server> servers = ScalewayManager.scaleway.getAllServers(1, 100).getServers();
					while (resultSet.next())
					{
						String serverId = resultSet.getString("serverId");
						long count = servers.parallelStream().filter(server -> server.getId().equals(serverId)).count();
						if (count == 0)
						{
							BadblockDatabase.getInstance().addRequest(new Request("DELETE FROM esalix WHERE serverId = '" + serverId + "'", RequestType.SETTER));
							Log.log("Removed useless database server " + serverId + ".", LogType.SUCCESS);
						}
					}
				}
				catch (Exception exception)
				{
					exception.printStackTrace();
				}
			}
		});
	}

	private void removeNotDockerizedServers()
	{
		try {
			ScalewayManager.scaleway.getAllServers(1, 100).getServers().parallelStream().filter(server2 -> server2.getPublicIp() != null && server2.getState().equals(State.running)).forEach(
					server2 ->
					{
						try {
							long timeMargin = System.currentTimeMillis() - server2.getCreationDate().getTime();
							long count = DedicatedServerEntity.getServers().values().parallelStream().filter(server -> server.getIp().equalsIgnoreCase(server2.getPublicIp().getIpAddress())).count();
							if (count == 0 && timeMargin > 1200_000L)
							{
								ScalewayManager.scaleway.executeServerAction(server2.getId(), ServerAction.TERMINATE);
								Log.log("Stopping an not-dockerized server " + server2.getId() + ".", LogType.SUCCESS);
								return;
							}
							if (count == 0)
							{
								return;
							}
							DedicatedServerEntity.getServers().values().parallelStream().filter(server -> server.getIp().equalsIgnoreCase(server2.getPublicIp().getIpAddress())).forEach(server -> 
							{
								if (!server.isOnline() && !server.getDedicatedServerType().equals(DedicatedServerType.NONE))
								{
									try {
										ScalewayManager.scaleway.executeServerAction(server2.getId(), ServerAction.TERMINATE);
										Log.log("Stopping a server " + server2.getId() + ".", LogType.SUCCESS);
									} catch (ScalewayApiException e) {
										e.printStackTrace();
									}
								}
							}); 
						} catch (Exception e) {
							e.printStackTrace();
						}
					});
		} catch (ScalewayApiException e) {
			e.printStackTrace();
		}
	}

}
