package fr.badblock.docker.esalix.v2.configuration.sub;

import lombok.Data;

@Data
public class DebugConfiguration
{

	private boolean		discordDebug	= true;
	private boolean		logDebug		= true;

}
