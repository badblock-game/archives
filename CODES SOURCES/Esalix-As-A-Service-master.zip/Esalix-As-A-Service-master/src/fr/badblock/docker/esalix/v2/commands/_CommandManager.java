package fr.badblock.docker.esalix.v2.commands;

import java.util.Arrays;
import java.util.Scanner;

import fr.badblock.docker.esalix.v2.logging.Log;
import fr.badblock.docker.esalix.v2.logging.Log.LogType;

public class _CommandManager
{

	private _Command[] commands		=	new _Command[]
			{
					new ByeAllServersCommand(),
					new ByeServerCommand(),
					new CpuCommand(),
					new CreateServerCommand(),
					new DeleteIPCommand(),
					new DeleteServerCommand(),
					new DeleteVolumeCommand(),
					new HelpCommand(),
					new IPListCommand(),
					new ServerListCommand(),
					new StateCommand(),
					new VolumeListCommand()
			};

	@SuppressWarnings("resource")
	public _CommandManager()
	{
		Scanner scanner = new Scanner(System.in);
		while (true)
		{
			String string = scanner.nextLine();
			execute(string);
		}
	}

	public void execute(String string)
	{
		for (_Command command : commands)
		{
			if (Arrays.asList(command.getCommands()).contains(string.split(" ")[0]))
			{
				command.run(string);
				return;
			}
		}
		Log.log("Unknown command '" + string + "'. Please type help for help.", LogType.WARNING);
	}

}
