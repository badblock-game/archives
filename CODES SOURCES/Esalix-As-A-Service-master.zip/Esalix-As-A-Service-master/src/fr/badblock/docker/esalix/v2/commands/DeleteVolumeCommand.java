package fr.badblock.docker.esalix.v2.commands;

import java.util.List;

import fr.badblock.docker.esalix.scaleway.model.Volume;
import fr.badblock.docker.esalix.v2.Esalix;

public class DeleteVolumeCommand extends _Command
{

	public DeleteVolumeCommand()
	{
		super("deletevolume");
	}

	@Override
	public void run(String command)
	{
		String[] args = command.split(" ");
		if (args.length != 2)
		{
			Esalix.getInstance().sendDiscordMessage("Usage: deleteip <ip>");
			return;
		}
		try
		{
			String id = args[1];
			List<Volume> s = Esalix.getInstance().getScaleway().getAllVolumes(1, 100).getVolumes();
			if (s.isEmpty())
			{
				Esalix.getInstance().sendDiscordMessage("Unknown volume: '" + id + "'");
				return;
			}
			boolean f = false;
			for (Volume volume : s)
			{
				if (volume.getId().equalsIgnoreCase(id))
				{
					f = true;
					Esalix.getInstance().getScaleway().deleteVolume(volume.getId());
					Esalix.getInstance().sendDiscordMessage("Removed volume: " + volume.getId());
				}
			}
			if (!f)
			{
				Esalix.getInstance().sendDiscordMessage("Unknown volume: '" + id + "'");
				return;
			}
		}
		catch(Exception error)
		{
			error.printStackTrace();
			Esalix.getInstance().sendDiscordMessage("An error occurred while trying to delete volume (command): " + error.getMessage());
		}
	}

}
