package fr.badblock.docker.esalix.v2.commands;

import fr.badblock.docker.esalix.v2.Esalix;
import fr.badblock.docker.esalix.v2.dockerpart.entities.DedicatedServerEntity;
import fr.badblock.docker.esalix.v2.manager.ScalewayManager;

public class ByeAllServersCommand extends _Command
{

	public ByeAllServersCommand()
	{
		super("byeallservers");
	}

	@Override
	public void run(String command)
	{
		try
		{
			Esalix.getInstance().sendDiscordMessage("Sended 'bye' signal to all servers:");
			DedicatedServerEntity.getServers().values().stream().filter(server -> server.isOnline()).forEach(server -> {
				ScalewayManager.byeServer(server);
				Esalix.getInstance().sendDiscordMessage("Sended 'bye' signal to '" + server.getIp() + "'");
			});
		}
		catch(Exception error)
		{
			error.printStackTrace();
			Esalix.getInstance().sendDiscordMessage("An error occurred while trying to 'bye' servers (command): " + error.getMessage());
		}
	}

}
