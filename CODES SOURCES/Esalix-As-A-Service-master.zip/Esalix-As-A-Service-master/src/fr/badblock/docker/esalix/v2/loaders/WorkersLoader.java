package fr.badblock.docker.esalix.v2.loaders;

import fr.badblock.docker.esalix.v2.Esalix;
import fr.badblock.docker.esalix.v2.workers.DockerAsAService;
import fr.badblock.docker.esalix.v2.workers.RemoveUselessResources;

public class WorkersLoader extends _EsalixLoader
{

	public WorkersLoader()
	{
		super(_EsalixLoaderType.WORKERS);
	}

	@Override
	public void load(Esalix esalix)
	{
		new DockerAsAService();
		new RemoveUselessResources();
	}
	
}
