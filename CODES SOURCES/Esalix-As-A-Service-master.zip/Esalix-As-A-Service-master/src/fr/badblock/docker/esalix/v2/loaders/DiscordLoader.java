package fr.badblock.docker.esalix.v2.loaders;

import fr.badblock.docker.esalix.v2.Esalix;
import fr.badblock.docker.esalix.v2.discord.TemmieWebhook;

public class DiscordLoader extends _EsalixLoader
{

	public DiscordLoader()
	{
		super(_EsalixLoaderType.DISCORD);
	}

	@Override
	public void load(Esalix esalix)
	{
		esalix.setWebhook(new TemmieWebhook(esalix.getConfiguration().getDiscord().getWebhook()));
	}
	
}
