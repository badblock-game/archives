package fr.badblock.docker.esalix.v2.loaders;

import java.util.Arrays;

import fr.badblock.docker.esalix.v2.Esalix;
import fr.badblock.docker.esalix.v2.logging.Log;
import fr.badblock.docker.esalix.v2.logging.Log.LogType;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode (callSuper = false)
@Data
public abstract class _EsalixLoader
{

	private _EsalixLoaderType	type;

	public _EsalixLoader(_EsalixLoaderType type)
	{
		setType(type);
	}
	
	private void preLoad(Esalix esalix)
	{
		Log.log("Executing loader : " + type.name(), LogType.INFO);
		load(esalix);
		Log.log("Executed loader : " + type.name(), LogType.SUCCESS);
	}
	
	public abstract void load(Esalix esalix);

	public static void loadAll(Esalix esalix)
	{
		Log.log("Loading Esalix...", LogType.INFO);
		Arrays.asList(getLoaders()).forEach(esalixLoader -> esalixLoader.preLoad(esalix));
		Log.log("Esalix is now fully loaded.", LogType.SUCCESS);
	}

	public static _EsalixLoader[] getLoaders()
	{
		return new _EsalixLoader[]
				{
					new InfinitySleeperLoader(),
					new GsonLoader(),
					new ConfigurationLoader(),
					new RabbitMQLoader(),
					new RabbitListenersLoader(),
					new CloudflareLoader(),
					new DatabaseLoader(),
					new DiscordLoader(),
					new ScalewayLoader(),
					new WorkersLoader(),
					new StopLoader(),
					new CommandsLoader()
				};
	}

}
