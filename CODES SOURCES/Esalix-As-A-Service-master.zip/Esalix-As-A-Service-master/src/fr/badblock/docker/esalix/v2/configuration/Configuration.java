package fr.badblock.docker.esalix.v2.configuration;

import fr.badblock.docker.esalix.v2.configuration.sub.CloudflareConfiguration;
import fr.badblock.docker.esalix.v2.configuration.sub.DatabaseConfiguration;
import fr.badblock.docker.esalix.v2.configuration.sub.DebugConfiguration;
import fr.badblock.docker.esalix.v2.configuration.sub.DiscordConfiguration;
import fr.badblock.docker.esalix.v2.configuration.sub.MarginsConfiguration;
import fr.badblock.docker.esalix.v2.configuration.sub.ResourcesConfiguration;
import fr.badblock.docker.esalix.v2.configuration.sub.ScalewayConfiguration;
import fr.toenga.common.tech.rabbitmq.setting.RabbitSettings;
import lombok.Getter;

@Getter
public class Configuration 
{

	public DebugConfiguration			debug		= new DebugConfiguration();
	public ScalewayConfiguration		scaleway	= new ScalewayConfiguration();
	public DatabaseConfiguration		database	= new DatabaseConfiguration();
	public RabbitSettings				rabbitmq	= new RabbitSettings(new String[] { "127.0.0.1" }, 5672, "a", "b", "c", true, 5000, 60, 32);
	public ResourcesConfiguration		resources	= new ResourcesConfiguration();
	public MarginsConfiguration			margins		= new MarginsConfiguration();
	public DiscordConfiguration			discord		= new DiscordConfiguration();
	public CloudflareConfiguration		cloudflare	= new CloudflareConfiguration();

}
