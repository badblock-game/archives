package fr.badblock.docker.esalix.v2.loaders;

import fr.badblock.docker.esalix.v2.Esalix;
import fr.toenga.common.tech.rabbitmq.RabbitConnector;
import fr.toenga.common.tech.rabbitmq.RabbitService;
import fr.toenga.common.tech.rabbitmq.setting.RabbitSettings;

public class RabbitMQLoader extends _EsalixLoader
{

	public RabbitMQLoader()
	{
		super(_EsalixLoaderType.RABBITMQ_AUTHENTICATION);
	}

	@Override
	public void load(Esalix esalix)
	{
		RabbitSettings rabbitSettings = esalix.getConfiguration().getRabbitmq();
		esalix.setRabbitService(RabbitConnector.getInstance().registerService(new RabbitService("default", rabbitSettings)));
	}
	
}
