package fr.badblock.docker.esalix.v2.dockerpart.entities;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter public abstract class Entity {
	
	private EntityType		entityType;
	
	public Entity(EntityType entityType) {
		setEntityType(entityType);
	}
	
}
