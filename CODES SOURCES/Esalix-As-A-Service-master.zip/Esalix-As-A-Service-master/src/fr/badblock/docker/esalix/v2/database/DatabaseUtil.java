package fr.badblock.docker.esalix.v2.database;

import java.sql.ResultSet;

import fr.badblock.docker.esalix.v2.database.Request.RequestType;
import fr.badblock.docker.esalix.v2.utils.Callback;

public class DatabaseUtil
{

	public static void getCount(String query, Callback<Integer> callback)
	{
		BadblockDatabase.getInstance().addSyncRequest(new Request("SELECT COUNT(*) AS count " + query, RequestType.GETTER)
		{
			@Override
			public void done(ResultSet resultSet)
			{
				try
				{
					if (resultSet.next())
					{
						int count = resultSet.getInt("count");
						callback.done(count, null);
					}
				}
				catch(Exception error)
				{

				}
			}
		});
	}

}
