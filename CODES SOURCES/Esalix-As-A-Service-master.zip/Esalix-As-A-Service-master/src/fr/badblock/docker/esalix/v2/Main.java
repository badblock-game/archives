package fr.badblock.docker.esalix.v2;

public class Main
{

	public static void main(String[] args)
	{
		try
		{
			Esalix.class.newInstance();
		}
		catch (Exception exception)
		{
			exception.printStackTrace();
		}
	}
	
}
