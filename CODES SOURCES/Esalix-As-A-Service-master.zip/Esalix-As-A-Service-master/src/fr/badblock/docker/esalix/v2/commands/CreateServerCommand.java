package fr.badblock.docker.esalix.v2.commands;

import fr.badblock.docker.esalix.v2.Esalix;
import fr.badblock.docker.esalix.v2.manager.ScalewayManager;

public class CreateServerCommand extends _Command
{

	public CreateServerCommand()
	{
		super("createserver");
	}

	@Override
	public void run(String command)
	{
		Esalix.getInstance().sendDiscordMessage("Forced to create a server (command):");
		ScalewayManager.generateServer(Esalix.getInstance());
	}

}
