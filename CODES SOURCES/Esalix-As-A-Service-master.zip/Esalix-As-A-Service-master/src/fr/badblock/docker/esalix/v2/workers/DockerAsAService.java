package fr.badblock.docker.esalix.v2.workers;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import fr.badblock.docker.esalix.v2.Esalix;
import fr.badblock.docker.esalix.v2.configuration.Configuration;
import fr.badblock.docker.esalix.v2.configuration.sub.MarginsConfiguration;
import fr.badblock.docker.esalix.v2.configuration.sub.ResourcesConfiguration;
import fr.badblock.docker.esalix.v2.dockerpart.entities.DedicatedServerEntity;
import fr.badblock.docker.esalix.v2.dockerpart.entities.DedicatedServerType;
import fr.badblock.docker.esalix.v2.manager.ScalewayManager;

public class DockerAsAService extends TimerTask
{

	public static double averageCpu;
	public static double averageRam;
	private static final String IPADDRESS_PATTERN =
			"^([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
					"([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
					"([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
					"([01]?\\d\\d?|2[0-4]\\d|25[0-5])$";

	private int  	createrMargin = 0;
	private int  	removerMargin = 0;
	private long 	timeMargin = 0;
	private Pattern pattern;
	private Matcher matcher;

	public DockerAsAService()
	{
		pattern = Pattern.compile(IPADDRESS_PATTERN);
		new Timer().schedule(this, 1000, 1000);
		timeMargin = System.currentTimeMillis() + 5000;
	}

	@Override
	public void run() {
		if (timeMargin >= System.currentTimeMillis())
		{
			Esalix.getInstance().sendDebugMessage("ACTION: WAITING FOR TIME MARGIN...");
			return;
		}
		List<DedicatedServerEntity> servers = null;
		List<DedicatedServerEntity> servers2 = null;
		try 
		{
			servers = DedicatedServerEntity.getServers().values().stream().
					filter(server -> server.isOnline() && server.isAvailable() && server.getDedicatedServerType().equals(DedicatedServerType.PRODUCTION))
					.collect(Collectors.toList());
			servers2 = DedicatedServerEntity.getServers().values().stream().
					filter(server -> server.isOnline() && validate(server.getIp()) && server.isAvailable() && server.getDedicatedServerType().equals(DedicatedServerType.PRODUCTION))
					.collect(Collectors.toList());
			averageCpu = servers.stream().filter(server -> !server.getCpu120S().isEmpty()).mapToDouble(server -> server.getCpu120S().stream().mapToDouble(cp -> cp.doubleValue()).sum() / server.getCpu120S().size()).sum() / servers.size();
			averageRam = servers.stream().mapToDouble(server -> server.getRam()).sum() / servers.size();
			Esalix esalix = Esalix.getInstance();
			Configuration config = esalix.getConfiguration();
			ResourcesConfiguration resources = config.getResources();
			MarginsConfiguration margins = config.getMargins();
			if (canOpenAServer(config, servers))
			{
				if (servers2.size() < resources.getMaxServers())
				{
					createrMargin++;
					if (createrMargin >= margins.getToCreateSeconds())
					{
						createrMargin = margins.getToCreateSeconds();
						new Thread("Esalix/ServerCreator")
						{
							@Override
							public void run()
							{
								if (esalix.getScaleway() != null)
								{
									// Generate a dedicated server
									ScalewayManager.generateServer(esalix);
								}
								else
								{
									Esalix.getInstance().sendDebugMessage(averageCpu + " : ACTION: Can't create a dedicated server. Need Scaleway API.");
								}
							}
						}.start();
					}
					else
					{
						Esalix.getInstance().sendDebugMessage(averageCpu + " : ACTION: WAITING FOR CREATE MARGIN... (" + (margins.getToCreateSeconds() - createrMargin) + ")");
					}
				}
				else
				{
					Esalix.getInstance().sendDiscordMessage(averageCpu + " : Max server value reached!");
				}
			}
			else if (servers2.size() > resources.getMinServers())
			{
				if (createrMargin > 0)
				{
					createrMargin--;
				}
				double maxRemoverCpu = resources.getMinCpuToDelete();
				if (averageCpu < maxRemoverCpu && servers2.size() > resources.getMinServers())
				{
					DedicatedServerEntity unusedServer = null;
					for (DedicatedServerEntity server : servers)
					{
						if (unusedServer == null || server.getCpu() < unusedServer.getCpu())
						{
							unusedServer = server;
						}
					}
					if (unusedServer == null)
					{
						Esalix.getInstance().sendDebugMessage(averageCpu + " : ACTION: NO SERVER TO USE AS A REMOVER.");
						return;
					}
					final DedicatedServerEntity finalUnusedServer = unusedServer;
					long newServerSize = servers.stream().filter(server -> validate(server.getIp()) && !server.equals(finalUnusedServer)).count();
					double anticipatedCpu = servers.stream().filter(server -> validate(server.getIp()) && !server.equals(finalUnusedServer)).mapToDouble(server -> server.getCpu()).sum() / newServerSize;
					if (anticipatedCpu < maxRemoverCpu)
					{
						if (averageCpu < maxRemoverCpu)
						{
							if (removerMargin >= margins.getToDeleteSeconds())
							{
								Esalix.getInstance().sendDiscordMessage(averageCpu + " : Deleting a dedicated server: " + finalUnusedServer.getIp());
								removerMargin = margins.getToDeleteSeconds();
								ScalewayManager.byeServer(finalUnusedServer);
							}
							else
							{
								Esalix.getInstance().sendDebugMessage(averageCpu + " : ACTION: WAITING FOR REMOVE MARGIN... (" + (margins.getToDeleteSeconds() - removerMargin) + ")");
							}
							removerMargin++;
						}
						else
						{
							if (removerMargin > 0)
							{
								removerMargin--;
							}
						}
					}
					else
					{
						if (removerMargin > 0)
						{
							removerMargin--;
						}
					}
				}
				else
				{
					if (removerMargin > 0)
					{
						removerMargin--;
					}
				}
			}
		}
		catch(Exception error)
		{
			error.printStackTrace();
			return;
		}
	}

	public boolean canOpenAServer(Configuration config, List<DedicatedServerEntity> servers)
	{
		double maxCpuCreater = config.getResources().getMinCpuToCreate();
		return averageCpu >= maxCpuCreater || 
				Double.isNaN(averageCpu) || 
				(averageRam * 1024) < config.getResources().getMaxLeftRamToCreate() || 
				servers.size() < config.getResources().getMinServers();
	}

	public boolean validate(final String ip){
		matcher = pattern.matcher(ip);
		return matcher.matches();
	}

}