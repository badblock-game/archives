package fr.badblock.docker.esalix.v2.loaders;

import fr.badblock.docker.esalix.v2.Esalix;
import fr.badblock.docker.esalix.v2.commands._CommandManager;

public class CommandsLoader extends _EsalixLoader
{

	public CommandsLoader()
	{
		super(_EsalixLoaderType.COMMANDS);
	}

	@Override
	public void load(Esalix esalix)
	{
		new _CommandManager();
	}
	
}
