package fr.badblock.docker.esalix.v2.dockerpart.entities;

public enum EntityType {

	DEDICATED_SERVER,
	INSTANCE,
	WORLD,
	SERVER;
	
}
