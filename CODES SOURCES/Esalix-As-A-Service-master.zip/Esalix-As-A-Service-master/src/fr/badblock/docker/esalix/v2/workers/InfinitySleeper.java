package fr.badblock.docker.esalix.v2.workers;

public class InfinitySleeper extends Thread
{
	
	@Override
	public void run()
	{
		while (true)
		{
			try
			{
				sleep(Long.MAX_VALUE);
			}
			catch (InterruptedException exception)
			{
				exception.printStackTrace();
			}
		}
	}
	
}
