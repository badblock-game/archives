package fr.badblock.docker.esalix.v2.configuration.sub;

import lombok.Data;

@Data
public class DiscordConfiguration
{

	private String		webhook	= "http://linkhere/";

}
