package fr.badblock.docker.esalix.v2;

import com.cloudflare.api.CloudflareAccess;
import com.google.gson.Gson;

import fr.badblock.docker.esalix.scaleway.ScalewayApiClient;
import fr.badblock.docker.esalix.v2.configuration.Configuration;
import fr.badblock.docker.esalix.v2.discord.DiscordMessage;
import fr.badblock.docker.esalix.v2.discord.TemmieWebhook;
import fr.badblock.docker.esalix.v2.loaders._EsalixLoader;
import fr.badblock.docker.esalix.v2.logging.Log;
import fr.badblock.docker.esalix.v2.logging.Log.LogType;
import fr.toenga.common.tech.rabbitmq.RabbitService;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
public class Esalix
{

	@Getter @Setter private static Esalix	instance;

	private	ScalewayApiClient	scaleway;
	private CloudflareAccess	cloudflare;
	private RabbitService		rabbitService;
	private Configuration		configuration;
	private TemmieWebhook		webhook;
	private Gson				gson;
	
	public Esalix()
	{
		setInstance(this);
		load();
	}
	
	private void load()
	{
		_EsalixLoader.loadAll(this);
	}

	public void sendDebugMessage(String message)
	{
		if (getConfiguration().getDebug().isLogDebug())
		{
			Log.log(message, LogType.DEBUG);
		}
		if (!getConfiguration().getDebug().isDiscordDebug())
		{
			return;
		}
		DiscordMessage dm = new DiscordMessage("Esalix", "[DEBUG] " + message, "");
		webhook.sendMessage(dm);
	}

	public void sendDiscordMessage(String message)
	{
		Log.log(message, LogType.INFO);
		DiscordMessage dm = new DiscordMessage("Esalix", "[DEBUG] " + message, "");
		webhook.sendMessage(dm);
	}
	
	public void stop()
	{
		
	}
	
}