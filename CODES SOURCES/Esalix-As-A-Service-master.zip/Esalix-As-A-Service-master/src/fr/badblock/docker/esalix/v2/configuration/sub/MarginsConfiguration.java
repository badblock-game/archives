package fr.badblock.docker.esalix.v2.configuration.sub;

import lombok.Data;

@Data
public class MarginsConfiguration
{

	private int						toCreateSeconds		=	120;
	private int						toDeleteSeconds		=	900;
	
}
