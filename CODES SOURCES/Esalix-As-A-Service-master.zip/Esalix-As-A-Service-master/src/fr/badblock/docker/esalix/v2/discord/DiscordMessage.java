package fr.badblock.docker.esalix.v2.discord;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.annotations.SerializedName;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

/**
 * A discord message
 * 
 * @author MrPowerGamerBR
 */
@Getter
@Setter
@Builder
@AllArgsConstructor
public class DiscordMessage {
	String username;
	String content;
	@SerializedName("avatar_url")
	String avatarUrl;
	@SerializedName("tts")
	boolean textToSpeech;

	public DiscordMessage() {

	}

	public DiscordMessage(String username, String content, String avatar_url) {
		this(username, content, avatar_url, false);
	}

	public void setUsername(String username) {
		if (username != null) {
			this.username = username.substring(0, Math.min(31, username.length()));
		} else {
			this.username = null;
		}
	}

	public static class DiscordMessageBuilder {
		List<DiscordEmbed> embeds = new ArrayList<DiscordEmbed>();
		
		public DiscordMessageBuilder embed(DiscordEmbed embed) {
			embeds.add(embed);
			return this;
		}
	}
}
