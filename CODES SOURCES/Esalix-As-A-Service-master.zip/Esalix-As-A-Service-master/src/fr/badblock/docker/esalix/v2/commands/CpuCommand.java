package fr.badblock.docker.esalix.v2.commands;

import fr.badblock.docker.esalix.v2.Esalix;
import fr.badblock.docker.esalix.v2.workers.DockerAsAService;

public class CpuCommand extends _Command
{

	public CpuCommand()
	{
		super("cpu");
	}

	@Override
	public void run(String command)
	{
		Esalix.getInstance().sendDiscordMessage("CPU Usage: " + DockerAsAService.averageCpu);
	}

}
