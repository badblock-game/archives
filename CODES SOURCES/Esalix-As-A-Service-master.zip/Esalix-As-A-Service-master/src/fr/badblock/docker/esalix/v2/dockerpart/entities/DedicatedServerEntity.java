package fr.badblock.docker.esalix.v2.dockerpart.entities;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ConcurrentHashMap;

import fr.badblock.docker.esalix.v2.logging.Log;
import fr.badblock.docker.esalix.v2.logging.Log.LogType;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter public class DedicatedServerEntity extends Entity {

	@Getter @Setter private static ConcurrentHashMap<String, DedicatedServerEntity>		servers		= new ConcurrentHashMap<>();

	private	String															ip;
	private long															keepAlive;
	private double															cpu			= 100;
	private long															ram			= 0;
	private	boolean															first;
	private boolean															available;
	private	boolean															last;
	private TimerTask														timerTask;
	private DedicatedServerType												dedicatedServerType;
	private Queue<Double>													cpu120S;

	public DedicatedServerEntity(String ip) {
		super(EntityType.DEDICATED_SERVER);
		dedicatedServerType = DedicatedServerType.NONE;
		setIp(ip);
		setCpu120S(new LinkedList<Double>());
		servers.put(getIp(), this);
		this.setTimerTask(this.run());
		new Timer().schedule(timerTask, 1000, 1000);
	}

	public TimerTask run() {
		if (timerTask == null) {
			return timerTask = new TimerTask() {
				@Override
				public void run() {
					if ((isOnline() && !last)) {
						Log.log("[Docker] " + ip + " dedicated server is online!", LogType.SUCCESS);
					}else if ((!isOnline() && last) || first) {
						Log.log("[Docker] " + ip + " dedicated server is offline!", LogType.WARNING);
					}
					setFirst(false);
					setLast(isOnline());
				}
			};
		}
		return timerTask;
	}

	public void keepAlive(double cpu, long ram, long disk, long ramPercent, int slots, boolean slotsIncrease, String dedicatedServerType) {
		this.dedicatedServerType = DedicatedServerType.get(dedicatedServerType);
		setKeepAlive(System.currentTimeMillis() + 300_000L);
		if (cpu120S.size() >= 120 / 0.500)
		{
			cpu120S.poll();
		}
		cpu120S.add(cpu);
		setCpu(cpu);
		setRam(ram);
	}

	public boolean isOnline() {
		return this.getKeepAlive() > System.currentTimeMillis();
	}

	public void remove() {
		setKeepAlive(0L);
		run().run();
		run().cancel();
	}
}
