package fr.badblock.docker.esalix.v2.configuration.sub;

import java.util.HashMap;
import java.util.Map;

import fr.badblock.docker.esalix.scaleway.model.ArchType;
import lombok.Data;

@Data
public class ResourcesConfiguration
{

	private int						minServers				= 1;
	private int						maxServers				= 20;
	private long					minCpuToDelete			= 35;
	private long					minCpuToCreate			= 50;
	private long					maxLeftRamToCreate		= 2048;
	private long					timeBetweenEachServer	= 600_000;
	private long					stockReset				= 3600_000;
	public String[]					serverTypes				= new String[]
			{
					"AServerType",
					"AnotherServerType"
			};
	public String[]					tags					= new String[]
			{
					"example"
			};
	public Map<ArchType, String> 	images					= new HashMap<>();

}
