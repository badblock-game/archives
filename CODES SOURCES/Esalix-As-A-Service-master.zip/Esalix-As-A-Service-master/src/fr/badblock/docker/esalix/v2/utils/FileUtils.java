package fr.badblock.docker.esalix.v2.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import fr.badblock.docker.esalix.v2.Esalix;
import fr.badblock.docker.esalix.v2.configuration.Configuration;

public class FileUtils
{

	private static final String CONFIG = "config.json";

	/** READ FILES **/

	public static List<String> readFile(Esalix esalix, String name)
	{
		List<String> lines = new ArrayList<>();
		File file = new File(name);
		if (!file.exists())
		{
			try 
			{
				file.createNewFile();
				esalix.setConfiguration(new Configuration());
				saveConfiguration(esalix);
			} 
			catch (IOException e1)
			{
				e1.printStackTrace();
			}
		}
		try (BufferedReader br = new BufferedReader(new FileReader(file)))
		{
			String currentLine;
			while ((currentLine = br.readLine()) != null)
			{
				lines.add(currentLine);
			}
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		return lines;
	}

	public static Configuration loadConfiguration(Esalix esalix)
	{
		Iterator<String> iterator = readFile(esalix, CONFIG).iterator();
		String result = !iterator.hasNext() ? "{}" : "";
		while (iterator.hasNext()) 
		{
			result += iterator.next();
			if (iterator.hasNext()) result += System.lineSeparator();
		}

		return esalix.getGson().fromJson(result, Configuration.class);
	}

	/** SAVE FILES **/

	public static void save(String name, List<String> list)
	{
		Path file = Paths.get(name);
		try
		{
			Files.write(file, list, Charset.forName("UTF-8"));
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}

	public static void saveConfiguration(Esalix esalix)
	{
		save(CONFIG, Arrays.asList(esalix.getGson().toJson(esalix.getConfiguration()).split(System.lineSeparator())));
	}

}
