package fr.badblock.docker.esalix.v2.commands;

public class HelpCommand extends _Command
{

	public HelpCommand()
	{
		super("help", "h", "?", "");
	}

	@Override
	public void run(String command) {
		sendMessage("Command list:");
		sendMessage(" - reload - Reload configuration");
		sendMessage(" - cpu - Get CPU usage");
		sendMessage(" - serverlist - List all servers");
		sendMessage(" - createserver - Create a server.");
		sendMessage(" - deleteserver <ip> - Delete a server.");
		sendMessage(" - byeserver <ip> - Send a bye signal to a server.");
		sendMessage(" - byeallservers - Send a bye signal to all servers.");
		sendMessage(" - state <ip> <POWERON/POWEROFF/TERMINATE/REBOOT> - Update state of a server");
		sendMessage(" - volumelist - List all volumes");
		sendMessage(" - deletevolume <id> - Delete a volume");
		sendMessage(" - iplist - List all IPs");
		sendMessage(" - deleteip <ip> - Delete an IP");
	}

}
