package fr.badblock.docker.esalix.v2.commands;

import fr.badblock.docker.esalix.v2.Esalix;
import fr.badblock.docker.esalix.v2.dockerpart.entities.DedicatedServerEntity;
import fr.badblock.docker.esalix.v2.manager.ScalewayManager;

public class ByeServerCommand extends _Command
{

	public ByeServerCommand()
	{
		super("byeserver");
	}

	@Override
	public void run(String command)
	{
		String[] args = command.split(" ");
		if (args.length != 2)
		{
			Esalix.getInstance().sendDiscordMessage("Usage: byeserver <ip>");
			return;
		}
		try
		{
			String server = args[1];
			DedicatedServerEntity entity = DedicatedServerEntity.getServers().get(server);
			if (entity == null)
			{
				Esalix.getInstance().sendDiscordMessage("Unknown server with IP '" + server + "'.");
				return;
			}
			ScalewayManager.byeServer(entity);
			Esalix.getInstance().sendDiscordMessage("Sended 'bye' signal to '" + server + "'");
		}
		catch(Exception error)
		{
			error.printStackTrace();
			Esalix.getInstance().sendDiscordMessage("An error occurred while trying to 'bye' server (command): " + error.getMessage());
		}
	}

}
