package fr.badblock.docker.esalix.v2.commands;

import fr.badblock.docker.esalix.v2.logging.Log;
import fr.badblock.docker.esalix.v2.logging.Log.LogType;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = false)
@Data
public abstract class _Command
{

	private String[] commands;
	
	public _Command(String... commands)
	{
		setCommands(commands);
	}
	
	public abstract void run(String command);
	
	void sendMessage(String string)
	{
		Log.log(string, LogType.INFO);
	}
	
}
