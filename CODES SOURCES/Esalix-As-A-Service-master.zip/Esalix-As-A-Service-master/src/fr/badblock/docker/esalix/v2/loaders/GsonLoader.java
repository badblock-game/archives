package fr.badblock.docker.esalix.v2.loaders;

import com.google.gson.GsonBuilder;

import fr.badblock.docker.esalix.v2.Esalix;

public class GsonLoader extends _EsalixLoader
{

	public GsonLoader()
	{
		super(_EsalixLoaderType.GSON);
	}

	@Override
	public void load(Esalix esalix)
	{
		// Set Gson
		esalix.setGson(new GsonBuilder().setPrettyPrinting().create());
	}
	
}
