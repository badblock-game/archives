package fr.badblock.docker.esalix.v2.loaders;

import fr.badblock.docker.esalix.v2.Esalix;
import fr.badblock.docker.esalix.v2.dockerpart.rabbitlisteners.DedicatedServerLoadListener;

public class RabbitListenersLoader extends _EsalixLoader
{

	public RabbitListenersLoader()
	{
		super(_EsalixLoaderType.RABBITMQ_LISTENERS);
	}

	@Override
	public void load(Esalix esalix)
	{
		new DedicatedServerLoadListener(esalix.getRabbitService());
	}
	
}
