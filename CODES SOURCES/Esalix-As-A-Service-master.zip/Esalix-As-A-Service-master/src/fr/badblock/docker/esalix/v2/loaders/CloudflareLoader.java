package fr.badblock.docker.esalix.v2.loaders;

import com.cloudflare.api.CloudflareAccess;

import fr.badblock.docker.esalix.v2.Esalix;
import fr.badblock.docker.esalix.v2.configuration.sub.CloudflareConfiguration;

public class CloudflareLoader extends _EsalixLoader
{

	public CloudflareLoader()
	{
		super(_EsalixLoaderType.CLOUDFLARE);
	}

	@Override
	public void load(Esalix esalix)
	{
		CloudflareConfiguration configuration = esalix.getConfiguration().getCloudflare();
		esalix.setCloudflare(new CloudflareAccess(configuration.getEmail(), configuration.getApikey()));
	}
	
}
