package fr.badblock.docker.esalix.v2.commands;

import fr.badblock.docker.esalix.v2.Esalix;

public class VolumeListCommand extends _Command
{

	public VolumeListCommand()
	{
		super("volumelist");
	}

	@Override
	public void run(String command)
	{
		Esalix.getInstance().sendDiscordMessage("Volume list:");
		try
		{
			Esalix.getInstance().getScaleway().getAllVolumes(1, 100).getVolumes().forEach(volume -> 
			{
				Esalix.getInstance().sendDiscordMessage(" - Volume ID: " + volume.getId() + " | " + volume.getSize() + " | " + (volume.getServer() != null ? "Server: " + volume.getServer().getName() + (volume.getServer().getPublicIp() != null ? " - " + volume.getServer().getPublicIp().getIpAddress() : "") : "No server"));
			});
		}
		catch(Exception error)
		{
			error.printStackTrace();
			Esalix.getInstance().sendDiscordMessage("An error occurred while trying to list volumes (command): " + error.getMessage());
		}
	}

}
