package fr.badblock.docker.esalix.v2.commands;

import fr.badblock.docker.esalix.v2.Esalix;
import fr.badblock.docker.esalix.v2.dockerpart.entities.DedicatedServerEntity;

public class ServerListCommand extends _Command
{

	public ServerListCommand()
	{
		super("serverlist");
	}

	@Override
	public void run(String command)
	{
		Esalix.getInstance().sendDiscordMessage("Scaleway server list:");
		try
		{
			Esalix.getInstance().getScaleway().getAllServers(1, 100).getServers().forEach(server -> 
			{
				Esalix.getInstance().sendDiscordMessage(" - Server ID: " + server.getId() + " | " + (server.getPublicIp() != null ? server.getPublicIp().getIpAddress() : "No IP assigned.") + " | " + server.getServerType().name());
			});
		}
		catch(Exception error)
		{
			error.printStackTrace();
			Esalix.getInstance().sendDiscordMessage("An error occurred while trying to list servers (command): " + error.getMessage());
		}
		Esalix.getInstance().sendDiscordMessage("Docker server list:");
		DedicatedServerEntity.getServers().values().forEach(server -> 
		{
			Esalix.getInstance().sendDiscordMessage(" - (" + server.getDedicatedServerType() + ") " + server.getIp() + " - " + server.getCpu() + "% CPU");
		});
	}

}
