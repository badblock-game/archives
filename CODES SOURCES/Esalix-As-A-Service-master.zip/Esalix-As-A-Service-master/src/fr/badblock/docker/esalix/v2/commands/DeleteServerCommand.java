package fr.badblock.docker.esalix.v2.commands;

import java.util.List;
import java.util.stream.Collectors;

import fr.badblock.docker.esalix.scaleway.model.Server;
import fr.badblock.docker.esalix.v2.Esalix;

public class DeleteServerCommand extends _Command
{

	public DeleteServerCommand()
	{
		super("deleteserver");
	}

	@Override
	public void run(String command)
	{
		String[] args = command.split(" ");
		if (args.length != 2)
		{
			Esalix.getInstance().sendDiscordMessage("Usage: deleteserver <ip>");
			return;
		}
		try
		{
			String server = args[1];
			List<Server> s = Esalix.getInstance().getScaleway().getAllServers(1, 100).getServers().stream().filter(se -> se.getId().equals(server)).collect(Collectors.toList());
			if (s.isEmpty())
			{
				Esalix.getInstance().sendDiscordMessage("Unknown server: '" + server + "'");
				return;
			}
			Server se = s.get(0);
			Esalix.getInstance().getScaleway().deleteServer(se.getId());
			Esalix.getInstance().sendDiscordMessage("Removed server: " + (se.getPublicIp() == null ? se.getId() :se.getPublicIp().getIpAddress()));
		}
		catch(Exception error)
		{
			error.printStackTrace();
			Esalix.getInstance().sendDiscordMessage("An error occurred while trying to delete server (command): " + error.getMessage());
		}
	}

}
