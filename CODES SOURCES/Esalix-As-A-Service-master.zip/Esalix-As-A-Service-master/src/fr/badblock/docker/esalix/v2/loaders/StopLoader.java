package fr.badblock.docker.esalix.v2.loaders;

import fr.badblock.docker.esalix.v2.Esalix;

public class StopLoader extends _EsalixLoader
{

	public StopLoader()
	{
		super(_EsalixLoaderType.STOP);
	}

	@Override
	public void load(Esalix esalix)
	{
		Runtime.getRuntime().addShutdownHook(new Thread()
		{
			public void run()
			{
				esalix.stop();
			}
		});
	}
	
}
