package fr.badblock.docker.esalix.v2.commands;

import java.util.List;

import fr.badblock.docker.esalix.scaleway.model.IP;
import fr.badblock.docker.esalix.v2.Esalix;

public class DeleteIPCommand extends _Command
{

	public DeleteIPCommand()
	{
		super("deleteip");
	}

	@Override
	public void run(String command)
	{
		String[] args = command.split(" ");
		if (args.length != 2)
		{
			Esalix.getInstance().sendDiscordMessage("Usage: deleteip <ip>");
			return;
		}
		try
		{
			String server = args[1];
			List<IP> s = Esalix.getInstance().getScaleway().getAllIPs(1, 100).getIPs();
			if (s.isEmpty())
			{
				Esalix.getInstance().sendDiscordMessage("Unknown IP: '" + server + "'");
				return;
			}
			boolean f = false;
			for (IP ipe : s)
			{
				if (ipe.getIpAddress().equalsIgnoreCase(server))
				{
					f = true;
					Esalix.getInstance().getScaleway().deleteIP(ipe.getId());
					Esalix.getInstance().sendDiscordMessage("Removed IP: " + ipe.getId() + " | " + ipe.getIpAddress());
				}
			}
			if (!f)
			{
				Esalix.getInstance().sendDiscordMessage("Unknown IP: '" + server + "'");
				return;
			}
		}
		catch(Exception error)
		{
			error.printStackTrace();
			Esalix.getInstance().sendDiscordMessage("An error occurred while trying to delete ip (command): " + error.getMessage());
		}
	}

}
