package fr.badblock.docker.esalix.v2.configuration;

@SuppressWarnings("serial")
public class ConfigurationException extends RuntimeException
{

	public ConfigurationException(String message)
	{
		super("Error occurred while loading config. " + message);
	}
	
}
