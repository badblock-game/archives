package fr.badblock.docker.esalix.v2.manager;

import fr.badblock.docker.esalix.scaleway.ScalewayApiClient;
import fr.badblock.docker.esalix.scaleway.exception.ScalewayApiException;
import fr.badblock.docker.esalix.v2.Esalix;
import fr.badblock.docker.esalix.v2.database.BadblockDatabase;
import fr.badblock.docker.esalix.v2.database.Request;
import fr.badblock.docker.esalix.v2.database.Request.RequestType;
import fr.badblock.docker.esalix.v2.dockerpart.entities.DedicatedServerEntity;
import fr.badblock.docker.esalix.v2.logging.Log;
import fr.badblock.docker.esalix.v2.logging.Log.LogType;
import fr.toenga.common.tech.rabbitmq.packet.RabbitPacket;
import fr.toenga.common.tech.rabbitmq.packet.RabbitPacketEncoder;
import fr.toenga.common.tech.rabbitmq.packet.RabbitPacketMessage;
import fr.toenga.common.tech.rabbitmq.packet.RabbitPacketType;

public class ScalewayManager
{

	// API
	public static 	ScalewayApiClient	scaleway		= Esalix.getInstance().getScaleway();
	
	// Thread
	public static Thread				thread;

	/**
	 * Get scaleway organization ID
	 * @return
	 * @throws ScalewayApiException
	 */
	public static String getScalewayOrganization() throws ScalewayApiException
	{
		return (scaleway.getAllOrganizations().get(0).getId());
	}

	/**
	 * Generating a server
	 * @param esalix
	 */
	public static void generateServer(Esalix esalix)
	{
		try
		{
			new OpenServerManager().start();
		}
		catch (ScalewayApiException exception)
		{
			exception.printStackTrace();
		}
	}

	public static void byeServer(DedicatedServerEntity finalUnusedServer)
	{
		RabbitPacketMessage rabbitMessage = new RabbitPacketMessage(60000, "deleter");
		RabbitPacket rabbitPacket = new RabbitPacket(rabbitMessage, "networkdocker.docker.stopcreate." + finalUnusedServer.getIp(),
				true, RabbitPacketEncoder.UTF8, RabbitPacketType.PUBLISHER);
		Esalix.getInstance().getRabbitService().sendPacket(rabbitPacket);
		BadblockDatabase.getInstance().addSyncRequest(
				new Request("UPDATE esalix SET state = 'STOPPING' WHERE serverIp = '" + finalUnusedServer.getIp() + "'", RequestType.SETTER));
		Log.log("Sended deleting server signal to '" + finalUnusedServer.getIp() + "' !", LogType.SUCCESS);
		Esalix.getInstance().sendDiscordMessage(finalUnusedServer.getIp() + " will not accept further instances.");
	}

}
