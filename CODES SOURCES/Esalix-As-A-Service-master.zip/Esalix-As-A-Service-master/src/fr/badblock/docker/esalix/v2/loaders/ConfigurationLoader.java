package fr.badblock.docker.esalix.v2.loaders;

import fr.badblock.docker.esalix.v2.Esalix;
import fr.badblock.docker.esalix.v2.configuration.ConfigurationChecker;
import fr.badblock.docker.esalix.v2.utils.FileUtils;

public class ConfigurationLoader extends _EsalixLoader
{

	public ConfigurationLoader()
	{
		super(_EsalixLoaderType.CONFIGURATION);
	}

	@Override
	public void load(Esalix esalix)
	{
		// Load configuration
		esalix.setConfiguration(FileUtils.loadConfiguration(esalix));
		// Check configuration
		ConfigurationChecker configurationChecker = new ConfigurationChecker(esalix.getConfiguration());
		configurationChecker.check();
	}
	
}
