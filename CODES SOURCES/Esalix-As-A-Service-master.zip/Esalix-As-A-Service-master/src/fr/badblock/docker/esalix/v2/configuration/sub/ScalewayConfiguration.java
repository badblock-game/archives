package fr.badblock.docker.esalix.v2.configuration.sub;

import lombok.Data;

@Data
public class ScalewayConfiguration
{
	
	public String	scalewayToken		=	"AToken";
	public String 	organizationId		=	"MyOrganization";
	
}
