package fr.badblock.docker.esalix.v2.manager;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.cloudflare.api.CloudflareAccess;
import com.cloudflare.api.constants.RecordType;
import com.cloudflare.api.requests.dns.DNSAddRecord;

import fr.badblock.docker.esalix.scaleway.exception.ScalewayApiException;
import fr.badblock.docker.esalix.scaleway.model.IP;
import fr.badblock.docker.esalix.scaleway.model.Server;
import fr.badblock.docker.esalix.scaleway.model.ServerAction;
import fr.badblock.docker.esalix.scaleway.model.ServerType;
import fr.badblock.docker.esalix.v2.Esalix;
import fr.badblock.docker.esalix.v2.configuration.Configuration;
import fr.badblock.docker.esalix.v2.configuration.sub.CloudflareConfiguration;
import fr.badblock.docker.esalix.v2.database.BadblockDatabase;
import fr.badblock.docker.esalix.v2.database.DatabaseUtil;
import fr.badblock.docker.esalix.v2.database.Request;
import fr.badblock.docker.esalix.v2.database.Request.RequestType;
import fr.badblock.docker.esalix.v2.logging.Log;
import fr.badblock.docker.esalix.v2.logging.Log.LogType;
import fr.badblock.docker.esalix.v2.utils.Callback;
import lombok.Data;
import net.sf.json.JSONObject;

@Data
public class OpenServerManager
{

	// Static fields
	private static	long 				lastTry;
	// Freeze deleters
	public 	static	long 				freezeDeleters;

	// Server margin
	public static long					sLast		= 0;
	public static Map<String, Long>		servers		= new HashMap<>();

	// Stock checking
	private static List<String> 		sTypeList	= Arrays.asList(Esalix.getInstance().getConfiguration().getResources().getServerTypes());
	private static Iterator<String> 	iterator 	= sTypeList.iterator();
	private static String				serverType;
	private static long					stockReset	= System.currentTimeMillis() + 3600_000L;

	// Current manager
	private Server		server;
	private ServerType	currentServerType;
	private IP			ip;
	private String		dns;
	private String		organization;
	private String		uuid;
	private long		currentTimestamp;
	private	long		dnsId;

	public void start() throws ScalewayApiException
	{
		setDefaultFields();
		checkLimited(new Callback<Boolean>()
		{
			@Override
			public void done(Boolean result, Throwable error)
			{
				if (!result.booleanValue())
				{
					return;
				}
				setLastTry();
				logStep(1);
				try
				{
					createIp();
					logStep(2);
					createDNS();
					logStep(3);
					selectStock();
					logStep(4);
					createServer();
					logStep(5);
					attachIp();
					logStep(6);
					insertIntoDatabase();
					logStep(7);
					openServer();
					logStep(8);
				}
				catch (ScalewayApiException e)
				{
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Fast access to config
	 * @return
	 */
	private static Configuration config()
	{
		return Esalix.getInstance().getConfiguration();
	}

	public void setDefaultFields() throws ScalewayApiException
	{
		setOrganization(ScalewayManager.getScalewayOrganization());
		setCurrentTimestamp(System.currentTimeMillis());
		setUuid(UUID.randomUUID().toString().split("-")[0]);
	}

	public void checkLimited(Callback<Boolean> callback)
	{
		DatabaseUtil.getCount("FROM esalix WHERE startTime > '" + currentTimestamp + "' AND state = 'LOADING'", new Callback<Integer>()
		{
			@Override
			public void done(Integer result, Throwable error)
			{
				// Check if a server has been generated recently
				if (lastTry > currentTimestamp)
				{
					Log.log("ACTION : TRYING TO GENERATE A SERVER BUT LIMITED. #1", LogType.DEBUG);
					callback.done(false, null);
					return;
				}
				// A server is starting up, don't generate a new server.
				if (result.intValue() != 0)
				{
					Log.log("ACTION : TRYING TO GENERATE A SERVER BUT LIMITED. #2", LogType.DEBUG);
					callback.done(false, null);
					return;
				}
				callback.done(true, null);
			}
		});
	}

	public void setLastTry()
	{
		// Set freezers & last try
		lastTry = currentTimestamp + config().getResources().getTimeBetweenEachServer();
		freezeDeleters = currentTimestamp + 30_000L;
	}

	public void createIp() throws ScalewayApiException
	{
		setIp(ScalewayManager.scaleway.createIP(organization));
	}

	public void createDNS()
	{
		// Adding DNS record to Cloudflare
		CloudflareConfiguration configuration = config().getCloudflare();
		setDns(configuration.getDns().replace("{0}", uuid));
		CloudflareAccess cloudflare = Esalix.getInstance().getCloudflare();
		DNSAddRecord dns = new DNSAddRecord(cloudflare, configuration.getWebsite(), RecordType.IPV4Address, getDns(), getIp().getIpAddress());
		setDns(getDns() + "." + configuration.getWebsite());
		try
		{
			JSONObject object = dns.executeBasic();
			if (object != null) {
				if (object.has("rec")) {
					JSONObject rec = object.getJSONObject("rec");
					if (rec != null) {
						if (rec.has("obj")) {
							JSONObject obj = rec.getJSONObject("obj");
							if (obj != null) {
								if (obj.has("rec_id")) {
									int recId = obj.getInt("rec_id");
									dnsId = recId;
								}
							}
						}
					}
				}
			}
			dns.close();
			Thread.sleep(15_000);
		}
		catch (Exception exception)
		{
			exception.printStackTrace();
		}
	}

	public void selectStock()
	{
		// Stock manage
		sLast = currentTimestamp + 30_000L;
		if (!iterator.hasNext())
		{
			iterator = sTypeList.iterator();
		}
		if (serverType == null || stockReset < currentTimestamp)
		{
			serverType = iterator.next();
			stockReset = currentTimestamp + config().getResources().getStockReset();
		}

		// Creating image
		setCurrentServerType(ServerType.get(serverType));
	}

	public void createServer() throws ScalewayApiException
	{
		String image = config().getResources().getImages().get(getCurrentServerType().getArchType());
		setServer(ScalewayManager.scaleway.createServer(uuid, image, organization, getCurrentServerType(), false, config().getResources().getTags()));
		synchronized (ScalewayManager.thread)
		{
			servers.put(server.getId(), currentTimestamp + 30_000);
			sLast = 0;
		}
	}

	public void attachIp() throws ScalewayApiException
	{
		ScalewayManager.scaleway.attachIP(getIp().getId(), getOrganization(), getIp().getIpAddress(), getServer().getId(), getDns());
	}

	public void insertIntoDatabase()
	{
		BadblockDatabase.getInstance().addSyncRequest(
				new Request(
						"INSERT INTO esalix(serverId, serverIp, serverHost, state, startTime, dnsId) VALUES('" + server.getId() + "', '" + 
								ip.getIpAddress() + "', '" + 
								server.getHostname() + "', 'LOADING', '" + lastTry + "', '" + dnsId + "')", 
								RequestType.SETTER));
	}

	public void logStep(int i)
	{
		Esalix.getInstance().sendDiscordMessage("[" + i + "/8] Starting the dedicated server..." + (getIp() == null ? "" : " (" + getIp().getIpAddress() + ")"));
	}
	
	public void openServer()
	{
		try
		{
			ScalewayManager.scaleway.executeServerAction(getServer().getId(), ServerAction.POWERON);
		}
		catch (ScalewayApiException exception)
		{
			exception.printStackTrace();
		}
	}

}