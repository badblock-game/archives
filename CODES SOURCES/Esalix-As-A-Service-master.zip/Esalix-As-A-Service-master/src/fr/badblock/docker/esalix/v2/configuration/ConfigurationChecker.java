package fr.badblock.docker.esalix.v2.configuration;

import fr.badblock.docker.esalix.v2.configuration.sub.MarginsConfiguration;
import fr.badblock.docker.esalix.v2.configuration.sub.ResourcesConfiguration;
import fr.badblock.docker.esalix.v2.utils.OperatorUtils;
import lombok.Data;

@Data
public class ConfigurationChecker
{
	
	private Configuration configuration;
	
	public ConfigurationChecker(Configuration configurationToCheck)
	{
		setConfiguration(configurationToCheck);
	}

	public void check() throws ConfigurationException
	{
		// Check CPU values
		checkCpuCreateValues();
		checkCpuRemoveValues();
		checkCpuDifferenceValues();
		// Check margins
		checkCreateMargin();
		checkDeleteMargin();
		// Check servers
		checkServerCount();
	}
	
	private void checkCpuCreateValues()
	{
		ResourcesConfiguration resources = getConfiguration().getResources();
		long value = resources.getMinCpuToCreate();
		if (OperatorUtils.notInRange(value, 20, 100))
		{
			throw new ConfigurationException("[Resources] MinCpuToCreate is not in range. Min: 20 & Max: 100. Currently: " + value);
		}
	}
	
	private void checkCpuRemoveValues()
	{
		ResourcesConfiguration resources = getConfiguration().getResources();
		long value = resources.getMinCpuToDelete();
		if (OperatorUtils.notInRange(value, 10, 100))
		{
			throw new ConfigurationException("[Resources] MinCpuToDelete is not in range. Min: 10 & Max: 100. Currently: " + value);
		}
	}
	
	private void checkCpuDifferenceValues()
	{
		ResourcesConfiguration resources = getConfiguration().getResources();
		long value = resources.getMinCpuToCreate() - resources.getMinCpuToDelete();
		if (OperatorUtils.notInRange(value, 10, 100))
		{
			throw new ConfigurationException("[Resources] Difference between MinCpuToCreate and MinCpuToDelete not in range. Min: 10 & Max: 100. Currently: " + value);
		}
	}

	private void checkCreateMargin()
	{
		MarginsConfiguration margins = getConfiguration().getMargins();
		long value = margins.getToCreateSeconds();
		if (OperatorUtils.notInRange(value, 60, 600))
		{
			throw new ConfigurationException("[Margins] ToCreateSeconds is not in range. Min: 60 & Max: 600. Currently: " + value);
		}
	}

	private void checkDeleteMargin()
	{
		MarginsConfiguration margins = getConfiguration().getMargins();
		long value = margins.getToDeleteSeconds();
		if (OperatorUtils.notInRange(value, 60, 3600))
		{
			throw new ConfigurationException("[Margins] ToDeleteSeconds is not in range. Min: 60 & Max: 3600s. Currently: " + value);
		}
	}
	
	private void checkServerCount()
	{
		ResourcesConfiguration resources = getConfiguration().getResources();
		if (resources.getMinServers() >= resources.getMaxServers())
		{
			throw new ConfigurationException("[Resources] There's more min servers than max servers (" + 
					resources.getMinServers() + " > " + resources.getMaxServers() + ")");
		}
	}

}
