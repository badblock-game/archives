package fr.badblock.docker.esalix.v2.loaders;

public enum _EsalixLoaderType
{

	INFINITYSLEEPER,
	GSON,
	CONFIGURATION,
	RABBITMQ_AUTHENTICATION,
	RABBITMQ_LISTENERS,
	CLOUDFLARE,
	DATABASE,
	COMMANDS,
	SCALEWAY,
	DISCORD,
	WORKERS,
	STOP;
	
}
