package fr.badblock.docker.esalix.v2.commands;

import fr.badblock.docker.esalix.v2.Esalix;

public class IPListCommand extends _Command
{

	public IPListCommand()
	{
		super("iplist");
	}

	@Override
	public void run(String command)
	{
		Esalix.getInstance().sendDiscordMessage("IP list:");
		try
		{
			Esalix.getInstance().getScaleway().getAllIPs(1, 100).getIPs().forEach(ip -> 
			{
				Esalix.getInstance().sendDiscordMessage(" - IP ID: " + ip.getId() + " | " + ip.getIpAddress());
			});
		}
		catch(Exception error)
		{
			error.printStackTrace();
			Esalix.getInstance().sendDiscordMessage("An error occurred while trying to list ip (command): " + error.getMessage());
		}
	}

}
