package fr.badblock.docker.esalix.v2.configuration.sub;

import lombok.Getter;

@Getter
public class DatabaseConfiguration {

	public String	hostname		= "127.0.0.1";
	public int		port			= 3306;
	public String	username		= "admin";
	public String	password		= "password";
	public String	database		= "arandomdbname";
	
}
