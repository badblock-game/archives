package fr.badblock.docker.esalix.v2.loaders;

import fr.badblock.docker.esalix.v2.Esalix;
import fr.badblock.docker.esalix.v2.workers.InfinitySleeper;

public class InfinitySleeperLoader extends _EsalixLoader
{

	public InfinitySleeperLoader()
	{
		super(_EsalixLoaderType.INFINITYSLEEPER);
	}

	@Override
	public void load(Esalix esalix)
	{
		new InfinitySleeper().start();
	}
	
}
