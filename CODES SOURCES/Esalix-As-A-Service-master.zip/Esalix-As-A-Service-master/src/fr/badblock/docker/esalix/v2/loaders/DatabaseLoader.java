package fr.badblock.docker.esalix.v2.loaders;

import fr.badblock.docker.esalix.v2.Esalix;
import fr.badblock.docker.esalix.v2.configuration.sub.DatabaseConfiguration;
import fr.badblock.docker.esalix.v2.database.BadblockDatabase;

public class DatabaseLoader extends _EsalixLoader
{

	public DatabaseLoader()
	{
		super(_EsalixLoaderType.DATABASE);
	}

	@Override
	public void load(Esalix esalix)
	{
		DatabaseConfiguration configuration = esalix.getConfiguration().getDatabase();
		BadblockDatabase.getInstance().connect(configuration.getHostname(), configuration.getPort(), configuration.getUsername(), 
				configuration.getPassword(), configuration.getDatabase());
	}
	
}
