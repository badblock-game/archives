<?php

require './vendor/autoload.php';

echo "== START ==", PHP_EOL;

use MongoDB\BSON\Regex;


#TeamSpeak Query
#TS_IP=ts.badblock.fr
#TS_PORT=9987
#TS_USER=webserver_reader
#TS_PASSWORD=+9ZppWco
#TS_QUERYPORT=10011


$GLOBALS['ts3_user'] = "serveradmin";
$GLOBALS['ts3_pass'] = "RoR6OYlY";
$GLOBALS['ts3_ip'] = "node02-dev.cluster.badblock-network.fr";
$GLOBALS['ts3_queryport'] = "10011";
$GLOBALS['ts3_port'] = "9987";

$GLOBALS['mongo_server_user'] = "wjayBSTtdN49ur";
$GLOBALS['mongo_server_pass'] = "2WtM97v6kAeskALjrEZTp3M89H25Rn78BXZ8Z3sZA";
$GLOBALS['mongo_server_database'] = "admin";
$GLOBALS['mongo_server_ip'] = "node01-int.clusprv.badblock-network.fr";
$GLOBALS['mongo_server_port'] = "49857";

$GLOBALS['mongo_user'] = "toenga";
$GLOBALS['mongo_pass'] = "toto";
$GLOBALS['mongo_database'] = "admin";
$GLOBALS['mongo_ip'] = "node02-dev.cluster.badblock-network.fr";
$GLOBALS['mongo_port'] = "27019";

global $ts3;
global $nop;

$ts3 = \TeamSpeak3::factory("serverquery://{$GLOBALS['ts3_user']}:{$GLOBALS['ts3_pass']}@{$GLOBALS['ts3_ip']}:{$GLOBALS['ts3_queryport']}/?server_port={$GLOBALS['ts3_port']}&blocking=0");
echo "[INFO] Connected to server!", PHP_EOL;
echo "[INFO] Memory usage: ".$ts3->getParent()->getAdapter()->getProfiler()->getMemUsage(), PHP_EOL;



TeamSpeak3_Helper_Signal::getInstance()->subscribe("notifyEvent", "onEvent");

$ts3->serverGetSelected()->notifyRegister("server");
$ts3->serverGetSelected()->notifyRegister("channel");
$ts3->serverGetSelected()->notifyRegister("textserver");
$ts3->serverGetSelected()->notifyRegister("textchannel");
$ts3->serverGetSelected()->notifyRegister("textprivate");

while (true){
    $ts3->getAdapter()->wait();
}

$nop = [];

function getChannel($uid){
    global $ts3;
    $client = new \MongoDB\Client(
        'mongodb://' . $GLOBALS['mongo_user'] . ":" . $GLOBALS['mongo_pass'] . "@" . $GLOBALS['mongo_ip'] . ":" . $GLOBALS['mongo_port'] . "/" . $GLOBALS['mongo_database']
    );
    $mongo = $client->selectDatabase($GLOBALS['mongo_database']);
    echo "[INFO] Search data channel for $uid...", PHP_EOL;
    $data = $mongo->teamspeak_channel->findOne(["ts_owner_uid" => $uid]);

    if ($data !=null){
        if ($data["state"] == false && !isset($data['channel_id'])){
            echo "[INFO] Creating channel for $uid...", PHP_EOL;
            $properties = [
                "channel_name" => $data['channel_name'],
                "channel_flag_password" => 1,
                "channel_password" => $data['channel_pwd'],
                "channel_flag_permanent" => 1
            ];

            $cid = $ts3->execute("channelcreate", $properties)->toList()['cid'];
            echo "[INFO] Channel created with ID : $cid ", PHP_EOL;

            $client = new \MongoDB\Client(
                'mongodb://' . $GLOBALS['mongo_user'] . ":" . $GLOBALS['mongo_pass'] . "@" . $GLOBALS['mongo_ip'] . ":" . $GLOBALS['mongo_port'] . "/" . $GLOBALS['mongo_database']
            );
            $mongo = $client->selectDatabase($GLOBALS['mongo_database']);
            $data = $mongo->teamspeak_channel->updateOne(["ts_owner_uid" => $uid], ['$set' => ['state' => true, "channel_id" => $cid]]);
            echo "[INFO] Store Channel ID to MongoDB", PHP_EOL;

            $ts3->clientPoke( $ts3->clientGetByUid($uid), "Votre canal custom a bien été crée !");
            $ts3->clientMove($ts3->clientGetByUid($uid), $cid, null);
        }elseif ($data["state"] == false && isset($data['channel_id'])){
            $properties = [
                "channel_name" => $data['channel_name'],
                "channel_flag_password" => 1,
                "channel_password" => $data['channel_pwd'],
                "channel_flag_permanent" => 1
            ];
            echo "[INFO] Delete channel for re-creating...", PHP_EOL;
            $cid = $ts3->execute("channeldelete", array("cid" => $data['channel_id'], "force" => 1));

            $cid = $ts3->execute("channelcreate", $properties)->toList()['cid'];
            echo "[INFO] Channel created with ID : $cid ", PHP_EOL;

            $client = new \MongoDB\Client(
                'mongodb://' . $GLOBALS['mongo_user'] . ":" . $GLOBALS['mongo_pass'] . "@" . $GLOBALS['mongo_ip'] . ":" . $GLOBALS['mongo_port'] . "/" . $GLOBALS['mongo_database']
            );
            $mongo = $client->selectDatabase($GLOBALS['mongo_database']);
            $data = $mongo->teamspeak_channel->updateOne(["ts_owner_uid" => $uid], ['$set' => ['state' => true, "channel_id" => $cid]]);
            echo "[INFO] Store Channel ID to MongoDB", PHP_EOL;

            $ts3->clientPoke( $ts3->clientGetByUid($uid), "Votre canal custom a bien été mis à jour !");
            $ts3->clientMove($ts3->clientGetByUid($uid), $cid, null);
        }elseif (isset($data['channel_id'])){
            $ts3->clientMove($ts3->clientGetByUid($uid), $data['channel_id'], null);
        }
    }
}


function getGroup($uid){
    $client = new \MongoDB\Client(
        'mongodb://' . $GLOBALS['mongo_user'] . ":" . $GLOBALS['mongo_pass'] . "@" . $GLOBALS['mongo_ip'] . ":" . $GLOBALS['mongo_port'] . "/" . $GLOBALS['mongo_database']
    );

    $mongo = $client->selectDatabase($GLOBALS['mongo_database']);
    echo "[INFO] Search data for $uid...", PHP_EOL;
    $data = $mongo->teamspeak_uid->findOne(["teamspeak_uid" => $uid]);

    if ($data != null){
        if ($data['ban'] == true && $data['banExpire'] < time()){
            $ban = true;
        }else{
            $ban = false;
        }
        echo "[INFO] Search data for $uid found !", PHP_EOL;
        echo "[INFO] Search data on Int-Server...", PHP_EOL;
        $uid = $data["uniqueId"];

        $client = new \MongoDB\Client(
            'mongodb://' . $GLOBALS['mongo_server_user'] . ":" . $GLOBALS['mongo_server_pass'] . "@" . $GLOBALS['mongo_server_ip'] . ":" . $GLOBALS['mongo_server_port'] . "/" . $GLOBALS['mongo_server_database']
        );
        $mongo = $client->selectDatabase($GLOBALS['mongo_server_database']);
        echo "[INFO] Search data for $uid...", PHP_EOL;
        $data = $mongo->players->findOne(["uniqueId" => $uid]);

        $custom = false;
        $mvp_ = false;
        $mvp = false;

        foreach ((array) $data['permissions']['alternateGroups'] as $k => $row){
            if ($k == "custom"){
                $custom = true;
            }elseif ($k == "mvp+"){
                $mvp_ = true;
            }elseif ($k == "mvp"){
                $mvp = true;
            }
        }
        if ($data['permissions']['group'] == "custom"){
            $custom = true;
        }elseif ($data['permissions']['group'] == "mvp+"){
            $mvp_ = true;
        }elseif ($data['permissions']['group'] == "mvp"){
            $mvp = true;
        }

        //Check sur le serveur de prod
        $gid = false;
        if ($custom == true){
            echo "[INFO] $uid is custom search custom_data !", PHP_EOL;
            $data = $mongo->custom_data->findOne(["uniqueId" => $uid]);
            $name = $data['prefix'];
            $group = "custom";
            if (isset($data['teamspeak_group_id'])){
                $gid = $data['teamspeak_group_id'];
                echo "[INFO] $uid have an custom group with id $gid !", PHP_EOL;
            }else{
                $gid = false;
            }
        }elseif($mvp_ == true){
            echo "[INFO] $uid have MVP+ group !", PHP_EOL;
            $group = 9;
            $name = "";
        }elseif($mvp == true){
            echo "[INFO] $uid have MVP group !", PHP_EOL;
            $group = 10;
            $name = "";
        }else{
            echo "[INFO] $uid doesn't have TeamSpeak group !", PHP_EOL;
            $group = 'nop';
            $name = '';
        }

        $data = [
            'ban' => $ban,
            'group' => $group,
            'name' => $name,
            'teamspeak_group_id' => $gid,
        ];

        return $data;

    }else{
        echo "[INFO] Search data for $uid NOT found !", PHP_EOL;

        return null;
    }
}

function onEvent(TeamSpeak3_Adapter_ServerQuery_Event $event, TeamSpeak3_Node_Host $host)
{
    global $ts3;
    global $nop;

    if ($event->getType() == 'cliententerview'){
        //client_unique_identifier
        $data = explode("client_unique_identifier=", $event->getMessage());
        $data = explode("=", $data[1]);
        $unique_id = $data[0] . "=";

        //Connection duplication patch
        if ($nop[$unique_id] == true){
            $nop[$unique_id] = false;
        }else{
            $nop[$unique_id] = true;
            getChannel($unique_id);
            $data = getGroup($unique_id);
            if ($data != null){
                if ($data['ban'] == true){
                    $ts3->clientGetByUid($unique_id)->kick(TeamSpeak3::KICK_SERVER, "Vous êtes bannis !");
                }

                if ($data['group'] == 'nop'){
                }elseif ($data['group'] != "custom"){
                    $ts3->serverGetSelected()->serverGroupClientAdd($data['group'], $ts3->clientGetByUid($unique_id)["client_database_id"]);
                }else{
                    foreach($ts3->serverGroupList() as $group)
                    {
                        if($group["name"] == $data['name'] ) $g = $group;
                    }
                    if (isset($g)){
                        $ts3->serverGetSelected()->serverGroupClientAdd($g['sgid'], $ts3->clientGetByUid($unique_id)["client_database_id"]);
                        echo "[INFO] Added user to custom group ! (No create)", PHP_EOL;
                    }else{
                        //New prefix of custom data
                        if ($data['teamspeak_group_id'] == false){
                            $id = $ts3->execute("servergroupadd", array("name" => $data['name'], "type" => 1))->toList()["sgid"];
                            echo "[INFO] Create group for custom data ! (ID : $id)", PHP_EOL;
                            $ts3->serverGetSelected()->serverGroupClientAdd($id, $ts3->clientGetByUid($unique_id)["client_database_id"]);
                            $ts3->execute("servergroupaddperm", array(
                                "sgid" => $id,
                                "permid" => 145,
                                "permvalue" => 0,
                                "permnegated" => 0,
                                "permskip" => 0
                            ));
                            echo "[INFO] Added user to custom group !", PHP_EOL;

                            //Storing in mongoDB

                            $client = new \MongoDB\Client(
                                'mongodb://' . $GLOBALS['mongo_server_user'] . ":" . $GLOBALS['mongo_server_pass'] . "@" . $GLOBALS['mongo_server_ip'] . ":" . $GLOBALS['mongo_server_port'] . "/" . $GLOBALS['mongo_server_database']
                            );
                            $mongo = $client->selectDatabase($GLOBALS['mongo_server_database']);
                            echo "[INFO] Store Group ID to MongoDB", PHP_EOL;
                            $data = $mongo->custom_data->updateOne(["prefix" => $data['name']], ['$set' => ['teamspeak_group_id' => $id]]);
                        }else{
                            echo "[INFO] Rename custom group & added to group (No create)", PHP_EOL;
                            $ts3->execute("servergrouprename", array("sgid" => $data['teamspeak_group_id'], "name" => $data['name']));
                            $ts3->serverGetSelected()->serverGroupClientAdd($data['teamspeak_group_id'], $ts3->clientGetByUid($unique_id)["client_database_id"]);
                        }
                    }
                }
            }
        }
    }
}





?>