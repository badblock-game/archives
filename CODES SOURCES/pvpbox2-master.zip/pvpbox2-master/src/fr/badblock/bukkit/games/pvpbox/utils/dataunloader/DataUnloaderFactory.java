package fr.badblock.bukkit.games.pvpbox.utils.dataunloader;

import fr.badblock.bukkit.games.pvpbox.players.BoxPlayer;
import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class DataUnloaderFactory
{

	private BoxPlayer boxPlayer;
	
}
