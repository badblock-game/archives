package fr.badblock.bukkit.games.pvpbox.inventories.objects;

public enum CustomItemAction
{
	
	OPEN_INV,
	CLOSE_INV,
	TELEPORT,
	SELECT_KIT,
	NOTHING;
	
}
