package fr.badblock.bukkit.games.pvpbox.commands.teamcommands;

public class TeamInviteCommand 
{

}
