package fr.badblock.bukkit.games.pvpbox.utils.dataloader;

import fr.badblock.bukkit.games.pvpbox.players.BoxPlayer;
import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class DataLoaderFactory
{

	private BoxPlayer boxPlayer;
	
}
