package fr.badblock.factionutils;

import java.io.File;

import org.bukkit.plugin.java.JavaPlugin;

import fr.badblock.factionutils.commands.SpawnerCommand;
import fr.badblock.factionutils.listeners.BlockPlaceListener;
import fr.badblock.factionutils.listeners.PlayerAndEntityDeathListener;
import fr.badblock.factionutils.listeners.PlayerJoinQuitListener;
import fr.badblock.factionutils.threads.ClearLagThread;
import fr.badblock.factionutils.utils.JsonUtils;
import lombok.Getter;

public class FactionUtils extends JavaPlugin {
	private static final long TICKS_PER_MINUTE = 20L * 60;
	
	@Getter private static FactionUtils instance;
	public static Configuration config;

	@Override
	public void onEnable(){
		instance = this;
		
		getDataFolder().mkdirs();
		
		File configFile = new File(getDataFolder(), "config.json");
		
		config = JsonUtils.load(configFile, Configuration.class);
		JsonUtils.save(configFile, config, true);
		
		new BlockPlaceListener();
		new PlayerAndEntityDeathListener();
		new PlayerJoinQuitListener();
		
		new SpawnerCommand();
		
		new ClearLagThread(config.minutesBetweenClearlag).runTaskTimer(this, TICKS_PER_MINUTE, TICKS_PER_MINUTE);
	}
}
