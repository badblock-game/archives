package fr.badblock.factionutils;

public class Configuration {
	public int entitySkullDropChance  = 100;
	public int playerSkullDropChance  = 50;
	
	public int minutesBetweenClearlag = 10;
	
	public String[] killInOneMinute   = new String[]{ "&7Toutes les entités (monstres, items) seront supprimées dans une minute !", "Et ouais ... #RT" };
	public String[] killAll			  = new String[]{ "&7@0 monstres, @1 animaux et @2 items ont été REMOOOOVE *w*" };
	
	public String[] worlds			  = new String[]{ "world" };
	public String[] blacklisted		  = new String[]{};
}
