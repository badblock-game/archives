package fr.badblock.factionutils.listeners;

import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.inventory.ItemStack;

import fr.badblock.factionutils.utils.ItemStackExtras;
import fr.badblock.factionutils.utils.SpawnerEntity;
import fr.badblock.factionutils.utils.SpawnerUtils;

public class BlockPlaceListener extends _FactionUtilsListener {
	@EventHandler
	public void onBlockPlace(BlockPlaceEvent e){
		ItemStack used = e.getPlayer().getItemInHand();
		
		if(used == null || used.getType() != Material.MOB_SPAWNER || used.getItemMeta() == null || used.getItemMeta().getDisplayName() == null)
			return;
		
		int encode = ItemStackExtras.decodeId(used.getItemMeta().getDisplayName());
		
		if(encode == -1) return;
		
		SpawnerEntity spawnerEntity = SpawnerEntity.getByOrdinal(encode);
		
		if(spawnerEntity == null)
			return;
		
		SpawnerUtils.setSpawnerType(e.getBlock(), spawnerEntity);
	}
}
