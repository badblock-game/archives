package fr.badblock.factionutils.listeners;

import org.bukkit.Bukkit;
import org.bukkit.event.Listener;

import fr.badblock.factionutils.FactionUtils;

public class _FactionUtilsListener implements Listener {
	public _FactionUtilsListener(){
		Bukkit.getPluginManager().registerEvents(this, FactionUtils.getInstance());
	}
}
