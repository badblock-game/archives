package fr.badblock.factionutils.listeners;

import java.util.List;
import java.util.Random;

import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import fr.badblock.factionutils.FactionUtils;
import fr.badblock.factionutils.utils.SpawnerEntity;
import net.md_5.bungee.api.ChatColor;

public class PlayerAndEntityDeathListener extends _FactionUtilsListener {
	private Random random = new Random();
	
	@EventHandler
	public void onPlayerDeath(PlayerDeathEvent e){
		spawnSkull(FactionUtils.config.playerSkullDropChance, e.getEntity().getName(), ChatColor.GREEN + e.getEntity().getName(), e.getDrops());
	}
	
	@EventHandler
	public void onEntityDeath(EntityDeathEvent e){
		SpawnerEntity spawnerEntity = SpawnerEntity.getByEntityType(e.getEntityType());
		
		if(spawnerEntity != null){
			spawnSkull(FactionUtils.config.playerSkullDropChance, spawnerEntity.getHeadName(), ChatColor.GREEN + spawnerEntity.getName(), e.getDrops());
		}
	}
	
	private void spawnSkull(int probability, String playerName, String displayName, List<ItemStack> drops){
		if(probability > 100 || probability == 0) {
			new IllegalArgumentException("Invalid probability (" + probability + ") : must be between 1 and 100");
			return;
		}
		
		if(random.nextInt(100) + 1 > probability){ // do not spawn
			return;
		}
		
		ItemStack skull = new ItemStack(Material.SKULL_ITEM, 1, (short) 3);
		SkullMeta sm = (SkullMeta) skull.getItemMeta();
		
		sm.setOwner(playerName);
		sm.setDisplayName(displayName);
		
		skull.setItemMeta(sm);
		drops.add(skull);
	}
}
