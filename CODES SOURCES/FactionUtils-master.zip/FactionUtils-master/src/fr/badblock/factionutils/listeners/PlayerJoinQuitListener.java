package fr.badblock.factionutils.listeners;

import org.bukkit.ChatColor;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class PlayerJoinQuitListener extends _FactionUtilsListener {
	@EventHandler
	public void onPlayerJoin(PlayerJoinEvent e){
		e.setJoinMessage(ChatColor.translateAlternateColorCodes('&', "&7[&c+&7] &e" + e.getPlayer().getName()));
	}
	
	@EventHandler
	public void onPlayerQuit(PlayerQuitEvent e){
		e.setQuitMessage(null);
	}
}
