package fr.badblock.factionutils.commands;

import java.util.Arrays;
import java.util.HashSet;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import fr.badblock.factionutils.utils.ItemStackExtras;
import fr.badblock.factionutils.utils.SpawnerEntity;
import fr.badblock.factionutils.utils.SpawnerUtils;
import net.md_5.bungee.api.ChatColor;

public class SpawnerCommand extends AbstractCommand {
	private static final String mobs = StringUtils.join(Arrays.stream(SpawnerEntity.values()).map(spawner -> {
		return spawner.getName();
	}).collect(Collectors.toSet()), ", ");
	
	
	public SpawnerCommand() {
		super("spawner", new String[]{
				"&c> &7/spawner &bgive &7<mob> (<player>) : donne un spawner",
				"&c> &7/spawner &bset &7<mob> : change le type de spawner",
				"&c> &7/spawner &blist &7 : liste les mobs disponibles"
		}, "spawner.command");
	}


	@Override
	public boolean executeCommand(CommandSender sender, String[] args) {
		if(args.length == 0)
			return false;
		
		switch(args[0].toLowerCase()){
			case "give":
				if(args.length == 1)
					return false;
				
				SpawnerEntity entity = SpawnerEntity.getByName(args[1]);
				
				if(entity == null){
					sender.sendMessage(ChatColor.RED + "Mob inconnu ! Utilisez, afin de les connaître, /spawner list.");
				} else {
					Player player = null;
					
					if(sender instanceof Player){
						player = (Player) sender;
					}
					
					if(args.length > 2){
						player = Bukkit.getPlayer(args[2]);
					}
					
					if(player == null){
						sender.sendMessage(ChatColor.RED + "Aucun joueur assigné à la requête !");
						return false;
					}
					
					ItemStack item = new ItemStack(Material.MOB_SPAWNER);
					ItemMeta  meta = item.getItemMeta();
					
					String dname = ChatColor.GREEN + entity.getName() + " spawner";
					
					meta.setDisplayName( ItemStackExtras.encodeInName(dname, entity.ordinal()) );
					item.setItemMeta(meta);
					
					player.getInventory().addItem(item);
					sender.sendMessage(ChatColor.GRAY + "Spawner donné !");
					
					if(!sender.equals(player)){
						sender.sendMessage(ChatColor.GRAY + "Vous avez reçu un spawner !");
					}
				}
			break;
			
			case "set":
				if(args.length == 1)
					return false;
				
				if(sender instanceof Player == false){
					sender.sendMessage(ChatColor.RED + "Vous devez être un joueur pour exécuter cette commande !");
					return true;
				}
				
				entity = SpawnerEntity.getByName(args[1]);
				
				if(entity == null){
					sender.sendMessage(ChatColor.RED + "Mob inconnu ! Utilisez, afin de les connaître, /spawner list.");
				} else {
					Block spawner = getLookedSpawner((Player) sender);
					
					if(spawner == null){
						sender.sendMessage(ChatColor.RED + "Vous devez regarder un spawner !");
					} else {
						SpawnerUtils.setSpawnerType(spawner, entity);
						sender.sendMessage(ChatColor.GRAY + "Spawner modifié !");
					}
				}
			break;
			
			case "list":
				sender.sendMessage(ChatColor.GRAY + "Les mobs disponibles pour les spawners sont : " + ChatColor.AQUA + mobs);
			break;
			default: return false;
		}
		
		return true;
	}

	private Block getLookedSpawner(Player p){
		Block blockTarget = null;
		
		for(Block b : p.getLineOfSight((HashSet<Material>) null, 200)) {
			if(!b.getType().equals(Material.AIR)) { blockTarget = b; break; }
		}
		
		if(blockTarget == null || blockTarget.getType() != Material.MOB_SPAWNER){
			return null;
		}

		return blockTarget;
	}
}
