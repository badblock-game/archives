package fr.badblock.factionutils.commands;

import java.util.Arrays;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandMap;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import fr.badblock.factionutils.utils.Reflector;
import lombok.Getter;

/**
 * Classe abstraite permettantt de simplifier l'utilisation des commandes. Par exemple, elles ne devront pas �tre situ�es
 * dans le plugin.yml
 * @author LeLanN
 */
@Getter public abstract class AbstractCommand implements CommandExecutor {
	private String   		   command;
	private String[]		   usage;
	private String   		   permission;
	private String[] 		   aliases;

	private boolean  		   allowConsole = true;

	/**
	 * Cr�e une nouvelle commande
	 * @param command Le nom de la commande
	 * @param usage Le message d'erreur si la commande est mal utilis�e
	 * @param permission La permission n�cessaire (pas de permission est cha�ne vide)
	 * @param aliases Les aliases �ventuels de la commande
	 */
	public AbstractCommand(String command, String[] usage, String permission, String... aliases){
		this.command 	= command;
		this.usage      = usage;
		this.permission = permission;
		this.aliases    = aliases;

		ReflectCommand result = new ReflectCommand(command);

		result.setAliases(Arrays.asList(aliases));
		result.setExecutor(this);
		
		getCommandMap().register("", result);
	}

	public void allowConsole(boolean console){
		this.allowConsole = console;
	}
	
	@Override
	public final boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
		if(permission != null && !permission.isEmpty() && !sender.hasPermission(permission)){
			
		} else if(!allowConsole && !(sender instanceof Player)){
			sender.sendMessage(ChatColor.RED + "This command is only for players.");
		} else if(!executeCommand(sender, args) && usage != null){
			for(String usageLine : usage){
				sender.sendMessage( ChatColor.translateAlternateColorCodes('&', usageLine) );
			}
		}
		
		return true;
	}
	
	public abstract boolean executeCommand(CommandSender sender, String[] args);

	private final CommandMap getCommandMap() {
		try {
			return (CommandMap) new Reflector(Bukkit.getServer()).getFieldValue("commandMap");
		} catch (Exception e) { 
			e.printStackTrace(); 
			return null;
		}
	}

	private final class ReflectCommand extends Command {
		private AbstractCommand exe = null;

		protected ReflectCommand(String command) { 
			super(command); 
		}

		public void setExecutor(AbstractCommand exe) { 
			this.exe = exe; 
		}

		@Override public boolean execute(CommandSender sender, String commandLabel, String[] args) {
			if (exe != null) { return exe.onCommand(sender, this, commandLabel, args); }
			return false;
		}
	}
}