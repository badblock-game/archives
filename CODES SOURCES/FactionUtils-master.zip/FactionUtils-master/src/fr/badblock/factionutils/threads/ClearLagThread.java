package fr.badblock.factionutils.threads;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.scheduler.BukkitRunnable;

import fr.badblock.factionutils.FactionUtils;
import fr.badblock.factionutils.utils.KillallUtils;
import fr.badblock.factionutils.utils.KillallUtils.Type;

public class ClearLagThread extends BukkitRunnable {
	private final int minutes;
	private 	  int current;
	
	public ClearLagThread(int minutes){
		this.minutes = minutes;
		this.current = minutes;
	}

	@Override
	public void run() {
		current--;
		
		if(current == 1){
			broadcastKillInOneMinute();
		} else if(current == 0){
			kill();
		}
	}
	
	public void broadcastKillInOneMinute(){
		for(String message : FactionUtils.config.killInOneMinute){
			Bukkit.broadcastMessage( ChatColor.translateAlternateColorCodes('&', message) );
		}
	}
	
	public void kill(){
		this.current = minutes;
		
		int monsters = KillallUtils.doJob(Type.MONSTERS, null);
		int peaceful = KillallUtils.doJob(Type.PEACEFUL, null);
		int items	 = KillallUtils.doJob(Type.ITEMS   , null);
		
		for(String message : FactionUtils.config.killAll){
			message = message.replace("@0", Integer.toString(monsters + peaceful));
			message = message.replace("@1", Integer.toString(items));
			message = message.replace("@2", Integer.toString(minutes));
			
			Bukkit.broadcastMessage( ChatColor.translateAlternateColorCodes('&', message) );
		}
	}
}
