package fr.badblock.factionutils.utils;

import org.bukkit.entity.EntityType;

public enum SpawnerEntity {
	BLAZE(),
	BAT(),
	CAVE_SPIDER(),
	CHICKEN(),
	COW(),
	CREEPER(),
	ENDER_DRAGON(),
	ENDERMAN(),
	ENDERMITE(),
	GHAST(),
	GIANT(),
	GUARDIAN(),
	HORSE(),
	MAGMA_CUBE(),
	MUSHROOM_COW(),
	OCELOT(),
	PIG(),
	PIG_ZOMBIE(),
	RABBIT(),
	SHEEP(),
	SILVERFISH(),
	SKELETON(),
	SLIME(),
	SNOWMAN(),
	SPIDER(),
	SQUID(),
	VILLAGER(),
	WITCH(),
	WITHER(),
	WOLF(),
	ZOMBIE();

	static {
		
	}
	
	public String getName(){
		String[] parts = name().split("_");
		
		String result = "";
		
		for(String part : parts)
			result += StringUtils.getUpperFirstLetter(part);
		
		return result;
	}
	
	public String getHeadName(){
		return "MFH_" + getName();
	}
	
	public static SpawnerEntity getByOrdinal(int ord){
		for(SpawnerEntity entity : values())
			if(ord == entity.ordinal())
				return entity;
		
		return null;
	}
	
	public static SpawnerEntity getByName(String name){
		for(SpawnerEntity entity : values())
			if(name.equalsIgnoreCase( entity.name() ) || name.equalsIgnoreCase( entity.getName() ))
				return entity;
		
		return null;
	}
	
	public static SpawnerEntity getByEntityType(EntityType type){
		for(SpawnerEntity entity : values())
			if(type.name().equalsIgnoreCase( entity.name() ))
				return entity;
		
		return null;
	}
}
