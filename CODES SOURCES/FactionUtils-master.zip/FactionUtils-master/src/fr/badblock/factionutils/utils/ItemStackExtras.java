package fr.badblock.factionutils.utils;

import org.bukkit.ChatColor;

public class ItemStackExtras {
	public static final char colorChar = ChatColor.COLOR_CHAR;
	
	public static String encodeInName(String itemName, int itemID) {
		String id = Integer.toString(itemID);
		StringBuilder builder = new StringBuilder();
		for (int i = 0; i < id.length(); i++) {
			builder.append(colorChar).append(id.charAt(i));
		}
		String result = builder.toString() + colorChar + "S" + itemName;
		return result;
	}

	public static int decodeId(String itemName) {
		int intId = -1;
		
		if(itemName.contains(colorChar + "S")) {
			String[] stringID = itemName.split(colorChar + "S");
			if (stringID.length > 0) {
				itemName = stringID[0].replaceAll(colorChar + "", "");
				try {
					intId = Integer.parseInt(itemName);
				} catch (NumberFormatException unused){}
			}
		}
		
		return intId;
	}
}
