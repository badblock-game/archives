package fr.badblock.factionutils.utils;

import java.util.Arrays;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.entity.EntityType;

import fr.badblock.factionutils.FactionUtils;

public class KillallUtils {
	public static int doJob(Type t, CreatureType param){
		Filter filter;
		
		switch(t){
			case ALL:
				filter = new Filter(type -> {
					return type != EntityType.PLAYER;
				});			
			break;
			case CREATURE:
				if(param == null)
					return 0;
				
				filter = new Filter(type -> {
					CreatureType ctype = CreatureType.getByBukkit(type);
					
					return ctype == param;
				});
			break;
			case MONSTERS:
				filter = new Filter(type -> {
					CreatureType ctype = CreatureType.getByBukkit(type);

					return ctype != null && ctype.isHostile();
				});
			break;
			case PEACEFUL:
				filter = new Filter(type -> {
					CreatureType ctype = CreatureType.getByBukkit(type);

					return ctype != null && ctype.isFriendly();
				});
			break;
			case ITEMS:
				filter = new Filter(type -> {
					return type == EntityType.DROPPED_ITEM;
				});
			break;
			default:
				return 0;
		}
		
		return remove(filter);
	}

	private static int remove(Filter filter){
		Count count = new Count();
		
		Set<World> 		  worlds 	  = Arrays.stream(FactionUtils.config.worlds).map(name -> Bukkit.getWorld(name)).collect(Collectors.toSet());
		Set<CreatureType> blacklisted = Arrays.stream(FactionUtils.config.blacklisted).map(name -> CreatureType.matchCreature(name)).collect(Collectors.toSet());
		
		
		worlds.forEach(world -> {

			world.getEntities().forEach(entity -> {

				if(filter.test(entity.getType())){
					CreatureType type = CreatureType.getByBukkit(entity.getType());
					
					if(type == null || !blacklisted.contains(type)){
						count.inc();
						entity.remove();
					}
				}

			});

		});
		
		return count.count;
	}
	
	public enum Type {
		ALL,
		MONSTERS,
		PEACEFUL,
		ITEMS,
		CREATURE;
	}

	private static class Count {
		int count = 0;

		public void inc(){
			count++;
		}
	}

	private static class Filter {
		Predicate<EntityType> test;

		public Filter(Predicate<EntityType> test){
			this.test = test;
		}

		public boolean test(EntityType type){
			return test.test(type);
		}
	}
}