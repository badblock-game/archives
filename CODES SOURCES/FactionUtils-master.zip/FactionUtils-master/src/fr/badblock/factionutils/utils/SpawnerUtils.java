package fr.badblock.factionutils.utils;

import org.bukkit.block.Block;
import org.bukkit.block.CreatureSpawner;
import org.bukkit.entity.EntityType;

public class SpawnerUtils {
	public static void setSpawnerType(Block block, EntityType entity){
		if(block.getState() instanceof CreatureSpawner){
			CreatureSpawner spawner = (CreatureSpawner) block.getState();
			
			spawner.setSpawnedType(entity);
		}
	}
	
	public static void setSpawnerType(Block block, SpawnerEntity entity){
		setSpawnerType(block, EntityType.valueOf(entity.name()));
	}
}
