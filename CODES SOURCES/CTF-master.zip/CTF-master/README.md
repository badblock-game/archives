Do you read me ?
I read you, yes.