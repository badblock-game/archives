package fr.badblock.bukkit.games.cts.commands;

import org.bukkit.command.CommandSender;

import fr.badblock.bukkit.games.cts.CTFPlugin;
import fr.badblock.bukkit.games.cts.runnable.StartRunnable;
import fr.badblock.gameapi.GameAPI;
import fr.badblock.gameapi.command.AbstractCommand;
import fr.badblock.gameapi.players.BadblockPlayer;
import fr.badblock.gameapi.players.BadblockTeam;
import fr.badblock.gameapi.utils.BukkitUtils;
import fr.badblock.gameapi.utils.i18n.TranslatableString;

public class GameCommand extends AbstractCommand {
	public GameCommand() {
		super("game", new TranslatableString("commands.grush.usage"), "animation.gamecommand");
		allowConsole(false);
	}

	@Override
	public boolean executeCommand(CommandSender sender, String[] args) {

		BadblockPlayer player = (BadblockPlayer) sender;
		CTFPlugin plug = CTFPlugin.getInstance();
		if(args.length == 0){
			new TranslatableString("commands.grush.usage").send(sender);
			return true;
		}

		switch(args[0].toLowerCase()){
		case "start":
			String msg = "commands.grush.start";

			if(!StartRunnable.started()){
				StartRunnable.startGame();
			} else msg += "-fail";

			player.sendTranslatedMessage(msg);
			break;
		case "stop":
			msg = "commands.grush.stop";

			if(StartRunnable.started()){
				StartRunnable.stopGame();
			} else msg += "-fail";

			player.sendTranslatedMessage(msg);
			break;
		case "playersperteam":
			if(args.length != 2)
				return false;

			int perTeam = 4;

			try {
				perTeam = Integer.parseInt(args[1]);
			} catch(Exception e){
				return false;
			}

			for(BadblockTeam team : GameAPI.getAPI().getTeams())
				team.setMaxPlayers(perTeam);

			plug.getConfiguration().maxPlayersInTeam = perTeam;
			plug.setMaxPlayers(GameAPI.getAPI().getTeams().size() * perTeam);
			plug.setMinPlayers((GameAPI.getAPI().getTeams().size() * perTeam) / 2);
			try {
				BukkitUtils.setMaxPlayers(GameAPI.getAPI().getTeams().size() * perTeam);
			} catch (Exception e) {
				e.printStackTrace();
			}
			player.sendTranslatedMessage("commands.grush.modifycount");
			break;
		default: return false;
		}

		return true;
	}

}
