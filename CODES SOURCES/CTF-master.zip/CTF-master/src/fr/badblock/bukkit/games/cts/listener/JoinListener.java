package fr.badblock.bukkit.games.cts.listener;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

import fr.badblock.bukkit.games.cts.CTFPlugin;
import fr.badblock.bukkit.games.cts.CtfScoreboard;
import fr.badblock.bukkit.games.cts.runnable.BossBarRunnable;
import fr.badblock.bukkit.games.cts.runnable.GameRunnable;
import fr.badblock.bukkit.games.cts.runnable.PreStartRunnable;
import fr.badblock.bukkit.games.cts.runnable.StartRunnable;
import fr.badblock.gameapi.BadListener;
import fr.badblock.gameapi.GameAPI;
import fr.badblock.gameapi.events.PartyJoinEvent;
import fr.badblock.gameapi.events.PlayerGameInitEvent;
import fr.badblock.gameapi.events.api.SpectatorJoinEvent;
import fr.badblock.gameapi.game.GameState;
import fr.badblock.gameapi.game.rankeds.RankedCalc;
import fr.badblock.gameapi.game.rankeds.RankedManager;
import fr.badblock.gameapi.players.BadblockPlayer;
import fr.badblock.gameapi.players.BadblockPlayer.BadblockMode;
import fr.badblock.gameapi.utils.i18n.TranslatableString;
import fr.badblock.gameapi.utils.i18n.messages.GameMessages;

public class JoinListener extends BadListener{

	@EventHandler
	public void onSpectatorJoin(SpectatorJoinEvent e){
		e.getPlayer().teleport(CTFPlugin.getInstance().getMapConfiguration().getSpawnLocation());
	}

	@EventHandler
	public void onJoin(PlayerJoinEvent e){
		e.setJoinMessage(null);

		if(inGame()){
			return;
		}

		BadblockPlayer player = (BadblockPlayer) e.getPlayer();

		if (!player.getBadblockMode().equals(BadblockMode.SPECTATOR)) {
			new BossBarRunnable(player.getUniqueId()).runTaskTimer(GameAPI.getAPI(), 0, 20L);

			player.setGameMode(GameMode.SURVIVAL);
			player.sendTranslatedTitle("cts.title.join");
			if(player.isInsideVehicle()){
				player.eject();
			}
			player.teleport(CTFPlugin.getInstance().getConfiguration().spawn.getHandle());
			player.sendTimings(0, 80, 20);
			player.sendTranslatedTabHeader(new TranslatableString("cts.tab.header"), new TranslatableString("cts.tab.footer"));

			GameMessages.joinMessage(GameAPI.getGameName(), player.getTabGroupPrefix().getAsLine(player) + player.getName(), Bukkit.getOnlinePlayers().size(), CTFPlugin.getInstance().getMaxPlayers()).broadcast();
		}
		PreStartRunnable.doJob();
		StartRunnable.joinNotify(Bukkit.getOnlinePlayers().size(), CTFPlugin.getInstance().getMinPlayers());

	}

	@EventHandler
	public void onPlayerGameInit(PlayerGameInitEvent event) {
		GameRunnable.handle(event.getPlayer());
	}

	@EventHandler
	public void onQuit(PlayerQuitEvent e){
		e.setQuitMessage(null);
		if (!inGame())
		{
			return;
		}
		BadblockPlayer player = (BadblockPlayer) e.getPlayer();
		// Work with rankeds
		String rankedGameName = RankedManager.instance.getCurrentRankedGameName();
		player.getPlayerData().incrementTempRankedData(rankedGameName, CtfScoreboard.LOOSES, 1);
		RankedManager.instance.calcPoints(rankedGameName, player, new RankedCalc()
		{

			@Override
			public long done() {
				double kills = RankedManager.instance.getData(rankedGameName, player, CtfScoreboard.KILLS);
				double deaths = RankedManager.instance.getData(rankedGameName, player, CtfScoreboard.DEATHS);
				double wins = RankedManager.instance.getData(rankedGameName, player, CtfScoreboard.WINS);
				double looses = RankedManager.instance.getData(rankedGameName, player, CtfScoreboard.LOOSES);
				double capturedFlags = RankedManager.instance.getData(rankedGameName, player, CtfScoreboard.CAPTUREDFLAGS);
				double total = 
						( (kills / 0.25D) + (wins * 4) + 
								( (kills * (capturedFlags * 4)) + (capturedFlags * 6) * (kills / (deaths > 0 ? deaths : 1) ) ) )
						/ (1 + looses);
				return (long) total;
			}

		});
		RankedManager.instance.fill(rankedGameName);
	}

	@EventHandler
	public void onPartyJoin(PartyJoinEvent event) {
		if(inGame()) return;
		event.balancePlayersInTeam();
	}

	public boolean inGame(){
		return GameAPI.getAPI().getGameServer().getGameState() == GameState.RUNNING;
	}

	@EventHandler
	public void craftItem(PrepareItemCraftEvent e) {
		e.getInventory().setResult(new ItemStack(Material.AIR));
	}

}
