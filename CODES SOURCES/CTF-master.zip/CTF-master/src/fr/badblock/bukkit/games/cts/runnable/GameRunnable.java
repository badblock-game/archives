package fr.badblock.bukkit.games.cts.runnable;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;

import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World.Environment;
import org.bukkit.block.Block;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import fr.badblock.bukkit.games.cts.CTFAchievementList;
import fr.badblock.bukkit.games.cts.CTFPlugin;
import fr.badblock.bukkit.games.cts.CtfData;
import fr.badblock.bukkit.games.cts.CtfScoreboard;
import fr.badblock.bukkit.games.cts.CtfTeamData;
import fr.badblock.bukkit.games.cts.configuration.CtfMapConfiguration;
import fr.badblock.bukkit.games.cts.results.CtfResults;
import fr.badblock.gameapi.GameAPI;
import fr.badblock.gameapi.achievements.PlayerAchievement;
import fr.badblock.gameapi.game.GameState;
import fr.badblock.gameapi.game.rankeds.RankedCalc;
import fr.badblock.gameapi.game.rankeds.RankedManager;
import fr.badblock.gameapi.players.BadblockPlayer;
import fr.badblock.gameapi.players.BadblockPlayer.BadblockMode;
import fr.badblock.gameapi.players.BadblockTeam;
import fr.badblock.gameapi.players.data.InGameKitData;
import fr.badblock.gameapi.players.data.PlayerAchievementState;
import fr.badblock.gameapi.players.kits.PlayerKit;
import fr.badblock.gameapi.utils.BukkitUtils;
import fr.badblock.gameapi.utils.general.TimeUnit;
import fr.badblock.gameapi.utils.i18n.TranslatableString;
import lombok.Getter;

public class GameRunnable extends BukkitRunnable {
	public static GameRunnable gameTask;
	public boolean forceEnd = false;
	public int    time 	= 0;
	@Getter private static BadblockTeam winner = null;


	public GameRunnable(CtfMapConfiguration config){
		gameTask = this;
		GameAPI.getAPI().getGameServer().setGameState(GameState.RUNNING);
		GameAPI.getAPI().getGameServer().saveTeamsAndPlayersForResult();

		List<Chunk> unloaded = new ArrayList<Chunk>();
		for(Block b : config.getMapBounds().getBlocks()){
			if(!unloaded.contains(b.getChunk()) && !b.getChunk().isLoaded()){
				unloaded.add(b.getChunk());
			}
		}

		for(Chunk c : unloaded){
			c.load();
		}



		Bukkit.getWorlds().forEach(world -> {
			world.setTime(config.getTime());
			world.getEntities().forEach(entity -> {
				if(entity.getType() != EntityType.PLAYER)
					entity.remove();
			});
		});

		for(BadblockTeam team : GameAPI.getAPI().getTeams()){

			Location location = team.teamData(CtfTeamData.class).getSheepLocation();
			location.getChunk().load();

			team.teamData(CtfTeamData.class).setSheep(GameAPI.getAPI().spawnCustomEntity(location, EntityType.SHEEP), team.getDyeColor());

			for(BadblockPlayer p : team.getOnlinePlayers()){
				handle(p);
			}
		}

		/*new BukkitRunnable(){
			@Override
			public void run() {
				for(BadblockTeam team : GameAPI.getAPI().getTeams()){
					if(team.teamData(CtfTeamData.class).getSheep() == null || team.teamData(CtfTeamData.class).getSheep().getBukkit() == null || team.teamData(CtfTeamData.class).getSheep().getBukkit().isDead()){
						team.teamData(CtfTeamData.class).setSheep(
								GameAPI.getAPI().spawnCustomEntity(team.teamData(CtfTeamData.class).getSheepLocation(), EntityType.SHEEP),
								team.getDyeColor()
								);
					}else if(team.teamData(CtfTeamData.class).hasFlag() && team.teamData(CtfTeamData.class).getSheep().getBukkit().getLocation().getBlock() != team.teamData(CtfTeamData.class).getSheepLocation().getBlock()){
						team.teamData(CtfTeamData.class).getSheep().getBukkit().remove();
						team.teamData(CtfTeamData.class).setSheep(
								GameAPI.getAPI().spawnCustomEntity(team.teamData(CtfTeamData.class).getSheepLocation(), EntityType.SHEEP),
								team.getDyeColor()
								);
					}
				}


			}

		}.runTaskTimer(GameAPI.getAPI(), 0L, 100L);*/


		new BukkitRunnable(){
			@Override
			public void run() {
				for(BadblockTeam team : GameAPI.getAPI().getTeams()){
					for(BadblockPlayer bp : team.getOnlinePlayers()){
						if(bp.getInventory().contains(Material.COMPASS)){
							bp.setCompassTarget(team.teamData(CtfTeamData.class).getSheep().getBukkit().getLocation());
						}
					}
				}
			}
		}.runTaskTimerAsynchronously(GameAPI.getAPI(), 0L, 20L);

		GameAPI.getAPI().getJoinItems().doClearInventory(false);
		GameAPI.getAPI().getJoinItems().end();
		for(Player p : GameAPI.getAPI().getOnlinePlayers()){
			BadblockPlayer bp = (BadblockPlayer) p;
			if (bp.getCustomObjective() != null)
				bp.getCustomObjective().generate();
			if(bp == null || (bp.getTeam() == null && !bp.getBadblockMode().equals(BadblockMode.SPECTATOR) && !bp.getBadblockMode().equals(BadblockMode.RESPAWNING))){
				bp.setBadblockMode(BadblockMode.SPECTATOR);
			}
		}
	}

	public static void handle(BadblockPlayer player) {
		BadblockTeam team = player.getTeam();
		if (team == null) return;
		player.changePlayerDimension(get( CTFPlugin.getInstance().getMapConfiguration().getDimension() ));
		player.teleport(team.teamData(CtfTeamData.class).getRespawnLocation());

		boolean good = true;


		for(PlayerKit toUnlock : CTFPlugin.getInstance().getKits().values()){
			if(!toUnlock.isVIP()){
				if(player.getPlayerData().getUnlockedKitLevel(toUnlock) < 2){
					good = false; break;
				}
			}
		}

		if(good && !player.getPlayerData().getAchievementState(CTFAchievementList.CTS_ALLKITS).isSucceeds()){
			player.getPlayerData().getAchievementState(CTFAchievementList.CTS_ALLKITS).succeed();
			CTFAchievementList.CTS_ALLKITS.reward(player);
		}

		PlayerKit kit = player.inGameData(InGameKitData.class).getChoosedKit();


		if(kit != null){
			kit.giveKit(player);
		} else {
			CTFPlugin.getInstance().giveDefaultKit(player);
		}
	}

	@SuppressWarnings("deprecation")
	private static Environment get(int id){
		Environment env = Environment.getEnvironment(id);

		if(env == null)
			return Environment.NORMAL;
		return env;
	}

	@Override
	public void run() {
		GameAPI.setJoinable(time < 900);
		if(time == 2){
			for(Player player : Bukkit.getOnlinePlayers()){
				BadblockPlayer bp = (BadblockPlayer) player;
				if(bp == null || (bp.getTeam() == null && !bp.getBadblockMode().equals(BadblockMode.SPECTATOR) && !bp.getBadblockMode().equals(BadblockMode.RESPAWNING))){
					bp.setBadblockMode(BadblockMode.SPECTATOR);
				}else if(player == null || ((BadblockPlayer)player) == null){
					GameAPI.getAPI().getLogger().log(Level.WARNING, "Da Fuck, c est pas logique (TeamData2) " + player.getName());
					return; 
				}else if(((BadblockPlayer)player).getCustomObjective() == null){
					new CtfScoreboard(((BadblockPlayer)player)).generate();
				}else{
					((BadblockPlayer)player).getCustomObjective().generate();
				}
				if(!bp.getBadblockMode().equals(BadblockMode.SPECTATOR)){
					bp.pseudoJail(bp.getTeam().teamData(CtfTeamData.class).getRespawnLocation(), 300.0d);
				}

			}
		}

		int size = GameAPI.getAPI().getTeams().size();

		List<BadblockTeam> to = new ArrayList<>();

		for(BadblockTeam team : GameAPI.getAPI().getTeams()){
			if(team.getOnlinePlayers().size() == 0){
				GameAPI.getAPI().getGameServer().cancelReconnectionInvitations(team);
				to.add(team);

				new TranslatableString("cts.team-loose", team.getChatName()).broadcast();
			}else if(team.teamData(CtfTeamData.class).getNbrPlace() >= CTFPlugin.getInstance().getMaxPoints()){
				forceEnd = true;
				winner = team;
			}
		}

		to.forEach(GameAPI.getAPI()::unregisterTeam);

		if((size == 1 || forceEnd || time >= CTFPlugin.getInstance().getMaxTime())){
			if(winner == null){
				BadblockTeam o = null;
				for(BadblockTeam team : GameAPI.getAPI().getTeams()){
					if(team.getOnlinePlayers().size() > 0)
						if(o == null || (o != null && team.teamData(CtfTeamData.class).getNbrPlace() >= o.teamData(CtfTeamData.class).getNbrPlace())){
							o = team;
						}
				}
				winner = o;
				if (winner == null) winner = GameAPI.getAPI().getTeams().iterator().next();
			}
			cancel();


			GameAPI.getAPI().getGameServer().setGameState(GameState.FINISHED);

			Location winnerLocation = CTFPlugin.getInstance().getMapConfiguration().getSpawnLocation();
			Location looserLocation = winnerLocation.clone().add(0d, 7d, 0d);

			for(Player player : Bukkit.getOnlinePlayers()){
				BadblockPlayer bp = (BadblockPlayer) player;
				if(!bp.getBadblockMode().equals(BadblockMode.SPECTATOR)){

					bp.heal();
					bp.clearInventory();
					bp.setInvulnerable(true);

					double badcoins = bp.inGameData(CtfData.class).getScore() / 10;
					double xp	    = bp.inGameData(CtfData.class).getScore() / 5;

					if(bp.getTeam().equals(winner)){
						bp.teleport(winnerLocation);
						bp.setAllowFlight(true);
						bp.setFlying(true);

						bp.sendTranslatedTitle("cts.title-win", winner.getChatName());
						bp.getPlayerData().incrementStatistic("cts", CtfScoreboard.WINS);
						bp.getPlayerData().incrementTempRankedData(RankedManager.instance.getCurrentRankedGameName(), CtfScoreboard.WINS, 1);
						bp.getPlayerData().addRankedPoints(3);

						incrementAchievements(bp, CTFAchievementList.CTS_WIN_1, CTFAchievementList.CTS_WIN_2, CTFAchievementList.CTS_WIN_3, CTFAchievementList.CTS_WIN_4);

						if(bp.inGameData(CtfData.class).capturedFlags >= 2){
							incrementAchievements(bp, CTFAchievementList.CTS_WINNERSHEEP_1, CTFAchievementList.CTS_WINNERSHEEP_2, CTFAchievementList.CTS_WINNERSHEEP_3, CTFAchievementList.CTS_WINNERSHEEP_4);
						}
					} else {
						badcoins = ((double) badcoins) / 1.5d;

						if(player == null || bp == null){
							continue;
						}
						bp.jailPlayerAt(looserLocation);

						if(winner != null){
							bp.sendTranslatedTitle("cts.title-win", winner.getChatName());
						}


						if(bp.getBadblockMode() == BadblockMode.PLAYER){
							bp.getPlayerData().incrementStatistic("cts", CtfScoreboard.LOOSES);
							bp.getPlayerData().incrementTempRankedData(RankedManager.instance.getCurrentRankedGameName(), CtfScoreboard.LOOSES, 1);
							bp.getPlayerData().addRankedPoints(-2);
						}
					}

					if(badcoins > 20 * bp.getPlayerData().getBadcoinsMultiplier())
						badcoins = 20 * bp.getPlayerData().getBadcoinsMultiplier();
					if(xp > 50 * bp.getPlayerData().getXpMultiplier())
						xp = 50 * bp.getPlayerData().getXpMultiplier();

					int rbadcoins = badcoins < 2 ? 2 : (int) badcoins;
					int rxp		  = xp < 5 ? 5 : (int) xp;

					bp.getPlayerData().addBadcoins(rbadcoins, true);
					bp.getPlayerData().addXp(rxp, true);
					new BukkitRunnable(){

						@Override
						public void run(){
							if(bp.isOnline()){
								bp.sendTranslatedActionBar("cts.win", rbadcoins, rxp);
							}
						}

					}.runTaskTimer(GameAPI.getAPI(), 0, 30L);
				}else{
					bp.teleport( CTFPlugin.getInstance().getMapConfiguration().getSpawnLocation());
					bp.sendTranslatedTitle("cts.title-win", winner.getChatName());
				}

				bp.getCustomObjective().generate();

			}

			// Work with rankeds
			String rankedGameName = RankedManager.instance.getCurrentRankedGameName();
			for (BadblockPlayer player : BukkitUtils.getPlayers())
			{
				RankedManager.instance.calcPoints(rankedGameName, player, new RankedCalc()
				{

					@Override
					public long done() {
						double kills = RankedManager.instance.getData(rankedGameName, player, CtfScoreboard.KILLS);
						double deaths = RankedManager.instance.getData(rankedGameName, player, CtfScoreboard.DEATHS);
						double wins = RankedManager.instance.getData(rankedGameName, player, CtfScoreboard.WINS);
						double looses = RankedManager.instance.getData(rankedGameName, player, CtfScoreboard.LOOSES);
						double capturedFlags = RankedManager.instance.getData(rankedGameName, player, CtfScoreboard.CAPTUREDFLAGS);
						double total = 
								( (kills / 0.25D) + (wins * 4) + 
										( (kills * (capturedFlags * 4)) + (capturedFlags * 6) * (kills / (deaths > 0 ? deaths : 1) ) ) )
								/ (1 + looses);
						return (long) total;
					}

				});
			}
			RankedManager.instance.fill(rankedGameName);

			if(winner != null){
				new CtfResults(TimeUnit.SECOND.toShort(time, TimeUnit.SECOND, TimeUnit.HOUR), winner);
				new EndEffectRunnable(winnerLocation, winner).runTaskTimer(GameAPI.getAPI(), 0, 1L);
			}
			new KickRunnable().runTaskTimer(GameAPI.getAPI(), 0, 20L);

		} else if(size == 0){
			cancel();
			Bukkit.shutdown();
			return;
		}

		for(Player p : GameAPI.getAPI().getOnlinePlayers()){
			BadblockPlayer bp = (BadblockPlayer) p;
			if (bp.getCustomObjective() != null)
				bp.getCustomObjective().generate();
		}

		time++;

	}

	private static void incrementAchievements(BadblockPlayer player, PlayerAchievement... achievements){
		for(PlayerAchievement achievement : achievements){
			PlayerAchievementState state = player.getPlayerData().getAchievementState(achievement);
			state.progress(1.0d);
			state.trySucceed(player, achievement);
		}
		player.saveGameData();
	}
}
