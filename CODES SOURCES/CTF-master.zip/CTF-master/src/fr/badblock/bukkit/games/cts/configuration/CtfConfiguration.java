package fr.badblock.bukkit.games.cts.configuration;

import fr.badblock.gameapi.configuration.values.MapLocation;
import lombok.NoArgsConstructor;

@NoArgsConstructor
public class CtfConfiguration {
	public String 	   		   fallbackServer   = "lobby";
	public int    	   		   maxPlayersInTeam = 4;
	public int    	   		   maxPoints = 4;
	public int    	   		   minPlayers = 4;
	public MapLocation 		   spawn;
	public String              defaultKit = "defaultKit";
	public int                 maxTime = 1200;  
}
