package fr.badblock.bukkit.games.cts.listener;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;

import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.Sheep;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.scheduler.BukkitRunnable;

import fr.badblock.bukkit.games.cts.CTFAchievementList;
import fr.badblock.bukkit.games.cts.CTFPlugin;
import fr.badblock.bukkit.games.cts.CtfData;
import fr.badblock.bukkit.games.cts.CtfScoreboard;
import fr.badblock.bukkit.games.cts.CtfTeamData;
import fr.badblock.gameapi.BadListener;
import fr.badblock.gameapi.GameAPI;
import fr.badblock.gameapi.achievements.PlayerAchievement;
import fr.badblock.gameapi.events.fakedeaths.FakeDeathEvent;
import fr.badblock.gameapi.events.fakedeaths.FightingDeathEvent;
import fr.badblock.gameapi.events.fakedeaths.NormalDeathEvent;
import fr.badblock.gameapi.events.fakedeaths.PlayerFakeRespawnEvent;
import fr.badblock.gameapi.game.GameState;
import fr.badblock.gameapi.game.rankeds.RankedManager;
import fr.badblock.gameapi.players.BadblockPlayer;
import fr.badblock.gameapi.players.BadblockPlayer.BadblockMode;
import fr.badblock.gameapi.players.BadblockTeam;
import fr.badblock.gameapi.players.data.PlayerAchievementState;
import fr.badblock.gameapi.utils.i18n.TranslatableString;
import fr.badblock.gameapi.utils.i18n.messages.GameMessages;

public class DeathListener extends BadListener{
	@EventHandler
	public void onDeath(NormalDeathEvent e){
		e.getDrops().clear();
		death(e, e.getPlayer(), null, e.getLastDamageCause());
		e.setDeathMessage(GameMessages.deathEventMessage(e));
	}

	@EventHandler
	public void onDeath(FightingDeathEvent e){
		e.getDrops().clear();
		death(e, e.getPlayer(), e.getKiller(), e.getLastDamageCause());
		e.setDeathMessage(GameMessages.deathEventMessage(e));
		if(e.getKiller().getType() == EntityType.PLAYER){
			BadblockPlayer killer = (BadblockPlayer) e.getKiller();
			incrementAchievements(killer, CTFAchievementList.CTS_KILL_1, CTFAchievementList.CTS_KILL_2, CTFAchievementList.CTS_KILL_3, CTFAchievementList.CTS_KILL_4);
		}
	}

	private Map<String, Long> lastDeath = new HashMap<>();

	private void death(FakeDeathEvent e, BadblockPlayer player, Entity killer, DamageCause last){
		if (lastDeath.containsKey(player.getName())) {
			if (lastDeath.get(player.getName()) > System.currentTimeMillis()) {
				e.setCancelled(true);
				System.out.println("Death of " + player.getName() + ", not two death!");
				return;
			}
		}
		lastDeath.put(player.getName(), System.currentTimeMillis() + 1000L);
		e.getDrops().clear();
		if(player.getTeam() == null) return; //WTF
		if (player.getOpenInventory() != null && player.getOpenInventory().getCursor() != null)
			player.getOpenInventory().setCursor(null);

		if(player.isInsideVehicle()){
			Sheep vehicle = (Sheep) player.getVehicle();

			SheepListener.getHaveNoLeave().add(player.getName());
			new BukkitRunnable(){
				@Override
				public void run() {
					if(SheepListener.getHaveNoLeave().contains(player.getName())) SheepListener.getHaveNoLeave().remove(player.getName());
				}
			}.runTaskLater(GameAPI.getAPI(), 10L);
			vehicle.eject();
			for(BadblockTeam team : GameAPI.getAPI().getTeams()){
				if(team.getDyeColor().equals(vehicle.getColor())){
					team.teamData(CtfTeamData.class).resetSheep();
					new TranslatableString("cts.message.sheep-reset-by-death", ((BadblockPlayer)player).getTeam().getChatName(), player.getName(), team.getChatName()).broadcast();
				}
			}
		}

		player.getPlayerData().incrementStatistic("cts", CtfScoreboard.DEATHS);
		player.getPlayerData().incrementTempRankedData(RankedManager.instance.getCurrentRankedGameName(), CtfScoreboard.DEATHS, 1);
		player.inGameData(CtfData.class).deaths++;

		e.setTimeBeforeRespawn(5);


		e.setRespawnPlace(player.getTeam().teamData(CtfTeamData.class).getRespawnLocation());


		if(killer != null && killer instanceof Player){

			BadblockPlayer bKiller = (BadblockPlayer) killer;
			bKiller.getPlayerData().incrementStatistic("cts", CtfScoreboard.KILLS);
			bKiller.getPlayerData().incrementTempRankedData(RankedManager.instance.getCurrentRankedGameName(), CtfScoreboard.KILLS, 1);
			bKiller.inGameData(CtfData.class).kills++;

		}


		for(Player temp : Bukkit.getOnlinePlayers()){
			if(temp == null || ((BadblockPlayer)temp) == null){
				GameAPI.getAPI().getLogger().log(Level.WARNING, "Da Fuck, c est pas logique (Death) " + temp.getName());
				return; 
			}else if(((BadblockPlayer)temp).getCustomObjective() == null){
				new CtfScoreboard(((BadblockPlayer)temp)).generate();
			}else{
				((BadblockPlayer)temp).getCustomObjective().generate();
			}
		}
	}

	@EventHandler
	public void onRespawn(PlayerFakeRespawnEvent e){
		if (e.getPlayer().getOpenInventory() != null && e.getPlayer().getOpenInventory().getCursor() != null)
			e.getPlayer().getOpenInventory().setCursor(null);
		if(GameAPI.getAPI().getGameServer().getGameState().equals(GameState.FINISHED)){
			e.getPlayer().teleport(CTFPlugin.getInstance().getMapConfiguration().getSpawnLocation());
		}else{
			if(e.getPlayer().getTeam() == null){
				//DaFuck
				return;
			}else if(e.getPlayer().getBadblockMode().equals(BadblockMode.SPECTATOR)){
				e.getPlayer().teleport(e.getPlayer().getTeam().teamData(CtfTeamData.class).getRespawnLocation());
				return;
			}else{
				e.getPlayer().teleport(e.getPlayer().getTeam().teamData(CtfTeamData.class).getRespawnLocation());
			}
			CTFPlugin.getInstance().giveDefaultKit(e.getPlayer());
		}

	}

	private void incrementAchievements(BadblockPlayer player, PlayerAchievement... achievements){
		for(PlayerAchievement achievement : achievements){
			PlayerAchievementState state = player.getPlayerData().getAchievementState(achievement);
			state.progress(1.0d);
			state.trySucceed(player, achievement);
		}
		player.saveGameData();
	}
}
