package fr.badblock.bukkit.games.cts;

import fr.badblock.bukkit.games.cts.runnable.GameRunnable;
import fr.badblock.gameapi.GameAPI;
import fr.badblock.gameapi.players.BadblockPlayer;
import fr.badblock.gameapi.players.BadblockPlayer.BadblockMode;
import fr.badblock.gameapi.players.BadblockTeam;
import fr.badblock.gameapi.players.scoreboard.BadblockScoreboardGenerator;
import fr.badblock.gameapi.players.scoreboard.CustomObjective;

public class CtfScoreboard extends BadblockScoreboardGenerator {
	public static final String WINS 	  = "wins",
			                 LOOSES 	  = "looses",
			                   KILLS 	  = "kills",
			                   DEATHS 	  = "deaths",
		                    CAPTUREDFLAGS = "capturedFlags";

    private CustomObjective objective;
    private BadblockPlayer  player;
    
    public CtfScoreboard(BadblockPlayer player){
		this.objective = GameAPI.getAPI().buildCustomObjective("cts");
		this.player    = player;

		objective.showObjective(player);
		objective.setDisplayName("&b&o" + GameAPI.getGameName());
		objective.setGenerator(this);

		objective.generate();
		doBadblockFooter(objective);
	}

	@Override
	public void generate(){
		objective.changeLine(16, "&8&m----------------------");

		int i = 15;

		if(GameRunnable.gameTask != null){
			objective.changeLine(i--,  i18n("cts.scoreboard.time-desc"));
			objective.changeLine(i--,  i18n("cts.scoreboard.time", time(CTFPlugin.getInstance().getMaxTime() - GameRunnable.gameTask.time) ));
		}
		objective.changeLine(i--,  "");
		for(BadblockTeam team : GameAPI.getAPI().getTeams()){
			CtfTeamData data = team.teamData(CtfTeamData.class);

			if(!data.hasFlag())
				objective.changeLine(i, team.getChatName().getAsLine(player) + " > &c✘");
			else objective.changeLine(i, team.getChatName().getAsLine(player) + " > &a✔");
			i--;
		}
		objective.changeLine(i,  ""); i--;
		for(BadblockTeam team : GameAPI.getAPI().getTeams()){
			objective.changeLine(i,  i18n("cts.scoreboard.points", team.teamData(CtfTeamData.class).getNbrPlace(), team.getChatName())); i--;
		}

		if(player.getBadblockMode() != BadblockMode.SPECTATOR){
			objective.changeLine(i,  ""); i--;

			objective.changeLine(i,  i18n("cts.scoreboard.wins", stat(WINS))); i--;
			objective.changeLine(i,  i18n("cts.scoreboard.looses", stat(LOOSES))); i--;
			objective.changeLine(i,  i18n("cts.scoreboard.kills", stat(KILLS))); i--;
			objective.changeLine(i,  i18n("cts.scoreboard.deaths", stat(DEATHS))); i--;
			objective.changeLine(i,  i18n("cts.scoreboard.capturedflags", stat(CAPTUREDFLAGS))); i--;
		}

		for(int a=3;a<i;a++)
			objective.removeLine(a);

		objective.changeLine(2,  "&8&m----------------------");
	}
	
	private String time(int time){
		String res = "m";
		int    sec = time % 60;
		
		res = (time / 60) + res;
		if(sec < 10){
			res += "0";
		}
		
		return res + sec + "s";
	}
	
	private int stat(String name){
		return (int) player.getPlayerData().getStatistics("cts", name);
	}
	
	private String i18n(String key, Object... args){
		return GameAPI.i18n().get(player.getPlayerData().getLocale(), key, args)[0];
	}
	
}
