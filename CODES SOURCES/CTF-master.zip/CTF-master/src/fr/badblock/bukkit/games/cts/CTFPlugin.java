package fr.badblock.bukkit.games.cts;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;

import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.Recipe;

import fr.badblock.bukkit.games.cts.commands.CTFCommand;
import fr.badblock.bukkit.games.cts.commands.GameCommand;
import fr.badblock.bukkit.games.cts.configuration.CtfConfiguration;
import fr.badblock.bukkit.games.cts.configuration.CtfMapConfiguration;
import fr.badblock.bukkit.games.cts.listener.CtfMapProtector;
import fr.badblock.bukkit.games.cts.listener.DeathListener;
import fr.badblock.bukkit.games.cts.listener.DisconnectListener;
import fr.badblock.bukkit.games.cts.listener.JoinListener;
import fr.badblock.bukkit.games.cts.listener.MoveListener;
import fr.badblock.bukkit.games.cts.listener.SheepListener;
import fr.badblock.bukkit.games.cts.runnable.PreStartRunnable;
import fr.badblock.gameapi.BadblockPlugin;
import fr.badblock.gameapi.GameAPI;
import fr.badblock.gameapi.achievements.AchievementList;
import fr.badblock.gameapi.game.GameServer.WhileRunningConnectionTypes;
import fr.badblock.gameapi.game.rankeds.RankedManager;
import fr.badblock.gameapi.players.BadblockPlayer;
import fr.badblock.gameapi.players.kits.PlayerKit;
import fr.badblock.gameapi.run.BadblockGame;
import fr.badblock.gameapi.run.BadblockGameData;
import fr.badblock.gameapi.run.RunType;
import fr.badblock.gameapi.utils.BukkitUtils;
import fr.badblock.gameapi.utils.GameRules;
import fr.badblock.gameapi.utils.general.JsonUtils;
import lombok.Getter;
import lombok.Setter;

public class CTFPlugin extends BadblockPlugin{
	@Getter private static CTFPlugin instance;

	public static 	     File   MAP;

	private static final String CONFIG 		   		   = "config.json";
	private static final String TEAMS_CONFIG 		   = "teams.yml";
	private static final String TEAMS_CONFIG_INVENTORY = "teamsInventory.yml";
	private static final String VOTES_CONFIG 		   = "votes.json";
	private static final String KITS_CONFIG_INVENTORY  = "kitInventory.yml";
	private static final String MAPS_CONFIG_FOLDER     = "maps";

	@Getter@Setter
	private int 			    maxPlayers;
	@Getter@Setter
	private int                 minPlayers;
	@Getter@Setter
	private int					maxTime;
	@Getter
	private CtfConfiguration    configuration;
	@Getter@Setter
	private CtfMapConfiguration mapConfiguration;

	@Getter
	private Map<String, PlayerKit> kits;

	@Getter 
	private int maxPoints;


	@Override
	public void onEnable(RunType runType){
		AchievementList list = CTFAchievementList.instance;

		BadblockGame.CTS.setGameData(new BadblockGameData() {
			@Override
			public AchievementList getAchievements() {
				return list;
			}
		});

		instance = this;

		if(runType == RunType.LOBBY)
			return;

		try{
			if(!getDataFolder().exists()) getDataFolder().mkdir();
			/**
			 * Chargement de la configuration du jeu
			 */

			// Modification des GameRules
			GameRules.doDaylightCycle.setGameRule(false);
			GameRules.spectatorsGenerateChunks.setGameRule(false);
			GameRules.doFireTick.setGameRule(false);

			// Lecture de la configuration du jeu

			BadblockGame.CTS.use();

			GameAPI.setGameName("CTS");
			GameAPI.setInternalGameName("cts");
			GameAPI.getAPI().formatChat(true, true);

			File configFile    = new File(getDataFolder(), CONFIG);
			this.configuration = JsonUtils.load(configFile, CtfConfiguration.class);

			JsonUtils.save(configFile, configuration, true);

			File 			  teamsFile 	= new File(getDataFolder(), TEAMS_CONFIG);
			FileConfiguration teams 		= YamlConfiguration.loadConfiguration(teamsFile);

			getAPI().registerTeams(configuration.maxPlayersInTeam, teams);
			getAPI().setDefaultKitContentManager(false);

			maxPlayers = getAPI().getTeams().size() * configuration.maxPlayersInTeam;
			try {
				BukkitUtils.setMaxPlayers(maxPlayers);
			} catch (ReflectiveOperationException e) {
				e.printStackTrace();
			}
			minPlayers = configuration.minPlayers;
			maxTime = configuration.maxTime;
			kits	   = getAPI().loadKits(GameAPI.getInternalGameName());
			Iterator<Recipe> it = getServer().recipeIterator();
			while(it.hasNext()) {
				it.next();
				it.remove();
			}

			try { teams.save(teamsFile); } catch (IOException unused){}

			getAPI().getBadblockScoreboard().doBelowNameHealth();
			getAPI().getBadblockScoreboard().doTabListHealth();
			getAPI().getBadblockScoreboard().doTeamsPrefix();

			getAPI().getJoinItems().registerKitItem(0, kits, new File(getDataFolder(), KITS_CONFIG_INVENTORY));
			getAPI().getJoinItems().registerTeamItem(3, new File(getDataFolder(), TEAMS_CONFIG_INVENTORY));
			getAPI().getJoinItems().registerAchievementsItem(4, BadblockGame.CTS);
			getAPI().getJoinItems().registerVoteItem(5);
			getAPI().getJoinItems().registerLeaveItem(8, configuration.fallbackServer);

			getAPI().setMapProtector(new CtfMapProtector());
			getAPI().enableAntiSpawnKill();

			getAPI().getGameServer().whileRunningConnection(WhileRunningConnectionTypes.BACKUP);

			File votesFile = new File(getDataFolder(), VOTES_CONFIG);

			if(!votesFile.exists())
				votesFile.createNewFile();

			getAPI().getBadblockScoreboard().beginVote(JsonUtils.loadArray(votesFile));

			MAP = new File(getDataFolder(), MAPS_CONFIG_FOLDER);

			new PreStartRunnable().runTaskTimer(GameAPI.getAPI(), 0, 30L);

			new CTFCommand(MAP);
			new GameCommand();

			new JoinListener();
			new SheepListener();
			new MoveListener();
			new DeathListener();
			new DisconnectListener();

			Bukkit.getWorlds().forEach(world -> {
				world.setTime(2000L);
				world.getEntities().forEach(entity -> {
					entity.remove();
				});
			});

			maxPoints = configuration.maxPoints;
			
			// Ranked
			RankedManager.instance.initialize(RankedManager.instance.getCurrentRankedGameName(), 
					CtfScoreboard.KILLS, CtfScoreboard.DEATHS, CtfScoreboard.CAPTUREDFLAGS, CtfScoreboard.WINS, CtfScoreboard.LOOSES);
			

		}catch(Throwable e){

		}
	}

	public void giveDefaultKit(BadblockPlayer player){
		PlayerKit kit = kits.get(configuration.defaultKit);

		if(kit == null){
			player.clearInventory();
			return;
		}

		player.getPlayerData().unlockNextLevel(kit);
		kit.giveKit(player);
	}


	public void saveJsonConfig(){
		File configFile = new File(getDataFolder(), CONFIG);
		JsonUtils.save(configFile, configuration, true);
	}
}
