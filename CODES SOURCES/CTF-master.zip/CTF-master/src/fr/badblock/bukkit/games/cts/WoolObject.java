package fr.badblock.bukkit.games.cts;

import org.bukkit.Location;
import org.bukkit.Material;

import lombok.Getter;

public class WoolObject {
	
	@Getter private Long since;
	private Material mat;
	private byte data;
	
	public WoolObject(Long since, Material mat, byte data){
		this.since = since;
		this.mat = mat;
		this.data = data;
	}
	
	@SuppressWarnings("deprecation")
	public void resetBlock(Location loc){
		loc.getBlock().setType(mat);
		loc.getBlock().setData(data);
	}
	
}
