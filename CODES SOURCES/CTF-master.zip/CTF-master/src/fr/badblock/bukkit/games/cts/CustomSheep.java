package fr.badblock.bukkit.games.cts;

import net.minecraft.server.v1_8_R3.EntitySheep;
import net.minecraft.server.v1_8_R3.World;

public class CustomSheep extends EntitySheep{
	
	    public CustomSheep(World world) {
	        super(world);
	    }
	    
	    @Override
	    public void g(float sideMot, float forMot) {
	        this.S = 0.5F;
	        this.aM = 0.02F;
	        super.g(sideMot, forMot);
	    }
}
