package fr.badblock.bukkit.games.cts.listener;

import java.util.logging.Level;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.Sheep;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scheduler.BukkitRunnable;

import fr.badblock.bukkit.games.cts.CTFPlugin;
import fr.badblock.bukkit.games.cts.CtfScoreboard;
import fr.badblock.bukkit.games.cts.CtfTeamData;
import fr.badblock.bukkit.games.cts.runnable.StartRunnable;
import fr.badblock.gameapi.BadListener;
import fr.badblock.gameapi.GameAPI;
import fr.badblock.gameapi.players.BadblockPlayer;
import fr.badblock.gameapi.players.BadblockPlayer.BadblockMode;
import fr.badblock.gameapi.players.BadblockTeam;
import fr.badblock.gameapi.utils.BukkitUtils;
import fr.badblock.gameapi.utils.entities.CustomCreature;
import fr.badblock.gameapi.utils.entities.CustomCreature.CreatureFlag;
import fr.badblock.gameapi.utils.i18n.messages.GameMessages;

public class DisconnectListener extends BadListener{
	
	@EventHandler
	public void onDisconnect(PlayerQuitEvent e){
		
		BadblockPlayer player = (BadblockPlayer) e.getPlayer();
		if (!player.getGameMode().equals(GameMode.SPECTATOR) && !player.getBadblockMode().equals(BadblockMode.SPECTATOR))
		{
			GameMessages.quitMessage(GameAPI.getGameName(), player.getTabGroupPrefix().getAsLine(player) + player.getName(), Bukkit.getOnlinePlayers().size(), CTFPlugin.getInstance().getMaxPlayers()).broadcast();
		}
		
		if (StartRunnable.gameTask == null && BukkitUtils.getPlayers().size() - 1 < CTFPlugin.getInstance().getConfiguration().minPlayers) {
			StartRunnable.stopGame();
			StartRunnable.time = StartRunnable.time > 60 ? StartRunnable.time : 60;
		}
		if(!inGame()) return;
		for(BadblockTeam team : GameAPI.getAPI().getTeams()){
			if(!team.teamData(CtfTeamData.class).hasFlag()){
				if(team.teamData(CtfTeamData.class).getTaker() != null && team.teamData(CtfTeamData.class).getTaker().equalsIgnoreCase(e.getPlayer().getName())){
					if(team.teamData(CtfTeamData.class).getSheep() != null){
						CustomCreature sheep = team.teamData(CtfTeamData.class).getSheep();
						sheep.removeCreatureFlag(CreatureFlag.INVINCIBLE);
						
						new BukkitRunnable(){
							@Override
							public void run() {
								if(sheep.getBukkit() == null || sheep.getBukkit().isDead()){
									cancel();
								}
								sheep.getBukkit().remove();
							}
						}.runTaskTimer(GameAPI.getAPI(), 1L, 5L);
						
					}else{
						team.teamData(CtfTeamData.class).getSheepLocation().getWorld().getEntities().forEach(entity -> {
							if(entity.getType() == EntityType.SHEEP && ((Sheep)entity).getColor().equals(team.getDyeColor()))
								entity.remove();
						});
					}
					team.teamData(CtfTeamData.class).setSheep(
							GameAPI.getAPI().spawnCustomEntity(team.teamData(CtfTeamData.class).getSheepLocation(), EntityType.SHEEP),
							team.getDyeColor()
							);
					for(Player p : Bukkit.getOnlinePlayers()){
						if(p == null || ((BadblockPlayer)p) == null ){
							GameAPI.getAPI().getLogger().log(Level.WARNING, "Da Fuck, c est pas logique (Disconnect) " + p.getName());
							return; 
						}else if(((BadblockPlayer)p).getCustomObjective() == null){
							new CtfScoreboard(((BadblockPlayer)p)).generate();
						}else{
							((BadblockPlayer)p).getCustomObjective().generate();
						}
					}
				}
			}
		}
		
	}
}
