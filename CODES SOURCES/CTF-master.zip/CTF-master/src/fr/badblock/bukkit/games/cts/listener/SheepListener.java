package fr.badblock.bukkit.games.cts.listener;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.GameMode;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.Sheep;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;
import org.spigotmc.event.entity.EntityDismountEvent;

import fr.badblock.bukkit.games.cts.CtfTeamData;
import fr.badblock.gameapi.BadListener;
import fr.badblock.gameapi.GameAPI;
import fr.badblock.gameapi.game.GameState;
import fr.badblock.gameapi.players.BadblockPlayer;
import fr.badblock.gameapi.players.BadblockTeam;
import fr.badblock.gameapi.utils.i18n.TranslatableString;
import lombok.Getter;

public class SheepListener extends BadListener{
	@Getter private static List<String> haveNoLeave = new ArrayList<String>();
	
	public boolean inGame(){
		return GameAPI.getAPI().getGameServer().getGameState() == GameState.RUNNING;
	}
	
	@EventHandler
	public void onSheepMount(PlayerInteractAtEntityEvent e){
		if(!inGame()){
			e.setCancelled(true);
			return;
		}else if(!e.getPlayer().getGameMode().equals(GameMode.SURVIVAL)){
			e.setCancelled(true);
			return;
		}else if(!(e.getRightClicked().getType().equals(EntityType.SHEEP))){
			e.setCancelled(true);
			return;
		}
		
		
		for(BadblockTeam team : GameAPI.getAPI().getTeams()){
			CtfTeamData data = team.teamData(CtfTeamData.class);
			BadblockPlayer player = (BadblockPlayer)e.getPlayer();
			if(data.isTeamSheep(e.getRightClicked())){
				if(player.getTeam().equals(team)){
					e.setCancelled(true);
					return;
				}else if(e.getRightClicked().getPassenger() != null){
					return;
				}
				e.getRightClicked().setPassenger(player);
				data.pickUp(player.getName(), player.getTeam().getChatName(), team.getChatName(), team.getDyeColor());
			}else{
				Sheep temp = (Sheep) e.getRightClicked();
				if(temp.getColor().equals(team.getDyeColor())){
					temp.remove();
					team.teamData(CtfTeamData.class).setSheep(
							GameAPI.getAPI().spawnCustomEntity(team.teamData(CtfTeamData.class).getSheepLocation(), EntityType.SHEEP),
							team.getDyeColor()
							);
				}
			}
		}
		
	}
	
	@EventHandler
	public void onEntityExit(EntityDismountEvent e){
		if(!(e.getDismounted() instanceof Sheep)){
			return;
		}else if(haveNoLeave.contains(((Player)e.getEntity()).getName())){
			haveNoLeave.remove(((Player)e.getEntity()).getName());
			return;
		}
		
		Sheep vehicle = (Sheep) e.getDismounted();
		BadblockPlayer player = (BadblockPlayer) e.getEntity();
		for(BadblockTeam team : GameAPI.getAPI().getTeams()){
			if(team.getDyeColor().equals(vehicle.getColor())){
				team.teamData(CtfTeamData.class).resetSheep();
				new TranslatableString("cts.message.sheep-reset-by-dismount", player.getTeam().getChatName(), player.getName(), team.getChatName()).broadcast();
			}
		}
		
	}
	
	@EventHandler
	public void onSheepDamage(EntityDamageByEntityEvent e){
		if(e.getEntityType() == EntityType.SHEEP){
			e.setDamage(0D);
			e.setCancelled(true);
		}
	}

}
