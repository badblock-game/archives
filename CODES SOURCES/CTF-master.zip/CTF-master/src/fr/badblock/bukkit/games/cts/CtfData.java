package fr.badblock.bukkit.games.cts;

import fr.badblock.gameapi.players.data.InGameData;

public class CtfData implements InGameData {
	public int kills  = 0;
	public int deaths = 0;
	public int capturedFlags = 0;
	
	public int getScore(){
		return (kills * 20 + capturedFlags * 100) / (deaths == 0 ? 1 : (10 * deaths));
	}
}
