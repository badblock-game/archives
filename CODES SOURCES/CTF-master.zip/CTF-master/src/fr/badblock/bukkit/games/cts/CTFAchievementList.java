package fr.badblock.bukkit.games.cts;

import fr.badblock.gameapi.achievements.AchievementList;
import fr.badblock.gameapi.achievements.PlayerAchievement;
import fr.badblock.gameapi.run.BadblockGame;

public class CTFAchievementList {
public static AchievementList instance = new AchievementList(BadblockGame.CTS);
	
	/*
	 * Tuer X personnes
	 */
	public static final PlayerAchievement CTS_KILL_1 = instance.addAchievement(new PlayerAchievement("cts_kill_1", 10, 5, 10));
	public static final PlayerAchievement CTS_KILL_2 = instance.addAchievement(new PlayerAchievement("cts_kill_2", 50, 25, 100));
	public static final PlayerAchievement CTS_KILL_3 = instance.addAchievement(new PlayerAchievement("cts_kill_3", 250, 100, 1000));
	public static final PlayerAchievement CTS_KILL_4 = instance.addAchievement(new PlayerAchievement("cts_kill_4", 500, 250, 5000));
	
	/*
	 * Ramener X moutons
	 */
	public static final PlayerAchievement CTS_SHEEP_1  = instance.addAchievement(new PlayerAchievement("cts_sheep_1", 10, 5, 20));
	public static final PlayerAchievement CTS_SHEEP_2  = instance.addAchievement(new PlayerAchievement("cts_sheep_2", 50, 25, 200));
	public static final PlayerAchievement CTS_SHEEP_3  = instance.addAchievement(new PlayerAchievement("cts_sheep_3", 250, 100, 2000));
	public static final PlayerAchievement CTS_SHEEP_4  = instance.addAchievement(new PlayerAchievement("cts_sheep_4", 500, 250, 6000));

	/*
	 * Gagner X parties
	 */
	public static final PlayerAchievement CTS_WIN_1  = instance.addAchievement(new PlayerAchievement("cts_win_1", 10, 5, 10));
	public static final PlayerAchievement CTS_WIN_2  = instance.addAchievement(new PlayerAchievement("cts_win_2", 50, 25, 100));
	public static final PlayerAchievement CTS_WIN_3  = instance.addAchievement(new PlayerAchievement("cts_win_3", 250, 100, 1000));
	public static final PlayerAchievement CTS_WIN_4  = instance.addAchievement(new PlayerAchievement("cts_win_4", 500, 250, 5000));

	/*
	 * Gagner X parties en ayant ramener 2 moutons
	 */
	public static final PlayerAchievement CTS_WINNERSHEEP_1  = instance.addAchievement(new PlayerAchievement("cts_winnersheep_1", 10, 5, 10));
	public static final PlayerAchievement CTS_WINNERSHEEP_2  = instance.addAchievement(new PlayerAchievement("cts_winnersheep_2", 50, 25, 100));
	public static final PlayerAchievement CTS_WINNERSHEEP_3  = instance.addAchievement(new PlayerAchievement("cts_winnersheep_3", 250, 100, 1000));
	public static final PlayerAchievement CTS_WINNERSHEEP_4  = instance.addAchievement(new PlayerAchievement("cts_winnersheep_4", 500, 250, 5000));
	
	public static final PlayerAchievement CTS_ALLKITS = instance.addAchievement(new PlayerAchievement("cts_allkits", 300, 150, 3, true));
}
