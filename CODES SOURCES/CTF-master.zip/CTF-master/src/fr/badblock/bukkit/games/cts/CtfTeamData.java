package fr.badblock.bukkit.games.cts;

import java.util.logging.Level;

import org.bukkit.Bukkit;
import org.bukkit.DyeColor;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Sheep;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import fr.badblock.gameapi.GameAPI;
import fr.badblock.gameapi.configuration.BadConfiguration;
import fr.badblock.gameapi.configuration.values.MapLocation;
import fr.badblock.gameapi.configuration.values.MapSelection;
import fr.badblock.gameapi.players.BadblockPlayer;
import fr.badblock.gameapi.players.BadblockPlayer.BadblockMode;
import fr.badblock.gameapi.players.data.TeamData;
import fr.badblock.gameapi.utils.entities.CustomCreature;
import fr.badblock.gameapi.utils.entities.CustomCreature.CreatureBehaviour;
import fr.badblock.gameapi.utils.entities.CustomCreature.CreatureFlag;
import fr.badblock.gameapi.utils.entities.CustomCreature.CreatureGenericAttribute;
import fr.badblock.gameapi.utils.i18n.TranslatableString;
import fr.badblock.gameapi.utils.selections.CuboidSelection;
import lombok.Getter;

public class CtfTeamData implements TeamData{
	
	@Getter private Location sheepLocation, respawnLocation;
	@Getter private CustomCreature         sheep = null;
	@Getter private int                  nbrPlace = 0;
	private boolean                         flag = true;
	@Getter private CuboidSelection      bergery = null;
	@Getter private String               taker = null;
	
	public void load(BadConfiguration config){
		sheepLocation        = config.getValue("sheepLocation", MapLocation.class, new MapLocation()).getHandle();
		respawnLocation      = config.getValue("respawnLocation", MapLocation.class, new MapLocation()).getHandle();
		bergery 	         = config.getValue("bergery", MapSelection.class, new MapSelection()).getHandle();
	}
	
	public void save(BadConfiguration config){
		config.setValue("sheepLocation", new MapLocation(sheepLocation));
		config.setValue("respawnLocation", new MapLocation(respawnLocation));
		config.setValue("bergery", new MapSelection(bergery));
	}
	
	public boolean hasFlag(){
		return flag;
	}
	
	public void addNbrPlace(BadblockPlayer placer, TranslatableString chatNameSheepTeam){
		nbrPlace++;
		for(Player p : Bukkit.getOnlinePlayers()){
			BadblockPlayer badPlayer = (BadblockPlayer) p;
			badPlayer.sendTranslatedTitle("cts.title.player-addpoint", placer.getTeam().getChatName(), placer.getName());
			badPlayer.sendTimings(10, 40, 10);
			badPlayer.sendTranslatedMessage("cts.message.player-addpoint", placer.getTeam().getChatName(), placer.getName());

			if(badPlayer.getCustomObjective() == null){
				new CtfScoreboard(badPlayer);
			}else{
				badPlayer.getCustomObjective().generate();
			}
		}
	}
	
	public boolean isTeamSheep(Entity ent){
		if(sheep != null && sheep.getBukkit().equals(ent)){
			return true;
		}
		return false;
	}
	
	public void pickUp(String player, TranslatableString playerTeamColorName, TranslatableString sheepTeamColorName,DyeColor sheepColor){
		flag = false;
		sheep.setCreatureBehaviour(CreatureBehaviour.NORMAL);
		//sheep.setMovable(true);
		sheep.removeCreatureFlag(CreatureFlag.INVINCIBLE);
		//sheep.setInvincible(false);
		sheep.setCreatureGenericAttribute(CreatureGenericAttribute.SPEED, 0.05d);
		taker = player;
		
		
		for(Player p : Bukkit.getOnlinePlayers()){
			if(p == null || ((BadblockPlayer)p) == null){
				GameAPI.getAPI().getLogger().log(Level.WARNING, "Da Fuck, c est pas logique (TeamData) " + p.getName());
				return; 
			}else if(((BadblockPlayer)p).getCustomObjective() == null){
				new CtfScoreboard(((BadblockPlayer)p)).generate();
			}else{
				((BadblockPlayer)p).getCustomObjective().generate();
			}
			BadblockPlayer badPlayer = (BadblockPlayer) p;
			if(!badPlayer.getBadblockMode().equals(BadblockMode.SPECTATOR)){
				if(badPlayer.getTeam().getDyeColor().equals(sheepColor)){
					badPlayer.sendTranslatedTitle("cts.title.own-sheep-take", playerTeamColorName, player);
					badPlayer.sendTimings(10, 40, 10);
					
					if(badPlayer.getCustomObjective() == null){
						new CtfScoreboard(badPlayer);
					}else{
						badPlayer.getCustomObjective().generate();
					}
				}else{
					badPlayer.sendTranslatedMessage("cts.message.other-sheep-take", player, playerTeamColorName, sheepTeamColorName);
					
					if(badPlayer.getCustomObjective() == null){
						new CtfScoreboard(badPlayer);
					}else{
						badPlayer.getCustomObjective().generate();
					}
				}
			}
		}
	}
	
	public void resetSheep(){
		new BukkitRunnable(){
			@Override
			public void run() {
				if(sheep.getBukkit().getLocation().getBlock().getLocation().equals(sheepLocation.getBlock().getLocation())){
					cancel();
				}
				sheep.getBukkit().teleport(sheepLocation);
			}
		}.runTaskTimer(GameAPI.getAPI(), 10L, 5L);
		
		sheep.setCreatureBehaviour(CreatureBehaviour.MOTIONLESS);
		sheep.addCreatureFlag(CreatureFlag.INVINCIBLE);
		
		flag = true;
		taker = null;
		for(Player p : Bukkit.getOnlinePlayers()){
			if(p == null || ((BadblockPlayer)p) == null ){
				GameAPI.getAPI().getLogger().log(Level.WARNING, "Da Fuck, c est pas logique (TeamData2) " + p.getName());
				return; 
			}else if(((BadblockPlayer)p).getCustomObjective() == null){
				new CtfScoreboard(((BadblockPlayer)p)).generate();
			}else{
				((BadblockPlayer)p).getCustomObjective().generate();
			}
		}
	}
	
	public void setSheep(CustomCreature ent, DyeColor color){
		if(!(ent.getBukkit() instanceof Sheep)){
			return; //DaFuck !!!
		}
		Sheep sheep = (Sheep) ent.getBukkit();
		sheep.setColor(color);
		ent.addCreatureFlag(CreatureFlag.INVINCIBLE);
		sheep.setMaxHealth(200);
		
		sheep.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 10000000, 5));
		
		//ent.setInvincible(true);
		ent.removeCreatureFlag(CreatureFlag.RIDEABLE);
		//ent.setRideable(false);
		ent.setCreatureBehaviour(CreatureBehaviour.MOTIONLESS);
		ent.setSpeed(0.4d);
		//ent.setMovable(false);
		this.sheep = ent;
		flag = true;
		taker = null;
	}
	
}
