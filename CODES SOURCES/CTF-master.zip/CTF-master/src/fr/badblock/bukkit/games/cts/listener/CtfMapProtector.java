package fr.badblock.bukkit.games.cts.listener;

import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.event.block.Action;

import fr.badblock.bukkit.games.cts.CtfTeamData;
import fr.badblock.gameapi.GameAPI;
import fr.badblock.gameapi.game.GameState;
import fr.badblock.gameapi.players.BadblockPlayer;
import fr.badblock.gameapi.players.BadblockTeam;
import fr.badblock.gameapi.servers.MapProtector;
import fr.badblock.gameapi.utils.selections.CuboidSelection;

public class CtfMapProtector implements MapProtector{
	private boolean inGame(){
		return GameAPI.getAPI().getGameServer().getGameState() == GameState.RUNNING;
	}

	@Override
	public boolean allowBlockFormChange(Block arg0) {
		return false;
	}

	@Override
	public boolean allowBlockPhysics(Block arg0) {
		return false;
	}

	@Override
	public boolean allowExplosion(Location arg0) {
		return false;
	}

	@Override
	public boolean allowFire(Block arg0) {
		return false;
	}

	@Override
	public boolean allowInteract(Entity arg0) {
		return false;
	}

	@Override
	public boolean allowLeavesDecay(Block arg0) {
		return false;
	}

	@Override
	public boolean allowMelting(Block arg0) {
		return false;
	}

	@Override
	public boolean allowPistonMove(Block arg0) {
		return false;
	}

	@Override
	public boolean allowRaining() {
		return false;
	}

	@Override
	public boolean blockBreak(BadblockPlayer player, Block block) {

		if(!inGame()) return player.hasAdminMode();

		boolean can = true;

		for(BadblockTeam team : GameAPI.getAPI().getTeams()){
			CuboidSelection bergery = team.teamData(CtfTeamData.class).getBergery();
			if((bergery.getMaxX() >= block.getX() && bergery.getMinX() <= block.getX()) && (bergery.getMaxZ() >= block.getZ() && bergery.getMinZ() <= block.getZ())){
				can = false;
			}
		}
		for(BadblockTeam team : GameAPI.getAPI().getTeams()){
			Location location = team.teamData(CtfTeamData.class).getRespawnLocation();
			if (location.distance(block.getLocation()) <= 23) {
				can = false;
				if (!player.hasAdminMode()) {
					player.sendTranslatedMessage("cts.antibuildaroundrespawnlocation");
					break;
				}
			}
		}

		return can || player.hasAdminMode();
	}

	@Override
	public boolean blockPlace(BadblockPlayer player, Block block) {
		if(!inGame()) return player.hasAdminMode();

		boolean can = true;

		for(BadblockTeam team : GameAPI.getAPI().getTeams()){
			CuboidSelection bergery = team.teamData(CtfTeamData.class).getBergery();
			if((bergery.getMaxX() >= block.getX() && bergery.getMinX() <= block.getX()) && (bergery.getMaxZ() >= block.getZ() && bergery.getMinZ() <= block.getZ())){
				can = false;
			}
		}
		for(BadblockTeam team : GameAPI.getAPI().getTeams()){
			Location location = team.teamData(CtfTeamData.class).getRespawnLocation();
			if (location.distance(block.getLocation()) <= 23) {
				can = false;
				if (!player.hasAdminMode()) {
					player.sendTranslatedMessage("cts.antibuildaroundrespawnlocation");
					break;
				}
			}
		}

		return can;
	}

	@Override
	public boolean canBeingDamaged(BadblockPlayer arg0) {
		return inGame();
	}

	@Override
	public boolean canBlockDamage(Block arg0) {
		return true;
	}

	@Override
	public boolean canCombust(Entity arg0) {
		return false;
	}

	@Override
	public boolean canCreatureSpawn(Entity e, boolean isPlugin) {
		return isPlugin;
	}

	@Override
	public boolean canDrop(BadblockPlayer player) {
		return player.hasAdminMode();
	}

	@Override
	public boolean canEmptyBucket(BadblockPlayer arg0) {
		return false;
	}

	@Override
	public boolean canEnchant(BadblockPlayer arg0, Block arg1) {
		return false;
	}

	@Override
	public boolean canEntityBeingDamaged(Entity arg0) {
		return true;
	}

	@Override
	public boolean canFillBucket(BadblockPlayer player) {
		return inGame() || player.hasAdminMode();
	}

	@Override
	public boolean canInteract(BadblockPlayer player, Action action, Block block) {
		return player.hasAdminMode() || inGame();
	}

	@Override
	public boolean canInteractArmorStand(BadblockPlayer player, ArmorStand arg1) {
		return player.hasAdminMode();
	}

	@Override
	public boolean canInteractEntity(BadblockPlayer arg0, Entity arg1) {
		return true;
	}

	@Override
	public boolean canItemDespawn(Item arg0) {
		return true;
	}

	@Override
	public boolean canItemSpawn(Item arg0) {
		return true;
	}

	/*
	 * A voir si lost food ou non
	 */

	@Override
	public boolean canLostFood(BadblockPlayer player) {
		return inGame() && !player.hasAdminMode();
	}

	@Override
	public boolean canPickup(BadblockPlayer player) {
		return inGame() || player.hasAdminMode();
	}

	@Override
	public boolean canSoilChange(Block arg0) {
		return false;
	}

	@Override
	public boolean canSpawn(Entity arg0) {
		return true;
	}

	@Override
	public boolean canUseBed(BadblockPlayer arg0, Block arg1) {
		return false;
	}

	@Override
	public boolean canUsePortal(BadblockPlayer arg0) {
		return false;
	}

	@Override
	public boolean destroyArrow() {
		return true;
	}

	@Override
	public boolean healOnJoin(BadblockPlayer player) {
		return true;
	}

	@Override
	public boolean modifyItemFrame(Entity arg0) {
		return false;
	}

	@Override
	public boolean modifyItemFrame(BadblockPlayer player, Entity arg1) {
		return player.hasAdminMode();
	}

	@Override
	public boolean canEntityBeingDamaged(Entity arg0, BadblockPlayer arg1) {
		// TODO Auto-generated method stub
		return false;
	}

}
