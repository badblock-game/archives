package fr.badblock.bukkit.games.cts.listener;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.Sheep;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.scheduler.BukkitRunnable;

import fr.badblock.bukkit.games.cts.CTFAchievementList;
import fr.badblock.bukkit.games.cts.CTFPlugin;
import fr.badblock.bukkit.games.cts.CtfData;
import fr.badblock.bukkit.games.cts.CtfScoreboard;
import fr.badblock.bukkit.games.cts.CtfTeamData;
import fr.badblock.gameapi.BadListener;
import fr.badblock.gameapi.GameAPI;
import fr.badblock.gameapi.achievements.PlayerAchievement;
import fr.badblock.gameapi.game.GameState;
import fr.badblock.gameapi.game.rankeds.RankedManager;
import fr.badblock.gameapi.players.BadblockPlayer;
import fr.badblock.gameapi.players.BadblockPlayer.BadblockMode;
import fr.badblock.gameapi.players.BadblockTeam;
import fr.badblock.gameapi.players.data.PlayerAchievementState;
import fr.badblock.gameapi.utils.threading.TaskManager;

public class MoveListener extends BadListener{
	private List<String> noMsg = new ArrayList<String>();
	
	public boolean inGame(){
		return GameAPI.getAPI().getGameServer().getGameState() == GameState.RUNNING;
	}
	
	public MoveListener(){
	
	}
	@SuppressWarnings("deprecation")
	@EventHandler
	public void onMove(PlayerMoveEvent e){	
		
		if(e.getFrom().getBlock().equals(e.getTo().getBlock())){
			return;
		}else if(e.getTo().getY() <= 0.0d && !inGame()){
			Location spawn = CTFPlugin.getInstance().getConfiguration().spawn.getHandle();
			
			Entity vehicle = null;
			
			if(e.getPlayer().isInsideVehicle()){
				vehicle = e.getPlayer().getVehicle();
				vehicle.eject();
				vehicle.teleport(spawn);
			}
			
			e.setCancelled(true);
			e.getPlayer().teleport(spawn);
			
			if(vehicle != null)
				vehicle.setPassenger(e.getPlayer());
			return;
		}else if(e.getTo().getY() <= 0.0d && inGame()){
			BadblockPlayer player = (BadblockPlayer) e.getPlayer();
			if (player.getBadblockMode().equals(BadblockMode.PLAYER)) {
				EntityDamageEvent event = new EntityDamageEvent(player, EntityDamageEvent.DamageCause.VOID, player.getHealth());
				player.setLastDamageCause(event);
				Bukkit.getServer().getPluginManager().callEvent(event);
			}
		}else if(!inGame()){
			return;
		}else if(!e.getPlayer().isInsideVehicle() || !e.getPlayer().getVehicle().getType().equals(EntityType.SHEEP)){
			return;
		}
		
		Sheep vehicle = (Sheep) e.getPlayer().getVehicle();
		
		BadblockPlayer badPlayer = (BadblockPlayer) e.getPlayer();
		CtfTeamData teamData = badPlayer.getTeam().teamData(CtfTeamData.class);
		
		if(teamData.getBergery().isInSelection(badPlayer)){
			
			if(teamData.hasFlag() == false){
				if(!noMsg.contains(badPlayer.getName())) badPlayer.sendTranslatedMessage("cts.message.own-sheep-alreadytake");
				noMsg.add(badPlayer.getName());
				new BukkitRunnable(){
					@Override
					public void run() {
						if(noMsg.contains(badPlayer.getName())) noMsg.remove(badPlayer.getName());
					}
				}.runTaskLater(GameAPI.getAPI(), 5 * 20L);
				return;
			}
			
			SheepListener.getHaveNoLeave().add(badPlayer.getName());
			new BukkitRunnable(){
				@Override
				public void run() {
					if(SheepListener.getHaveNoLeave().contains(badPlayer.getName())) SheepListener.getHaveNoLeave().remove(badPlayer.getName());
				}
			}.runTaskLater(GameAPI.getAPI(), 10L);
			vehicle.eject();
			
            incrementAchievements(badPlayer, CTFAchievementList.CTS_SHEEP_1, CTFAchievementList.CTS_SHEEP_2, CTFAchievementList.CTS_SHEEP_3, CTFAchievementList.CTS_SHEEP_4);
			
			badPlayer.getPlayerData().incrementStatistic("cts", CtfScoreboard.CAPTUREDFLAGS);
			badPlayer.getPlayerData().incrementTempRankedData(RankedManager.instance.getCurrentRankedGameName(), CtfScoreboard.CAPTUREDFLAGS, 1);
			badPlayer.inGameData(CtfData.class).capturedFlags++;
			
			for(BadblockTeam team : GameAPI.getAPI().getTeams()){
				if(team.getDyeColor().equals(vehicle.getColor())){
					team.teamData(CtfTeamData.class).resetSheep();
					teamData.addNbrPlace(badPlayer, team.getChatName());
					break;
				}
			}
		}else{
			Location location = vehicle.getLocation().clone();
			for (int x = -2; x < 2; x++) {
				for (int z = -2; z < 2; z++) {
					Block block = location.clone().add(x, -1, z).getBlock();
					if (block.getType() == null)
						continue;
					if (!block.getType().isSolid())
						continue;
					if (block.getType().equals(Material.AIR))
						continue;
					if (block.getType().name().contains("SLAB")
							|| block.getType().name().contains("STAIR")
							|| block.getType().name().contains("STEP")
				            || block.getType().name().contains("FENCE"))
						continue;
					for (Player p : Bukkit.getOnlinePlayers())
						p.sendBlockChange(location.clone().add(x, -1, z),
								Material.WOOL, (byte) vehicle.getColor().getData());
					final int finalX = x;
					final int finalZ = z;
					TaskManager.runTaskLater("removesheepchange_" + UUID.randomUUID().toString(),
							new Runnable() {
						@Override
						public void run() {
							for (Player p : Bukkit.getOnlinePlayers())
								p.sendBlockChange(
										location.clone().add(finalX, -1,
												finalZ),
										block.getType(), block.getData());
						}
					}, 40);
				}
			}
		}
	}
	
	private void incrementAchievements(BadblockPlayer player, PlayerAchievement... achievements){
		for(PlayerAchievement achievement : achievements){
			PlayerAchievementState state = player.getPlayerData().getAchievementState(achievement);
			state.progress(1.0d);
			state.trySucceed(player, achievement);
		}
		player.saveGameData();
	}
}
