package com.lelann.tower;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Item;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.inventory.ItemStack;

import fr.badblock.api.MJPlugin;
import fr.badblock.api.commands.CommandsManager;
import fr.badblock.api.game.BPlayer;
import fr.badblock.api.game.BPlayersManager;
import fr.badblock.api.game.Team;
import fr.badblock.api.game.Team.TeamType;
import fr.badblock.api.game.TeamsManager;
import fr.badblock.api.listeners.minigame.VoteListener;
import fr.badblock.api.runnables.GameRunnable;
import fr.badblock.api.runnables.StartRunnable;
import fr.badblock.api.scoreboard.BPlayerBoard;
import fr.badblock.api.utils.bukkit.ChatUtils;
import fr.badblock.api.utils.bukkit.ConfigUtils;

public class PluginTower extends MJPlugin {
	
	public int points	= 10;
	
	@Override
	public boolean canBeDamaged() {
		return status != GameStatus.WAITING_PLAYERS && status != GameStatus.STARTING;
	}

	@Override
	public boolean canBurn() {
		return false;
	}

	@Override
	public boolean canDropOrPickup() {
		return status != GameStatus.WAITING_PLAYERS && status != GameStatus.STARTING;
	}

	@Override
	public boolean canExplode() {
		return false;
	}

	@Override
	public boolean canFight() {
		return status != GameStatus.WAITING_PLAYERS && status != GameStatus.STARTING;
	}

	@Override
	public boolean canInteract(Material material) {
		return status != GameStatus.WAITING_PLAYERS && status != GameStatus.STARTING;
	}

	@Override
	public boolean canLostFood() {
		return status != GameStatus.WAITING_PLAYERS && status != GameStatus.STARTING;
	}

	@Override
	public boolean canModifyMap() {
		return status != GameStatus.WAITING_PLAYERS && status != GameStatus.STARTING;
	}

	@Override
	public boolean canSpawn() {
		return false;
	}

	@Override
	public boolean canSpawnCustom() {
		return false;
	}

	@Override
	public boolean canUseFlintAndSteel() {
		return true;
	}

	@Override
	public String deathMessageSuffix(PlayerDeathEvent e) {
		return "";
	}

	@Override
	public boolean enableAntiSpawnKill() {
		return true;
	}

	@Override
	public boolean enableVote() {
		return true;
	}

	@Override
	public List<String> getVotes() {
		if(!getConfig().contains("maps")){
			getConfig().set("maps", Arrays.asList(new String[]{"example"}));
		}
		return getConfig().getStringList("maps");
	}
	
	@Override
	public List<String> getKits(){
		if(!getConfig().contains("kits")){
			getConfig().set("kits", Arrays.asList(new String[]{"example"}));
		}
		return getConfig().getStringList("kits");
	}

	@Override
	public boolean lightningOnDeath() {
		return true;
	}

	@Override
	public int getTime(){
		return 2000;
	}
	
	public int playersByTeam(){
		return getConfig().getInt("playersByTeam");
	}
	@Override
	public int maxPlayer() {
		return playersByTeam() * 2;
	}

	@Override
	public int minPlayer() {
		return maxPlayer();
	}

	@Override
	public boolean respawnAtDeathPoint() {
		return false;
	}

	@Override
	public boolean respawnAutomaticly() {
		return true;
	}

	@Override
	public void disableGame() {

	}
	@Override
	public void enableGame() {
		if(!getConfig().contains("playersByTeam"))
			getConfig().set("playersByTeam", 4);
		if(!new File(getDataFolder(), "maps").exists())
			new File(getDataFolder(), "maps").mkdirs();

		registerEvent(new TowerListener());
		CommandsManager.getInstance().registerCommand("tower", TowerCommand.class);
		new TeamsManager(getConfig(), playersByTeam(), TowerTeam.class, TeamType.RED, TeamType.BLUE);
	}

	@Override
	public void start() {
		status = GameStatus.STARTING;
		new StartRunnable(10){
			@Override
			public void begin(){
				String map = VoteListener.getWinner();
				int voteNumber = VoteListener.getVoteNumber(map);

				ChatUtils.broadcast("%gold%La map %red%" + map + " %gold%a été choisie avec %red% " + voteNumber + " votes !");

				FileConfiguration config = YamlConfiguration.loadConfiguration(new File(getDataFolder(), "maps/" + map.toLowerCase() + ".yml"));
				spectatorSpawn = ConfigUtils.loadLocation(config, "spawn-spectator");
				final Location bottleSpawn = ConfigUtils.loadLocation(config, "bottle-spawn"),
						ironSpawn = ConfigUtils.loadLocation(config, "ironspawn");
				
				for(Team team : TeamsManager.getInstance().getTeams()){
					TowerTeam rteam = (TowerTeam) team;
					rteam.init(config, "teams." + team.getType().getName(), team.getType(), true);
				}
				
				for(BPlayer player : BPlayersManager.getInstance().getPlayers()){
					if(player.getUsedKit() == null) TowerListener.giveKit(player, player.getPlayer());
				}

				try {
					config.save(new File(getDataFolder(), map.toLowerCase() + ".yml"));
				} catch (IOException unused) {}

				teleportPlayersToTeamSpawn();
				new GameRunnable(60 * 30, -1){
					private Item bottle, iron;
					@Override
					public void update() {
						if(bottle != null) bottle.remove();
						if(iron != null) iron.remove();
						
						bottle = bottleSpawn.getWorld().dropItem(bottleSpawn, new ItemStack(Material.EXP_BOTTLE, 1));
						iron = ironSpawn.getWorld().dropItem(ironSpawn, new ItemStack(Material.IRON_INGOT, 1));

						Team best = null;
						
						for(Team team : TeamsManager.getInstance().getTeams()){
							if(best != null){
								if(best.getScore() < team.getScore())
									best = team;
							} else best = team;
							
							if(team.getScore() >= points){
								win(team);
							}
						}
						
						if(time == 0){
							win(best);
						}
					}
				}.start();
				status = GameStatus.PLAYING;
			}
		}.start();
	}

	@Override
	public boolean respawnAtSpectatorSpawn() {
		return false;
	}

	@Override
	public boolean respawnAtTeamSpawn() {
		return true;
	}

	@Override
	public String getGameName() {
		return "BadTower";
	}

	@Override
	public BPlayerBoard getPlayerBoard(BPlayer player) {
		return new TowerScoreboard(player);
	}

	@Override
	public String getWelcomeTitle() {
		return "%gold%Bienvenue en %red%Tower %gold%!";
	}

	@Override
	public String getWelcomeSubTitle() {
		return "%gold%Tuer, massacrer, voler ... Viens t'amuser ! :)";
	}

	@Override
	public boolean enableKits() {
		return true;
	}

	@Override
	public boolean initTeams() {
		return false;
	}
}
