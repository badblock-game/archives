	package com.lelann.tower;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.LeatherArmorMeta;

import fr.badblock.api.game.BPlayer;
import fr.badblock.api.game.BPlayersManager;
import fr.badblock.api.game.Team;
import fr.badblock.api.game.Team.TeamType;
import fr.badblock.api.game.TeamsManager;

public class TowerListener implements Listener {
	
	private Map<UUID, Long> lastMarked = new HashMap<>();
	
	private boolean hasChanged(Location loc, Location loc2){
		return loc.getBlockX() != loc2.getBlockX() || loc.getBlockY() != loc2.getBlockY()
				|| loc.getBlockZ() != loc2.getBlockZ();
	}
	
	@EventHandler
	public void onMove(PlayerMoveEvent e){
		if(!hasChanged(e.getFrom(), e.getTo())) return;
		
		BPlayer player = BPlayersManager.getInstance().getPlayer(e.getPlayer());
		if(player == null || player.isSpectator() || player.getTeam() == null || player.getTeam().getTeam() == null) return;

		for(Team team : TeamsManager.getInstance().getTeams()){
			TowerTeam tTeam = (TowerTeam) team;
			if(tTeam.canMark(player, e.getTo())){
				final UUID uniqueId = player.getUniqueId();
				long last = !lastMarked.containsKey(uniqueId) ? lastMarked.put(uniqueId, 0L) : lastMarked.get(uniqueId);
				if (last < System.currentTimeMillis()) {
				((TowerTeam) player.getTeam().getTeam()).mark(player);
					lastMarked.put(uniqueId, System.currentTimeMillis() + 30000);
				}
			}
		}
	}
	
	public static void giveKit(BPlayer player, Player p){
		p.getInventory().addItem(new ItemStack(Material.ARROW, 1));

		ItemStack leatherChestplate = new ItemStack(Material.LEATHER_CHESTPLATE, 1);
		ItemStack leatherLeggings = new ItemStack(Material.LEATHER_LEGGINGS, 1);
		ItemStack leatherHelmet = new ItemStack(Material.LEATHER_HELMET, 1);
		ItemStack leatherBoots = new ItemStack(Material.LEATHER_BOOTS, 1);
		
		LeatherArmorMeta armorMeta = (LeatherArmorMeta)leatherLeggings.getItemMeta();
		
		if(player.getTeam() == TeamType.RED)
			armorMeta.setColor(Color.RED);
		else if(player.getTeam() == TeamType.BLUE)
			armorMeta.setColor(Color.BLUE);
		else if(player.getTeam() == TeamType.GREEN)
			armorMeta.setColor(Color.GREEN);
		else if(player.getTeam() == TeamType.YELLOW)
			armorMeta.setColor(Color.YELLOW);
		
		leatherLeggings.setItemMeta(armorMeta);
		leatherBoots.setItemMeta(armorMeta);
		leatherHelmet.setItemMeta(armorMeta);
		leatherChestplate.setItemMeta(armorMeta);
		
		p.getInventory().setChestplate(leatherChestplate);
		p.getInventory().setLeggings(leatherLeggings);
		p.getInventory().setBoots(leatherBoots);
		p.getInventory().setHelmet(leatherHelmet);
		
		p.getInventory().setItem(0, new ItemStack(Material.BAKED_POTATO, 16));

	}
	
	@EventHandler
	public void onRespawn(PlayerRespawnEvent e){
		BPlayer p = BPlayersManager.getInstance().getPlayer(e.getPlayer());
		giveKit(p, e.getPlayer());
	}
	@EventHandler
	public void onBreak(BlockBreakEvent e){
		BPlayer player = BPlayersManager.getInstance().getPlayer(e.getPlayer());
		if(player == null || player.isSpectator()) return;

		for(Team team : TeamsManager.getInstance().getTeams()){
			TowerTeam tTeam = (TowerTeam) team;
			if(tTeam.protectBreak(player, e.getBlock()))
				e.setCancelled(true);
		}
	}
	
	@EventHandler
	public void onOpenChest(PlayerInteractEvent e){
		if(e.getClickedBlock() == null || e.getClickedBlock().getType() != Material.CHEST) return;
		
		BPlayer player = BPlayersManager.getInstance().getPlayer(e.getPlayer());
		if(player == null || player.isSpectator()) return;

		for(Team team : TeamsManager.getInstance().getTeams()){
			TowerTeam tTeam = (TowerTeam) team;
			
			if(tTeam.protectChest(player, e.getClickedBlock()))
				e.setCancelled(true);
		}
	}
	
	@EventHandler
	public void onPlace(BlockPlaceEvent e){
		BPlayer player = BPlayersManager.getInstance().getPlayer(e.getPlayer());
		if(player == null || player.isSpectator()) return;
		Material material = e.getBlock().getType();
		if (material.name().contains("PISTON")) {
			e.setCancelled(true);
			player.sendMessage("§cIl est interdit de poser des pistons.");
		}
		for(Team team : TeamsManager.getInstance().getTeams()){
			TowerTeam tTeam = (TowerTeam) team;
			if(tTeam.protectBuild(player, e.getBlock()))
				e.setCancelled(true);
		}
	}
}
