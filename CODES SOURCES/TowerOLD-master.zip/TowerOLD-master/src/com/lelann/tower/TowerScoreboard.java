package com.lelann.tower;

import java.util.UUID;

import org.bukkit.scoreboard.Team;

import fr.badblock.api.MJPlugin;
import fr.badblock.api.game.BPlayer;
import fr.badblock.api.game.BPlayersManager;
import fr.badblock.api.game.Team.TeamType;
import fr.badblock.api.scoreboard.BPlayerBoard;
import fr.badblock.api.utils.bukkit.ChatUtils;

public class TowerScoreboard extends BPlayerBoard {
	public TowerScoreboard(BPlayer player) {
		super(player);

		setDisplayName("&b&o" + MJPlugin.getInstance().getGameName());

		if(time == null){}
	}

	private String  time   = "00m00s";
	private int		line   = 0;
	
	@Override
	public void setTime(String time) {
		this.time = time;
		
		setLine(line,  "&b➔ " + time);
	}

	@Override
	public void update() {
		setLine(15, "&8&m----------------------");

		int i = 14;
		
		for(TeamType type : TeamType.values()){
			if(type.getTeam() != null){
				setLine(i, type.getColor() + type.getFrench() + " > " + type.getTeam().getScore());
				i--;
				
				Team team = board.getTeam(type.getName());
				
				if(team == null) team = board.registerNewTeam(type.getName());
				team.setPrefix(ChatUtils.colorReplace(type.getColor()));

				for(UUID player : type.getTeam().getPlayers()){
					BPlayer p = BPlayersManager.getInstance().getPlayer(player);
					if(p != null && p.getPlayer() != null)
						team.addPlayer(p.getPlayer());
				}
			}
		}
		
		setLine(i,  ""); i--;
		setLine(i,  "&7Fin du jeu"); i--;
		line = i;
		setLine(i,  "&b➔ " + time); i--;

		setLine(i,  ""); i--;
		
		setLine(i,  "&7Victoires &b" + (int)player.getStatValue("wins")); i--;
		setLine(i,  "&7Kills &b" + (int)player.getStatValue("kills")); i--;
		setLine(i,  "&7Morts &b" + (int)player.getStatValue("deaths")); i--;
		setLine(i,  "&7Points marqués &b" + (int)player.getStatValue("marks")); i--;

		for(int a=3;a<i;a++)
			removeLine(a);
		
		setLine(2,  "&8&m----------------------");
		setLine(1,  "&b/badblock");
	}
}
