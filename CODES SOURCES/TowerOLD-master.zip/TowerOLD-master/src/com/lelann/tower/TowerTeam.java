package com.lelann.tower;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;

import fr.badblock.api.commands.HealCommand;
import fr.badblock.api.game.BPlayer;
import fr.badblock.api.game.BPlayersManager;
import fr.badblock.api.game.Team;
import fr.badblock.api.utils.bukkit.ChatUtils;
import fr.badblock.api.utils.bukkit.ConfigUtils;
import fr.badblock.api.utils.bukkit.title.Title;
import fr.badblock.api.utils.maths.Selection;

public class TowerTeam extends Team {
	private static boolean hasChanged = false;
	public static boolean hasChanged(){
		boolean changed = hasChanged;
		hasChanged = false;
		
		return changed;
	}
	private Selection chestProtectSelection, spawnProtectSelection, markSelection;
	
	private int marks = 0;
	@Override
	public int getScore() {
		return marks;
	}

	@Override
	public void loose() {
		ChatUtils.broadcast("%gold%L'�quipe " + getType().getDisplayName() + " %gold%a perdu !");
	}

	@Override
	public void initTeam(ConfigurationSection config, String deb) {
		chestProtectSelection =
				new Selection(ConfigUtils.loadLocation(config, deb + ".protectchest.first"),
						ConfigUtils.loadLocation(config, deb + ".protectchest.second"));
		spawnProtectSelection =
				new Selection(ConfigUtils.loadLocation(config, deb + ".protectspawn.first"),
						ConfigUtils.loadLocation(config, deb + ".protectspawn.second"));
		markSelection =
				new Selection(ConfigUtils.loadLocation(config, deb + ".pool.first"),
						ConfigUtils.loadLocation(config, deb + ".pool.second"));
	}
	public boolean protectBreak(BPlayer player, Block block){
		if(spawnProtectSelection == null || chestProtectSelection == null) return false;
		if(block.getType() == Material.CHEST && chestProtectSelection.isInSelection(block.getLocation())){
			return true;
		} else if(spawnProtectSelection.isInSelection(block.getLocation())){
			return true;
		} else return false;
	}
	public boolean protectBuild(BPlayer player, Block block){
		if(spawnProtectSelection == null || chestProtectSelection == null) return false;
		if(chestProtectSelection.isInSelection(block.getLocation())){
			return true;
		} else if(spawnProtectSelection.isInSelection(block.getLocation())){
			return true;
		} else return false;
	}
	
	public boolean protectChest(BPlayer player, Block block){
		if(spawnProtectSelection == null || chestProtectSelection == null) return false;
		
		if(player.getTeam() != type && chestProtectSelection.isInSelection(block.getLocation())){
			return true;
		}
		
		return false;
	}
	
	public boolean canMark(BPlayer player, Location to){
		if(markSelection == null) return false;
		return player.getTeam() != type && markSelection.isInSelection(to);
	}
	public void mark(BPlayer player){
		marks++;
		player.incrementStat("marks");
		for(BPlayer p : BPlayersManager.getInstance().getPlayers()){
			p.hasChanged(true);
		}
		player.getPlayer().teleport(getSpawn());
		HealCommand.heal(player.getPlayer());
		new Title("%red%" + marks + " points !", type.getDisplayName() + " " + player.getPlayerName() + " %gold%a marqué un point.").broadcast();;
	}
	public TowerTeam(){super();}
}