package com.lelann.tower;

import java.io.File;
import java.io.IOException;
import java.util.HashSet;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import fr.badblock.api.BPlugin;
import fr.badblock.api.commands.AbstractCommand;
import fr.badblock.api.utils.bukkit.ConfigUtils;

public class TowerCommand extends AbstractCommand {
	public TowerCommand() {
		super("minigames.admin", "%gold%Utilisation : /tower (lala) <map>", false);
	}
	
	@Override
	public void run(CommandSender sender, String[] args) {
		Player player = (Player) sender;
		BPlugin p = BPlugin.getInstance();
		File file = null;
		FileConfiguration config = null;
		
		if(args.length == 0){
			sendHelp(sender);
		} else if(args[0].equalsIgnoreCase("setspawn")){
			ConfigUtils.saveLocation(p.getConfig(), "spawn", player.getLocation());
		} else if(args[0].equalsIgnoreCase("setspectatorspawn") && args.length > 1){
			file = new File(p.getDataFolder(), "maps/" + args[1].toLowerCase() + ".yml");
			config = YamlConfiguration.loadConfiguration(file);
			
			ConfigUtils.saveLocation(config, "spawn-spectator", player.getLocation());
		} else if(args[0].equalsIgnoreCase("setbottlespawn") && args.length > 1){
			file = new File(p.getDataFolder(), "maps/" + args[1].toLowerCase() + ".yml");
			config = YamlConfiguration.loadConfiguration(file);
			
			ConfigUtils.saveLocation(config, "bottle-spawn", player.getLocation());
		} else if(args[0].equalsIgnoreCase("setironspawn") && args.length > 1){
			file = new File(p.getDataFolder(), "maps/" + args[1].toLowerCase() + ".yml");
			config = YamlConfiguration.loadConfiguration(file);
			
			ConfigUtils.saveLocation(config, "ironspawn", player.getLocation());
		} else if(args[0].equalsIgnoreCase("setteamspawn") && args.length > 2){
			file = new File(p.getDataFolder(), "maps/" + args[2].toLowerCase() + ".yml");
			config = YamlConfiguration.loadConfiguration(file);
			
			ConfigUtils.saveLocation(config, "teams." + args[1].toLowerCase() + ".spawn", player.getLocation());
		} else if(args[0].equalsIgnoreCase("setpool_first") && args.length > 2){
			file = new File(p.getDataFolder(), "maps/" + args[2].toLowerCase() + ".yml");
			config = YamlConfiguration.loadConfiguration(file);
			
			Location l = getBlockTarget(player);
			if(l == null) return;
			ConfigUtils.saveLocation(config, "teams." + args[1].toLowerCase() + ".pool.first", l);
		} else if(args[0].equalsIgnoreCase("setpool_second") && args.length > 2){
			file = new File(p.getDataFolder(), "maps/" + args[2].toLowerCase() + ".yml");
			config = YamlConfiguration.loadConfiguration(file);
			
			Location l = getBlockTarget(player);
			if(l == null) return;
			ConfigUtils.saveLocation(config, "teams." + args[1].toLowerCase() + ".pool.second", l);
		} else if(args[0].equalsIgnoreCase("setprotectspawn_first") && args.length > 2){
			file = new File(p.getDataFolder(), "maps/" + args[2].toLowerCase() + ".yml");
			config = YamlConfiguration.loadConfiguration(file);
			
			Location l = getBlockTarget(player);
			if(l == null) return;
			ConfigUtils.saveLocation(config, "teams." + args[1].toLowerCase() + ".protectspawn.first", l);
		} else if(args[0].equalsIgnoreCase("setprotectspawn_second") && args.length > 2){
			file = new File(p.getDataFolder(), "maps/" + args[2].toLowerCase() + ".yml");
			config = YamlConfiguration.loadConfiguration(file);
			
			Location l = getBlockTarget(player);
			if(l == null) return;
			ConfigUtils.saveLocation(config, "teams." + args[1].toLowerCase() + ".protectspawn.second", l);
		} else if(args[0].equalsIgnoreCase("setprotectchest_first") && args.length > 2){
			file = new File(p.getDataFolder(), "maps/" + args[2].toLowerCase() + ".yml");
			config = YamlConfiguration.loadConfiguration(file);
			
			Location l = getBlockTarget(player);
			if(l == null) return;
			ConfigUtils.saveLocation(config, "teams." + args[1].toLowerCase() + ".protectchest.first", l);
		} else if(args[0].equalsIgnoreCase("setprotectchest_second") && args.length > 2){
			file = new File(p.getDataFolder(), "maps/" + args[2].toLowerCase() + ".yml");
			config = YamlConfiguration.loadConfiguration(file);
			
			Location l = getBlockTarget(player);
			if(l == null) return;
			ConfigUtils.saveLocation(config, "teams." + args[1].toLowerCase() + ".protectchest.second", l);
		} else {
			sendHelp(sender);
			return;
		}
		if(file == null && config == null)
			p.saveConfig();
		else {
			try {
				config.save(file);
			} catch(IOException e){}
		}
		sendMessage(sender, "%green%Modifié !");
	}
	@SuppressWarnings("deprecation")
	public Location getBlockTarget(Player p){
		Block blockTarget = null;
		for (Block b : p.getLineOfSight(new HashSet<Material>(), 200)) {
			if (!b.getType().equals(Material.AIR)) { blockTarget = b; break; }
		}
		if(blockTarget == null){
			sendMessage(p, "%red%Vous devez regarder un block pour executer cette commande !");
			return null;
		}

		return blockTarget.getLocation();
	}
}