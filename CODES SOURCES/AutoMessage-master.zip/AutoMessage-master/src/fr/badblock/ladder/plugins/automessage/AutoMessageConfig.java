package fr.badblock.ladder.plugins.automessage;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import lombok.Data;

@Data public class AutoMessageConfig {

	private List<InsistentMessage> insistentMessages;

	public AutoMessageConfig() {
		this.setInsistentMessages(new ArrayList<>());
		this.getInsistentMessages().add(new InsistentMessage(10, Arrays.asList(new String[] { "test" }, new String[] {"test2"}), null));
	}

}
