package fr.badblock.bukkit.gameserver.listeners;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;

import fr.badblock.bukkit.gameserver.GameServer;

public class PlayerInteractListener implements Listener {

	@EventHandler (priority = EventPriority.LOWEST)
	public void onPlayerInteract(PlayerInteractEvent event) {
		Player player = event.getPlayer();
		if (player.getItemInHand() == null) return;
		if (player.getItemInHand().getType().equals(Material.AIR)) return;
		if (player.getItemInHand().getType().equals(Material.ENDER_CHEST)) {
			if (!player.hasPermission("game.manage")) return;
			player.openInventory(GameServer.getInstance().getInventory());
		}
	}
	
}