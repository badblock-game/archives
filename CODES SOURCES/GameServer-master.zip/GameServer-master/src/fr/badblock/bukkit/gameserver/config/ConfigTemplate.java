package fr.badblock.bukkit.gameserver.config;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter public class ConfigTemplate {
	
	private int			id;
	private String		key;
	private String		material;
	private String		type;
	private String		displayName;
	private String		lore;
	
	public ConfigTemplate(int id, String key, String material, String type, String displayName, String lore) {
		this.setId(id);
		this.setKey(key);
		this.setMaterial(material);
		this.setType(type);
		this.setDisplayName(displayName);
		this.setLore(lore);
	}

}
