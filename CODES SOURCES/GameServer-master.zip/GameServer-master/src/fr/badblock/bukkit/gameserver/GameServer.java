package fr.badblock.bukkit.gameserver;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.management.ManagementFactory;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import org.bukkit.Bukkit;
import org.bukkit.DyeColor;
import org.bukkit.Material;
import org.bukkit.Server;
import org.bukkit.World;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Creature;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

import com.google.gson.Gson;
import com.lelann.tower.PluginTower;
import com.sun.management.OperatingSystemMXBean;

import fr.badblock.api.MJPlugin;
import fr.badblock.api.game.TeamsManager;
import fr.badblock.bukkit.gameserver.commands.FreezeCommand;
import fr.badblock.bukkit.gameserver.commands.GameCommand;
import fr.badblock.bukkit.gameserver.commands.LagCommand;
import fr.badblock.bukkit.gameserver.config.ConfigSystem;
import fr.badblock.bukkit.gameserver.config.ConfigTemplate;
import fr.badblock.bukkit.gameserver.database.BadblockDatabase;
import fr.badblock.bukkit.gameserver.database.Request;
import fr.badblock.bukkit.gameserver.database.Request.RequestType;
import fr.badblock.bukkit.gameserver.factories.GameAliveFactory;
import fr.badblock.bukkit.gameserver.listeners.EntityDamageByEntityListener;
import fr.badblock.bukkit.gameserver.listeners.EntitySpawnListener;
import fr.badblock.bukkit.gameserver.listeners.InventoryClickListener;
import fr.badblock.bukkit.gameserver.listeners.PlayerBlockUseListener;
import fr.badblock.bukkit.gameserver.listeners.PlayerCommandPreprocessListener;
import fr.badblock.bukkit.gameserver.listeners.PlayerHeldItemSlotListener;
import fr.badblock.bukkit.gameserver.listeners.PlayerInteractListener;
import fr.badblock.bukkit.gameserver.listeners.PlayerJoinListener;
import fr.badblock.bukkit.gameserver.listeners.PlayerMoveListener;
import fr.badblock.bukkit.gameserver.listeners.PlayerQuitListener;
import fr.badblock.bukkit.gameserver.listeners.PlayerTeleportListener;
import fr.badblock.bukkit.gameserver.rabbitmq.RabbitQueue;
import fr.badblock.bukkit.gameserver.state.APIGameState;
import fr.badblock.bukkit.gameserver.state.GameState;
import fr.badblock.bukkit.gameserver.threading.LogSenderThread;
import fr.badblock.rabbitconnector.RabbitConnector;
import fr.badblock.rabbitconnector.RabbitPacketType;
import fr.badblock.rabbitconnector.RabbitService;
import fr.badblock.utils.Encodage;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter public class GameServer extends JavaPlugin {

	@Getter @Setter private static GameServer instance;

	private RabbitConnector			rabbitConnector;
	private RabbitService			rabbitService;
	private String					serverName;
	private ConsoleCommandSender	console;
	private long					joinTime;
	private String					logsFile;
	private LogSenderThread			logSenderThread;
	private Gson					gson;
	private boolean					available;
	private boolean					last;
	private String					version; 
	private String					mysqlHostname;
	private int						mysqlPort;
	private String					mysqlUsername;
	private String					mysqlPassword;
	private String					mysqlDatabase;
	private boolean					API;
	private boolean					isDocker;
	private Map<String, ConfigTemplate>	configTemplates		= new HashMap<>();
	private Map<ConfigSystem, Inventory>	configInventories = new HashMap<>();
	private List<ConfigSystem>		configz					= new ArrayList<>();
	private ItemStack				configItem;
	private Inventory				inventory;
	public Map<Integer, ItemStack>	itemStacks 				= new HashMap<>();
	Map<String, ConfigSystem>  		configss 				= new HashMap<>();
	public boolean					isWhitelisted;
	public HashSet<String>			whitelist 				= new HashSet<>();
	public boolean					canBeLogged;
	public long						maxOpenedTime;
	public double					boostXP					= 1;
	public double					boostBadcoins			= 1;

	@Override
	public void onEnable() {
		BadblockDatabase badblockDatabase = BadblockDatabase.getInstance();
		badblockDatabase.connect(mysqlHostname, mysqlPort, mysqlUsername, mysqlPassword, mysqlDatabase);
		this.gson = new Gson();
		this.version = this.getVersion();
		this.maxOpenedTime = System.currentTimeMillis() + 600_000L;
		this.getServer().dispatchCommand(this.getServer().getConsoleSender(), "timings on");
		PluginManager pluginManager = this.getServer().getPluginManager();
		getCommand("lag").setExecutor(new LagCommand());
		getCommand("game").setExecutor(new GameCommand());
		getCommand("freeze").setExecutor(new FreezeCommand());
		pluginManager.registerEvents(new EntitySpawnListener(), this);
		pluginManager.registerEvents(new PlayerBlockUseListener(), this);
		pluginManager.registerEvents(new EntityDamageByEntityListener(), this);
		pluginManager.registerEvents(new InventoryClickListener(), this);
		pluginManager.registerEvents(new PlayerHeldItemSlotListener(), this);
		pluginManager.registerEvents(new PlayerJoinListener(), this);
		pluginManager.registerEvents(new PlayerCommandPreprocessListener(), this);
		pluginManager.registerEvents(new PlayerMoveListener(), this);
		pluginManager.registerEvents(new PlayerInteractListener(), this);
		pluginManager.registerEvents(new PlayerQuitListener(), this);
		pluginManager.registerEvents(new PlayerTeleportListener(), this);
		getServer().getScheduler().runTaskTimer(this, new Runnable() {
			@Override
			public void run() {
				if (getJoinTime() < System.currentTimeMillis() && getOnlinePlayers() < 1) {
					console.sendMessage("§c§l➤ §r§cNo enough players during 5 minutes, shutdown.");
					Bukkit.shutdown();
				}
				if (getMaxOpenedTime() < System.currentTimeMillis() && getOnlinePlayers() < 1) {
					console.sendMessage("§c§l➤ §r§cNo enough players during 10 minutes, shutdown.");
					Bukkit.shutdown();
				}
				if (available) {
					keepAlive();
				}
			}
			// 10 seconds
		}, 200, 200);
		getServer().getScheduler().runTaskTimer(this, new Runnable() {
			boolean b = false;
			@Override
			public void run() {
				if (!b) {
					int c = 0;
					for (World world : Bukkit.getWorlds())
						for (Entity entity : world.getEntities())
							if (entity instanceof Creature || entity.getType().equals(EntityType.DROPPED_ITEM) || entity.getType().equals(EntityType.FALLING_BLOCK)) {
								if (entity.isDead()) continue;
								c++;
							}
					console.sendMessage("§b§l➤ §r§a" + c + " entité" + (c > 1 ? "s" : "") + "!");
					b = true;
				}
				OperatingSystemMXBean operatingSystemMXBean = (OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean();
				long freeMemory = operatingSystemMXBean.getFreePhysicalMemorySize() / (1024 * 1024);
				double cpuLoad = (operatingSystemMXBean.getProcessCpuLoad() + operatingSystemMXBean.getSystemCpuLoad()) * 100;
				console.sendMessage("§b§l➤ §r§7Instance" + (getOpenedServers() > 1 ? "s" : "") + ": " + getOpenedServers() + " | CPU: " + round(cpuLoad, 2) + "% | FREEMEM: " + round(freeMemory, 2) + "MB");
				getServer().dispatchCommand(console, "tps");
				System.out.println("--------- GSInspector - CPU ---------");
				double cpu = 0.0D;
				for (Method method : operatingSystemMXBean.getClass().getDeclaredMethods()) {
					method.setAccessible(true);
					if (method.getName().startsWith("get") && Modifier.isPublic(method.getModifiers())) {
						Object value;
						try {
							value = method.invoke(operatingSystemMXBean);
						} catch (Exception e) {
							value = e;
						}
						if (method.getName().equals("getSystemCpuLoad")) cpu = (double) value * 100;
					}
				}
				int mb = 1024*1024;
				double ram = (Runtime.getRuntime().maxMemory() - Runtime.getRuntime().freeMemory()) / mb;
				double max = Runtime.getRuntime().maxMemory() / mb;
				System.out.println("CPU : " + cpu + " / RAM : " + ram + "/" + max + " - (Usage: " + String.format("%.2f", ram * 100D / max) + "%)");
				System.out.println("--------- GSInspector - Entities ---------");
				int nbPlayers = Bukkit.getOnlinePlayers().size();
				int nbEntities = 0;
				for (World world : Bukkit.getWorlds())
					for (Entity entity : world.getEntities())
						if (!entity.isDead()) nbEntities++;
				System.out.println("Joueurs en ligne: " + nbPlayers + "/" + Bukkit.getMaxPlayers() + " / Total d'entitées: " + nbEntities);
				Map<String, Integer> chunks = new HashMap<>();
				for (World world : Bukkit.getWorlds()) {
					synchronized (world.getLoadedChunks()) {
						chunks.put(world.getName(), world.getLoadedChunks().length);
					}
					Map<EntityType, Integer> maps = new HashMap<>();
					for (Entity entity : world.getEntities()) {
						if (entity.isDead()) continue;
						if (!maps.containsKey(entity.getType()))
							maps.put(entity.getType(), 1);
						else maps.put(entity.getType(), maps.get(entity.getType()) + 1);
					}
					String builder = world.getName() + " (" + chunks.get(world.getName()) + " chunks loaded) >";
					for (Entry<EntityType, Integer> entry : maps.entrySet())
						builder += " " + entry.getKey().name() + "(" + entry.getValue() + ")";
					System.out.println(builder);
				}
				System.out.println("--------- GSInspector - Scheduler ---------");
				System.out.println("Tâches en attente : " + Bukkit.getScheduler().getPendingTasks().size() + " | Tâches en actif : " + Bukkit.getScheduler().getActiveWorkers().size() + " | Threads en actif : " + Thread.getAllStackTraces().size());
			}
			// 2 minutes
		}, 0, 2400);
		getServer().getScheduler().runTaskTimerAsynchronously(this, new Runnable() {
			@Override
			public void run() {
				if (!available) return;
				boolean current = GameState.instance.isJoinable();
				if (current != last)
					keepAlive();
				last = current;
			}
		}, 1, 1);
		getServer().getScheduler().runTaskLater(this, new Runnable() {
			@SuppressWarnings("rawtypes")
			@Override
			public void run() {
				try {
					Class clazz = Class.forName("fr.badblock.api.MJPlugin");
					if (clazz != null) {
						setAPI(true);
						GameState.instance = new APIGameState();
						try {
							MJPlugin mjPlugin = MJPlugin.getInstance();
							double xpBoost = getConfig().getDouble("boost.xp", 1);
							mjPlugin.setBoostXP(xpBoost);
							console.sendMessage("§b§l➤ §r§b§eBoostXP: §6" + xpBoost + "§e.");
							setBoostXP(xpBoost);
							double badCoinsBoost = getConfig().getDouble("boost.badcoins", 1);
							mjPlugin.setBoostBadcoins(badCoinsBoost);
							setBoostBadcoins(badCoinsBoost);
							console.sendMessage("§b§l➤ §r§b§eBoostCoins: §6" + badCoinsBoost + "§e.");
						} catch (Exception e) {
							e.printStackTrace();
						}
					}	
				}catch(Exception error) {
					error.printStackTrace();
				}
				console.sendMessage("§a§l➤ §r§aState fetcher set to " + GameState.instance.getClass().getName());
				keepAlive();
				available = true;
			}
		}, 1);
		for (World world : Bukkit.getWorlds())
			world.setAutoSave(false);
		/*Bukkit.getScheduler().runTaskTimer(instance, new Runnable() {
			@Override
			public void run() {
				Calendar now = Calendar.getInstance();
				int hour = now.get(Calendar.HOUR_OF_DAY);
				int minute = now.get(Calendar.MINUTE);
				int second = now.get(Calendar.SECOND);
				if (hour == 4 && minute == 0 && second == 55) Bukkit.broadcastMessage("§7[§bBadBlock§7] §cRedémarrage du serveur dans 1 heure.");
				else if (hour == 4 && minute == 15 && second == 0) Bukkit.broadcastMessage("§7[§bBadBlock§7] §cRedémarrage du serveur dans 45 minutes.");
				else if (hour == 4 && minute == 30 && second == 55) Bukkit.broadcastMessage("§7[§bBadBlock§7] §cRedémarrage du serveur dans 30 minutes.");
				else if (hour == 4 && minute == 45 && second == 55) Bukkit.broadcastMessage("§7[§bBadBlock§7] §cRedémarrage du serveur dans 15 minutes.");
				else if (hour == 4 && minute == 50 && second == 55) Bukkit.broadcastMessage("§7[§bBadBlock§7] §cRedémarrage du serveur dans 10 minutes.");
				else if (hour == 4 && minute == 54 && second == 55) Bukkit.broadcastMessage("§7[§bBadBlock§7] §cRedémarrage du serveur dans 5 minutes.");
				else if (hour == 4 && minute == 55 && second == 55) Bukkit.broadcastMessage("§7[§bBadBlock§7] §cRedémarrage du serveur dans 4 minutes.");
				else if (hour == 4 && minute == 56 && second == 55) Bukkit.broadcastMessage("§7[§bBadBlock§7] §cRedémarrage du serveur dans 3 minutes.");
				else if (hour == 4 && minute == 57 && second == 55) Bukkit.broadcastMessage("§7[§bBadBlock§7] §cRedémarrage du serveur dans 2 minutes.");
				else if (hour == 4 && minute == 58 && second == 55) Bukkit.broadcastMessage("§7[§bBadBlock§7] §cRedémarrage du serveur dans 1 minute.");
				else if (hour == 4 && minute == 59 && second == 25) Bukkit.broadcastMessage("§7[§bBadBlock§7] §cRedémarrage du serveur dans 30 secondes.");
				else if (hour == 4 && minute == 59 && second == 40) Bukkit.broadcastMessage("§7[§bBadBlock§7] §cRedémarrage du serveur dans 15 secondes.");
				else if (hour == 4 && minute == 59 && second == 45) Bukkit.broadcastMessage("§7[§bBadBlock§7] §cRedémarrage du serveur dans 10 secondes.");
				else if (hour == 4 && minute == 59 && second == 50) Bukkit.broadcastMessage("§7[§bBadBlock§7] §cRedémarrage du serveur dans 5 secondes.");
				else if (hour == 4 && minute == 59 && second == 51) Bukkit.broadcastMessage("§7[§bBadBlock§7] §cRedémarrage du serveur dans 4 secondes.");
				else if (hour == 4 && minute == 59 && second == 52) Bukkit.broadcastMessage("§7[§bBadBlock§7] §cRedémarrage du serveur dans 3 secondes.");
				else if (hour == 4 && minute == 59 && second == 53) Bukkit.broadcastMessage("§7[§bBadBlock§7] §cRedémarrage du serveur dans 2 secondes.");
				else if (hour == 4 && minute == 59 && second == 54) Bukkit.broadcastMessage("§7[§bBadBlock§7] §cRedémarrage du serveur dans 1 seconde.");
				else if (hour == 4 && minute == 59 && second == 55) Bukkit.broadcastMessage("§7[§bBadBlock§7] §cRedémarrage du serveur...");
			}
		}, 0, 20);

		int rebootHour = 4;
		int rebootMinute = 59;
		int rebootSeconds = 56;

		Calendar now = Calendar.getInstance();
		Calendar nextReboot = (Calendar) now.clone();

		nextReboot.set(Calendar.HOUR_OF_DAY, rebootHour);
		nextReboot.set(Calendar.MINUTE, rebootMinute);
		nextReboot.set(Calendar.SECOND, rebootSeconds);

		long diff = nextReboot.getTimeInMillis() - now.getTimeInMillis();
		//System.out.println("Now = " + now.getTime().toString());
		// Pass�
		if (diff <= 0) nextReboot.add(Calendar.DAY_OF_YEAR, 1);
		//System.out.println("Reboot Scheduled = " + nextReboot.getTime().toString());
		final Timer timer = new Timer();
		now.getTime();
		timer.schedule(new TimerTask() {
			@Override
			public void run() {
				Bukkit.getScheduler().runTask(instance, new Runnable() {
					@Override
					public void run() {
						for (Player player : Bukkit.getOnlinePlayers()) 
							player.kickPlayer("§cRedémarrage de BadBlock !");
						Bukkit.broadcastMessage("§§3Time to reboot. (5am)");
						Bukkit.shutdown();
						timer.cancel();
					}
				});
			}
		}, nextReboot.getTime());*/
		if (logsFile != null && logsFile.split("/") != null) {
			canBeLogged = true;
			String string = logsFile.split("/")[0];
			BadblockDatabase.getInstance().addRequest(new Request("SELECT * FROM config_template", RequestType.GETTER) {
				@Override
				public void done(ResultSet resultSet) {
					this.setDoNotClose(true);
					try {
						while (resultSet.next()) {
							String key = resultSet.getString("key");
							ConfigTemplate configTemplate = new ConfigTemplate(resultSet.getInt("id"), key, resultSet.getString("material"), resultSet.getString("type"), resultSet.getString("displayName"), resultSet.getString("lore"));
							configTemplates.put(key, configTemplate);
						}
						resultSet.close();
						BadblockDatabase.getInstance().addRequest(new Request("SELECT * FROM config_systems WHERE prefix = '" + string + "'", RequestType.GETTER) {
							@SuppressWarnings({ "deprecation", "unchecked" })
							@Override
							public void done(ResultSet resultSet) {
								try {
									while (resultSet.next()) {
										ConfigSystem configSystem = new ConfigSystem(configTemplates.get(resultSet.getString("key")), resultSet.getInt("defaultInt"), resultSet.getInt("minInt"), resultSet.getInt("maxInt"), resultSet.getBoolean("defaultBool"));
										configz.add(configSystem);
										int o = ((configz.size() + 4) / 9) + 1;
										inventory = getServer().createInventory(null, o * 9, "§bConfigurer son serveur");
										ItemStack itemStack = new ItemStack(Material.getMaterial(configSystem.getConfigTemplate().getMaterial()));
										ItemMeta itemMeta = itemStack.getItemMeta();
										itemMeta.setDisplayName(configSystem.getConfigTemplate().getDisplayName().replace("%0", Integer.toString(configSystem.getDefaultInt())));
										List<String> lore = new ArrayList<>();
										for (String l : configSystem.getConfigTemplate().getLore().split(","))
											lore.add(l.replace("%0", Integer.toString(configSystem.getDefaultInt())));
										itemMeta.setLore(lore);
										itemStack.setItemMeta(itemMeta);
										itemStacks.put(configSystem.getConfigTemplate().getId(), itemStack);
										configss.put(itemStack.getItemMeta().getDisplayName(), configSystem);
										Inventory inv = Bukkit.createInventory(null, 9, itemStack.getItemMeta().getDisplayName());
										ItemStack close = new ItemStack(Material.WOOL, -5, DyeColor.RED.getWoolData());
										itemMeta = close.getItemMeta();
										itemMeta.setDisplayName("§c-5");
										close.setItemMeta(itemMeta);
										inv.setItem(0, close);
										close = new ItemStack(Material.WOOL, -1, DyeColor.ORANGE.getWoolData());
										itemMeta = close.getItemMeta();
										itemMeta.setDisplayName("§6-1");
										close.setItemMeta(itemMeta);
										inv.setItem(1, close);
										inv.setItem(3, itemStack);
										close = new ItemStack(Material.WOOL, 1, DyeColor.LIME.getWoolData());
										itemMeta = close.getItemMeta();
										itemMeta.setDisplayName("§a+1");
										close.setItemMeta(itemMeta);
										inv.setItem(5, close);
										close = new ItemStack(Material.WOOL, 5, DyeColor.GREEN.getWoolData());
										itemMeta = close.getItemMeta();
										itemMeta.setDisplayName("§2+5");
										close.setItemMeta(itemMeta);
										inv.setItem(6, close);
										close = new ItemStack(Material.WOOD_DOOR);
										itemMeta = close.getItemMeta();
										itemMeta.setDisplayName("§cRetour");
										close.setItemMeta(itemMeta);
										inv.setItem(8, close);
										configInventories.put(configSystem, inv);
									}
									ItemStack close = new ItemStack(Material.WOOD_DOOR);
									ItemMeta itemMeta = close.getItemMeta();
									itemMeta.setDisplayName("§cQuitter");
									close.setItemMeta(itemMeta);
									ItemStack game = new ItemStack(Material.DIODE);
									itemMeta = game.getItemMeta();
									itemMeta.setDisplayName("§bGestion du status la partie");
									itemMeta.setLore(Arrays.asList("", "§7Démarrez une partie §bde force §7ou §béteignez la !", "§7> §b/game <start/stop>"));
									game.setItemMeta(itemMeta);
									ItemStack whitelist = new ItemStack(Material.BOOK_AND_QUILL);
									itemMeta = whitelist.getItemMeta();
									itemMeta.setDisplayName("§aListe blanche (whitelist)");
									itemMeta.setLore(Arrays.asList("", "§7Gérez la liste blanche efficacement !", "§7 > §b/whitelist <on/off/add/remove/list> [player]"));
									whitelist.setItemMeta(itemMeta);
									Map<Integer, ItemStack> treeMap = sortByKey(itemStacks);
									inventory.setItem(inventory.getSize() - 1, close);
									inventory.setItem(inventory.getSize() - 2, whitelist);
									inventory.setItem(inventory.getSize() - 3, game);
									for (ItemStack is : treeMap.values())
										inventory.addItem(is);
									loadCustomConfig();
								}catch(Exception error) {
									error.printStackTrace();
								}
							}
						});
					}catch(Exception error) {
						error.printStackTrace();
					}
				}
			});
			int i = Integer.parseInt(serverName.replace(string, "").replace("_", ""));
			badblockDatabase.addRequest(new Request("INSERT INTO gameservers(name, currentId, timestamp, logFile) VALUES('" + string + "', '" + i + "', '" + System.currentTimeMillis() + "', '" + logsFile + "')", RequestType.SETTER));
		}
		ItemStack itemStack = new ItemStack(Material.ENDER_CHEST);
		ItemMeta itemMeta = itemStack.getItemMeta();
		itemMeta.setDisplayName("§bConfigurer le serveur");
		itemMeta.setLore(Arrays.asList("", "§7> §bConfigurez §7le serveur", "§7comme vous le souhaitez", "§7et devenez hôte de celle-ci!"));
		itemStack.setItemMeta(itemMeta);
		this.setConfigItem(itemStack);
	}

	@SuppressWarnings("rawtypes")
	public void loadCustomConfig() throws ReflectiveOperationException {
		for (ConfigSystem configSystem : this.configz) {
			System.out.println(configSystem.defaultBool + " / " + configSystem.maxInt + " / " + configSystem.minInt + " / " + configSystem.configTemplate);
			if (configSystem.getConfigTemplate().getKey().equals("slots")) {
				setMaxPlayers(configSystem.getDefaultInt());
				MJPlugin.getInstance().getConfig().set("maxPlayers", configSystem.getDefaultInt());
			}else if (configSystem.getConfigTemplate().getKey().equals("minPlayers")) {
				MJPlugin.getInstance().getConfig().set("minPlayers", configSystem.getDefaultInt());
			}else if (configSystem.getConfigTemplate().getKey().equals("team9")) {
				setMaxPlayers(configSystem.getDefaultInt() * 9);
				Field field = TeamsManager.class.getDeclaredField("maxPlayerInTeam");
				field.setAccessible(true);
				field.setInt(TeamsManager.getInstance(), configSystem.getDefaultInt());
				MJPlugin.getInstance().getConfig().set("playersByTeam", configSystem.getDefaultInt());
			}else if (configSystem.getConfigTemplate().getKey().equals("team4")) {
				setMaxPlayers(configSystem.getDefaultInt() * 4);
				Field field = TeamsManager.class.getDeclaredField("maxPlayerInTeam");
				field.setAccessible(true);
				field.setInt(TeamsManager.getInstance(), configSystem.getDefaultInt());
				MJPlugin.getInstance().getConfig().set("playersByTeam", configSystem.getDefaultInt());
			}else if (configSystem.getConfigTemplate().getKey().equals("team2")) {
				setMaxPlayers(configSystem.getDefaultInt() * 2);
				Field field = TeamsManager.class.getDeclaredField("maxPlayerInTeam");
				field.setAccessible(true);
				field.setInt(TeamsManager.getInstance(), configSystem.getDefaultInt());
				MJPlugin.getInstance().getConfig().set("playersByTeam", configSystem.getDefaultInt());
			}else if (configSystem.getConfigTemplate().getKey().equals("points")) {
				Class clazz = Class.forName("com.lelann.tower.PluginTower");
				if (clazz != null) {
					Field field = PluginTower.class.getDeclaredField("points");
					field.setAccessible(true);
					field.setInt(PluginTower.getInstance(), configSystem.getDefaultInt());
				}
			}
		}
		MJPlugin.getInstance().saveConfig();
	}

	public static void setMaxPlayers(int maxPlayers)
			throws ReflectiveOperationException {
		String bukkitversion = Bukkit.getServer().getClass().getPackage()
				.getName().substring(23);
		Object playerlist = Class.forName("org.bukkit.craftbukkit." + bukkitversion    + ".CraftServer")
				.getDeclaredMethod("getHandle", null).invoke(Bukkit.getServer(), null);
		Field maxplayers = playerlist.getClass().getSuperclass()
				.getDeclaredField("maxPlayers");
		maxplayers.setAccessible(true);

		maxplayers.set(playerlist, maxPlayers);
	}

	static void setStatic(Field field, Object newValue) throws Exception {
		field.setAccessible(true);
		field.set(null, newValue);
	}

	private double round(double value, int places) {
		if (places < 0) throw new IllegalArgumentException();

		BigDecimal bd = new BigDecimal(value);
		bd = bd.setScale(places, RoundingMode.HALF_UP);
		return bd.doubleValue();
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static Map sortByKey(Map unsortedMap){
		Map sortedMap = new TreeMap();
		sortedMap.putAll(unsortedMap);
		return sortedMap;
	}

	@SuppressWarnings("unused")
	public int getOpenedServers() {
		int openServers = 0;
		try {
			Runtime rt = Runtime.getRuntime();
			Process p = rt.exec("docker ps");
			try {
				p.waitFor();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			BufferedReader reader = new BufferedReader(new InputStreamReader(
					p.getInputStream()));
			String line = "";

			while ((line = reader.readLine()) != null) {
				openServers++;
			}
		}catch(Exception e) {
			return 0;
		}
		return openServers;
	}

	@Override
	public void onLoad() {
		setInstance(this);
		setJoinTime(System.currentTimeMillis() + 1800_000L);
		this.reloadConfig();
		String fileName = "server.properties";
		this.console = this.getServer().getConsoleSender();
		FileConfiguration configuration = this.getConfig();
		String rabbitHostname = configuration.getString("rabbit.hostname");
		this.setMysqlHostname(configuration.getString("mysql.hostname"));
		this.setMysqlPort(configuration.getInt("mysql.port"));
		this.setMysqlUsername(configuration.getString("mysql.username"));
		this.setMysqlPassword(configuration.getString("mysql.password"));
		this.setMysqlDatabase(configuration.getString("mysql.database"));
		this.setDocker(configuration.getBoolean("docker"));
		console.sendMessage("§b§l➤ §r§bVersion: " + version);
		List<String> lines = null;
		try {
			lines = Files.readAllLines(Paths.get(fileName), Charset.defaultCharset());
		} catch (IOException e) {
			e.printStackTrace();
		}
		for (String line : lines) {
			if (line.startsWith("docker-started=")) {
				long reste = Long.parseLong(line.replace("docker-started=", ""));
				long time = System.currentTimeMillis() - reste;
				console.sendMessage("§b§l➤ §r§b§6Loaded instance in " + time / 1000D + " secondes.");
			}else if (line.startsWith("docker-mode=")) {
				String mode = line.replace("docker-mode=", "");
				console.sendMessage("§b§l➤ §r§b§eSelected §6" + mode + " §emode.");
			} else if (line.startsWith("docker-map=")) {
				String map = line.replace("docker-map=", "");
				console.sendMessage("§b§l➤ §r§b§eWorld: §6" + map + "§e.");
			}else if (line.startsWith("server-name=")) {
				serverName = line.replace("server-name=", "");
				console.sendMessage("§b§l➤ §r§b§eServer name: §6" + serverName + "§e.");
			}else if (line.startsWith("docker-prefix=")) {
				String prefix = line.replace("docker-prefix=", "");
				console.sendMessage("§b§l➤ §r§b§eScreen name: §6" + prefix + "§e.");
			}else if (line.startsWith("docker-logs=")) {
				logsFile = line.replace("docker-logs=", "");
				console.sendMessage("§b§l➤ §r§b§eLogs file: §6" + logsFile + "§e.");
			}else if (line.startsWith("docker-fi=")) {
				String furtherInformation = line.replace("docker-fi=", "");
				console.sendMessage("§b§l➤ §r§b§eFurther information: §6" + furtherInformation + "§e.");
			}else if (line.startsWith("rabbit-hostname=")) {
				rabbitHostname = line.replace("rabbit-hostname=", "");
				console.sendMessage("§b§l➤ §r§b§eRabbit hostname: §6" + rabbitHostname + "§e.");
			}
		}
		console.sendMessage("§b§l➤ §r§b§aServer is working with Docker for BadBlock by xMalware.");
		String rabbitPassword = configuration.getString("rabbit.password");
		this.setRabbitConnector(RabbitConnector.getInstance());
		this.setRabbitService(this.getRabbitConnector().newService("default", rabbitHostname, 5672, "root", rabbitPassword, "rabbit"));
		String ftpHostname = configuration.getString("ftp.hostname");
		String ftpUsername = configuration.getString("ftp.username");
		String ftpPassword = configuration.getString("ftp.password");
		int	   ftpPort     = configuration.getInt("ftp.port");
		setLogSenderThread(new LogSenderThread(ftpHostname, ftpUsername, ftpPassword, ftpPort));
		setServerName(this.getServer().getServerName());
	}

	@SuppressWarnings("deprecation")
	@Override
	public void onDisable() {
		console.sendMessage("§b§l➤ §r§b§eUnloading...");
		this.getServer().dispatchCommand(this.getServer().getConsoleSender(), "timings paste");
		getLogSenderThread().doLog();
		if (BadblockDatabase.getInstance().isConnected())
			try {
				BadblockDatabase.getInstance().closeConnection();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		this.getRabbitService().sendSyncPacket(RabbitQueue.INSTANCE_STOP.getQueueName(), getServerName(), Encodage.UTF8, RabbitPacketType.PUBLISHER, 5000, false);
		console.sendMessage("§b§l➤ §r§b§aUnloaded!");
		if (this.isDocker()) {
			File currentPath = new File(".");
			deleteDirectory(currentPath);
			try {
				Runtime runtime = Runtime.getRuntime();
				Process process = runtime.exec("rm -R " + currentPath.getAbsolutePath());
				process.waitFor();
			}catch(Exception error) {
				error.printStackTrace();
			}
		}
	}

	public boolean deleteDirectory(File path) {
		if( path.exists() ) {
			File[] files = path.listFiles();
			for(int i=0; i<files.length; i++) {
				if(files[i].isDirectory()) {
					deleteDirectory(files[i]);
				}
				else {
					files[i].delete();
				}
			}
		}
		return( path.delete() );
	}

	public void keepAlive() {
		Server server = getServer();
		GameAliveFactory gameAliveFactory = new GameAliveFactory(this.getServerName(), GameState.instance.isJoinable(), getOnlinePlayers(), server.getMaxPlayers());
		this.getRabbitService().sendPacket(RabbitQueue.INSTANCE_KEEPALIVE.getQueueName(), this.getGson().toJson(gameAliveFactory), Encodage.UTF8, RabbitPacketType.PUBLISHER, 5000, false);
	}

	public int getOnlinePlayers() {
		return Bukkit.getOnlinePlayers().size();
	}

}
