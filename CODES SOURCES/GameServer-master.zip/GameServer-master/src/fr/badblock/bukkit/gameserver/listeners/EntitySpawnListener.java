package fr.badblock.bukkit.gameserver.listeners;

import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;

public class EntitySpawnListener implements Listener {
	
	@EventHandler (priority = EventPriority.MONITOR, ignoreCancelled = true)
	public void onCreatureSpawn(CreatureSpawnEvent event) {
		/*System.out.println("[GS-DEBUG] SPAWN: " + event.getEntityType().name() + " | " + event.getSpawnReason().name());
		if (!GameState.instance.isPlaying() && !event.getEntityType().equals(EntityType.PLAYER)) event.setCancelled(true);
		else {
			Entity entit = event.getEntity();
			World world = entit.getWorld();
			long count = world.getEntities().stream().filter(entity -> entity.getType().equals(entit.getType())).count();
			if (count >= 50) event.setCancelled(true);
		}*/
	}
	
}
