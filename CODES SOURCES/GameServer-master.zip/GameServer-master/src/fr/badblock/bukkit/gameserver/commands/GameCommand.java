package fr.badblock.bukkit.gameserver.commands;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import fr.badblock.api.MJPlugin;
import fr.badblock.api.MJPlugin.GameStatus;
import fr.badblock.bukkit.gameserver.GameServer;

public class GameCommand implements CommandExecutor {

	@Override
	public boolean onCommand(CommandSender sender, Command command, String arg, String[] args) {
		if (args.length == 1 && args[0].equalsIgnoreCase("start") && sender.hasPermission("game.manage.start")) {
			if (!GameServer.getInstance().isAPI()) return true;
			MJPlugin mjPlugin = MJPlugin.getInstance();
			if (!mjPlugin.getStatus().equals(GameStatus.WAITING_PLAYERS)) {
				sender.sendMessage("§cLa partie est déjà lancée.");
				return true;
			}
			Bukkit.getConsoleSender().sendMessage("§a" + sender.getName() + " has launched the game!");
			Bukkit.broadcastMessage("§b" + sender.getName() + " §7a démarré le compte à rebours !");
			mjPlugin.setStatus(GameStatus.STARTING);
			mjPlugin.start();
			sender.sendMessage("§aVous avez démarré le compte à rebours.");
		}else if (args.length == 1 && args[0].equalsIgnoreCase("stop") && sender.hasPermission("game.manage.stop")) {
			if (!GameServer.getInstance().isAPI()) return true;
			MJPlugin mjPlugin = MJPlugin.getInstance();
			Bukkit.broadcastMessage("§b" + sender.getName() + " §7a stoppé la partie !");
			sender.sendMessage("§aVous avez stoppé la partie.");
			for (Player player : Bukkit.getOnlinePlayers())
				mjPlugin.kick(player);
			Bukkit.getConsoleSender().sendMessage("§c" + sender.getName() + " has stopped the game!");
			Bukkit.getScheduler().runTaskLater(MJPlugin.getInstance(), new Runnable() {
				@Override
				public void run() {
					Bukkit.shutdown();
				}
			}, 20 * 5);
		}else if (sender.hasPermission("game.manage"))
			sender.sendMessage("§cUsage: /game <start/stop>");
		else sender.sendMessage("§cVous n'avez pas la permission de gérer le status de la partie.");
		return true;
	}

}
