package fr.badblock.bukkit.gameserver.commands;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import fr.badblock.bukkit.gameserver.GameServer;

public class LagCommand implements CommandExecutor {

	private static SimpleDateFormat		simpleDateFormat			= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	@Override
	public boolean onCommand(CommandSender sender, Command command, String arg, String[] args) {
		send(sender);
		return true;
	}

	public static void send(CommandSender sender) {
		GameServer instance = GameServer.getInstance();
		sender.sendMessage("§8§l«§b§l-§8§l»§m------§f§8§l«§b§l-§8§l»§b §b§lLag §8§l«§b§l-§8§l»§m------§f§8§l«§b§l-§8§l»");
		sender.sendMessage("§c> §7Nom du serveur: §b" + instance.getServerName());
		sender.sendMessage("§c> §7Heure: §b" + simpleDateFormat.format(new Date()));
		double lagPercent = (getPassMarkTps() / 20.0D * 100.0D);
		double speed = round(lagPercent, 2);
		String rapidity = speed >= 90 ? "§a" + speed : speed >= 80 ? "§b" + speed : speed >= 50 ? "§e" + speed : speed >= 30 ? "§c" + speed : speed >= 20 ? "§4" + speed : "§4§l" + speed; 
		sender.sendMessage("§c> §7Fluidité: " + rapidity + " %");
		if (sender instanceof Player) {
			Player player = (Player) sender;
			int ping = getPing(player);
			String ms = ping < 80 ? "§a" + ping : ping <= 100 ? "§b" + ping : ping < 200 ? "§e" + ping : ping < 300 ? "§c" + ping : ping < 500 ? "§4" + ping : "§4§l" + ping; 
			sender.sendMessage("§c> §7Ping: " + ms + " §7ms");
		}
		sender.sendMessage("§8§l«§b§l-§8§l»§m----------------------§f§8§l«§b§l-§8§l»§b");
	}

	static int getPing(Player player) {
		try {
			String bukkitversion = Bukkit.getServer().getClass().getPackage().getName().substring(23);
			Class<?> craftPlayer = Class.forName("org.bukkit.craftbukkit." + bukkitversion + ".entity.CraftPlayer");
			Object handle = craftPlayer.getMethod("getHandle").invoke(player);
			Integer ping = (Integer) handle.getClass().getDeclaredField("ping").get(handle);
			return ping.intValue();
		} catch (ClassNotFoundException | IllegalAccessException
				| IllegalArgumentException | InvocationTargetException
				| NoSuchMethodException | SecurityException
				| NoSuchFieldException e) {
			return -1;
		}
	}

	static double round(double value, int places) {
		if (places < 0) throw new IllegalArgumentException();
		BigDecimal bd = new BigDecimal(value);
		bd = bd.setScale(places, RoundingMode.HALF_UP);
		return bd.doubleValue();
	}

	static double getPassMarkTps() {
		try {
			String bukkitversion = Bukkit.getServer().getClass().getPackage() .getName().substring(23);
			Class<?> craftPlayer = Class.forName("net.minecraft.server." + bukkitversion + ".MinecraftServer");
			Object handle = craftPlayer.getDeclaredMethod("getServer").invoke(null);
			Field field = handle.getClass().getField("recentTps");
			field.setAccessible(true);
			double[] original = (double[]) field.get(handle);
			double[] tps = new double[original.length];
			double total = 0.0D;
			for (int x = 0; x < original.length; x++) {
				double value = original[x];
				if (value > 20.0D) {
					value = 20.0D;
				} else if (value < 0.0D) {
					value = 0.0D;
				}
				tps[x] = value;
				total += value;
			}
			total /= original.length;
			return total;
		} catch (ClassNotFoundException | IllegalAccessException
				| IllegalArgumentException | InvocationTargetException
				| NoSuchMethodException | SecurityException
				| NoSuchFieldException e) {
			e.printStackTrace();
			return -1;
		}
	}


}
