package fr.badblock.bukkit.gameserver.state;

import fr.badblock.api.MJPlugin;
import fr.badblock.api.MJPlugin.GameStatus;

public class APIGameState extends GameState {

	@Override
	public boolean isJoinable() {
		return MJPlugin.getInstance().getStatus().equals(GameStatus.WAITING_PLAYERS) || MJPlugin.getInstance().getStatus().equals(GameStatus.STARTING);
	}

	@Override
	public boolean isPlaying() {
		return MJPlugin.getInstance().getStatus().equals(GameStatus.PLAYING) || MJPlugin.getInstance().getStatus().equals(GameStatus.STARTING);
	}

	@Override
	public boolean isEnding() {
		return MJPlugin.getInstance().getStatus().equals(GameStatus.ENDING);
	}

}
