package fr.badblock.bukkit.gameserver.threading;

/**
 * A CustomThread can manage a multithreading support with easiness.
 * @author xMalware
 */
public abstract class CustomThread {
	
	// Private final fields
	private final Thread thread;
	
	/**
	 * Constructor of the CustomThread
	 * @param name > the name of the thread
	 */
	public CustomThread(String name) {
		this.thread = new Thread(name) {
			@Override
			public void run() {
				done();
			}
		};
	}
	
	/**
	 * Starting the thread
	 * @return
	 */
	public CustomThread start() {
		this.getThread().start();
		return this;
	}
	
	/**
	 * When the thread was call
	 */
	public abstract void done();
	
	/**
	 * Getting the generated thread
	 * @return
	 */
	public Thread getThread() {
		return this.thread;
	}
	
	/**
	 * Wait the thread
	 */
	public void threadWait() {
		synchronized (thread) {
			try {
				thread.wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * Notify the thread;
	 */
	public void threadNotify() {
		synchronized (thread) {
			thread.notify();
		}
	}
	
}
