package fr.badblock.bukkit.gameserver.listeners;

import java.util.HashMap;
import java.util.Map;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerItemHeldEvent;

import fr.badblock.bukkit.gameserver.commands.FreezeCommand;

public class PlayerHeldItemSlotListener implements Listener {

	private Map<String, Long> lastWarned = new HashMap<>();

	@EventHandler (priority = EventPriority.LOWEST)
	public void onInventoryInteract(PlayerItemHeldEvent event) {
		Player player = event.getPlayer();
		if (FreezeCommand.playerNames.contains(player.getName())) {
			event.setCancelled(true);
			long time = System.currentTimeMillis();
			if (!lastWarned.containsKey(player.getName()) || lastWarned.get(player.getName()) < time) {
				lastWarned.put(player.getName(), time + 1_000L);
				player.sendMessage("§cVous êtes actuellement congelé, vous ne pouvez pas intéragir.");
			}
		}
	}

}