package fr.badblock.bukkit.gameserver.config;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter public class ConfigSystem {

	public ConfigTemplate 	configTemplate;
	public int				defaultInt;
	public int				minInt;
	public int				maxInt;
	public boolean			defaultBool;

	public ConfigSystem(ConfigTemplate configTemplate, int defaultInt, int minInt, int maxInt, boolean defaultBool) {
		this.setConfigTemplate(configTemplate);
		this.setDefaultInt(defaultInt);
		this.setMinInt(minInt);
		this.setMaxInt(maxInt);
		this.setDefaultBool(defaultBool);
	}
	
}
