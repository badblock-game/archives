package fr.badblock.bukkit.gameserver.commands;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class FreezeCommand implements CommandExecutor {

	public static List<String> playerNames		 =		new ArrayList<>();
	
	@Override
	public boolean onCommand(CommandSender sender, Command command, String arg, String[] args) {
		send(sender, args);
		return true;
	}

	public static void send(CommandSender sender, String[] args) {
		if (!sender.hasPermission("freeze.modo")) {
			sender.sendMessage("§cVous n'avez pas le droit de congeler les joueurs !");
			return;
		}
		if (args.length != 1) {
			sender.sendMessage("§cUsage: /freeze <pseudo>");
			return;
		}
		String pseudo = args[0];
		Player player = Bukkit.getPlayer(pseudo);
		if (player == null || !player.isOnline()) {
			sender.sendMessage("§cCe joueur n'est pas connecté.");
			return;
		}
		if (player.hasPermission("freeze.modo") && !sender.hasPermission("freeze.admin")) {
			sender.sendMessage("§cVous ne pouvez pas congeler ce joueur !");
			return;
		}
		// Already freezed
		if (playerNames.contains(player.getName())) {
			playerNames.remove(player.getName());
			sender.sendMessage("§a" + player.getName() + " n'est désormais §cplus §acongelé.");
			player.sendMessage("§a§lVous êtes désormais libre !");
			return;
		}
		playerNames.add(player.getName());
		sender.sendMessage("§a" + player.getName() + " est désormais congelé.");
		player.sendMessage("§c§lVous êtes désormais congelé par un modérateur !");
	}

}
