package fr.badblock.bukkit.gameserver.listeners;

import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import fr.badblock.bukkit.gameserver.GameServer;

public class PlayerQuitListener implements Listener {

	@EventHandler (priority = EventPriority.LOWEST)
	public void onPlayerQuit(PlayerQuitEvent event) {
		Bukkit.getScheduler().runTaskLaterAsynchronously(GameServer.getInstance(), new Runnable() {
			@Override
			public void run() {
				GameServer gameServer = GameServer.getInstance();
				gameServer.setJoinTime(System.currentTimeMillis() + 300_000L);
				gameServer.keepAlive();
			}
		}, 1);
		/*Player player = event.getPlayer();
		GameServer gameServer = GameServer.getInstance();*/
		//if (gameServer.getPlayers().containsKey(player.getName()) && System.currentTimeMillis() - gameServer.getPlayers().get(player.getName()) >= 10000) return;
		/*if (gameServer.isAPI()) {
			BPlayer bPlayer = BPlayersManager.getInstance().getPlayer(player);
			if (isInLeaverBusterMode(player)) {
				BadblockDatabase.getInstance().addRequest(new Request("INSERT INTO penalities(pseudo) VALUES('" + player.getName() + "')", RequestType.SETTER));
				BadblockDatabase.getInstance().addRequest(new Request("INSERT INTO penalities_history(pseudo, timestamp) VALUES('" + player.getName() + "', '" + System.currentTimeMillis() + "')", RequestType.SETTER));
			}
		}*/
	}
	
	@EventHandler
	public void onPlayerKick(PlayerKickEvent event) {
	}
	
	/*public static boolean isInLeaverBusterMode(Player player) {
		BPlayer bPlayer = BPlayersManager.getInstance().getPlayer(player);
		return bPlayer != null && !bPlayer.isSpectator() && GameState.instance.isPlaying();
	}*/
}