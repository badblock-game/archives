package fr.badblock.bukkit.gameserver.listeners;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.bukkit.Bukkit;
import org.bukkit.DyeColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import fr.badblock.bukkit.gameserver.GameServer;
import fr.badblock.bukkit.gameserver.commands.FreezeCommand;
import fr.badblock.bukkit.gameserver.config.ConfigSystem;

public class InventoryClickListener implements Listener {

	private Map<String, Long> lastWarned = new HashMap<>();

	@SuppressWarnings("deprecation")
	@EventHandler (priority = EventPriority.LOWEST)
	public void onInventoryClick(InventoryClickEvent event) {
		if (!event.getWhoClicked().getType().equals(EntityType.PLAYER)) return;
		Player player = (Player) event.getWhoClicked();
		if (FreezeCommand.playerNames.contains(player.getName())) {
			event.setCancelled(true);
			long time = System.currentTimeMillis();
			if (!lastWarned.containsKey(player.getName()) || lastWarned.get(player.getName()) < time) {
				lastWarned.put(player.getName(), time + 1_000L);
				player.sendMessage("§cVous êtes actuellement congelé, vous ne pouvez pas intéragir.");
			}
			return;
		}
		if (event.getClickedInventory() != null && event.getClickedInventory().getName() != null) {
			if (GameServer.getInstance().getInventory() != null && !GameServer.getInstance().getInventory().equals(event.getClickedInventory())) {
				for (Entry<ConfigSystem, Inventory> entry : GameServer.getInstance().getConfigInventories().entrySet()) {
					if (!entry.getValue().equals(event.getClickedInventory())) continue;
					event.setCancelled(true);
					ConfigSystem system = entry.getKey();
					if (system.getConfigTemplate().getType().equals("integer")) {
						if (event.getCurrentItem() == null) return;
						ItemStack itemStack = event.getCurrentItem();
						if (itemStack.getType().equals(Material.WOOD_DOOR)) {
							player.openInventory(GameServer.getInstance().getInventory());
							return;
						}
						ItemStack stack = entry.getValue().getItem(3);
						if (itemStack.getType().equals(Material.WOOL)) {
							byte data = itemStack.getData().getData();
							boolean ok = false;
							if (data == DyeColor.RED.getWoolData()) {
								ok = true;
								if (system.getDefaultInt() <= system.getMinInt()) {
									player.playSound(player.getLocation(), Sound.ARROW_HIT, 100F, 1F);
									player.sendMessage("§cNombre minimal atteint.");
									return;
								}
								int o = system.getDefaultInt() - 5 < system.getMinInt() ? system.getMinInt() : system.getDefaultInt() - 5;
								system.setDefaultInt(o);
								player.playSound(player.getLocation(), Sound.CLICK, 100F, 1F);
								player.sendMessage("§a-5 §b(" + o + ")");
							}else if (data == DyeColor.ORANGE.getWoolData()) {
								ok = true;
								if (system.getDefaultInt() <= system.getMinInt()) {
									player.playSound(player.getLocation(), Sound.ARROW_HIT, 100F, 1F);
									player.sendMessage("§cNombre minimal atteint.");
									return;
								}
								int o = system.getDefaultInt() - 1 < system.getMinInt() ? system.getMinInt() : system.getDefaultInt() - 1;
								system.setDefaultInt(o);
								player.playSound(player.getLocation(), Sound.CLICK, 100F, 1F);
								player.sendMessage("§a-1 §b(" + o + ")");
							}else if (data == DyeColor.LIME.getWoolData()) {
								ok = true;
								if (system.getDefaultInt() >= system.getMaxInt()) {
									player.playSound(player.getLocation(), Sound.ARROW_HIT, 100F, 1F);
									player.sendMessage("§cNombre limite atteint.");
									return;
								}
								int o = system.getDefaultInt() + 1 > system.getMaxInt() ? system.getMaxInt() : system.getDefaultInt() + 1;
								system.setDefaultInt(o);
								player.playSound(player.getLocation(), Sound.CLICK, 100F, 1F);
								player.sendMessage("§a+1 §b(" + o + ")");
							}else if (data == DyeColor.GREEN.getWoolData()) {
								ok = true;
								if (system.getDefaultInt() >= system.getMaxInt()) {
									player.playSound(player.getLocation(), Sound.ARROW_HIT, 100F, 1F);
									player.sendMessage("§cNombre limite atteint.");
									return;
								}
								int o = system.getDefaultInt() + 5 > system.getMaxInt() ? system.getMaxInt() : system.getDefaultInt() + 5;
								system.setDefaultInt(o);
								player.playSound(player.getLocation(), Sound.CLICK, 100F, 1F);
								player.sendMessage("§a+5 §b(" + o + ")");
							}
							if (ok) {
								int s = -1;
								for (int i = 0; i < GameServer.getInstance().getInventory().getSize(); i++) {
									ItemStack is = GameServer.getInstance().getInventory().getItem(i);
									if (is == null || !system.getConfigTemplate().getMaterial().equals(is.getType().name())) continue;
									s = i;
									break;
								}
								ItemMeta itemMeta = stack.getItemMeta();
								GameServer.getInstance().getConfigss().remove(stack.getItemMeta().getDisplayName());
								itemMeta.setDisplayName(system.getConfigTemplate().getDisplayName().replace("%0", Integer.toString(system.getDefaultInt())));
								List<String> lore = new ArrayList<>();
								for (String l : system.getConfigTemplate().getLore().split(","))
									lore.add(l.replace("%0", Integer.toString(system.getDefaultInt())));
								itemMeta.setLore(lore);
								stack.setItemMeta(itemMeta);
								if (s != -1) {
									GameServer.getInstance().getInventory().setItem(s, stack);
									entry.getValue().setItem(3, stack);
								}
								GameServer.getInstance().itemStacks.put(system.getConfigTemplate().getId(), stack);
								GameServer.getInstance().getConfigss().put(itemMeta.getDisplayName(), system);
								try {
									GameServer.getInstance().loadCustomConfig();
								} catch (ReflectiveOperationException e) {
									e.printStackTrace();
								}
								Inventory inventory = Bukkit.createInventory(null, 9, itemMeta.getDisplayName());
								inventory.setContents(entry.getValue().getContents());
								GameServer.getInstance().getConfigInventories().put(system, inventory);
								player.openInventory(inventory);
							}
						}
					}
					break;
				}
				return;
			}
			event.setCancelled(true);
			if (event.getCurrentItem() == null) return;
			if (event.getCurrentItem().getItemMeta() == null || event.getCurrentItem().getItemMeta().getDisplayName() == null) return;
			if (GameServer.getInstance().getConfigss().get(event.getCurrentItem().getItemMeta().getDisplayName()) != null) {
				ConfigSystem system = GameServer.getInstance().getConfigss().get(event.getCurrentItem().getItemMeta().getDisplayName());
				if (system.getConfigTemplate().getType().equals("integer")) {
					player.openInventory(GameServer.getInstance().getConfigInventories().get(system));
					/*	boolean ok = false;
					if (event.getAction().equals(InventoryAction.PICKUP_ALL)) {
						if (system.getDefaultInt() >= system.getMaxInt()) {
							player.playSound(player.getLocation(), Sound.ARROW_HIT, 100F, 1F);
							player.sendMessage("§cNombre limite atteint.");
							return;
						}
						int o = system.getDefaultInt() + 5 > system.getMaxInt() ? system.getMaxInt() : system.getDefaultInt() + 5;
						system.setDefaultInt(o);
						player.playSound(player.getLocation(), Sound.CLICK, 100F, 1F);
						player.sendMessage("§a+5 §b(" + o + ")");
						ok = true;
					}else if (event.getAction().equals(InventoryAction.PICKUP_HALF)) {
						if (system.getDefaultInt() <= system.getMinInt()) {
							player.playSound(player.getLocation(), Sound.ARROW_HIT, 100F, 1F);
							player.sendMessage("§cNombre minimal atteint.");
							return;
						}
						int o = system.getDefaultInt() - 1 < system.getMinInt() ? system.getMinInt() : system.getDefaultInt() - 1;
						system.setDefaultInt(o);
						player.playSound(player.getLocation(), Sound.CLICK, 100F, 1F);
						player.sendMessage("§a-1 §b(" + o + ")");
						ok = true;
					}else if (event.getAction().equals(InventoryAction.NOTHING)) {
						if (system.getDefaultInt() <= system.getMinInt()) {
							player.playSound(player.getLocation(), Sound.ARROW_HIT, 100F, 1F);
							player.sendMessage("§cNombre minimal atteint.");
							return;
						}
						int o = system.getDefaultInt() - 5 < system.getMinInt() ? system.getMinInt() : system.getDefaultInt() - 5;
						system.setDefaultInt(o);
						player.playSound(player.getLocation(), Sound.CLICK, 100F, 1F);
						player.sendMessage("§a-5 §b(" + o + ")");
						ok = true;
					}
					if (ok) {
						int stack = -1;
						for (int i = 0; i < GameServer.getInstance().getInventory().getSize(); i++) {
							ItemStack is = GameServer.getInstance().getInventory().getItem(i);
							if (is == null || !is.equals(event.getCurrentItem())) break;
							stack = i;
							break;
						}
						ItemMeta itemMeta = event.getCurrentItem().getItemMeta();
						itemMeta.setDisplayName(system.getConfigTemplate().getDisplayName().replace("%0", Integer.toString(system.getDefaultInt())));
						List<String> lore = new ArrayList<>();
						for (String l : system.getConfigTemplate().getLore().split(","))
							lore.add(l.replace("%0", Integer.toString(system.getDefaultInt())));
						itemMeta.setLore(lore);
						event.getCurrentItem().setItemMeta(itemMeta);
						if (stack != -1) GameServer.getInstance().getInventory().setItem(stack, event.getCurrentItem());
						GameServer.getInstance().itemStacks.put(system.getConfigTemplate().getId(), event.getCurrentItem());
						GameServer.getInstance().getConfigss().put(event.getCurrentItem().getItemMeta().getDisplayName(), system);
						try {
							GameServer.getInstance().loadCustomConfig();
						} catch (ReflectiveOperationException e) {
							e.printStackTrace();
						}
					}*/
				}
			}else{
				if (event.getCurrentItem().getType().equals(Material.WOOD_DOOR)) {
					player.closeInventory();
					player.playSound(player.getLocation(), Sound.CLICK, 100, 1);
				}else if (event.getCurrentItem().getType().equals(Material.BOOK_AND_QUILL)) {
					player.closeInventory();
					player.playSound(player.getLocation(), Sound.CLICK, 100, 1);
					player.sendMessage("§cUsage: /whitelist <on/off/add/remove/list> [player]");
				}else if (event.getCurrentItem().getType().equals(Material.DIODE)) {
					player.closeInventory();
					player.playSound(player.getLocation(), Sound.CLICK, 100, 1);
					Bukkit.dispatchCommand(player, "game");
				}
			}
		}
	}

}