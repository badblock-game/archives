package fr.badblock.bukkit.gameserver.listeners;

import java.util.Iterator;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

import fr.badblock.bukkit.gameserver.GameServer;

public class PlayerCommandPreprocessListener implements Listener {

	@EventHandler (priority = EventPriority.LOWEST)
	public void onPlayerCommandPreprocessEvent(PlayerCommandPreprocessEvent event) {
		Player player = event.getPlayer();
		String[] args = event.getMessage().split(" ");
		if (!args[0].equalsIgnoreCase("/whitelist")) return;
		event.setCancelled(true);
		if (!player.hasPermission("game.manage")) {
			player.sendMessage("§cVous n'avez pas la permission de gérer la liste blanche.");
			return;
		}
		if (args.length == 1) {
			player.sendMessage("§cUsage: /whitelist <on/off/add/remove/list> [player]");
			return;
		}
		if (args[1].equalsIgnoreCase("add")) {
			if (args.length != 3) {
				player.sendMessage("§cUsage: /whitelist add <player>");
				return;
			}
			GameServer gameServer = GameServer.getInstance();
			String playerName = args[2];
			if (gameServer.getWhitelist().contains(playerName)) {
				player.sendMessage("§c" + playerName + " est déjà dans la liste blanche.");
				return;
			}
			gameServer.getWhitelist().add(playerName);
			player.sendMessage("§b" + playerName + " §7a été §aajouté §7à la liste blanche.");
			return;
		}else if (args[1].equalsIgnoreCase("remove")) {
			if (args.length != 3) {
				player.sendMessage("§cUsage: /whitelist remove <player>");
				return;
			}
			GameServer gameServer = GameServer.getInstance();
			String playerName = args[2];
			if (!gameServer.getWhitelist().contains(playerName)) {
				player.sendMessage("§c" + playerName + " n'est pas dans la liste blanche.");
				return;
			}
			gameServer.getWhitelist().remove(playerName);
			player.sendMessage("§b" + playerName + " §7a été §cretiré §7de la liste blanche.");
			return;
		}else if (args[1].equalsIgnoreCase("on")) {
			GameServer gameServer = GameServer.getInstance();
			if (gameServer.isWhitelisted()) {
				player.sendMessage("§cLa liste blanche est déjà activée.");
				return;
			}
			gameServer.setWhitelisted(true);
			player.sendMessage("§7Liste blanche §aactivée §7!");
			return;
		}else if (args[1].equalsIgnoreCase("off")) {
			GameServer gameServer = GameServer.getInstance();
			if (!gameServer.isWhitelisted()) {
				player.sendMessage("§cLa liste blanche est déjà désactivée.");
				return;
			}
			gameServer.setWhitelisted(false);
			player.sendMessage("§7Liste blanche §cdésactivée §7!");
			return;
		}else if (args[1].equalsIgnoreCase("list")) {
			GameServer gameServer = GameServer.getInstance();
			if (gameServer.isWhitelisted()) player.sendMessage("§7Liste blanche: §aActive");
			else player.sendMessage("§7Liste blanche: §cInactive");
			String onlinesString = "";
			Iterator<String> iterator = gameServer.getWhitelist().iterator();
			while (iterator.hasNext()) {
				String entry = iterator.next(); 
				Player pl = Bukkit.getPlayer(entry);
				String color = "§a";
				if (pl == null) color = "§c";
				String spacer = ", "; 
				onlinesString += color + "[" + entry + "]";
				if (iterator.hasNext()) 
					onlinesString += spacer;
			}
			player.sendMessage("§7Liste: " + onlinesString);
			return;
		}else{
			player.sendMessage("§cUsage: /whitelist <on/off/add/remove/list> [player]");
			return;
		}
	}

}