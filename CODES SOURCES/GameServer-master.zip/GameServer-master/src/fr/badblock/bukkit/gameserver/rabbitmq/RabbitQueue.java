package fr.badblock.bukkit.gameserver.rabbitmq;

/**
 * A rabbitqueue can send messages/receive messages and also manage a network with it.
 * @author xMalware
 */
public enum RabbitQueue {
	
	// DATA
	DEDICATEDSERVER_STOP  ("networkdocker.dedicatedserver.stop"),
	DEDICATEDSERVER_LOAD  ("networkdocker.dedicatedserver.load"),
	INSTANCE_OPEN		  ("networkdocker.instance.open"),
	INSTANCE_KEEPALIVE	  ("networkdocker.instance.keepalive"),
	INSTANCE_STOP		  ("networkdocker.instance.stop"),
	KILLALL_SCREENS		  ("networkdocker.dedicatedserver.killallscreens");
	
	// Private fields
	private String queueName;
	
	/**
	 * Constructor for creating queues..
	 * @param queueName
	 */
	private RabbitQueue(String queueName) {
		this.queueName = queueName;
	}
	
	/**
	 * Getting the queue name
	 * @return
	 */
	public String getQueueName() {
		return this.queueName;
	}
	
}
