package fr.badblock.bukkit.gameserver.listeners;

import java.util.HashMap;
import java.util.Map;

import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

import fr.badblock.bukkit.gameserver.commands.FreezeCommand;

public class EntityDamageByEntityListener implements Listener {

	private Map<String, Long> lastWarned = new HashMap<>();

	@EventHandler (priority = EventPriority.LOWEST)
	public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
		Entity entity = event.getDamager();
		if (entity.getType().equals(EntityType.PLAYER)) {
			Player player = (Player) entity;
			if (FreezeCommand.playerNames.contains(player.getName())) {
				event.setCancelled(true);
				long time = System.currentTimeMillis();
				if (!lastWarned.containsKey(player.getName()) || lastWarned.get(player.getName()) < time) {
					lastWarned.put(player.getName(), time + 1_000L);
					player.sendMessage("§cVous êtes actuellement congelé, vous ne pouvez pas frapper.");
				}
			}
		}
		entity = event.getEntity();
		if (entity.getType().equals(EntityType.PLAYER)) {
			Player player = (Player) entity;
			if (FreezeCommand.playerNames.contains(player.getName())) {
				event.setCancelled(true);
				if (event.getDamager().getType().equals(EntityType.PLAYER)) {
					Player damager = (Player) event.getDamager();
					long time = System.currentTimeMillis();
					if (!lastWarned.containsKey(damager.getName()) || lastWarned.get(damager.getName()) < time) {
						lastWarned.put(damager.getName(), time + 1_000L);
						damager.sendMessage("§cCe joueur est congelé, vous ne pouvez pas le frapper.");
					}
				}
			}
		}
	}

}