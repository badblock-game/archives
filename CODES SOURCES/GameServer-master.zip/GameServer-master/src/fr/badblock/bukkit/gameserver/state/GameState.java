package fr.badblock.bukkit.gameserver.state;

public abstract class GameState {

	public static GameState			instance = new FakeGameState();
	
	public abstract boolean isJoinable();
	public abstract boolean isPlaying();
	public abstract boolean isEnding();
	
}
