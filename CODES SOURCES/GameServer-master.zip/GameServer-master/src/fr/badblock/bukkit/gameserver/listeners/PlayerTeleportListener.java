package fr.badblock.bukkit.gameserver.listeners;

import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;

public class PlayerTeleportListener implements Listener {
	
	@EventHandler (priority = EventPriority.LOWEST)
	public void onTeleport(PlayerTeleportEvent event) {
		if (event.getCause().equals(TeleportCause.PLUGIN)) {
			if (event.getPlayer().isInsideVehicle()) {
				event.setCancelled(true);
				event.getPlayer().getVehicle().setPassenger(null);
				event.getPlayer().getVehicle().remove();
			}
		}
	}
	
}
