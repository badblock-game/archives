package fr.badblock.bukkit.gameserver.state;

public class FakeGameState extends GameState {

	@Override
	public boolean isJoinable() {
		return true;
	}

	@Override
	public boolean isPlaying() {
		return false;
	}

	@Override
	public boolean isEnding() {
		return false;
	}

}
