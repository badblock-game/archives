package fr.badblock.bukkit.gameserver.listeners;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.event.player.PlayerLoginEvent.Result;

import fr.badblock.bukkit.gameserver.GameServer;

public class PlayerJoinListener implements Listener {

	public static List<String> penalities = new ArrayList<>();

	@EventHandler (priority = EventPriority.LOWEST)
	public void onLogin(PlayerLoginEvent event) {
		Player player = event.getPlayer();
		if (GameServer.getInstance().isWhitelisted() && !player.hasPermission("game.manage") && !GameServer.getInstance().getWhitelist().contains(player.getName()))
			event.disallow(Result.KICK_WHITELIST, "§cVous n'êtes pas sur la liste blanche de cette partie.");
	}


	@EventHandler (priority = EventPriority.LOWEST)
	public void onPlayerJoin(PlayerJoinEvent event) {
		GameServer gameServer = GameServer.getInstance();
		gameServer.setJoinTime(System.currentTimeMillis() + 300_000L);
		gameServer.keepAlive();
		Player player = event.getPlayer();
		player.sendMessage("§a§l➤ §r§aTéléporté au serveur §2" + gameServer.getServerName() + "§a.");
	}

	@EventHandler (priority = EventPriority.MONITOR)
	public void onPlayerJoinMonitor(PlayerJoinEvent event) {
		if (event.getJoinMessage().contains("nous a rejoint en tant que spectateur !")) {
			event.setJoinMessage("");
		}
		GameServer gameServer = GameServer.getInstance();
		Player player = event.getPlayer();
		if (!gameServer.isAPI()) return;
		if (!player.isOnline()) return;
		if (player.hasPermission("game.manage") && GameServer.getInstance().getConfigz().size() > 0) {
			player.getInventory().addItem(GameServer.getInstance().getConfigItem());
			player.sendMessage("§7Téléporté à un serveur §bconfigurable§7.");
		}
		/*if (!player.hasPermission("leaverbuster.bypass")) {
			Bukkit.getScheduler().runTaskTimerAsynchronously(GameServer.getInstance(), new Runnable() {
				public boolean isInLeaverBusterMode;
				@Override
				public void run() {
					if (!player.isOnline()) return;
					if (PlayerQuitListener.isInLeaverBusterMode(player) && !isInLeaverBusterMode) {
						player.sendMessage("§c§lLeaverBuster ➤ §r§cAttention: Si vous partez à partir de maintenant de la partie, vous serez sanctionné.");
						isInLeaverBusterMode = true;
					}else if (!PlayerQuitListener.isInLeaverBusterMode(player) && isInLeaverBusterMode) {
						player.sendMessage("§a§lLeaverBuster ➤ §r§aVous pouvez désormais vous déconnecter sans craindre une quelconque sanction de LeaverBuster.");
						isInLeaverBusterMode = false;
						BadblockDatabase.getInstance().addRequest(new Request("DELETE FROM penalities WHERE pseudo = '" + player.getName() + "'", RequestType.SETTER));
					}
				}
			}, 20, 20);
			BPlayer bPlayer = BPlayersManager.getInstance().getPlayer(player);
			if (bPlayer == null) return;
			if (bPlayer.isSpectator()) return;
			BadblockDatabase.getInstance().addRequest(new Request("SELECT * FROM penalities WHERE pseudo = '" + player.getName() + "'", RequestType.GETTER) {
				@Override
				public void done(ResultSet resultSet) {
					setDoNotClose(true);
					if (!player.isOnline()) return;
					try {
						if (resultSet.next()) {
							BPlayer bPlayer = BPlayersManager.getInstance().getPlayer(player);
							if (bPlayer != null) {
								Bukkit.getScheduler().runTask(GameServer.getInstance(), new Runnable() {
									@Override
									public void run() {
										player.playSound(player.getLocation(), Sound.ORB_PICKUP, 100, 1);
										penalities.add(player.getName());
										int i = 0;
										long time = System.currentTimeMillis();
										long limit = time - (86400 * 1000);
										BadblockDatabase.getInstance().addRequest(new Request("SELECT COUNT(*) AS count FROM penalities_history WHERE pseudo = '" + player.getName() + "' AND timestamp >= '" + limit + "'", RequestType.GETTER) {
											@Override
											public void done(ResultSet resultSet) {
												try {
													player.sendMessage("§8§m---------------------------------------------");
													player.sendMessage("§c§l✘ LeaverBuster ✘");
													player.sendMessage("§8§m---------------------------------------------");
													player.sendMessage("§4§l➤ §r§cVous avez quitté la précédente partie avant sa fin.");
													player.sendMessage("§4§l➤ §r§cNotre module automatique a détecté ce fait.");
													int i = 0;
													if (resultSet.next()) i = resultSet.getInt("count");
													String string = i == 0 ? "premier" : i == 1 ? "premier" : i == 2 ? "deuxième" : i == 3 ? "troisième" : i == 4 ? "quatrième" : i == 5 ? "cinquième" : i == 6 ? "sixième":
														i == 7 ? "septième" : i == 8 ? "huitième" : i == 9 ? "neuvième" : i == 10 ? "dixième" : i == 11 ? "onzième" : i == 12 ? "douzième" : i == 13 ? "treizième" :
															i == 14 ? "quatorzième" : i == 15 ? "quinzième" : i == 16 ? "seizième" : i == 17 ? "dix-septième" : i == 18 ? "dix-huitième" : i == 19 ? "dix-neuvième" :
																i == 20 ? "vingtième" : i == 21 ? "vingt-et-unième" : i == 22 ? "vingt-deuxième" : i == 23 ? "vingt-troisième" : i == 24 ? "vingt-quatrième" :
																	i == 25 ? "vingt-cinquième" : i == 26 ? "vingt-sixième" : i == 27 ? "vingt-septième" : i == 28 ? "vingt-huitième" : i == 29 ? "vingt-neuvième" :
																		i == 30 ? "trentième" : i == 31 ? "trente-et-unième" : i == 32 ? "trente-deuxième" : i == 33 ? "trente-troisième" : i == 34 ? "trente-quatrième" :
																			i == 35 ? "trente-cinquième" : i == 36 ? "trente-sixième" : i == 37 ? "trente-septième" : i == 38 ? "trente-huitième" : i == 39 ? "trente-neuvième":
																				i == 40 ? "quarantième" : i == 41 ? "quarante-et-unième" : i == 42 ? "quarante-deuxième" : i == 43 ? "quarante-troisième" : i == 44 ? "quarante-quatrième":
																					i == 45 ? "quarante-cinquième" : i == 46 ? "quarante-sixième" : i == 47 ? "quarante-septième" : i == 48 ? "quarante-huitième" : i == 49 ? "quarante-neuvième":
																						i + "ème";
													String sanction = "Aucune";
													if (i >= 3) {
														bPlayer.setHasEnded(true);
														sanction = "Pas de gains pour cette partie";
													}
													player.sendMessage("§4§l➤ §r§cCeci est votre §6" + string + " §cavertissement journalier.");
													player.sendMessage("§4§l➤ §r§cSanction attribuée : §4§l" + sanction);
													if (i < 3)
														player.sendMessage("§4§l➤ §r§cLes futurs avertissements vous feront valoir des sanctions plus lourdes.");
													player.sendMessage("§8§m---------------------------------------------");
												}catch(Exception error) {
													error.printStackTrace();
												}
											}
										});
									}
								});
							}
							resultSet.close();
						}else{
							resultSet.close();
						}
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			});
		}*/
		if (gameServer.getBoostBadcoins() > 1 || gameServer.getBoostXP() > 1) {
			player.playSound(player.getLocation(), Sound.LEVEL_UP, 100, 1);
			player.sendMessage("§8§m---------------------------------------------");
			player.sendMessage("§a§l✘ Événement actif ✘");
			player.sendMessage("§8§m---------------------------------------------");
			player.sendMessage("§a§l➤ §r§aBadCoins doublé par §b" + gameServer.getBoostBadcoins());
			player.sendMessage("§a§l➤ §r§aXP doublé par §b" + gameServer.getBoostXP());
			player.sendMessage("§8§m---------------------------------------------");		
		}
	}
}