package fr.badblock.bukkit.gameserver.threading;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Timer;
import java.util.TimerTask;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPSClient;

import fr.badblock.bukkit.gameserver.GameServer;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter public class LogSenderThread  {
	
	private String hostname;
	private String username;
	private String password;
	private int	   port;
	
	public LogSenderThread(String hostname, String username, String password, int port) {
		setHostname(hostname);
		setUsername(username);
		setPassword(password);
		setPort(port);
		new Timer().schedule(new TimerTask() {
			@Override
			public void run() {	
				doLog();
			}
		}, 0, 60000);
	}
	
	public void doLog() {
		if (!GameServer.getInstance().isCanBeLogged()) return;
		File file = new File("logs/latest.log");
		if (file.exists()) {
			FTPSClient ftpClient = new FTPSClient("TLS");
			try {
				ftpClient.connect(getHostname(), getPort());
				ftpClient.login(getUsername(), getPassword());
				ftpClient.setFileType(FTP.BINARY_FILE_TYPE);
				ftpClient.execPBSZ(0); 
				ftpClient.execPROT("P");
				ftpClient.enterLocalPassiveMode();
				String logFile = "/logs/" + GameServer.getInstance().getLogsFile();
				String[] splitter = logFile.split("/");
				String old = "";
				int nb = splitter.length;
				int i = 0;
				for (String split : splitter) {
					i++;
					if (i == nb) break;
					old += split + "/";
					ftpClient.makeDirectory(old);
				}
				FileInputStream fis = new FileInputStream(file);
				BufferedReader br = new BufferedReader(new InputStreamReader(fis));
				String line = null;
				String string = "";
				while ((line = br.readLine()) != null) {
					string += line.replaceAll("(\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}):(\\d{1,5})", "REGEX_IP").replaceAll("^((?!-)[A-Za-z0-9-]{1,63}(?<!-)\\.)+[A-Za-z]{2,6}$", "REGEX_URL") + System.lineSeparator();
				}
				br.close();
				fis.close();
				System.out.println(file.getAbsolutePath() + " / " + file.exists() + " / " + logFile + " / " + string.length());
				InputStream stream = new ByteArrayInputStream(string.getBytes(StandardCharsets.UTF_8));
				;
				System.out.println(ftpClient.getReplyCode() + " / " + ftpClient.storeFile(logFile, stream));
				stream.close();
				ftpClient.disconnect();
			}catch(Exception error) {
				error.printStackTrace();
			}
		}else{
			System.out.println("Unknown log file. (" + file.getAbsolutePath() + ")");
		}
	}
	
}
