package fr.badblock.bukkit.gameserver.listeners;

import java.util.HashMap;
import java.util.Map;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;

import fr.badblock.bukkit.gameserver.commands.FreezeCommand;

public class PlayerMoveListener implements Listener {

	private Map<String, Long> lastWarned = new HashMap<>();
	
	@EventHandler (priority = EventPriority.LOWEST)
	public void onPlayerMove(PlayerMoveEvent event) {
		Player player = event.getPlayer();
		if (FreezeCommand.playerNames.contains(player.getName())) {
			Location from = event.getFrom();
			Location to = event.getTo();
			boolean hasMoved = from.getX() != to.getX() || from.getZ() != to.getZ();
			if (hasMoved) {
				event.setTo(from);
				long time = System.currentTimeMillis();
				if (!lastWarned.containsKey(player.getName()) || lastWarned.get(player.getName()) < time) {
					lastWarned.put(player.getName(), time + 1_000L);
					player.sendMessage("§cVous êtes actuellement congelé, vous ne pouvez pas bouger.");
				}
			}
		}
	}
	
}