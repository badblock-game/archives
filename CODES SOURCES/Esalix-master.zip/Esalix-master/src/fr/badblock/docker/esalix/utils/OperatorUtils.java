package fr.badblock.docker.esalix.utils;

public class OperatorUtils
{

	public static boolean inRange(double number, double min, double max)
	{
		return number >= min && number <= max;
	}

	public static boolean notInRange(double number, double min, double max)
	{
		return !inRange(number, min, max);
	}
	
}
