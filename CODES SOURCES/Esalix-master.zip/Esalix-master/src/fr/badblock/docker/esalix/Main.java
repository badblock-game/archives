package fr.badblock.docker.esalix;

public class Main
{
	
	public static void main(String[] args)
	{
		new Esalix();
	}

}
