package fr.badblock.docker.esalix.config;

@SuppressWarnings("serial")
public class ConfigException extends RuntimeException {

	public ConfigException(String message)
	{
		super("Error occurred while loading config. " + message);
	}
	
}
