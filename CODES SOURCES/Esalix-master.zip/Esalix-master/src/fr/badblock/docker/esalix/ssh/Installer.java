package fr.badblock.docker.esalix.ssh;

import fr.badblock.docker.esalix.Esalix;

public class Installer {

	public Installer(String ip)
	{
	     SSHManager instance = new SSHManager("root", "", ip, "", 22, "id_rsa", Esalix.getInstance().getConfig().getPassphrase());
	     String errorMessage = instance.connect();
	     System.out.println(instance.sendCommand("mkdir /tmp/install"));
	     System.out.println(instance.sendCommand("wget -O /tmp/install/master.sh --user-agent=\"BadBlock-Auth-7288379222376377459473593455375766657722329226777957476999544955\" https://installer-7q2w32n:25yqk224rs43cbu343s9yynx44n44gd6t5tr28996s78ma944sy2d4ypm9w7k7uh@cloud.badblock.fr/installer-36fLiAiUWm7XNrse56bJQGrbh32V497e6V3899RQn99x7qzYrr2VYT9Pf5KmTZ6b/master_85vb7c69dfi38n2x.sh"));
	     System.out.println(instance.sendCommand("screen -dmS install sh /tmp/install/master.sh"));

	     if(errorMessage != null)
	     {
	        System.out.println(errorMessage);
	     }
	     
	     instance.close();
	}
	
}
