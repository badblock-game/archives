package fr.badblock.docker.esalix.tasks;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import fr.badblock.docker.esalix.Esalix;
import fr.badblock.docker.esalix.config.Configuration;
import fr.badblock.docker.esalix.entities.DedicatedServerEntity;
import fr.badblock.docker.esalix.entities.DedicatedServerType;
import fr.badblock.docker.esalix.manager.ServerManager;

public class OpenerTask extends TimerTask
{

	public static double averageCpu;
	public static double averageRam;
	private static final String IPADDRESS_PATTERN =
			"^([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
					"([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
					"([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
					"([01]?\\d\\d?|2[0-4]\\d|25[0-5])$";
	
	private int  createrMargin = 0;
	private int  removerMargin = 0;
	private long timeMargin = 0;
	private Pattern pattern;
	private Matcher matcher;

	public OpenerTask()
	{
		pattern = Pattern.compile(IPADDRESS_PATTERN);
		new Timer().schedule(this, 1000, 1000);
		timeMargin = System.currentTimeMillis() + 5000;
		Esalix.getInstance().sendDebugMessage("OpenerTask loaded.");
	}

	@Override
	public void run() {
		if (timeMargin >= System.currentTimeMillis())
		{
			Esalix.getInstance().sendDebugMessage("ACTION: WAITING FOR TIME MARGIN...");
			return;
		}
		List<DedicatedServerEntity> servers = null;
		List<DedicatedServerEntity> servers2 = null;
		try 
		{
			servers = DedicatedServerEntity.getServers().values().stream().
					filter(server -> server.isOnline() && server.isAvailable() && server.getDedicatedServerType().equals(DedicatedServerType.PRODUCTION))
					.collect(Collectors.toList());
			servers2 = DedicatedServerEntity.getServers().values().stream().
					filter(server -> server.isOnline() && validate(server.getIp()) && server.isAvailable() && server.getDedicatedServerType().equals(DedicatedServerType.PRODUCTION))
					.collect(Collectors.toList());
			averageCpu = servers2.stream().filter(server -> !server.getCpu120S().isEmpty()).mapToDouble(server -> server.getCpu120S().stream().mapToDouble(cp -> cp.doubleValue()).sum() / server.getCpu120S().size()).sum() / servers2.size();
			averageRam = servers2.stream().mapToDouble(server -> server.getRam()).sum() / servers2.size();
			Esalix esalix = Esalix.getInstance();
			Configuration config = esalix.getConfig();
			if (canOpenAServer(config, servers2))
			{
				if (servers2.size() < config.getMax())
				{
					createrMargin++;
					if (createrMargin >= config.getCreaterMargin())
					{
						new Thread("Esalix/ServerCreator")
						{
							@Override
							public void run()
							{
								if (esalix.getScaleway() != null)
								{
									// Generate a dedicated server
									ServerManager.generateServer(esalix);
								}
								else
								{
									Esalix.getInstance().sendDebugMessage(averageCpu + " : ACTION: Can't create a dedicated server. Need Scaleway API.");
								}
							}
						}.start();
					}
					else
					{
						Esalix.getInstance().sendDebugMessage(averageCpu + " : ACTION: WAITING FOR CREATE MARGIN... (" + (config.getCreaterMargin() - createrMargin) + ")");
					}
				}
				else
				{
					Esalix.getInstance().sendDiscordMessage(averageCpu + " : Max server value reached!");
				}
			}
			else if (servers2.size() > config.getMinServers())
			{
				if (createrMargin > 0)
				{
					createrMargin--;
				}
				double maxRemoverCpu = config.getRemoverThrottle() * 100;
				if (averageCpu < maxRemoverCpu && servers2.size() > config.getMinToDel())
				{
					DedicatedServerEntity unusedServer = null;
					for (DedicatedServerEntity server : servers)
					{
						if (unusedServer == null || server.getCpu() < unusedServer.getCpu())
						{
							unusedServer = server;
						}
					}
					if (unusedServer == null)
					{
						Esalix.getInstance().sendDebugMessage(averageCpu + " : ACTION: NO SERVER TO USE AS A REMOVER.");
						return;
					}
					int newServerSize = servers.size() - 1;
					final DedicatedServerEntity finalUnusedServer = unusedServer;
					double anticipatedCpu = servers.stream().filter(server -> validate(server.getIp())).mapToDouble(server -> server.getCpu()).sum() / newServerSize;
					if (anticipatedCpu < maxRemoverCpu)
					{
						if (removerMargin >= config.getRemoverMargin())
						{
							Esalix.getInstance().sendDiscordMessage(averageCpu + " : Deleting a dedicated server: " + finalUnusedServer.getIp());
							ServerManager.deleteServer(finalUnusedServer);
						}
						else
						{
							Esalix.getInstance().sendDebugMessage(averageCpu + " : ACTION: WAITING FOR REMOVE MARGIN... (" + (config.getRemoverMargin() - removerMargin) + ")");
						}
						removerMargin++;
					}
					else
					{
						if (removerMargin > 0)
						{
							removerMargin--;
						}
					}
				}
				else
				{
					if (removerMargin > 0)
					{
						removerMargin--;
					}
				}
			}
		}
		catch(Exception error)
		{
			error.printStackTrace();
			return;
		}
	}
	
	public boolean canOpenAServer(Configuration config, List<DedicatedServerEntity> servers)
	{
		double maxCpuCreater = config.getCreaterThrottle() * 100;
		return averageCpu >= maxCpuCreater || 
				Double.isNaN(averageCpu) || 
				averageRam < config.getMinRam() || 
				servers.size() < config.getMinServers();
	}

	public boolean validate(final String ip){
		matcher = pattern.matcher(ip);
		return matcher.matches();
	}

}