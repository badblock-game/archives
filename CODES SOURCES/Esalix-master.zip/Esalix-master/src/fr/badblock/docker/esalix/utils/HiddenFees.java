package fr.badblock.docker.esalix.utils;

import java.util.Iterator;
import java.util.Map;

import fr.badblock.docker.esalix.Esalix;
import fr.badblock.docker.esalix.scaleway.exception.ScalewayApiException;
import fr.badblock.docker.esalix.scaleway.model.Server;
import fr.badblock.docker.esalix.scaleway.model.Volume;
import lombok.Getter;

public class HiddenFees {

	@Getter private static HiddenFees instance = new HiddenFees();

	public void removeIP(Esalix esalix, String ipAddress) throws ScalewayApiException
	{
		esalix.getScaleway().getAllIPs(1, 100).getIPs().stream().filter(ip -> ip.getIpAddress().equalsIgnoreCase(ipAddress)).forEach(ip -> {
			try {
				esalix.getScaleway().deleteIP(ip.getId());
			} catch (ScalewayApiException e) {
				e.printStackTrace();
			}
		});
	}
	
	public void removeStorage(Esalix esalix, Server server) throws ScalewayApiException
	{
		Map<String, Volume> volumes = server.getVolumes();
		Iterator<String> iterator = volumes.keySet().iterator();
		while (iterator.hasNext())
		{
			String key = (String) iterator.next();
			Volume volume = volumes.get(key);
			esalix.getScaleway().deleteVolume(volume.getId());
		}
	}
	
}
