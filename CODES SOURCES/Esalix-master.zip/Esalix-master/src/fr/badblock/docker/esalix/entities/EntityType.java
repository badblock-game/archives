package fr.badblock.docker.esalix.entities;

public enum EntityType {

	DEDICATED_SERVER,
	INSTANCE,
	WORLD,
	SERVER;
	
}
