package fr.badblock.docker.esalix.config;

import java.util.Map;

import fr.badblock.docker.esalix.scaleway.model.ArchType;
import fr.toenga.common.tech.rabbitmq.setting.RabbitSettings;
import lombok.Getter;

@Getter
public class Configuration 
{

	public boolean			discordDebug;
	public boolean			logDebug;
	public double			removerThrottle;
	public double			createrThrottle;
	public int				max;
	public int				minServers;
	public int				minToDel;
	public int				minRam;
	public int				createrMargin;
	public int				removerMargin;
	public Map<ArchType, String> images;
	public String[]			serverTypes;
	public String			passphrase;
	public String			scalewayToken;
	public String 			organizationId;
	public String			discordWebhook;
	public String			cloudflare_email;
	public String			cloudflare_apikey;
	public RabbitSettings	rabbitSettings;
	public DatabaseConfig	databaseConfig;

}
