package fr.badblock.docker.esalix.utils;

import java.sql.ResultSet;

import fr.badblock.docker.esalix.database.BadblockDatabase;
import fr.badblock.docker.esalix.database.Request;
import fr.badblock.docker.esalix.database.Request.RequestType;

public class DatabaseUtils
{

	public static void getCount(String query, Callback<Integer> callback)
	{
		BadblockDatabase.getInstance().addSyncRequest(new Request("SELECT COUNT(*) AS count " + query, RequestType.GETTER)
		{
			@Override
			public void done(ResultSet resultSet)
			{
				try
				{
					if (resultSet.next())
					{
						int count = resultSet.getInt("count");
						callback.done(count, null);
					}
				}
				catch(Exception error)
				{

				}
			}
		});
	}

}
