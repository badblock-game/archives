package fr.badblock.docker.esalix.commands;

import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

import fr.badblock.docker.esalix.Esalix;
import fr.badblock.docker.esalix.entities.DedicatedServerEntity;
import fr.badblock.docker.esalix.manager.ServerManager;
import fr.badblock.docker.esalix.scaleway.model.IP;
import fr.badblock.docker.esalix.scaleway.model.Server;
import fr.badblock.docker.esalix.scaleway.model.ServerAction;
import fr.badblock.docker.esalix.scaleway.model.Volume;
import fr.badblock.docker.esalix.tasks.OpenerTask;

public class CommandManager {

	@SuppressWarnings("resource")
	public static void manage()
	{
		Scanner s = new Scanner(System.in);
		while (true)
		{
			String string = s.nextLine();
			switch (string.split(" ")[0])
			{
			case "createserver":
				createserver();
				break;
			case "deleteserver":
				deleteserver(string);
				break;
			case "byeserver":
				byeserver(string);
				break;
			case "byeallservers":
				byeallservers();
				break;
			case "cpu":
				cpu();
				break;
			case "state":
				state(string);
				break;
			case "volumelist":
				volumelist();
				break;
			case "deletevolume":
				deletevolume(string);
				break;
			case "iplist":
				iplist();
				break;
			case "serverlist":
				serverlist();
				break;
			case "deleteip":
				deleteip(string);
				break;
			case "help":
			case "?":
			case "":
				help();
				break;
			default:
				Esalix.getInstance().sendDiscordMessage("Unknown command '" + string.split(" ")[0] + "'. Type help");
			}
		}
	}

	public static void help()
	{
		Esalix.getInstance().sendDiscordMessage("Command list:");
		Esalix.getInstance().sendDiscordMessage(" - reload - Reload configuration");
		Esalix.getInstance().sendDiscordMessage(" - cpu - Get CPU usage");
		Esalix.getInstance().sendDiscordMessage(" - serverlist - List all servers");
		Esalix.getInstance().sendDiscordMessage(" - createserver - Create a server.");
		Esalix.getInstance().sendDiscordMessage(" - deleteserver <ip> - Delete a server.");
		Esalix.getInstance().sendDiscordMessage(" - byeserver <ip> - Send a bye signal to a server.");
		Esalix.getInstance().sendDiscordMessage(" - byeallservers - Send a bye signal to all servers.");
		Esalix.getInstance().sendDiscordMessage(" - state <ip> <POWERON/POWEROFF/TERMINATE/REBOOT> - Update state of a server");
		Esalix.getInstance().sendDiscordMessage(" - volumelist - List all volumes");
		Esalix.getInstance().sendDiscordMessage(" - deletevolume <id> - Delete a volume");
		Esalix.getInstance().sendDiscordMessage(" - iplist - List all IPs");
		Esalix.getInstance().sendDiscordMessage(" - deleteip <ip> - Delete an IP");
	}

	public static void reload()
	{
		Esalix.getInstance().loadConfig();
	}

	public static void cpu()
	{
		Esalix.getInstance().sendDiscordMessage("CPU Usage: " + OpenerTask.averageCpu);
	}

	public static void createserver()
	{
		Esalix.getInstance().sendDiscordMessage("Forced to create a server (command):");
		ServerManager.generateServer(Esalix.getInstance());
	}

	public static void iplist()
	{
		Esalix.getInstance().sendDiscordMessage("IP list:");
		try
		{
			Esalix.getInstance().getScaleway().getAllIPs(1, 100).getIPs().forEach(ip -> 
			{
				Esalix.getInstance().sendDiscordMessage(" - IP ID: " + ip.getId() + " | " + ip.getIpAddress());
			});
		}
		catch(Exception error)
		{
			error.printStackTrace();
			Esalix.getInstance().sendDiscordMessage("An error occurred while trying to list ip (command): " + error.getMessage());
		}
	}

	public static void volumelist()
	{
		Esalix.getInstance().sendDiscordMessage("Volume list:");
		try
		{
			Esalix.getInstance().getScaleway().getAllVolumes(1, 100).getVolumes().forEach(volume -> 
			{
				Esalix.getInstance().sendDiscordMessage(" - Volume ID: " + volume.getId() + " | " + volume.getSize() + " | " + (volume.getServer() != null ? "Server: " + volume.getServer().getName() + (volume.getServer().getPublicIp() != null ? " - " + volume.getServer().getPublicIp().getIpAddress() : "") : "No server"));
			});
		}
		catch(Exception error)
		{
			error.printStackTrace();
			Esalix.getInstance().sendDiscordMessage("An error occurred while trying to list volumes (command): " + error.getMessage());
		}
	}

	public static void serverlist()
	{
		Esalix.getInstance().sendDiscordMessage("Scaleway server list:");
		try
		{
			Esalix.getInstance().getScaleway().getAllServers(1, 100).getServers().forEach(server -> 
			{
				Esalix.getInstance().sendDiscordMessage(" - Server ID: " + server.getId() + " | " + (server.getPublicIp() != null ? server.getPublicIp().getIpAddress() : "No IP assigned.") + " | " + server.getServerType().name());
			});
		}
		catch(Exception error)
		{
			error.printStackTrace();
			Esalix.getInstance().sendDiscordMessage("An error occurred while trying to list servers (command): " + error.getMessage());
		}
		Esalix.getInstance().sendDiscordMessage("Docker server list:");
		DedicatedServerEntity.getServers().values().forEach(server -> {
			Esalix.getInstance().sendDiscordMessage(" - (" + server.getDedicatedServerType() + ") " + server.getIp() + " - " + server.getCpu() + "% CPU");
		});
	}

	public static void deleteserver(String message)
	{
		String[] args = message.split(" ");
		if (args.length != 2)
		{
			Esalix.getInstance().sendDiscordMessage("Usage: deleteserver <ip>");
		}
		try
		{
			String server = args[1];
			List<Server> s = Esalix.getInstance().getScaleway().getAllServers(1, 100).getServers().stream().filter(se -> se.getId().equals(server)).collect(Collectors.toList());
			if (s.isEmpty())
			{
				Esalix.getInstance().sendDiscordMessage("Unknown server: '" + server + "'");
				return;
			}
			Server se = s.get(0);
			Esalix.getInstance().getScaleway().deleteServer(se.getId());
			Esalix.getInstance().sendDiscordMessage("Removed server: " + (se.getPublicIp() == null ? se.getId() :se.getPublicIp().getIpAddress()));
		}
		catch(Exception error)
		{
			error.printStackTrace();
			Esalix.getInstance().sendDiscordMessage("An error occurred while trying to delete server (command): " + error.getMessage());
		}
	}

	public static void byeallservers()
	{
		try
		{
			Esalix.getInstance().sendDiscordMessage("Sended 'bye' signal to all servers:");
			DedicatedServerEntity.getServers().values().stream().filter(server -> server.isOnline()).forEach(server -> {
				ServerManager.deleteServer(server);
				Esalix.getInstance().sendDiscordMessage("Sended 'bye' signal to '" + server.getIp() + "'");
			});
		}
		catch(Exception error)
		{
			error.printStackTrace();
			Esalix.getInstance().sendDiscordMessage("An error occurred while trying to 'bye' servers (command): " + error.getMessage());
		}
	}

	public static void byeserver(String message)
	{
		String[] args = message.split(" ");
		if (args.length != 2)
		{
			Esalix.getInstance().sendDiscordMessage("Usage: byeserver <ip>");
		}
		try
		{
			String server = args[1];
			DedicatedServerEntity entity = DedicatedServerEntity.getServers().get(server);
			if (entity == null)
			{
				Esalix.getInstance().sendDiscordMessage("Unknown server with IP '" + server + "'.");
				return;
			}
			ServerManager.deleteServer(entity);
			Esalix.getInstance().sendDiscordMessage("Sended 'bye' signal to '" + server + "'");
		}
		catch(Exception error)
		{
			error.printStackTrace();
			Esalix.getInstance().sendDiscordMessage("An error occurred while trying to 'bye' server (command): " + error.getMessage());
		}
	}

	public static void deleteip(String message)
	{
		String[] args = message.split(" ");
		if (args.length != 2)
		{
			Esalix.getInstance().sendDiscordMessage("Usage: deleteip <ip>");
		}
		try
		{
			String server = args[1];
			List<IP> s = Esalix.getInstance().getScaleway().getAllIPs(1, 100).getIPs();
			if (s.isEmpty())
			{
				Esalix.getInstance().sendDiscordMessage("Unknown IP: '" + server + "'");
				return;
			}
			boolean f = false;
			for (IP ipe : s)
			{
				if (ipe.getIpAddress().equalsIgnoreCase(server))
				{
					f = true;
					Esalix.getInstance().getScaleway().deleteIP(ipe.getId());
					Esalix.getInstance().sendDiscordMessage("Removed IP: " + ipe.getId() + " | " + ipe.getIpAddress());
				}
			}
			if (!f)
			{
				Esalix.getInstance().sendDiscordMessage("Unknown IP: '" + server + "'");
				return;
			}
		}
		catch(Exception error)
		{
			error.printStackTrace();
			Esalix.getInstance().sendDiscordMessage("An error occurred while trying to delete ip (command): " + error.getMessage());
		}
	}

	public static void deletevolume(String message)
	{
		String[] args = message.split(" ");
		if (args.length != 2)
		{
			Esalix.getInstance().sendDiscordMessage("Usage: deleteip <ip>");
		}
		try
		{
			String id = args[1];
			List<Volume> s = Esalix.getInstance().getScaleway().getAllVolumes(1, 100).getVolumes();
			if (s.isEmpty())
			{
				Esalix.getInstance().sendDiscordMessage("Unknown volume: '" + id + "'");
				return;
			}
			boolean f = false;
			for (Volume volume : s)
			{
				if (volume.getId().equalsIgnoreCase(id))
				{
					f = true;
					Esalix.getInstance().getScaleway().deleteVolume(volume.getId());
					Esalix.getInstance().sendDiscordMessage("Removed volume: " + volume.getId());
				}
			}
			if (!f)
			{
				Esalix.getInstance().sendDiscordMessage("Unknown volume: '" + id + "'");
				return;
			}
		}
		catch(Exception error)
		{
			error.printStackTrace();
			Esalix.getInstance().sendDiscordMessage("An error occurred while trying to delete volume (command): " + error.getMessage());
		}
	}

	public static void state(String message)
	{
		String[] args = message.split(" ");
		if (args.length != 3)
		{
			Esalix.getInstance().sendDiscordMessage("Usage: state <ip> <POWERON/POWEROFF/TERMINATE/REBOOT>");
		}
		try
		{
			String server = args[1];
			String stateString = args[2];
			List<Server> s = Esalix.getInstance().getScaleway().getAllServers(1, 100).getServers().stream().filter(se -> se.getId().equals(server)).collect(Collectors.toList());
			if (s.isEmpty())
			{
				Esalix.getInstance().sendDiscordMessage("Unknown server: '" + server + "'");
				return;
			}
			boolean f = false;
			ServerAction state = getServerAction(stateString);
			if (state == null)
			{
				Esalix.getInstance().sendDiscordMessage("Unknown state.");
				return;
			}
			for (Server arg0 : s)
			{
				f = true;
				Esalix.getInstance().getScaleway().executeServerAction(arg0.getId(), state);
				Esalix.getInstance().sendDiscordMessage("Edited server ID state: " + arg0.getId() + " => " + stateString);
			}
			if (!f)
			{
				Esalix.getInstance().sendDiscordMessage("Unknown server: '" + server + "'");
				return;
			}
		}
		catch(Exception error)
		{
			error.printStackTrace();
			Esalix.getInstance().sendDiscordMessage("An error occurred while trying to change state (command): " + error.getMessage());
		}
	}

	private static ServerAction getServerAction(String string)
	{
		for (ServerAction serverAction : ServerAction.values())
			if (serverAction.name().equalsIgnoreCase(string))
				return serverAction;
		return null;
	}

}
