package fr.badblock.docker.esalix.utils;

import fr.badblock.docker.esalix.Esalix;

public class ShutdownUtils
{

	public static void addShutdown(Esalix esalix)
	{
		Runtime.getRuntime().addShutdownHook(new Thread() {
			public void run() {
				esalix.stop();
			}
		});
	}

}
