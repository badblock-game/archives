package fr.badblock.docker.esalix.config;

import lombok.Getter;

@Getter
public class DatabaseConfig {

	public String	hostname;
	public int		port;
	public String	username;
	public String	password;
	public String	database;
	
}
