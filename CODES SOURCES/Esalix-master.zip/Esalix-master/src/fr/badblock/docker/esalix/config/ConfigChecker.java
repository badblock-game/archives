package fr.badblock.docker.esalix.config;

import fr.badblock.docker.esalix.utils.OperatorUtils;

public class ConfigChecker
{

	public static void check(Configuration configuration) throws ConfigException
	{
		if (OperatorUtils.notInRange(configuration.getCreaterThrottle(), 0.2D, 1.0D))
		{
			throw new ConfigException("Creater throttle is not in range. Min: 0.2 & Max: 1.0");
		}
		if (OperatorUtils.notInRange(configuration.getRemoverThrottle(), 0.1, 1.0D))
		{
			throw new ConfigException("Remover throttle is not in range. Min: 0.1 & Max: 1.0");
		}
		if (OperatorUtils.notInRange(configuration.getCreaterThrottle() - configuration.getRemoverThrottle(), 0.1, 0.5))
		{
			throw new ConfigException("Remover throttle must be higher than creater throttle with a difference from 0.1 to 0.5");
		}
		if (OperatorUtils.notInRange(configuration.getCreaterMargin(), 30, 300))
		{
			throw new ConfigException("Creater margin is not in range. Min: 30 & Max: 300");
		}
		if (OperatorUtils.notInRange(configuration.getRemoverMargin(), 30, 3600))
		{
			throw new ConfigException("Remover margin is not in range. Min: 30 & Max: 3600");
		}
		if (OperatorUtils.notInRange(configuration.getMax(), 1, Integer.MAX_VALUE))
		{
			throw new ConfigException("Max is not in range. Min: 1 & Max: " + Integer.MAX_VALUE);
		}
		if (configuration.getMinServers() > configuration.getMax())
		{
			throw new ConfigException("Min servers is more than max.");
		}
	}

}
