package fr.badblock.docker.esalix;

import com.cloudflare.api.CloudflareAccess;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import fr.badblock.docker.esalix.commands.CommandManager;
import fr.badblock.docker.esalix.config.ConfigChecker;
import fr.badblock.docker.esalix.config.ConfigException;
import fr.badblock.docker.esalix.config.Configuration;
import fr.badblock.docker.esalix.config.DatabaseConfig;
import fr.badblock.docker.esalix.database.BadblockDatabase;
import fr.badblock.docker.esalix.discord.DiscordMessage;
import fr.badblock.docker.esalix.discord.TemmieWebhook;
import fr.badblock.docker.esalix.listeners.DedicatedServerLoadListener;
import fr.badblock.docker.esalix.logs.Log;
import fr.badblock.docker.esalix.logs.Log.LogType;
import fr.badblock.docker.esalix.scaleway.Region;
import fr.badblock.docker.esalix.scaleway.ScalewayApiClient;
import fr.badblock.docker.esalix.scaleway.exception.ScalewayApiException;
import fr.badblock.docker.esalix.tasks.DeleterTask;
import fr.badblock.docker.esalix.tasks.OpenerTask;
import fr.badblock.docker.esalix.utils.FileUtils;
import fr.badblock.docker.esalix.utils.ShutdownUtils;
import fr.toenga.common.tech.rabbitmq.RabbitConnector;
import fr.toenga.common.tech.rabbitmq.RabbitService;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
public class Esalix
{

	@Getter@Setter private static Esalix instance;

	private Configuration		config;
	private	RabbitService		rabbitService;
	private	Gson				gson;
	private	ScalewayApiClient	scaleway;
	private TemmieWebhook 		temmie;
	private CloudflareAccess	cloudflare;
	private Thread				thread;

	public Esalix()
	{
		instance = this;
		load();
	}

	public void stop()
	{

	}

	private void load()
	{
		setThread(Thread.currentThread());
		setGson(new GsonBuilder().setPrettyPrinting().create());
		try
		{
			loadConfig();
		}
		catch(Exception error)
		{
			error.printStackTrace();
			return;
		}
		FileUtils.saveConfiguration(this);
		loadShutdown();
		loadRabbit();
		loadListeners();
		cloudflare = new CloudflareAccess(getConfig().getCloudflare_email(), getConfig().getCloudflare_apikey());
		DatabaseConfig databaseConfig = getConfig().getDatabaseConfig();
		BadblockDatabase.getInstance().connect(databaseConfig.getHostname(), databaseConfig.getPort(), databaseConfig.getUsername(), 
				databaseConfig.getPassword(), databaseConfig.getDatabase());
		scaleway = new ScalewayApiClient(config.getScalewayToken(), Region.PARIS1);
		temmie = new TemmieWebhook(getConfig().getDiscordWebhook());
		DiscordMessage dm = new DiscordMessage("Esalix", "Esalix d�marr�.", "");
		temmie.sendMessage(dm);
		try {
			/*scaleway.getAllVolumes(1, 100).getVolumes().forEach(volume -> {
				try {
					scaleway.deleteVolume(volume.getId());
				} catch (ScalewayApiException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});*/
			//ServerManager.generateServer(this);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		new OpenerTask();
		new DeleterTask();
		CommandManager.manage();
	}

	public String getScalewayOrganization() throws ScalewayApiException
	{
		return(scaleway.getAllOrganizations().get(0).getId());
	}

	public void loadConfig() throws ConfigException
	{
		setConfig(FileUtils.loadConfiguration(this));
		ConfigChecker.check(getConfig());
	}

	private void loadShutdown()
	{
		ShutdownUtils.addShutdown(this);
	}

	private void loadRabbit()
	{
		setRabbitService(RabbitConnector.getInstance().registerService(new RabbitService("default", getConfig().getRabbitSettings())));
	}

	private void loadListeners()
	{
		getRabbitService().addListener(new DedicatedServerLoadListener());
	}

	public void sendDebugMessage(String message)
	{
		if (getConfig().isLogDebug())
		{
			Log.log(message, LogType.DEBUG);
		}
		if (!getConfig().isDiscordDebug())
		{
			return;
		}
		DiscordMessage dm = new DiscordMessage("Esalix", "[DEBUG] " + message, "");
		temmie.sendMessage(dm);
	}

	public void sendDiscordMessage(String message)
	{
		Log.log(message, LogType.INFO);
		DiscordMessage dm = new DiscordMessage("Esalix", "[DEBUG] " + message, "");
		temmie.sendMessage(dm);
	}

}