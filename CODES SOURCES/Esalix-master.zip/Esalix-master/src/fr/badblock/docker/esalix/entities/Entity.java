package fr.badblock.docker.esalix.entities;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter public abstract class Entity {
	
	private EntityType		entityType;
	
	public Entity(EntityType entityType) {
		setEntityType(entityType);
	}
	
}
