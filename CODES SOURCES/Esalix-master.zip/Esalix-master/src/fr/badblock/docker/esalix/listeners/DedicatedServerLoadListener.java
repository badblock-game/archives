package fr.badblock.docker.esalix.listeners;

import fr.badblock.docker.esalix.Esalix;
import fr.badblock.docker.esalix.entities.DedicatedServerEntity;
import fr.toenga.common.tech.rabbitmq.listener.RabbitListener;
import fr.toenga.common.tech.rabbitmq.listener.RabbitListenerType;

/**
 * A packet for known if the bungeecord is keeping alive
 * @author xMalware
 */
public class DedicatedServerLoadListener extends RabbitListener {

	public DedicatedServerLoadListener() {
		super(Esalix.getInstance().getRabbitService(), "networkdocker.dedicatedserver.load", RabbitListenerType.SUBSCRIBER, false);
	}

	/**
	 * Method called when the packet is received
	 */
	@Override
	public void onPacketReceiving(String message) {
		String[] splitter = message.split(";");
		String ip = splitter[0];
		DedicatedServerEntity dedicatedServer = DedicatedServerEntity.getServers().get(ip);
		if (dedicatedServer == null) {
			dedicatedServer = new DedicatedServerEntity(ip);
		}
		double cpu = Double.parseDouble(splitter[1]);
		long   ram = Long.parseLong(splitter[2]);
		long   disk = Long.parseLong(splitter[3]);
		long   ramPercent = Long.parseLong(splitter[4]);
		int	   slots = Integer.parseInt(splitter[5]);
		boolean slotsIncrease = Boolean.parseBoolean(splitter[6]);
		String serverType = splitter[7];
		dedicatedServer.setAvailable(true);
		dedicatedServer.keepAlive(cpu, ram, disk, ramPercent, slots, slotsIncrease, serverType);
	}
	
}
