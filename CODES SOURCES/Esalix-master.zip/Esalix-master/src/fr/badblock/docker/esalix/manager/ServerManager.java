package fr.badblock.docker.esalix.manager;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.cloudflare.api.constants.RecordType;
import com.cloudflare.api.requests.dns.DNSAddRecord;

import fr.badblock.docker.esalix.Esalix;
import fr.badblock.docker.esalix.database.BadblockDatabase;
import fr.badblock.docker.esalix.database.Request;
import fr.badblock.docker.esalix.database.Request.RequestType;
import fr.badblock.docker.esalix.entities.DedicatedServerEntity;
import fr.badblock.docker.esalix.logs.Log;
import fr.badblock.docker.esalix.logs.Log.LogType;
import fr.badblock.docker.esalix.scaleway.model.IP;
import fr.badblock.docker.esalix.scaleway.model.Server;
import fr.badblock.docker.esalix.scaleway.model.ServerAction;
import fr.badblock.docker.esalix.scaleway.model.ServerTask;
import fr.badblock.docker.esalix.scaleway.model.ServerTaskStatus;
import fr.badblock.docker.esalix.scaleway.model.ServerType;
import fr.badblock.docker.esalix.utils.CRC16;
import fr.badblock.docker.esalix.utils.Callback;
import fr.badblock.docker.esalix.utils.DatabaseUtils;
import fr.toenga.common.tech.rabbitmq.packet.RabbitPacket;
import fr.toenga.common.tech.rabbitmq.packet.RabbitPacketEncoder;
import fr.toenga.common.tech.rabbitmq.packet.RabbitPacketMessage;
import fr.toenga.common.tech.rabbitmq.packet.RabbitPacketType;

public class ServerManager
{

	public static long				lastTry		= 0;
	public static long				freezer		= 0;
	public static long				sLast		= 0;
	public static Map<String, Long>	spaces		= new HashMap<>();
	public static Map<String, Long>	servers		= new HashMap<>();
	
	private static List<String> 	sTypeList	= Arrays.asList(Esalix.getInstance().getConfig().getServerTypes());
	private static Iterator<String> iterator 	= sTypeList.iterator();
	private static String			serverType;
	private static long				stockReset	= System.currentTimeMillis() + 3600_000L;

	public static void generateServer(Esalix esalix)
	{
		DatabaseUtils.getCount("FROM esalix WHERE startTime > '" + System.currentTimeMillis() + "' AND state = 'LOADING'", new Callback<Integer>()
		{
			@Override
			public void done(Integer result, Throwable error)
			{
				long timestamp = System.currentTimeMillis();
				if (lastTry > timestamp)
				{
					Esalix.getInstance().sendDebugMessage("ACTION : TRYING TO GENERATE A SERVER BUT LIMITED.");
					return;
				}
				lastTry = timestamp + 1200_000L;
				freezer = timestamp + 600_000L;
				if (result.intValue() == 0)
				{
					try {
						Esalix.getInstance().sendDiscordMessage("[1/6] Generating a dedicated server...");
						Esalix.getInstance().sendDebugMessage("[1/6] C--");
						// Create dedicated server
						String uuid = UUID.randomUUID().toString().split("-")[0];
						Esalix.getInstance().sendDebugMessage("[1/6] AAA");
						synchronized (Esalix.getInstance().getThread())
						{
							sLast = timestamp + 30_000L;
						}
						IP ip = esalix.getScaleway().createIP(esalix.getConfig().getOrganizationId());
						long t = timestamp + 30_000L;
						spaces.put(ip.getId(), t);
						DNSAddRecord dns = new DNSAddRecord(esalix.getCloudflare(), "badblock-network.fr", RecordType.IPV4Address, CRC16.encode(ip.getIpAddress()) + ".sw", ip.getIpAddress());
						try {
							dns.executeBasic();
							dns.close();
							Thread.sleep(15_000);
						} catch (Exception e) {
							e.printStackTrace();
						}
						synchronized (Esalix.getInstance().getThread())
						{
							sLast = timestamp + 30_000L;
						}
						if (!iterator.hasNext())
						{
							iterator = sTypeList.iterator();
						}
						if (serverType == null || stockReset < timestamp)
						{
							serverType = iterator.next();
							stockReset = System.currentTimeMillis() + 3600_000L;
						}
						ServerType parsedServerType = ServerType.get(serverType);
						String image = esalix.getConfig().getImages().get(parsedServerType.getArchType());
						Server server = esalix.getScaleway().createServer(uuid, image, esalix.getConfig().getOrganizationId(), parsedServerType, false, new String[] { "docker" });
						synchronized (Esalix.getInstance().getThread())
						{
							t = System.currentTimeMillis() + 30_000L;
							servers.put(server.getId(), t);
							sLast = 0;
						}
						Esalix.getInstance().sendDiscordMessage("[1/6] Type: " + parsedServerType.name());
						Esalix.getInstance().sendDebugMessage("[1/6] E: " + ip.getId());
						Esalix.getInstance().sendDebugMessage("[1/6] E1: " + esalix.getConfig().getOrganizationId());
						Esalix.getInstance().sendDebugMessage("[1/6] E2: " + ip.getIpAddress());
						Esalix.getInstance().sendDebugMessage("[1/6] E3: " + server.getId());
						esalix.getScaleway().attachIP(ip.getId(), esalix.getConfig().getOrganizationId(), ip.getIpAddress(), server.getId(), CRC16.encode(ip.getIpAddress()) + ".sw.badblock-network.fr");
						Esalix.getInstance().sendDebugMessage("[1/6] BBB");
						Esalix.getInstance().sendDebugMessage("[1/6] 1: " + server);
						Esalix.getInstance().sendDebugMessage("[1/6] 2: " + server.getId());
						Esalix.getInstance().sendDebugMessage("[1/6] 3: " + ip);
						Esalix.getInstance().sendDebugMessage("[1/6] 4: " + ip.getIpAddress());
						Esalix.getInstance().sendDebugMessage("[1/6] 5: " + server.getHostname());
						Esalix.getInstance().sendDebugMessage("[1/6] INSERT INTO esalix(serverId, serverIp, serverHost, state, startTime) VALUES('" + server.getId() + "', '" + 
								ip.getIpAddress() + "', '" + 
								ip.getIpAddressReverse() + "', 'LOADING', '" + (System.currentTimeMillis() + 300_000) + "')");
						// Insert into database
						BadblockDatabase.getInstance().addSyncRequest(
								new Request(
										"INSERT INTO esalix(serverId, serverIp, serverHost, state, startTime) VALUES('" + server.getId() + "', '" + 
												ip.getIpAddress() + "', '" + 
												server.getHostname() + "', 'LOADING', '" + (System.currentTimeMillis() + 300_000) + "')", 
												RequestType.SETTER));
						Esalix.getInstance().sendDebugMessage("[1/6] CCC");
						// Check IPs
						//HiddenFees.getInstance().removeIPs(esalix);
						Esalix.getInstance().sendDebugMessage("[1/6] DDD");
						freezer = 0;
						Esalix.getInstance().sendDiscordMessage("[2/6] Starting the dedicated server... (" + ip.getIpAddress() + ")");
						boolean isStarted = false;
						try {
							ServerTask powerOnServerTask = esalix.getScaleway().executeServerAction(server.getId(), ServerAction.POWERON);
							while (!isStarted)
							{
								try {
									ServerTask taskStatus = esalix.getScaleway().getTaskStatus(powerOnServerTask.getId());
									Esalix.getInstance().sendDiscordMessage("[3/6] Server task with id '" + taskStatus.getId() + "' is in current state '" + taskStatus.getStatus() +
											"' (progress '" + taskStatus.getProgress() + "')");
									if (taskStatus.getStatus() == ServerTaskStatus.success)
									{
										isStarted = true;
									}
									else if (taskStatus.getStatus() == ServerTaskStatus.failure)
									{
										Esalix.getInstance().sendDiscordMessage("[3/6] Failed to start " + taskStatus.getId() + ". Are " + serverType + " out of stock?");
										if (!iterator.hasNext())
										{
											iterator = sTypeList.iterator();
										}
										serverType = iterator.next();
										Esalix.getInstance().sendDiscordMessage("[3/6] We will now use " + serverType + ".");
										lastTry = System.currentTimeMillis() + 5_000;
										freezer = System.currentTimeMillis() + 5_000;
										return;
									}
									else
									{
										try
										{ 
											Thread.sleep(30000);
										}
										catch (InterruptedException ex)
										{
											Esalix.getInstance().sendDiscordMessage("> Error occurred : " + ex.getMessage());
										}
									}
								} catch (Exception e) {
									Esalix.getInstance().sendDiscordMessage("> Error occurred : " + e.getMessage());
									e.printStackTrace();
									Thread.sleep(10_000);
								}
							}
						} catch (Exception e) {
							Esalix.getInstance().sendDiscordMessage("> Error occurred : " + e.getMessage());
							e.printStackTrace();
							Thread.sleep(400_000);
						}
						BadblockDatabase.getInstance().addSyncRequest(
								new Request("UPDATE esalix SET state = 'RUNNING' WHERE serverId = '" + server.getId() + "'", RequestType.SETTER));
						Esalix.getInstance().sendDiscordMessage("[4/6] Started dedicated server! (" + ip.getIpAddress() + ")");
						Esalix.getInstance().sendDiscordMessage("[5/6] Installing Docker... (" + ip.getIpAddress() + ")");
						//new Installer(ip.getIpAddress());
						Esalix.getInstance().sendDiscordMessage("[6/6] Installed Docker!");
						Esalix.getInstance().sendDiscordMessage("Created server '" + ip.getIpAddress() + "'!");
					} catch (Exception err) {
						err.printStackTrace();
					}
				}
				else
				{
					Esalix.getInstance().sendDebugMessage("Waiting for creating server...");
				}
			}
		});
	}

	public static void deleteServer(DedicatedServerEntity finalUnusedServer)
	{
		RabbitPacketMessage rabbitMessage = new RabbitPacketMessage(60000, "deleter");
		RabbitPacket rabbitPacket = new RabbitPacket(rabbitMessage, "networkdocker.docker.stopcreate." + finalUnusedServer.getIp(),
				true, RabbitPacketEncoder.UTF8, RabbitPacketType.PUBLISHER);
		Esalix.getInstance().getRabbitService().sendPacket(rabbitPacket);
		BadblockDatabase.getInstance().addSyncRequest(
				new Request("UPDATE esalix SET state = 'STOPPING' WHERE serverIp = '" + finalUnusedServer.getIp() + "'", RequestType.SETTER));
		Log.log("Sended deleting server signal to '" + finalUnusedServer.getIp() + "' !", LogType.SUCCESS);
		Esalix.getInstance().sendDiscordMessage(finalUnusedServer.getIp() + " will not accept further instances.");
	}

}
