package fr.badblock.docker.esalix.tasks;

import java.sql.ResultSet;
import java.util.Iterator;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.stream.Collectors;

import fr.badblock.docker.esalix.Esalix;
import fr.badblock.docker.esalix.database.BadblockDatabase;
import fr.badblock.docker.esalix.database.Request;
import fr.badblock.docker.esalix.database.Request.RequestType;
import fr.badblock.docker.esalix.entities.DedicatedServerEntity;
import fr.badblock.docker.esalix.logs.Log;
import fr.badblock.docker.esalix.logs.Log.LogType;
import fr.badblock.docker.esalix.manager.ServerManager;
import fr.badblock.docker.esalix.scaleway.exception.ScalewayApiException;
import fr.badblock.docker.esalix.scaleway.model.Server;
import fr.badblock.docker.esalix.scaleway.model.ServerAction;
import fr.badblock.docker.esalix.scaleway.model.ServerTask;
import fr.badblock.docker.esalix.scaleway.model.ServerTaskStatus;
import fr.badblock.docker.esalix.scaleway.model.State;
import fr.badblock.docker.esalix.utils.HiddenFees;

public class DeleterTask extends TimerTask
{

	public DeleterTask()
	{
		new Timer().schedule(this, 10000, 10000);
		Esalix.getInstance().sendDebugMessage("DeleterTask loaded.");
	}

	@Override
	public void run() {
		Esalix esalix = Esalix.getInstance();
		BadblockDatabase.getInstance().addSyncRequest(new Request("SELECT * FROM esalix", RequestType.GETTER)
		{
			@Override
			public void done(ResultSet resultSet)
			{
				try
				{
					synchronized (Esalix.getInstance().getThread())
					{
						if (ServerManager.sLast < System.currentTimeMillis())
						{
							esalix.getScaleway().getAllServers(1, 100).getServers().stream().filter(server -> server.getTags().contains("docker") && server.getState().equals(State.stopped)).forEach(server ->
							{
								if (ServerManager.servers.containsKey(server.getId()))
								{
									if (ServerManager.servers.get(server.getId()).longValue() > System.currentTimeMillis())
									{
										return;
									}
								}
								try {
									esalix.getScaleway().deleteServer(server.getId());
								} catch (ScalewayApiException e) {
									e.printStackTrace();
								}
								Log.log("Removed unused server " + server.getId() + ".", LogType.SUCCESS);
							});
							esalix.getScaleway().getAllIPs(1, 100).getIPs().stream().filter(ip -> ip.getServer() == null).forEach(ip ->
							{
								if (ServerManager.spaces.containsKey(ip.getId()))
								{
									if (ServerManager.spaces.get(ip.getId()).longValue() > System.currentTimeMillis())
									{
										return;
									}
								}
								try {
									esalix.getScaleway().deleteIP(ip.getId());
								} catch (ScalewayApiException e) {
									e.printStackTrace();
								}
								Log.log("Removed unused IP " + ip.getIpAddress() + ".", LogType.SUCCESS);
							});
						}
					}
					esalix.getScaleway().getAllVolumes(1, 100).getVolumes().stream().filter(volume -> volume.getServer() == null).forEach(volume ->
					{
						try {
							esalix.getScaleway().deleteVolume(volume.getId());
						} catch (ScalewayApiException e) {
							e.printStackTrace();
						}
						Log.log("Removed unused volume " + volume.getId() + ".", LogType.SUCCESS);
					});
					List<Server> servers = esalix.getScaleway().getAllServers(1, 100).getServers();
					while (resultSet.next())
					{
						String serverId = resultSet.getString("serverId");
						String state = resultSet.getString("state");
						Iterator<Server> iterator = servers.stream().filter(s -> s.getId().equals(serverId)).collect(Collectors.toList()).iterator();
						if (!iterator.hasNext())
						{
							BadblockDatabase.getInstance().addRequest(new Request("DELETE FROM esalix WHERE serverId = '" + serverId + "'", RequestType.SETTER));
							Log.log("Removed server " + serverId + ". (already destroyed?)", LogType.SUCCESS);
							continue;
						}
						Server server = iterator.next();
						if (server.getPublicIp() == null)
						{
							continue;
						}
						else if (state.equals("STOPPING"))
						{
							DedicatedServerEntity entity = DedicatedServerEntity.getServers().get(server.getPublicIp().getIpAddress());
							if (entity == null || !entity.isOnline())
							{
								try {
									ServerTask powerOnServerTask = esalix.getScaleway().executeServerAction(server.getId(), ServerAction.TERMINATE);
									boolean isDown = false;
									while (!isDown)
									{
										try {
											ServerTask taskStatus = esalix.getScaleway().getTaskStatus(powerOnServerTask.getId());
											Esalix.getInstance().sendDiscordMessage("Stopping " + server.getId() + "... (Progress: " + taskStatus.getProgress() + ")");
											try
											{ 
												Thread.sleep(10000);
											}
											catch (InterruptedException ex)
											{
											}
											if (taskStatus.getStatus() == ServerTaskStatus.success)
											{
												isDown = true;
											}
										} catch (Exception e) {
											e.printStackTrace();
											Thread.sleep(10_000);
										}
									}
								} catch (Exception e) {
									e.printStackTrace();
									Thread.sleep(60_000);
								}
								esalix.getScaleway().deleteServer(serverId);
								HiddenFees.getInstance().removeIP(esalix, server.getPublicIp().getIpAddress());
								HiddenFees.getInstance().removeStorage(esalix, server);
								BadblockDatabase.getInstance().addRequest(new Request("DELETE FROM esalix WHERE serverId = '" + serverId + "'", RequestType.SETTER));
								Log.log("Removed & destroyed server " + serverId + ".", LogType.SUCCESS);
							}
						}
					}
				}
				catch(Exception error)
				{
					error.printStackTrace();
				}
			}
		});
	}

}